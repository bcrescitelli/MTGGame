import SwiftUI
import UIKit

/// The Town Hotline, dropping down from the phone in the top bar. Ringing: pick up. On the
/// line: the caller's words type out with their babbling voice. Otherwise: today's task on a
/// notepad, or a quiet line.
struct HotlineView: View {
    @ObservedObject var state: GameState
    let dismiss: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Town Hotline")
                    .font(.display(19))
                    .foregroundStyle(Color.ink)
                Spacer()
                Button(action: dismiss) {
                    Image(systemName: "xmark")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.inkSoft)
                        .frame(width: 26, height: 26)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Close the hotline")
            }
            if state.ringingCall != nil || state.ringingFeature || state.ringingNews {
                ringing
            } else if let news = state.openNews {
                NewsCallCard(state: state, news: news)
                    .id(news.id)
            } else if state.featureCallOpen {
                PlanningCallCard(state: state)
            } else if let call = state.openCall {
                CallCard(state: state, call: call)
                    .id(call.id)
            } else if let task = state.openLetters.first {
                notepad(task)
            } else {
                Text("The line is quiet. Someone will call before long.")
                    .font(.bodySerif(13, italic: true))
                    .foregroundStyle(Color.inkSoft)
            }
        }
        .padding(14)
        .frame(width: 440)
        .background(PaperPanel(cornerRadius: 12))
    }

    private var ringing: some View {
        HStack(spacing: 14) {
            Image(systemName: "phone.and.waveform.fill")
                .font(.system(size: 26, weight: .bold))
                .foregroundStyle(Color.stampRed)
            VStack(alignment: .leading, spacing: 2) {
                Text("Someone's calling…")
                    .font(.display(17))
                Text("Pick up before it stops ringing.")
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
            }
            Spacer()
            Button {
                AudioManager.shared.stopRinging()
                AudioManager.shared.play(.tick)
                if state.ringingFeature { state.answerFeatureCall() }
                else if state.ringingNews { state.answerNews() }
                else { state.answerPhone() }
            } label: {
                InkButtonLabel(text: "PICK UP", symbol: "phone.fill", height: 36)
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(Color.ink)
    }

    private func notepad(_ task: Letter) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("On the notepad")
                .font(.bodySerif(12, italic: true))
                .foregroundStyle(Color.inkSoft)
            Text("\(task.sender) asked:")
                .font(.display(15))
            AskBox(state: state, letter: task)
        }
        .foregroundStyle(Color.ink)
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            ZStack(alignment: .leading) {
                Rectangle().fill(Color(uiColor: UIColor(hex: 0xFBF4DA)))
                VStack(spacing: 15) { ForEach(0..<8, id: \.self) { _ in Rectangle().fill(Color(uiColor: UIColor(hex: 0x8FB4D9)).opacity(0.35)).frame(height: 0.7) } }
                    .padding(.top, 20)
                Rectangle().fill(Color.stampRed.opacity(0.5)).frame(width: 1).padding(.leading, 6)
            }
            .clipped()
        )
    }
}

/// A call being read: the words type out, a syllable of muffled voice every few letters.
private struct CallCard: View {
    @ObservedObject var state: GameState
    let call: Letter
    @State private var shown = 0

    private var pitch: Double {
        // Every caller has their own voice.
        let seed = call.sender.unicodeScalars.reduce(0) { $0 &+ Int($1.value) }
        return 0.8 + Double(seed % 50) / 100
    }

    var body: some View {
        let done = shown >= call.body.count
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text(call.sender)
                    .font(.display(16))
                Text(call.role)
                    .font(.bodySerif(11, italic: true))
                    .foregroundStyle(Color.inkSoft)
            }
            Text(String(call.body.prefix(shown)))
                .font(.typewriter(12))
                .lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .topLeading)
            if done {
                AskBox(state: state, letter: call)
                Button {
                    AudioManager.shared.play(.tick)
                    state.hangUp()
                } label: {
                    InkButtonLabel(text: "WRITE IT DOWN", symbol: "pencil", height: 34)
                }
                .buttonStyle(.plain)
            } else {
                Button("Skip ahead") { shown = call.body.count }
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .buttonStyle(.plain)
            }
        }
        .foregroundStyle(Color.ink)
        .padding(12)
        .background(
            ZStack {
                Rectangle().fill(Color.card)
                PaperGrain(seed: 12, strength: 1.4)
                Rectangle().stroke(Color.ink.opacity(0.3), lineWidth: 1)
            }
        )
        .task(id: call.id) {
            let characters = Array(call.body)
            shown = 0
            while shown < characters.count {
                try? await Task.sleep(for: .milliseconds(32))
                guard !Task.isCancelled, shown < characters.count else { return }
                shown += 1
                if shown % 4 == 0, characters[shown - 1] != " " {
                    AudioManager.shared.babble(pitch: pitch)
                }
            }
        }
    }
}


/// The City Planning Office calling to say decorating is open, with a "Show me" button.
private struct PlanningCallCard: View {
    @ObservedObject var state: GameState
    @State private var shown = 0

    private var message: String {
        "Mayor! Hazel Moss here, from the City Planning Office. The town's buzzing, so we've cleared the paperwork: "
            + "you can now decorate \(state.townName). Trees, benches, lamps, flowers, and post boxes, on any square "
            + "or right along the streets. Shall I show you where?"
    }

    var body: some View {
        let done = shown >= message.count
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text("Hazel Moss")
                    .font(.display(16))
                Text("Head of City Planning")
                    .font(.bodySerif(11, italic: true))
                    .foregroundStyle(Color.inkSoft)
            }
            Text(String(message.prefix(shown)))
                .font(.typewriter(12))
                .lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .topLeading)
            if done {
                Button {
                    AudioManager.shared.play(.tick)
                    state.showMeDecor()
                } label: {
                    InkButtonLabel(text: "SHOW ME", symbol: "arrow.down.left", height: 34)
                }
                .buttonStyle(.plain)
            } else {
                Button("Skip ahead") { shown = message.count }
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .buttonStyle(.plain)
            }
        }
        .foregroundStyle(Color.ink)
        .padding(12)
        .background(ZStack { Rectangle().fill(Color.card); PaperGrain(seed: 14, strength: 1.4) })
        .task {
            let characters = Array(message)
            shown = 0
            while shown < characters.count {
                try? await Task.sleep(for: .milliseconds(30))
                guard !Task.isCancelled, shown < characters.count else { return }
                shown += 1
                if shown % 4 == 0, characters[shown - 1] != " " {
                    AudioManager.shared.babble(pitch: 0.9)
                }
            }
        }
    }
}


/// A phoned-in notice: the words type out in the caller's voice, then "Got it".
private struct NewsCallCard: View {
    @ObservedObject var state: GameState
    let news: NewsCall
    @State private var shown = 0

    var body: some View {
        let done = shown >= news.body.count
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .firstTextBaseline) {
                Text(news.sender)
                    .font(.display(16))
                Text(news.role)
                    .font(.bodySerif(11, italic: true))
                    .foregroundStyle(Color.inkSoft)
            }
            Text(String(news.body.prefix(shown)))
                .font(.typewriter(12))
                .lineSpacing(3)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .topLeading)
            if done {
                Button {
                    AudioManager.shared.play(.tick)
                    state.hangUpNews()
                } label: {
                    InkButtonLabel(text: "GOT IT", height: 32)
                }
                .buttonStyle(.plain)
            } else {
                Button("Skip ahead") { shown = news.body.count }
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .buttonStyle(.plain)
            }
        }
        .foregroundStyle(Color.ink)
        .padding(12)
        .background(ZStack { Rectangle().fill(Color.card); PaperGrain(seed: 16, strength: 1.4) })
        .task(id: news.id) {
            let characters = Array(news.body)
            shown = 0
            while shown < characters.count {
                try? await Task.sleep(for: .milliseconds(30))
                guard !Task.isCancelled, shown < characters.count else { return }
                shown += 1
                if shown % 4 == 0, characters[shown - 1] != " " {
                    AudioManager.shared.babble(pitch: news.pitch)
                }
            }
        }
    }
}


/// The request in plain words: what to do, how it's going, and what it's worth.
private struct AskBox: View {
    @ObservedObject var state: GameState
    let letter: Letter

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("THE ASK")
                .font(.mapBold(9.5))
                .kerning(1.4)
                .foregroundStyle(Color.stampRed)
            Text(state.askSummary(letter))
                .font(.display(15))
                .fixedSize(horizontal: false, vertical: true)
            Text(state.letterProgressText(letter))
                .font(.bodySerif(12, italic: true))
                .foregroundStyle(Color.inkSoft)
                .fixedSize(horizontal: false, vertical: true)
            Text("By the end of day \(letter.dueDay). Reward: $\(letter.reward) and a Golden Ticket.")
                .font(.bodySerif(11.5, italic: true))
                .foregroundStyle(Color.inkSoft)
        }
        .foregroundStyle(Color.ink)
        .padding(10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.stampRed.opacity(0.07)))
    }
}
