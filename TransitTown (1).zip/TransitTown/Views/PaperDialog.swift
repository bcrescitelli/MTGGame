import SwiftUI

/// The game's own pop-up: a taped paper card with the game's type and ink buttons, instead of
/// the system alert.
struct PaperDialogCard: View {
    let title: String
    let message: String
    var extra: AnyView? = nil
    let confirm: String
    var confirmColor: Color = Color.ink
    var confirmEnabled = true
    var cancel: String? = "Not yet"
    let onConfirm: () -> Void
    var onCancel: () -> Void = {}

    var body: some View {
        ZStack {
            Color.ink.opacity(0.4).ignoresSafeArea()
                .onTapGesture { if cancel != nil { onCancel() } }
            VStack(alignment: .leading, spacing: 12) {
                Text(title)
                    .font(.display(22))
                    .fixedSize(horizontal: false, vertical: true)
                Text(message)
                    .font(.bodySerif(14))
                    .foregroundStyle(Color.inkSoft)
                    .fixedSize(horizontal: false, vertical: true)
                if let extra { extra }
                HStack(spacing: 10) {
                    if let cancel {
                        Button {
                            AudioManager.shared.play(.tick)
                            onCancel()
                        } label: {
                            InkButtonLabel(text: cancel.uppercased(), filled: false, height: 38)
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.plain)
                    }
                    Button {
                        guard confirmEnabled else { return }
                        onConfirm()
                    } label: {
                        InkButtonLabel(text: confirm.uppercased(), height: 38, color: confirmColor)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.plain)
                    .opacity(confirmEnabled ? 1 : 0.45)
                }
                .padding(.top, 4)
            }
            .foregroundStyle(Color.ink)
            .padding(20)
            .frame(width: 400)
            .background(PaperPanel(cornerRadius: 14))
            .overlay(alignment: .top) { PaperTape() }
        }
        .transition(.opacity)
    }
}

/// A paper dialog shown over a view while `isPresented` is true.
private struct PaperAlert: ViewModifier {
    @Binding var isPresented: Bool
    let title: String
    let message: String
    let confirm: String
    var confirmColor: Color
    var cancel: String?
    let action: () -> Void

    func body(content: Content) -> some View {
        content.overlay {
            if isPresented {
                PaperDialogCard(title: title, message: message, confirm: confirm, confirmColor: confirmColor, cancel: cancel,
                                onConfirm: { isPresented = false; action() },
                                onCancel: { isPresented = false })
            }
        }
    }
}

extension View {
    func paperAlert(_ title: String, isPresented: Binding<Bool>, message: String, confirm: String,
                    confirmColor: Color = Color.ink, cancel: String? = "Cancel", action: @escaping () -> Void = {}) -> some View {
        modifier(PaperAlert(isPresented: isPresented, title: title, message: message, confirm: confirm,
                            confirmColor: confirmColor, cancel: cancel, action: action))
    }
}
