import SwiftUI
import UIKit

/// The bell's list: worn and broken track, crowded platforms, crews at work, and today's
/// events. Each row can take you there, and track problems can be repaired from here.
struct AttentionPanelView: View {
    @ObservedObject var state: GameState

    var body: some View {
        let issues = state.attentionIssues()
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Needs attention")
                    .font(.display(19))
                    .foregroundStyle(Color.ink)
                Spacer()
                Button {
                    state.isAttentionOpen = false
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.inkSoft)
                        .frame(width: 26, height: 26)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Close")
            }

            if issues.isEmpty {
                Text("All quiet. The trains are running and nothing's in the way.")
                    .font(.bodySerif(13, italic: true))
                    .foregroundStyle(Color.inkSoft)
            } else {
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(issues) { issue in
                            row(issue)
                        }
                    }
                }
                .frame(maxHeight: 230)
                Text("Closures reopen on their own later. To reopen one now, send a repair crew.")
                    .font(.bodySerif(11, italic: true))
                    .foregroundStyle(Color.inkSoft)
            }
        }
        .padding(14)
        .frame(width: 380)
        .background(PaperPanel(cornerRadius: 16))
    }

    private func row(_ issue: AttentionIssue) -> some View {
        let highlighted = state.attentionFocusID == issue.id
        return HStack(alignment: .top, spacing: 10) {
            Image(systemName: issue.symbol)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(issue.kind == .disruption ? Color.card : Color.ink)
                .frame(width: 26, height: 26)
                .background(Circle().fill(color(for: issue.kind)))
                .overlay(Circle().stroke(Color.ink, lineWidth: 1.5))
            VStack(alignment: .leading, spacing: 3) {
                Text(issue.title)
                    .font(.display(15))
                    .foregroundStyle(Color.ink)
                Text(issue.detail)
                    .font(.bodySerif(12))
                    .foregroundStyle(Color.ink)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 8) {
                    Button {
                        state.focus(on: issue)
                        state.isAttentionOpen = false
                    } label: {
                        InkButtonLabel(text: "SHOW ME", filled: false, height: 26)
                    }
                    .buttonStyle(.plain)
                    if issue.kind == .trip, let tripID = Int(issue.id.replacingOccurrences(of: "trip-", with: "")),
                       let cost = state.expressCost(for: tripID) {
                        Button {
                            AudioManager.shared.play(.whoosh)
                            state.sendExpress(tripID: tripID)
                        } label: {
                            InkButtonLabel(text: "SEND AN EXPRESS TRAIN FOR $\(cost)", symbol: "tram.fill", height: 26)
                        }
                        .buttonStyle(.plain)
                        .disabled(!state.canAfford(cost))
                        .opacity(state.canAfford(cost) ? 1 : 0.5)
                    }
                    if let event = state.crewableEvent(for: issue), let cost = state.crewCost(event) {
                        Button {
                            AudioManager.shared.play(.stamp)
                            state.sendCrew(event.id, withTicket: false)
                        } label: {
                            InkButtonLabel(text: "SEND A CREW FOR $\(cost)", symbol: "hammer.fill", height: 26)
                        }
                        .buttonStyle(.plain)
                        .disabled(!state.canAfford(cost))
                        .opacity(state.canAfford(cost) ? 1 : 0.5)
                        Button {
                            AudioManager.shared.play(.chunk)
                            state.sendCrew(event.id, withTicket: true)
                        } label: {
                            Image(systemName: "ticket.fill")
                                .font(.system(size: 12, weight: .bold))
                                .foregroundStyle(Color.gold)
                                .frame(width: 30, height: 26)
                                .background(RoundedRectangle(cornerRadius: 8).fill(Color.gold.opacity(0.16)))
                        }
                        .buttonStyle(.plain)
                        .disabled(state.tickets < 1)
                        .opacity(state.tickets < 1 ? 0.5 : 1)
                        .accessibilityLabel("Send a crew for one Golden Ticket")
                    }
                }
            }
        }
        .padding(8)
        .background(RoundedRectangle(cornerRadius: 10).fill(highlighted ? Color.gold.opacity(0.18) : Color.clear))
    }

    private func color(for kind: AttentionIssue.Kind) -> Color {
        switch kind {
        case .disruption: return .bad
        case .crowded, .upcoming: return Color(uiColor: Palette.warning)
        case .festival: return .card
        case .trip: return .gold
        }
    }
}
