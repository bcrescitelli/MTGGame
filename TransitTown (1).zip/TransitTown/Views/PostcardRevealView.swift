import SwiftUI
import UIKit

/// The grand-opening reveal: a postcard arrives showing who moved in. Time holds until the
/// mayor pins it to the album.
struct PostcardRevealView: View {
    @ObservedObject var state: GameState
    let landmark: Landmark
    @State private var arrived = false

    private var info: LandmarkInfo { landmark.kind.info }
    private var tint: Color { Color(uiColor: info.category.color) }

    var body: some View {
        ZStack {
            Color.ink.opacity(0.5).ignoresSafeArea()
            HStack(spacing: 0) {
                picture
                Rectangle().fill(Color.ink.opacity(0.18)).frame(width: 1).padding(.vertical, 18)
                message
            }
            .frame(width: 520, height: 280)
            .background(
                ZStack {
                    RoundedRectangle(cornerRadius: 6).fill(Color.black.opacity(0.2)).offset(x: 3, y: 7).blur(radius: 5)
                    RoundedRectangle(cornerRadius: 6).fill(Color(uiColor: UIColor(hex: 0xDCCDB2))).offset(x: 1.5, y: 3)
                    PrintedPaper(color: Color(uiColor: UIColor(hex: 0xFBF4E4)), seed: UInt64(landmark.id) &+ 5)
                        .clipShape(RoundedRectangle(cornerRadius: 6))
                }
            )
            .rotationEffect(.degrees(arrived ? -1.5 : 10))
            .scaleEffect(arrived ? 1 : 0.7)
            .offset(y: arrived ? 0 : 160)
            .opacity(arrived ? 1 : 0)
        }
        .onAppear {
            AudioManager.shared.play(.whoosh)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { AudioManager.shared.play(.sparkle) }
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            withAnimation(.spring(response: 0.55, dampingFraction: 0.78)) { arrived = true }
        }
    }

    /// The picture side: the new shop on a wash of its category's color.
    private var picture: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 3).fill(tint.opacity(0.18))
            if let art = UIImage(named: landmark.artName) {
                Image(uiImage: art)
                    .resizable()
                    .scaledToFit()
                    .padding(8)
            }
        }
        .padding(14)
        .frame(width: 250)
    }

    /// The message side: greeting, who moved in, a postage stamp and postmark, and the button.
    private var message: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .top) {
                SmallCapsHeading(text: "Greetings from \(state.townName)", size: 10.5, color: .inkSoft)
                Spacer()
                postage
            }
            Text("The \(info.name) has moved in!")
                .font(.display(21))
                .foregroundStyle(Color.ink)
                .fixedSize(horizontal: false, vertical: true)
            if let keeper = landmark.shopkeeper {
                Text("Opened by \(keeper)")
                    .font(.bodySerif(13, italic: true))
                    .foregroundStyle(Color.ink)
            }
            Text(info.blurb)
                .font(.typewriter(11.5))
                .foregroundStyle(Color.ink)
                .lineSpacing(2)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 4)
            Button {
                state.pinPostcard()
            } label: {
                InkButtonLabel(text: "PIN IT TO THE ALBUM", symbol: "pin.fill", height: 36)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 16)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    /// A little perforated stamp in the category's color, with a round postmark over its corner.
    private var postage: some View {
        ZStack(alignment: .bottomLeading) {
            ZStack {
                PerforatedRect(hole: 2.4)
                    .fill(Color.white, style: FillStyle(eoFill: true))
                    .clipShape(Rectangle())
                Rectangle().fill(tint.opacity(0.85)).padding(5)
                Image(systemName: info.symbol)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(Color.white)
            }
            .frame(width: 44, height: 52)
            .shadow(color: .black.opacity(0.12), radius: 1, x: 1, y: 1)
            ZStack {
                Circle().stroke(Color.ink.opacity(0.45), lineWidth: 1.2)
                Circle().stroke(Color.ink.opacity(0.3), lineWidth: 0.8).padding(4)
                Text("DAY \(state.day)")
                    .font(.mapBold(7))
                    .foregroundStyle(Color.ink.opacity(0.55))
            }
            .frame(width: 38, height: 38)
            .rotationEffect(.degrees(-12))
            .offset(x: -22, y: 10)
        }
        .accessibilityHidden(true)
    }
}
