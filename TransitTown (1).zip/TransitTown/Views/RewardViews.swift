import SwiftUI

/// "While you were away": what the town earned, and any streak ticket.
struct AwayRecapView: View {
    @ObservedObject var state: GameState
    let recap: AwayRecap

    var body: some View {
        let hours = Int(recap.seconds) / 3600, minutes = (Int(recap.seconds) % 3600) / 60
        let away = hours > 0 ? "\(hours) hour\(hours == 1 ? "" : "s")\(minutes > 0 ? " \(minutes) min" : "")" : "\(max(1, minutes)) minutes"
        let capped = recap.seconds > GameState.awayCap
        return PaperDialogCard(
            title: "While you were away",
            message: "\(state.townName) kept busy for \(away). The trains earn about half a day's fares for every hour you're away\(capped ? ", up to eight hours" : "").",
            extra: AnyView(VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 8) {
                    Image(systemName: "dollarsign.circle.fill").foregroundStyle(Color.good)
                    Text("$\(recap.money) in fares").font(.display(20))
                }
                if recap.streakTicket {
                    HStack(spacing: 8) {
                        Image(systemName: "ticket.fill").foregroundStyle(Color.gold)
                        Text("Day \(recap.streakDay) in a row: a Golden Ticket").font(.display(16))
                    }
                } else if recap.streakDay > 1 {
                    Text("Day \(recap.streakDay) in a row. Come back tomorrow for more.")
                        .font(.bodySerif(12.5, italic: true)).foregroundStyle(Color.inkSoft)
                }
            }),
            confirm: "Collect", cancel: nil,
            onConfirm: {
                AudioManager.shared.play(.chunk)
                state.awayRecap = nil
            })
    }
}

/// A stand-in for a rewarded video until a real ad network is connected.
struct AdPlaceholderView: View {
    @ObservedObject var state: GameState
    @State private var remaining = 3

    var body: some View {
        ZStack {
            Color.ink.opacity(0.85).ignoresSafeArea()
            VStack(spacing: 14) {
                Image(systemName: "play.rectangle.fill").font(.system(size: 44)).foregroundStyle(Color.card)
                Text("A short ad would play here").font(.display(22)).foregroundStyle(Color.card)
                Text(remaining > 0 ? "Your Golden Ticket in \(remaining)…" : "Done!")
                    .font(.bodySerif(15, italic: true)).foregroundStyle(Color.card.opacity(0.85))
            }
        }
        .task {
            while remaining > 0 {
                try? await Task.sleep(for: .seconds(1))
                remaining -= 1
            }
            try? await Task.sleep(for: .milliseconds(400))
            AudioManager.shared.play(.sparkle)
            state.finishAd()
        }
    }
}

/// The ad button, wherever tickets are wanted.
struct WatchAdButton: View {
    @ObservedObject var state: GameState

    var body: some View {
        Button {
            AudioManager.shared.play(.tick)
            state.watchAdForTicket()
        } label: {
            InkButtonLabel(text: state.adsLeftToday > 0 ? "WATCH AN AD FOR A TICKET (\(state.adsLeftToday) LEFT TODAY)" : "NO MORE ADS TODAY",
                           filled: false, symbol: "play.rectangle.fill", height: 32)
        }
        .buttonStyle(.plain)
        .disabled(state.adsLeftToday == 0)
        .opacity(state.adsLeftToday == 0 ? 0.5 : 1)
    }
}

/// A big, short-lived warning for things the mayor must notice.
struct AlertNoteView: View {
    let text: String

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(Color.card)
            Text(text)
                .font(.display(16))
                .foregroundStyle(Color.card)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 12)
        .frame(maxWidth: 460)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.stampRed).shadow(color: .black.opacity(0.25), radius: 6, y: 3))
    }
}

/// A quiet new day: the number, briefly, with no pause.
struct DayBannerView: View {
    let day: Int

    var body: some View {
        Text("DAY \(day)")
            .font(.mapBold(15))
            .kerning(3)
            .foregroundStyle(Color.ink)
            .padding(.horizontal, 22)
            .padding(.vertical, 10)
            .background(PaperPanel(cornerRadius: 10))
            .overlay(alignment: .top) { PaperTape() }
    }
}


/// Each train on a line, with its optional speed and capacity upgrades.
struct TrainUpgradeView: View {
    @ObservedObject var state: GameState
    let lineID: Int

    var body: some View {
        let line = state.line(id: lineID)
        let count = state.trainCount(for: lineID)
        let extra = VStack(alignment: .leading, spacing: 8) {
            ForEach(0..<count, id: \.self) { slot in
                let up = state.upgrade(lineID: lineID, slot: slot)
                HStack(spacing: 8) {
                    Text("Train \(slot + 1)").font(.display(15)).frame(width: 64, alignment: .leading)
                    upgradeButton(title: "SPEED \(up.speed)/\(GameState.maxSpeedLevel)",
                                  cost: state.nextSpeedCost(lineID: lineID, slot: slot)) {
                        state.buySpeed(lineID: lineID, slot: slot)
                    }
                    upgradeButton(title: "CARS \(up.capacity)/\(GameState.maxCapacityLevel)",
                                  cost: state.nextCapacityCost(lineID: lineID, slot: slot)) {
                        state.buyCapacity(lineID: lineID, slot: slot)
                    }
                }
            }
        }
        return PaperDialogCard(title: "Upgrade the \(line?.name ?? "line")",
                               message: "Optional, one train at a time. Speed gets riders there sooner; an extra car carries three more.",
                               extra: AnyView(extra), confirm: "Done", cancel: nil,
                               onConfirm: { state.upgradingLineID = nil })
    }

    private func upgradeButton(title: String, cost: Int?, action: @escaping () -> Void) -> some View {
        Button {
            AudioManager.shared.play(.chunk)
            action()
        } label: {
            InkButtonLabel(text: cost.map { "\(title) $\($0)" } ?? "\(title) MAX", filled: cost != nil, height: 28)
        }
        .buttonStyle(.plain)
        .disabled(cost == nil || !state.canAfford(cost ?? 0))
        .opacity(cost == nil || !state.canAfford(cost ?? 0) ? 0.5 : 1)
    }
}
