import SwiftUI
import UIKit

/// The end-of-day paper, laid out like a real front page: nameplate between two ears,
/// a dated rule, headline and story in columns with an engraving, and a side column of
/// numbers, town talk, notices, and tomorrow's forecast. Ink on newsprint, one red for emphasis.
struct GazetteView: View {
    @ObservedObject var state: GameState
    let edition: GazetteEdition
    @State private var appeared = false

    var body: some View {
        ZStack {
            Color.ink.opacity(0.55).ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                sheet
                    .frame(maxWidth: 800)
                    .padding(.vertical, 16)
                    .frame(maxWidth: .infinity)
            }
            // The classic spinning-newspaper entrance.
            .rotationEffect(.degrees(appeared ? -0.6 : -380))
            .scaleEffect(appeared ? 1 : 0.2)
            .opacity(appeared ? 1 : 0)
        }
        .onAppear {
            withAnimation(.spring(response: 0.7, dampingFraction: 0.78)) { appeared = true }
        }
    }

    private var sheet: some View {
        VStack(spacing: 8) {
            masthead
            dateline
            headlineBlock
            HStack(alignment: .top, spacing: 12) {
                storyColumn.frame(maxWidth: .infinity, alignment: .topLeading)
                columnRule
                pictureColumn.frame(maxWidth: .infinity, alignment: .topLeading)
                columnRule
                numbersColumn.frame(width: 206, alignment: .topLeading)
            }
            .fixedSize(horizontal: false, vertical: true)
            DoubleRule()
            footer
        }
        .padding(.horizontal, 22)
        .padding(.vertical, 16)
        .background(
            ZStack {
                Rectangle().fill(Color.black.opacity(0.35)).offset(x: 4, y: 6)
                PrintedPaper(seed: UInt64(state.day) &* 7 &+ 3)
            }
        )
    }

    // MARK: Masthead

    private var masthead: some View {
        HStack(alignment: .center, spacing: 12) {
            ear {
                Text("TOMORROW")
                    .font(.mapBold(8.5)).kerning(1.4)
                Text(edition.forecastWeather?.name ?? "Fair")
                    .font(.display(15))
                Text("Forecast inside")
                    .font(.bodySerif(9.5, italic: true))
            }
            Spacer(minLength: 0)
            Text(edition.masthead)
                .font(.custom(AppFont.nameplate, fixedSize: 40))
                .foregroundStyle(Color.ink)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Spacer(minLength: 0)
            ear {
                Text("ONE PENNY")
                    .font(.mapBold(8.5)).kerning(1.4)
                Text("No. \(state.day)")
                    .font(.display(15))
                Text("Vol. \(state.termNumber)")
                    .font(.bodySerif(9.5, italic: true))
            }
        }
        .foregroundStyle(Color.ink)
    }

    private func ear<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        VStack(spacing: 2) { content() }
            .multilineTextAlignment(.center)
            .frame(width: 92)
            .padding(.vertical, 6)
            .overlay(Rectangle().stroke(Color.ink, lineWidth: 1))
            .overlay(Rectangle().stroke(Color.ink.opacity(0.35), lineWidth: 0.6).padding(2.5))
    }

    private var dateline: some View {
        VStack(spacing: 3) {
            DoubleRule()
            Text(edition.dateline.uppercased())
                .frame(maxWidth: .infinity)
            .font(.mapSemibold(9.5))
            .kerning(1.2)
            .foregroundStyle(Color.ink)
            Rectangle().fill(Color.ink).frame(height: 0.8)
        }
    }

    // MARK: Lead story

    private var headlineBlock: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(edition.kicker.uppercased())
                .font(.mapBold(10))
                .kerning(1.6)
                .foregroundStyle(Color.stampRed)
            Text(edition.headline)
                .font(.display(32))
                .foregroundStyle(Color.ink)
                .fixedSize(horizontal: false, vertical: true)
            Text(edition.subhead)
                .font(.bodySerif(14, italic: true))
                .foregroundStyle(Color.ink)
                .fixedSize(horizontal: false, vertical: true)
            Rectangle().fill(Color.ink.opacity(0.6)).frame(height: 0.8).padding(.top, 4)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    /// Column one: the story, then what people are saying.
    private var storyColumn: some View {
        VStack(alignment: .leading, spacing: 10) {
            raisedInitial(edition.story)
            sectionHead("TOWN TALK")
            VStack(alignment: .leading, spacing: 3) {
                (Text("“").font(.display(30)).foregroundColor(Color.stampRed)
                 + Text(edition.talkQuote).font(.bodySerif(13, italic: true)).foregroundColor(Color.ink)
                 + Text("”").font(.bodySerif(13, italic: true)).foregroundColor(Color.ink))
                    .lineSpacing(1.5)
                    .fixedSize(horizontal: false, vertical: true)
                Text("— \(edition.talkAttribution)")
                    .font(.mapSemibold(10))
                    .kerning(0.6)
                    .foregroundStyle(Color.ink)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
        }
    }

    /// Column two: today's engraving, then the short notices.
    private var pictureColumn: some View {
        VStack(alignment: .leading, spacing: 10) {
            engraving
            sectionHead("IN BRIEF")
            VStack(alignment: .leading, spacing: 6) {
                ForEach(Array(edition.briefs.enumerated()), id: \.offset) { item in
                    HStack(alignment: .firstTextBaseline, spacing: 6) {
                        Rectangle().fill(Color.ink).frame(width: 4, height: 4).offset(y: -2)
                        Text(item.element)
                            .font(.bodySerif(12))
                            .lineSpacing(1.5)
                            .foregroundStyle(Color.ink)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
        }
    }

    /// Column three: the day in figures, and what tomorrow brings.
    private var numbersColumn: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionHead("BY THE NUMBERS")
            VStack(spacing: 4) {
                ForEach(edition.figures) { figure in
                    HStack(alignment: .lastTextBaseline, spacing: 4) {
                        Text(figure.label)
                            .font(.bodySerif(12))
                        DottedLeader()
                        Text(figure.value)
                            .font(.mapBold(12.5))
                    }
                    .foregroundStyle(Color.ink)
                }
            }
            forecastBox
        }
    }

    /// The story split into two columns at a sentence break.
    private var storyHalves: (first: String, second: String) {
        let sentences = edition.story
            .components(separatedBy: ". ")
            .map { $0.hasSuffix(".") ? $0 : $0 + "." }
        let cut = max(1, (sentences.count + 1) / 2)
        let first = sentences.prefix(cut).joined(separator: " ")
        let second = sentences.dropFirst(cut).joined(separator: " ")
        return (first, second)
    }

    /// The first letter set large, the way old papers open a story.
    private func raisedInitial(_ text: String) -> some View {
        // Numbers don't make good initials ("2" + "7 riders"), so only letters are raised.
        let startsWithLetter = text.first?.isLetter ?? false
        let initial = startsWithLetter ? String(text.prefix(1)) : ""
        let rest = startsWithLetter ? String(text.dropFirst()) : text
        return (Text(initial).font(.display(40)).foregroundColor(Color.stampRed)
                + Text(rest).font(.bodySerif(13)).foregroundColor(Color.ink))
            .lineSpacing(1.5)
            .fixedSize(horizontal: false, vertical: true)
    }

    /// One of today's landmarks, engraved over a halftone screen.
    private var engraving: some View {
        let kind = featuredKind
        return VStack(alignment: .leading, spacing: 3) {
            ZStack {
                Halftone()
                if let kind, let art = UIImage(named: "line-\(kind.rawValue)") {
                    Image(uiImage: art)
                        .renderingMode(.template)
                        .resizable()
                        .scaledToFit()
                        .foregroundStyle(Color.ink)
                        .padding(10)
                        .background(Ellipse().fill(Color.newsprint).padding(18).blur(radius: 6))
                }
            }
            .frame(height: 104)
            .clipped()
            .overlay(Rectangle().stroke(Color.ink, lineWidth: 1))
            if let kind {
                Text("The \(kind.info.name), as it stood today.")
                    .font(.bodySerif(10, italic: true))
                    .foregroundStyle(Color.ink)
            }
        }
    }

    private var featuredKind: LandmarkKind? {
        let candidates = state.openLandmarks
            .filter { $0.kind.info.district == state.currentDistrict && $0.kind.info.category != .canal }
            .sorted { $0.id < $1.id }
        guard !candidates.isEmpty else { return state.currentDistrict.hub }
        return candidates[state.day % candidates.count].kind
    }

    private var columnRule: some View {
        Rectangle().fill(Color.ink.opacity(0.45)).frame(width: 0.8)
    }

    // MARK: Pieces

    private func sectionHead(_ text: String) -> some View {
        HStack(spacing: 6) {
            Rectangle().fill(Color.ink).frame(height: 0.8)
            Text(text)
                .font(.mapBold(9.5))
                .kerning(1.6)
                .foregroundStyle(Color.ink)
                .fixedSize()
            Rectangle().fill(Color.ink).frame(height: 0.8)
        }
    }

    private var forecastBox: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(edition.forecastTitle)
                .font(.mapBold(10.5))
                .kerning(1.2)
            Text(edition.forecastText)
                .font(.bodySerif(11.5, italic: true))
                .fixedSize(horizontal: false, vertical: true)
            ForEach(Array(edition.forecastEffects.enumerated()), id: \.offset) { item in
                HStack(alignment: .firstTextBaseline, spacing: 5) {
                    Text("☞").font(.bodySerif(12))
                    Text(item.element)
                        .font(.mapSemibold(11))
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .foregroundStyle(Color.ink)
        .padding(9)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Halftone(density: 0.5))
        .overlay(Rectangle().stroke(Color.ink, lineWidth: 1.2))
        .overlay(Rectangle().stroke(Color.ink.opacity(0.4), lineWidth: 0.6).padding(3))
    }

    // MARK: Footer

    private var footer: some View {
        HStack {
            Text("Printed at the \(state.townName) Press, est. 1908")
                .font(.bodySerif(11, italic: true))
                .foregroundStyle(Color.ink)
            Spacer()
            Button {
                state.finishGazette()
            } label: {
                InkButtonLabel(text: edition.isFinalDay ? "TO THE TERM REVIEW" : "TO THE COUNCIL CHAMBER",
                               symbol: "arrow.right", height: 40)
            }
            .buttonStyle(.plain)
        }
    }
}

/// A halftone screen: rows of ink dots that fade from top to bottom, like a printed photo.
private struct Halftone: View {
    var density: Double = 1

    var body: some View {
        Canvas { context, size in
            let step: CGFloat = 4.5
            var y: CGFloat = 0
            var row = 0
            while y < size.height + step {
                var x: CGFloat = row % 2 == 0 ? 0 : step / 2
                let fade = 1 - y / max(size.height, 1)
                while x < size.width + step {
                    let r = (0.35 + 1.05 * fade) * CGFloat(density)
                    context.fill(Path(ellipseIn: CGRect(x: x - r, y: y - r, width: r * 2, height: r * 2)),
                                 with: .color(Color.ink.opacity(0.22)))
                    x += step
                }
                y += step * 0.87
                row += 1
            }
        }
        .allowsHitTesting(false)
    }
}

/// The dotted line between a label and its value in a newspaper table.
private struct DottedLeader: View {
    var body: some View {
        GeometryReader { proxy in
            Path { path in
                path.move(to: CGPoint(x: 0, y: proxy.size.height - 3))
                path.addLine(to: CGPoint(x: proxy.size.width, y: proxy.size.height - 3))
            }
            .stroke(Color.ink.opacity(0.45), style: StrokeStyle(lineWidth: 1, dash: [1, 3]))
        }
        .frame(height: 12)
    }
}
