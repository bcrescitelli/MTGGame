import SwiftUI
import UIKit

/// A landmark drawn as a postage stamp: perforated edge, its drawing on a tinted panel.
/// Mystery and blueprint styles hide the drawing behind a "?" until it's unlocked.
struct StampView: View {
    enum Style {
        case normal, selected, derelict, silhouette, mystery
    }

    let kind: LandmarkKind
    var style: Style = .normal
    var size: CGFloat = 50

    var body: some View {
        if style == .silhouette || style == .mystery {
            mystery
        } else {
            postage
        }
    }

    private var postage: some View {
        let hole = max(1.6, size * 0.045)
        let edge = hole * 2.2
        let faded = style == .derelict
        return ZStack {
            PerforatedRect(hole: hole)
                .fill(Color.card, style: FillStyle(eoFill: true))
                .clipShape(Rectangle())
                .background(
                    PerforatedRect(hole: hole)
                        .fill(Color.ink.opacity(0.18), style: FillStyle(eoFill: true))
                        .clipShape(Rectangle())
                        .offset(x: 1, y: 2)
                )
            ZStack {
                Rectangle().fill(faded ? Color(uiColor: UIColor(hex: 0xEFE9DC)) : Color(uiColor: kind.tintColor))
                art
                    .padding(size * 0.06)
                    .opacity(faded ? 0.4 : 1)
            }
            .overlay(Rectangle().stroke(Color.ink, lineWidth: max(1, size * 0.03)))
            .padding(edge)
        }
        .frame(width: size, height: size * 1.08)
        .overlay(alignment: .bottom) {
            if style == .selected {
                Rectangle().fill(Color(uiColor: kind.rimColor)).frame(height: max(2, size * 0.06)).padding(.horizontal, edge)
                    .padding(.bottom, edge)
            }
        }
        .rotationEffect(.degrees(faded ? -4 : 0))
    }

    @ViewBuilder
    private var art: some View {
        if let image = kind.artImage {
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
        } else {
            Image(systemName: kind.info.symbol)
                .font(.system(size: size * 0.32, weight: .bold))
                .foregroundStyle(Color.ink)
        }
    }

    private var mystery: some View {
        let corner = size * 0.14
        return ZStack {
            RoundedRectangle(cornerRadius: corner)
                .fill(Color.white.opacity(style == .mystery ? 0.12 : 0.05))
            RoundedRectangle(cornerRadius: corner)
                .stroke(Color.white.opacity(0.7), style: StrokeStyle(lineWidth: 1.5, dash: [4, 3]))
            Text("?")
                .font(.display(size * 0.5))
                .foregroundStyle(Color.white.opacity(0.75))
        }
        .frame(width: size, height: size * 1.08)
    }
}

/// A rectangle with half-circle bites along every edge, like a torn-off stamp.
/// Fill with `eoFill: true` and clip to the frame.
struct PerforatedRect: Shape {
    var hole: CGFloat

    func path(in rect: CGRect) -> Path {
        var path = Path(rect)
        let step = hole * 2.7
        func across(_ length: CGFloat) -> [CGFloat] {
            let count = max(1, Int((length / step).rounded()))
            return (0...count).map { CGFloat($0) * length / CGFloat(count) }
        }
        for x in across(rect.width) {
            path.addEllipse(in: CGRect(x: rect.minX + x - hole, y: rect.minY - hole, width: hole * 2, height: hole * 2))
            path.addEllipse(in: CGRect(x: rect.minX + x - hole, y: rect.maxY - hole, width: hole * 2, height: hole * 2))
        }
        for y in across(rect.height).dropFirst().dropLast() {
            path.addEllipse(in: CGRect(x: rect.minX - hole, y: rect.minY + y - hole, width: hole * 2, height: hole * 2))
            path.addEllipse(in: CGRect(x: rect.maxX - hole, y: rect.minY + y - hole, width: hole * 2, height: hole * 2))
        }
        return path
    }
}
