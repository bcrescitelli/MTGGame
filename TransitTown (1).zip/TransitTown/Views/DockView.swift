import SwiftUI
import UIKit

/// The line menu in the lower left. Collapsed, it's a circle showing this district's four
/// line colors; tap it to open the pens. It tucks away after a few seconds unused, unless a
/// pen is picked up. Everything else lives in the top bar.
struct DockView: View {
    @ObservedObject var state: GameState
    @Binding var isOpen: Bool
    @State private var lastInteraction = Date()

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            if isOpen, let id = state.selectedLineID, let line = state.line(id: id), line.isLightRail {
                LineTray(state: state, line: line)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
            HStack(spacing: 8) {
                toggleButton
                if isOpen {
                    pens
                        .transition(.move(edge: .leading).combined(with: .opacity))
                }
            }
        }
        .animation(.spring(response: 0.35, dampingFraction: 0.82), value: isOpen)
        .animation(.spring(response: 0.3, dampingFraction: 0.8), value: state.selectedLineID)
        .task(id: lastInteraction) {
            try? await Task.sleep(for: .seconds(8))
            guard !Task.isCancelled else { return }
            if canCollapse { isOpen = false }
        }
        .onChange(of: state.selectedLineID) { _, newValue in
            if newValue != nil { isOpen = true }
            touched()
        }
        .onChange(of: state.armedColorIndex) { _, _ in touched() }
    }

    private var canCollapse: Bool {
        state.selectedLineID == nil && state.armedColorIndex == nil && state.placingKind == nil
            && !state.isDecorating
    }

    private func touched() {
        lastInteraction = Date()
    }

    // MARK: Toggle

    /// Always the same 50-point circle in the same place, open or closed, so it's always tappable.
    private var toggleButton: some View {
        Button {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) {
                isOpen.toggle()
            }
            // Closing the menu puts the pen down too, so the line strip at the top closes with it.
            if !isOpen {
                state.setSelectedLine(nil)
                state.armedColorIndex = nil
                if state.isDecorating { state.stopDecorating() }
            }
            touched()
        } label: {
            ZStack {
                Circle().fill(Color.card)
                Circle().stroke(Color.ink.opacity(0.85), lineWidth: 1.5)
                if isOpen {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(Color.ink)
                } else {
                    miniLegend
                }
            }
            .frame(width: 50, height: 50)
            .contentShape(Circle())
            .background(Circle().fill(Color.ink.opacity(0.14)).offset(x: 1, y: 2))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(isOpen ? "Close line menu" : "Open line menu")
    }

    /// A ring of eight segments, one per line: bright when drawn, pale when open, grey when
    /// locked. A pencil tip in the middle says "your pens".
    private var miniLegend: some View {
        let district = state.focusedDistrict
        let count = Palette.lineCount
        return ZStack {
            ForEach(0..<count, id: \.self) { index in
                let from = Double(index) / Double(count) + 0.012
                let to = Double(index + 1) / Double(count) - 0.012
                let color = Color(uiColor: Palette.lines[index])
                let style: Color = !state.isLineUnlocked(colorIndex: index, in: district) ? Color.ink.opacity(0.12)
                    : (state.line(colorIndex: index, in: district) != nil ? color : color.opacity(0.35))
                Circle()
                    .trim(from: from, to: to)
                    .stroke(style, style: StrokeStyle(lineWidth: 6, lineCap: .butt))
                    .rotationEffect(.degrees(-90))
            }
            Image(systemName: "pencil.tip")
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(Color.ink)
        }
        .frame(width: 34, height: 34)
        .accessibilityLabel("Your line pens")
    }

    // MARK: Pens

    private var pens: some View {
        HStack(spacing: 10) {
            HStack(spacing: 5) {
                Circle()
                    .fill(Color(uiColor: state.focusedDistrict.accent))
                    .frame(width: 7, height: 7)
                Text(state.isSingleMap ? state.townName : state.focusedDistrict.name)
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .lineLimit(1)
                    .fixedSize()
            }
            ForEach(0..<Palette.lineCount, id: \.self) { index in
                LinePen(state: state, colorIndex: index) { touched() }
            }
            if state.openedDistricts.count > 1 {
                Rectangle()
                    .fill(Color.ink.opacity(0.15))
                    .frame(width: 1, height: 28)
                LightRailPen(state: state) { touched() }
            }
            Rectangle()
                .fill(Color.ink.opacity(0.15))
                .frame(width: 1, height: 28)
            if state.decorUnlocked {
                DecoratePen(state: state) { touched() }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(PaperPanel(cornerRadius: 25))
    }
}

/// One line's pen in the district on screen. Built lines show their stop count;
/// open slots show a plus; locked ones a lock.
private struct LinePen: View {
    @ObservedObject var state: GameState
    let colorIndex: Int
    let onTap: () -> Void

    var body: some View {
        let district = state.focusedDistrict
        let line = state.line(colorIndex: colorIndex, in: district)
        let unlocked = state.isLineUnlocked(colorIndex: colorIndex, in: district)
        let lifted = (line != nil && state.selectedLineID == line?.id) || state.armedColorIndex == colorIndex
        let color = Color(uiColor: Palette.lines[colorIndex])
        let name = Palette.lineNames[colorIndex]

        Button {
            onTap()
            if let line {
                state.toggleLineSelection(line.id)
            } else if unlocked {
                state.armColor(colorIndex)
            } else if state.canOpenLine(colorIndex) {
                state.openLinePrompt = colorIndex
            } else {
                state.show("The \(name) can be opened once \(state.lineUnlockHint(colorIndex: colorIndex, in: district)), then bought")
            }
        } label: {
            ZStack {
                if !unlocked {
                    Circle().fill(Color.ink.opacity(0.07))
                    Image(systemName: state.canOpenLine(colorIndex) ? "plus.circle.fill" : "lock.fill")
                        .font(.system(size: state.canOpenLine(colorIndex) ? 16 : 11, weight: .bold))
                        .foregroundStyle(Color.inkSoft)
                } else if let line {
                    Circle().fill(color)
                    Text("\(line.stops.count)")
                        .font(.mapBold(16))
                        .foregroundStyle(Color.white)
                } else {
                    Circle().stroke(color, style: StrokeStyle(lineWidth: 2.5, dash: [4, 3]))
                    Image(systemName: "plus")
                        .font(.system(size: 13, weight: .heavy))
                        .foregroundStyle(color)
                }
            }
            .frame(width: 36, height: 36)
            .overlay(Circle().stroke(Color.ink, lineWidth: 2.5).padding(-4).opacity(lifted ? 1 : 0))
            .offset(y: lifted ? -4 : 0)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: lifted)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(line == nil ? (unlocked ? "Start the \(name)" : "\(name), locked") : "\(name), \(Format.count(line?.stops.count ?? 0, "stop"))")
    }
}

/// The decorating tool: opens the bar of trees, benches, and Remove.
private struct DecoratePen: View {
    @ObservedObject var state: GameState
    let onTap: () -> Void

    var body: some View {
        let active = state.isDecorating
        let green = Color(uiColor: UIColor(hex: 0x5FA14B))
        Button {
            onTap()
            if active { state.stopDecorating() } else { state.startDecorating(.tree) }
        } label: {
            ZStack {
                Circle().fill(active ? green : Color.clear)
                Circle().stroke(green, lineWidth: active ? 0 : 2.5)
                Image(systemName: "tree.fill")
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(active ? Color.card : green)
            }
            .frame(width: 36, height: 36)
            .overlay(Circle().stroke(Color.ink, lineWidth: 2.5).padding(-4).opacity(active ? 1 : 0))
            .overlay(
                // After City Planning's "Show me": a pulsing gold ring around the pen.
                Circle().stroke(Color.gold, lineWidth: 3).padding(-7)
                    .scaleEffect(state.decorSpotlight ? 1.25 : 1)
                    .opacity(state.decorSpotlight ? 1 : 0)
                    .animation(state.decorSpotlight ? .easeInOut(duration: 0.6).repeatForever(autoreverses: true) : .default,
                               value: state.decorSpotlight)
            )
            .offset(y: active ? -4 : 0)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: active)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(active ? "Stop decorating" : "Decorate the town")
    }
}

/// The light rail's pen: a teal double-track roundel. Shown once a second district is open.
private struct LightRailPen: View {
    @ObservedObject var state: GameState
    let onTap: () -> Void

    var body: some View {
        let rail = state.lightRail
        let lifted = rail != nil && state.selectedLineID == rail?.id
        let teal = Color(uiColor: Palette.lightRail)
        Button {
            onTap()
            if let rail {
                state.toggleLineSelection(rail.id)
            } else {
                state.show("Drag from one district's hub to another's to lay light rail")
            }
        } label: {
            ZStack {
                Circle().fill(rail == nil ? Color.clear : teal)
                Circle().stroke(teal, lineWidth: rail == nil ? 2.5 : 0)
                Image(systemName: "tram.fill")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(rail == nil ? teal : Color.card)
            }
            .frame(width: 36, height: 36)
            .overlay(Circle().stroke(Color.ink, lineWidth: 2.5).padding(-4).opacity(lifted ? 1 : 0))
            .offset(y: lifted ? -4 : 0)
            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: lifted)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(rail == nil ? "Light rail, not built" : "Light rail")
    }
}

/// Shown above the menu while a pen is picked up: stops and trains, and for the light
/// rail, its upgrades.
private struct LineTray: View {
    @ObservedObject var state: GameState
    let line: TransitLine

    var body: some View {
        let trains = state.trainCount(for: line.id)
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 12) {
                Circle()
                    .fill(Color(uiColor: line.color))
                    .frame(width: 10, height: 10)
                VStack(alignment: .leading, spacing: 1) {
                    Text(line.name)
                        .font(.display(17))
                        .foregroundStyle(Color.ink)
                        .lineLimit(1)
                        .fixedSize()
                    Text("\(Format.count(line.stops.count, "stop"))   \(Format.count(trains, "train"))".uppercased())
                        .font(.mapSemibold(10))
                        .kerning(0.6)
                        .foregroundStyle(Color.inkSoft)
                        .lineLimit(1)
                        .fixedSize()
                }
                Button {
                    state.addTrain(to: line.id)
                } label: {
                    Text(trains >= GameState.maxTrainsPerLine ? "MAX TRAINS" : "+ TRAIN $\(state.nextTrainCost)")
                        .font(.mapBold(12))
                        .kerning(0.4)
                        .foregroundStyle(Color.card)
                        .padding(.horizontal, 12)
                        .frame(height: 28)
                        .background(RoundedRectangle(cornerRadius: 3).fill(state.canAddTrain(to: line.id) ? Color.ink : Color.inkSoft.opacity(0.5)))
                        .fixedSize()
                }
                .buttonStyle(.plain)
                .disabled(!state.canAddTrain(to: line.id))

                Button {
                    state.deleteLine(line.id)
                } label: {
                    Image(systemName: "trash")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.bad)
                        .frame(width: 30, height: 28)
                        .background(RoundedRectangle(cornerRadius: 3).stroke(Color.bad, lineWidth: 1.5))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Remove the \(line.name)")

                Button {
                    state.setSelectedLine(nil)
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.ink)
                        .frame(width: 28, height: 28)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Put the pen down")
            }

            if line.isLightRail {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        Text("SERVICE")
                            .font(.mapBold(9))
                            .kerning(1)
                            .foregroundStyle(Color.inkSoft)
                        ForEach(LightRailService.allCases) { service in
                            ServiceChip(state: state, service: service)
                        }
                    }
                }
                .frame(maxWidth: 520)
                HStack(spacing: 8) {
                    ForEach(LightRailUpgrade.allCases) { upgrade in
                        UpgradeChip(state: state, upgrade: upgrade)
                    }
                }
            }
        }
        .padding(.leading, 14)
        .padding(.trailing, 6)
        .padding(.vertical, 7)
        .background(PaperPanel(cornerRadius: 18))
    }
}

/// One light rail service: locked until enough light rail riders, otherwise tap to run it.
private struct ServiceChip: View {
    @ObservedObject var state: GameState
    let service: LightRailService

    var body: some View {
        let unlocked = state.lightRailRiders >= service.ridersNeeded
        let active = state.lightRailService == service
        Button {
            if unlocked {
                state.setService(service)
                state.show("\(service.title): \(service.effect)")
            } else {
                state.show("\(service.title) unlocks after \(Format.count(service.ridersNeeded, "light rail rider")). \(service.effect)")
            }
        } label: {
            HStack(spacing: 4) {
                Image(systemName: unlocked ? service.symbol : "lock.fill")
                    .font(.system(size: 9, weight: .bold))
                Text(service.title.uppercased())
                    .font(.mapBold(9))
                    .kerning(0.4)
                    .fixedSize()
            }
            .foregroundStyle(active ? Color.card : (unlocked ? Color.ink : Color.inkSoft))
            .padding(.horizontal, 8)
            .frame(height: 24)
            .background(
                RoundedRectangle(cornerRadius: 3).fill(active ? Color(uiColor: Palette.lightRail) : Color.ink.opacity(unlocked ? 0.08 : 0.04))
            )
        }
        .buttonStyle(.plain)
    }
}

/// One light rail upgrade: locked (riders needed), ready to buy, or owned.
private struct UpgradeChip: View {
    @ObservedObject var state: GameState
    let upgrade: LightRailUpgrade

    var body: some View {
        let owned = state.lightRailUpgrades.contains(upgrade)
        let earned = state.lightRailRiders >= upgrade.ridersNeeded
        Button {
            if earned && !owned {
                if state.canBuy(upgrade) {
                    state.buy(upgrade)
                } else {
                    state.show("\(upgrade.title) costs $\(upgrade.cost)")
                }
            } else {
                state.show(owned ? upgrade.effect
                           : "\(upgrade.title): \(upgrade.effect) Unlocks after \(upgrade.ridersNeeded) light rail riders.")
            }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: owned ? "checkmark" : (earned ? upgrade.symbol : "lock.fill"))
                    .font(.system(size: 10, weight: .bold))
                VStack(alignment: .leading, spacing: 0) {
                    Text(upgrade.title.uppercased())
                        .font(.mapBold(10))
                        .kerning(0.4)
                        .lineLimit(1)
                        .fixedSize()
                    Text(owned ? "OWNED" : (earned ? "$\(upgrade.cost)" : "\(min(state.lightRailRiders, upgrade.ridersNeeded))/\(upgrade.ridersNeeded) RIDERS"))
                        .font(.mapSemibold(9))
                        .kerning(0.4)
                        .lineLimit(1)
                        .fixedSize()
                }
            }
            .foregroundStyle(owned ? Color.good : (earned ? Color.card : Color.inkSoft))
            .padding(.horizontal, 9)
            .frame(height: 32)
            .background(
                RoundedRectangle(cornerRadius: 3).fill(owned ? Color.good.opacity(0.12) : (earned ? Color(uiColor: Palette.lightRail) : Color.ink.opacity(0.06)))
            )
        }
        .buttonStyle(.plain)
    }
}

/// A sheet of paper: a little grain, an ink border with an inner hairline, and a flat
/// print shadow. Corners are kept modest so panels read as paper, not app cards.
struct PaperPanel: View {
    var cornerRadius: CGFloat = 14

    var body: some View {
        let radius = min(cornerRadius, 12)
        ZStack {
            RoundedRectangle(cornerRadius: radius).fill(Color.black.opacity(0.10)).offset(x: 2, y: 5).blur(radius: 3)
            RoundedRectangle(cornerRadius: radius).fill(Color(uiColor: UIColor(hex: 0xDCCDB2))).offset(x: 1.5, y: 2.5)
            RoundedRectangle(cornerRadius: radius).fill(Color.card)
            PaperGrain(strength: 1.3).clipShape(RoundedRectangle(cornerRadius: radius))
        }
    }
}
