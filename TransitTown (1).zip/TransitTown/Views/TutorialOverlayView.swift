import SwiftUI
import UIKit

/// Tutorial steps and one-time tips: small cards on the right, under the top bar,
/// so they never cover the middle of the map.
struct TutorialOverlayView: View {
    @ObservedObject var state: GameState

    var body: some View {
        VStack {
            HStack(alignment: .top) {
                Spacer(minLength: 0)
                content
            }
            Spacer(minLength: 0)
        }
        .padding(.trailing, 10)
        .padding(.top, 66)
        .animation(.spring(response: 0.35, dampingFraction: 0.85), value: state.tutorial)
        .animation(.spring(response: 0.35, dampingFraction: 0.85), value: state.coachTip)
    }

    @ViewBuilder
    private var content: some View {
        if state.phase == .playing && !state.isBookOpen {
            if let step = state.tutorial {
                stepCard(step)
                    .id(step.rawValue)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
            } else if let tip = state.coachTip, state.placingKind == nil, state.selectedLineID == nil,
                      state.armedColorIndex == nil, !state.isDecorating {
                tipCard(tip)
                    .id(tip.id)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
            }
        }
    }

    private func stepCard(_ step: TutorialStep) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 6) {
                Text(step.isFirstMorning ? "No. \(step.number) of \(TutorialStep.firstMorningTotal)" : "New")
                    .font(.bodySerif(11, italic: true))
                    .foregroundStyle(Color.stampRed)
                Text(step.title)
                    .font(.display(16))
                    .foregroundStyle(Color.ink)
                    .lineLimit(1)
                Spacer(minLength: 4)
                Button("Skip") {
                    state.finishTutorial(skipped: true)
                }
                .font(.mapSemibold(11))
                .foregroundStyle(Color.inkSoft)
                .buttonStyle(.plain)
            }
            Text(step.text)
                .font(.bodySerif(12))
                .foregroundStyle(Color.ink)
                .fixedSize(horizontal: false, vertical: true)
            if step == .earnBlueprint {
                let target = TutorialStep.ridersForFirstBlueprint
                let carried = min(state.stats.ridersServed, target)
                HStack(spacing: 6) {
                    ProgressStrip(fraction: Double(carried) / Double(target), tint: .gold)
                    Text("\(carried)/\(target)")
                        .font(.mapBold(10))
                        .foregroundStyle(Color.inkSoft)
                }
            }
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 9)
        .frame(width: 250, alignment: .leading)
        .background(PaperPanel(cornerRadius: 12))
        .overlay(alignment: .top) { PaperTape() }
    }

    private func tipCard(_ tip: CoachTip) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: tip.symbol)
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(Color.card)
                .frame(width: 24, height: 24)
                .background(Circle().fill(Color.ink))
            VStack(alignment: .leading, spacing: 2) {
                Text(tip.title)
                    .font(.display(15))
                    .foregroundStyle(Color.ink)
                    .lineLimit(1)
                Text(tip.text)
                    .font(.bodySerif(12))
                    .foregroundStyle(Color.ink)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Button {
                state.dismissTip()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(Color.inkSoft)
                    .frame(width: 20, height: 20)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Dismiss tip")
        }
        .padding(10)
        .frame(width: 260, alignment: .leading)
        .background(PaperPanel(cornerRadius: 12))
        .overlay(alignment: .top) { PaperTape() }
    }
}
