import SwiftUI
import UIKit

/// The Town Shop: bundles of money, Golden Tickets, and decorations, set in a sunny paper scene
/// with the town's own buildings along the bottom. A placeholder for now: Buy explains that
/// purchases arrive in a later update.
struct ShopView: View {
    @ObservedObject var state: GameState
    @State private var comingSoon: String?
    @State private var appeared = false

    private enum Art { case postcards, crate, tickets(Int), coins }

    private struct Offer: Identifiable {
        let id: String
        let title: String
        let detail: String
        let price: String
        let art: Art
        var ribbon: String?
        var tint: UInt32 = 0xF3E3C0
    }

    private let offers: [Offer] = [
        Offer(id: "satchel", title: "Founder's Satchel", detail: "$1,000, 25 Golden Tickets, and a gold tram livery",
              price: "$6.99", art: .postcards, ribbon: "BEST VALUE", tint: 0xF6E2BC),
        Offer(id: "crate", title: "Decorator's Crate", detail: "$400, 4 Golden Tickets, and a brass lamp you can't get anywhere else",
              price: "$2.99", art: .crate, tint: 0xE3EBD4),
        Offer(id: "pocket", title: "A Pocketful", detail: "10 Golden Tickets", price: "$1.99", art: .tickets(2), tint: 0xF7E7B5),
        Offer(id: "roll", title: "A Whole Roll", detail: "30 Golden Tickets", price: "$4.99", art: .tickets(4),
              ribbon: "MOST LOVED", tint: 0xF7E7B5),
        Offer(id: "treasury", title: "Mayor's Treasury", detail: "$1,500 for permits, trains, and track", price: "$3.99",
              art: .coins, tint: 0xDCE6F0),
    ]

    var body: some View {
        ZStack {
            scene.ignoresSafeArea()
            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("A whole world awaits")
                            .font(.display(30))
                        Text("Buy now to speed it up: more permits, faster building, more to decorate with.")
                            .font(.bodySerif(13, italic: true))
                            .foregroundStyle(Color.ink.opacity(0.75))
                    }
                    Spacer()
                    Button {
                        state.isShopOpen = false
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 12, weight: .bold))
                            .foregroundStyle(Color.ink)
                            .frame(width: 32, height: 32)
                            .background(Circle().fill(Color.card.opacity(0.9)))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Close the shop")
                }
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 12) {
                        ForEach(Array(offers.enumerated()), id: \.element.id) { item in
                            card(item.element)
                                .offset(y: appeared ? 0 : 80)
                                .opacity(appeared ? 1 : 0)
                                .animation(.spring(response: 0.5, dampingFraction: 0.8).delay(Double(item.offset) * 0.06), value: appeared)
                        }
                    }
                    .padding(.vertical, 6)
                    .padding(.horizontal, 2)
                }
                WatchAdButton(state: state)
                Spacer(minLength: 0)
            }
            .foregroundStyle(Color.ink)
            .padding(.horizontal, 40)
            .padding(.top, 18)
        }
        .onAppear {
            AudioManager.shared.play(.whoosh)
            appeared = true
        }
        .paperAlert("Coming soon", isPresented: Binding(get: { comingSoon != nil }, set: { if !$0 { comingSoon = nil } }),
                    message: "\(comingSoon ?? "This") will be available when purchases open in a later update.",
                    confirm: "OK", cancel: nil)
    }

    /// A sunny paper sky with the town's own buildings along the bottom.
    private var scene: some View {
        GeometryReader { proxy in
            let w = proxy.size.width, h = proxy.size.height
            ZStack(alignment: .bottom) {
                Color(uiColor: UIColor(hex: 0xF4E2BE))
                PaperGrain(seed: 51, strength: 1.2)
                Circle().fill(Color(uiColor: UIColor(hex: 0xF6CF6E)))
                    .frame(width: 110, height: 110)
                    .position(x: w * 0.82, y: h * 0.2)
                Path { path in
                    path.move(to: CGPoint(x: 0, y: h * 0.8))
                    path.addCurve(to: CGPoint(x: w, y: h * 0.78), control1: CGPoint(x: w * 0.35, y: h * 0.7),
                                  control2: CGPoint(x: w * 0.7, y: h * 0.86))
                    path.addLine(to: CGPoint(x: w, y: h)); path.addLine(to: CGPoint(x: 0, y: h))
                }
                .fill(Color(uiColor: UIColor(hex: 0xBFD4A6)))
                HStack(alignment: .bottom, spacing: -10) {
                    ForEach(["stamp-bakery", "stamp-cafe", "stamp-library", "stamp-toyShop", "stamp-clockTower",
                             "stamp-catCafe", "stamp-aquarium", "stamp-fishMarket", "stamp-church", "stamp-park"], id: \.self) { name in
                        if let art = UIImage(named: name) {
                            Image(uiImage: art).resizable().scaledToFit().frame(width: max(90, w / 10))
                        }
                    }
                }
                .frame(width: w)
                .offset(y: 18)
                .opacity(0.95)
            }
        }
        .allowsHitTesting(false)
    }

    private func card(_ offer: Offer) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            ZStack(alignment: .topTrailing) {
                RoundedRectangle(cornerRadius: 8).fill(Color(uiColor: UIColor(hex: offer.tint)))
                artwork(offer.art)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .padding(8)
                if let ribbon = offer.ribbon {
                    Text(ribbon)
                        .font(.mapBold(9))
                        .kerning(1)
                        .foregroundStyle(Color.card)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(RoundedRectangle(cornerRadius: 4).fill(Color.stampRed))
                        .padding(6)
                }
            }
            .frame(maxWidth: .infinity)
            .frame(height: 104)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            Text(offer.title)
                .font(.display(17))
            Text(offer.detail)
                .font(.bodySerif(11.5, italic: true))
                .foregroundStyle(Color.inkSoft)
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, minHeight: 46, alignment: .topLeading)
            Spacer(minLength: 0)
            Button {
                AudioManager.shared.play(.chunk)
                comingSoon = offer.title
            } label: {
                InkButtonLabel(text: offer.price, height: 32, color: Color(uiColor: UIColor(hex: 0xC8553F)))
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
        }
        .padding(10)
        .frame(width: 176, height: 270)
        .background(PaperPanel(cornerRadius: 12))
    }

    @ViewBuilder
    private func artwork(_ art: Art) -> some View {
        switch art {
        case .postcards:
            ZStack {
                ForEach(Array(["stamp-library", "stamp-bakery", "stamp-aquarium"].enumerated()), id: \.offset) { item in
                    postcard(item.element)
                        .rotationEffect(.degrees(Double(item.offset - 1) * 10))
                        .offset(x: CGFloat(item.offset - 1) * 26, y: item.offset == 1 ? -4 : 4)
                        .scaleEffect(0.9)
                }
            }
        case .crate:
            ZStack(alignment: .bottom) {
                HStack(alignment: .bottom, spacing: -6) {
                    ForEach(DecorKind.everyday) { kind in
                        Image(uiImage: MarkerFactory.decorImage(kind, size: 40)).resizable().scaledToFit().frame(width: 32)
                    }
                }
                .offset(y: -20)
                RoundedRectangle(cornerRadius: 3)
                    .fill(Color(uiColor: UIColor(hex: 0xC98A55)))
                    .frame(height: 28)
                    .overlay(VStack(spacing: 8) {
                        Rectangle().fill(Color(uiColor: UIColor(hex: 0xA86E3E))).frame(height: 1.5)
                        Rectangle().fill(Color(uiColor: UIColor(hex: 0xA86E3E))).frame(height: 1.5)
                    })
            }
        case let .tickets(count):
            ZStack {
                ForEach(0..<count, id: \.self) { index in
                    ticket
                        .rotationEffect(.degrees(Double(index) * 12 - Double(count - 1) * 6))
                        .offset(x: CGFloat(index) * 10 - CGFloat(count - 1) * 5, y: CGFloat(index % 2) * -4)
                }
            }
        case .coins:
            if let art = UIImage(named: "shop-treasury") {
                Image(uiImage: art).resizable().scaledToFit()
            }
        }
    }

    private func postcard(_ name: String) -> some View {
        ZStack {
            RoundedRectangle(cornerRadius: 3).fill(Color.white).shadow(color: .black.opacity(0.15), radius: 1.5, x: 1, y: 2)
            if let art = UIImage(named: name) {
                Image(uiImage: art).resizable().scaledToFit().padding(4)
            }
        }
        .frame(width: 70, height: 58)
    }

    private var ticket: some View {
        ZStack {
            TicketShape(notch: 5).fill(Color(uiColor: UIColor(hex: 0xF2C14E)))
                .shadow(color: .black.opacity(0.15), radius: 1, x: 1, y: 2)
            TicketShape(notch: 5).stroke(Color(uiColor: UIColor(hex: 0xC8901A)), style: StrokeStyle(lineWidth: 1, dash: [3, 2]))
                .padding(4)
            Text("ADMIT ONE")
                .font(.mapBold(7))
                .kerning(1)
                .foregroundStyle(Color(uiColor: UIColor(hex: 0x8A5E10)))
        }
        .frame(width: 74, height: 40)
    }
}
