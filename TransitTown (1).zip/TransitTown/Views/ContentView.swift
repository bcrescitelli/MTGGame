import SpriteKit
import SwiftUI
import Combine
import UIKit

/// The map fills the screen. The top bar holds the town, money, rating, attention, Blueprints,
/// and settings; the line menu sits in the lower left and the speed control in the lower right.
/// Tips appear on the right. Game-loop screens (letter, Gazette, council, review) cover everything.
struct ContentView: View {
    let onNewCity: () -> Void

    @StateObject private var state: GameState
    @State private var scene = GameScene(size: CGSize(width: 800, height: 390))
    @State private var showHelp = false
    @State private var showSettings = false
    @State private var showTownPanel = false
    @State private var showLetters = false
    @State private var isDockOpen = true
    @State private var hubName = ""
    @Environment(\.scenePhase) private var scenePhase

    init(onNewCity: @escaping () -> Void) {
        self.onNewCity = onNewCity
        _state = StateObject(wrappedValue: GameState(save: SaveStore.load()))
    }

    private var layers: some View {
        ZStack {
            Color.paper.ignoresSafeArea()

            SpriteView(scene: scene, options: [.ignoresSiblingOrder])
                .ignoresSafeArea()

            VStack(spacing: 8) {
                HUDView(state: state, showTownPanel: $showTownPanel, showSettings: $showSettings, showLetters: $showLetters)
                if state.isDecorating {
                    DecorateBar(state: state)
                        .transition(.move(edge: .top).combined(with: .opacity))
                } else if state.placingKind != nil || state.selectedLineID != nil || state.armedColorIndex != nil {
                    ModeBanner(state: state)
                        .transition(.move(edge: .top).combined(with: .opacity))
                }
                Spacer(minLength: 0)
                HStack(alignment: .bottom) {
                    DockView(state: state, isOpen: $isDockOpen)
                    Spacer(minLength: 8)
                    SpeedControl(state: state)
                }
            }
            .padding(.horizontal, 10)
            .padding(.top, 6)
            .padding(.bottom, 4)
            .animation(.spring(response: 0.3, dampingFraction: 0.8), value: state.message)
            .animation(.spring(response: 0.3, dampingFraction: 0.8), value: state.isDecorating)

            if !showTownPanel && !state.isAttentionOpen && !showLetters && state.inspectedStationID == nil {
                TutorialOverlayView(state: state)
            }

            if showLetters {
                dismissLayer { showLetters = false }
                VStack {
                    HStack {
                        Spacer()
                        HotlineView(state: state) { showLetters = false }
                    }
                    Spacer()
                }
                .padding(.trailing, 10)
                .padding(.top, 62)
                .transition(.move(edge: .top).combined(with: .opacity))
            }

            if let stationID = state.inspectedStationID {
                dismissLayer { state.inspectedStationID = nil }
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        StationCardView(state: state, stationID: stationID) { state.inspectedStationID = nil }
                    }
                }
                .padding(.trailing, 10)
                .padding(.bottom, 58)
                .transition(.move(edge: .bottom).combined(with: .opacity))
            }



            if showTownPanel {
                dismissLayer { showTownPanel = false }
                VStack {
                    HStack {
                        TownPanelView(state: state, openSettings: {
                            showTownPanel = false
                            showSettings = true
                        }) { showTownPanel = false }
                        Spacer()
                    }
                    Spacer()
                }
                .padding(.leading, 10)
                .padding(.top, 62)
                .transition(.move(edge: .top).combined(with: .opacity))
            }

            if state.isAttentionOpen {
                dismissLayer { state.isAttentionOpen = false }
                VStack {
                    HStack {
                        Spacer()
                        AttentionPanelView(state: state)
                    }
                    Spacer()
                }
                .padding(.trailing, 10)
                .padding(.top, 62)
                .transition(.move(edge: .top).combined(with: .opacity))
            }

            if state.isBookOpen {
                BlueprintsView(state: state)
                    .transition(.move(edge: .bottom))
                    .zIndex(1)
            }

            if let info = state.spotlightCard, !state.isAlbumOpen {
                VStack {
                    Spacer()
                    SpotlightCardView(state: state, info: info)
                        .padding(.bottom, 24)
                }
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .zIndex(1.6)
            }
            if state.isAlbumOpen {
                AlbumView(state: state)
                    .transition(.opacity)
                    .zIndex(2.55)
            }
            if state.isShopOpen {
                ShopView(state: state)
                    .transition(.opacity)
                    .zIndex(2.6)
            }
            if let id = state.revealedLandmarkID, let landmark = state.landmark(id: id) {
                PostcardRevealView(state: state, landmark: landmark)
                    .id(id)
                    .transition(.opacity)
                    .zIndex(2.5)
            }
            phaseOverlay
                .zIndex(2)

            if showSettings {
                ZStack {
                    Color.ink.opacity(0.3)
                        .ignoresSafeArea()
                        .onTapGesture { showSettings = false }
                    SettingsView(state: state,
                                 showHelp: { showSettings = false; showHelp = true },
                                 onNewCity: onNewCity,
                                 dismiss: { showSettings = false })
                }
                .transition(.opacity)
                .zIndex(3)
            }

            if showHelp {
                ZStack {
                    Color.ink.opacity(0.3)
                        .ignoresSafeArea()
                        .onTapGesture { showHelp = false }
                    HelpCard { showHelp = false }
                }
                .transition(.opacity)
                .zIndex(4)
            }
        }
    }

    // The modifiers are split into small steps so the compiler checks each one separately
    // (one long chain is too much for it to type-check in reasonable time).

    var body: some View {
        ZStack {
            withPanelRules(withPrompts(withPhone(animatedLayers)))
            notices
            dialogs
        }
        .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { _ in
            state.updateReveals()
        }
        .onChange(of: state.dayBanner) { _, day in
            guard day != nil else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.4) { state.dayBanner = nil }
        }
        .statusBarHidden(true)
        .persistentSystemOverlays(.hidden)
    }

    /// Short-lived notes: a loud warning, or the new day's number.
    private var notices: some View {
        VStack(spacing: 10) {
            if let note = state.alertNote {
                AlertNoteView(text: note).transition(.scale.combined(with: .opacity))
            }
            if let note = state.ticketNote {
                HStack(spacing: 6) {
                    Image(systemName: "ticket.fill").font(.system(size: 11, weight: .bold)).foregroundStyle(Color.gold)
                    Text(note).font(.bodySerif(12.5, italic: true)).foregroundStyle(Color.ink)
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Capsule().fill(Color.card).shadow(color: .black.opacity(0.12), radius: 3, y: 1))
                .transition(.move(edge: .top).combined(with: .opacity))
            }
            if let day = state.dayBanner {
                DayBannerView(day: day).transition(.move(edge: .top).combined(with: .opacity))
            }
            Spacer()
        }
        .padding(.top, 70)
        .animation(.spring(response: 0.35, dampingFraction: 0.8), value: state.alertNote)
        .animation(.easeInOut(duration: 0.3), value: state.dayBanner)
        .animation(.easeInOut(duration: 0.3), value: state.ticketNote)
        .allowsHitTesting(false)
    }

    /// The game's own pop-ups, drawn over everything.
    @ViewBuilder private var dialogs: some View {
        if state.isAdPlaying {
            AdPlaceholderView(state: state)
        } else if let recap = state.awayRecap {
            AwayRecapView(state: state, recap: recap)
        } else if let lineID = state.upgradingLineID {
            TrainUpgradeView(state: state, lineID: lineID)
        } else if let index = state.openLinePrompt {
            openLineDialog(index)
        } else if state.hubNamingID != nil {
            hubNameDialog
        } else if state.returnPrompt != nil {
            PaperDialogCard(title: returnTitle, message: "They'll be so pleased to have it back.", confirm: "Return it",
                            onConfirm: {
                                AudioManager.shared.play(.sparkle)
                                state.returnLostItem()
                            },
                            onCancel: { state.returnPrompt = nil })
        } else if let lineID = state.deleteLinePrompt {
            PaperDialogCard(title: "Delete this line?", message: "Its trains go back to the depot. You can draw it again any time.",
                            confirm: "Delete", confirmColor: Color.stampRed, cancel: "Cancel",
                            onConfirm: {
                                state.deleteLine(lineID)
                                state.deleteLinePrompt = nil
                            },
                            onCancel: { state.deleteLinePrompt = nil })
        }
    }

    /// Opening a line: what it costs, what you have, and plainly what's missing.
    private func openLineDialog(_ index: Int) -> some View {
        let cost = state.lineOpeningCost(index)
        let moneyShort = max(0, cost.money - state.fares)
        let ticketsShort = max(0, cost.tickets - state.tickets)
        let enough = moneyShort == 0 && ticketsShort == 0
        var missing: [String] = []
        if moneyShort > 0 { missing.append("$\(moneyShort)") }
        if ticketsShort > 0 { missing.append(ticketsShort == 1 ? "1 Golden Ticket" : "\(ticketsShort) Golden Tickets") }
        let extra = VStack(alignment: .leading, spacing: 6) {
            requirement("$\(state.fares) of $\(cost.money)", met: moneyShort == 0, symbol: "dollarsign.circle.fill")
            requirement("\(state.tickets) of \(cost.tickets) Golden Tickets", met: ticketsShort == 0, symbol: "ticket.fill")
            if !enough {
                Text("You need \(missing.joined(separator: " and ")) more. Tickets come from calls, group trips, collections, and the council, or the shop.")
                    .font(.bodySerif(12.5, italic: true))
                    .foregroundStyle(Color.stampRed)
                    .fixedSize(horizontal: false, vertical: true)
                if ticketsShort > 0 { WatchAdButton(state: state) }
            }
        }
        return PaperDialogCard(title: "Open the \(Palette.lineNames[index])?",
                               message: "Once it's open, draw it anywhere in town.",
                               extra: AnyView(extra),
                               confirm: enough ? "Open it" : "Not enough yet",
                               confirmColor: Color(uiColor: Palette.lines[index]),
                               confirmEnabled: enough,
                               onConfirm: {
                                   AudioManager.shared.play(.chunk)
                                   state.openLine(index)
                               },
                               onCancel: { state.openLinePrompt = nil })
    }

    private func requirement(_ text: String, met: Bool, symbol: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: met ? "checkmark.circle.fill" : symbol)
                .foregroundStyle(met ? Color.good : Color.stampRed)
            Text(text).font(.bodySerif(14))
        }
    }

    private var hubNameDialog: some View {
        let field = TextField("Hub name", text: $hubName)
            .font(.display(18))
            .padding(10)
            .background(RoundedRectangle(cornerRadius: 8).fill(Color.ink.opacity(0.06)))
        return PaperDialogCard(title: "Name your new hub",
                               message: "Riders change lines here. Give it a name the town will remember.",
                               extra: AnyView(field),
                               confirm: "Name it", cancel: nil,
                               onConfirm: {
                                   if let id = state.hubNamingID { state.nameHub(id, hubName) }
                                   hubName = ""
                               })
    }

    private var animatedLayers: some View {
        layers
            .animation(.easeInOut(duration: 0.28), value: state.isBookOpen)
            .animation(.easeInOut(duration: 0.3), value: state.phase)
            .animation(.easeOut(duration: 0.2), value: showHelp)
            .animation(.easeOut(duration: 0.2), value: showSettings)
            .animation(.spring(response: 0.3, dampingFraction: 0.85), value: showTownPanel)
            .animation(.spring(response: 0.3, dampingFraction: 0.85), value: state.isAttentionOpen)
            .animation(.spring(response: 0.3, dampingFraction: 0.85), value: showLetters)
            .animation(.spring(response: 0.3, dampingFraction: 0.85), value: state.inspectedStationID)
            .animation(.easeOut(duration: 0.2), value: state.pendingDecision?.id)
            .onAppear {
            scene.configure(with: state)
        }
            .onChange(of: scenePhase) { _, phase in
            // Away: remember when, and schedule notifications. Back: the recap first.
            if phase == .background { state.wentAway() }
            else if phase == .active { state.cameBack() }
            else { state.autosave() }
        }
    }

    private func withPhone<Content: View>(_ content: Content) -> some View {
        content
        // The phone rings while a call is waiting.
        .onChange(of: state.ringingCall?.id) { _, ringing in
            if ringing != nil { AudioManager.shared.startRinging() } else if !state.ringingFeature && !state.ringingNews { AudioManager.shared.stopRinging() }
        }
        .onChange(of: state.ringingFeature) { _, ringing in
            if ringing { AudioManager.shared.startRinging() } else if state.ringingCall == nil && !state.ringingNews { AudioManager.shared.stopRinging() }
        }
        .onChange(of: state.ringingNews) { _, ringing in
            if ringing { AudioManager.shared.startRinging() } else if state.ringingCall == nil && !state.ringingFeature { AudioManager.shared.stopRinging() }
        }
        // The day's paper and the council never sit on top of a call: close the phone.
        .onChange(of: state.phase) { _, phase in
            if phase != .playing {
                showLetters = false
                AudioManager.shared.stopRinging()
            }
        }
        // City Planning's "Show me": open the menu so the decorating pen is in view.
        .onChange(of: state.dockOpenRequest) { _, requested in
            guard requested else { return }
            showLetters = false
            isDockOpen = true
            state.dockOpenRequest = false
        }
    }

    private func withPrompts<Content: View>(_ content: Content) -> some View {
        content
        .onChange(of: state.hubNamingID) { _, id in
            if id != nil { hubName = "\(state.focusedDistrict.name) Hub \(state.hubsBuilt)" }
        }
    }

    private func withPanelRules<Content: View>(_ content: Content) -> some View {
        content
        // One panel at a time: opening any panel closes the others.
        .onChange(of: showTownPanel) { _, open in if open { closePanels(except: .town) } }
        .onChange(of: showLetters) { _, open in if open { closePanels(except: .hotline) } }
        .onChange(of: state.isAttentionOpen) { _, open in if open { closePanels(except: .attention) } }
        .onChange(of: state.inspectedStationID) { _, id in if id != nil { closePanels(except: .station) } }
        .onChange(of: state.isBookOpen) { _, open in if open { closePanels(except: .book) } }
        .onChange(of: showSettings) { _, open in if open { closePanels(except: .settings) } }
    }

    private var openLineTitle: String {
        guard let index = state.openLinePrompt else { return "Open a line?" }
        return "Open the \(Palette.lineNames[index])?"
    }

    private var openLineMessage: String {
        guard let index = state.openLinePrompt else { return "" }
        let cost = state.lineOpeningCost(index)
        return "$\(cost.money) and \(cost.tickets) Golden Tickets. Once it's open, draw it anywhere in town."
    }

    private var returnTitle: String {
        guard let task = state.lostItemTask else { return "Return it?" }
        return "Return the \(task.item.item) to \(task.item.sender)?"
    }

    private enum Panel { case town, hotline, attention, station, book, settings }

    private func closePanels(except keep: Panel) {
        AudioManager.shared.play(.tick, volume: 0.6)
        if keep != .town { showTownPanel = false }
        if keep != .hotline { showLetters = false }
        if keep != .attention { state.isAttentionOpen = false }
        if keep != .station { state.inspectedStationID = nil }
        if keep != .book { state.isBookOpen = false }
        if keep != .settings { showSettings = false }
    }

    /// An invisible full-screen layer that closes a dropdown when tapped outside it.
    private func dismissLayer(_ action: @escaping () -> Void) -> some View {
        Color.black.opacity(0.001)
            .ignoresSafeArea()
            .onTapGesture(perform: action)
    }

    @ViewBuilder
    private var phaseOverlay: some View {
        switch state.phase {
        case .appointment:
            AppointmentLetterView(state: state) {
                state.acceptAppointment()
            }
            .transition(.opacity)
        case .gazette:
            if let edition = state.gazette {
                GazetteView(state: state, edition: edition)
                    .transition(.opacity)
            }
        case .council:
            CouncilView(state: state)
                .transition(.opacity)
        case .termReview:
            TermReviewView(state: state)
                .transition(.opacity)
        case .playing:
            EmptyView()
        }
    }
}
