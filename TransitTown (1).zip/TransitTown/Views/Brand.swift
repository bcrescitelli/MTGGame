import SwiftUI
import UIKit

// The Transit Town look, in a few shared pieces: paper with a little grain, ink rules like a
// newspaper, buttons that look stamped rather than glossy, and ticket stubs.

/// Faint fibers and specks, so surfaces read as paper rather than flat color.
struct PaperGrain: View {
    var seed: UInt64 = 11
    var strength: Double = 1

    var body: some View {
        Canvas { context, size in
            var generator = SeededGenerator(seed: seed)
            let count = Int(size.width * size.height / 90)
            for _ in 0..<count {
                let x = CGFloat.random(in: 0...size.width, using: &generator)
                let y = CGFloat.random(in: 0...size.height, using: &generator)
                let dark = Bool.random(using: &generator)
                let r = CGFloat.random(in: 0.3...0.9, using: &generator)
                context.fill(Path(ellipseIn: CGRect(x: x, y: y, width: r, height: r)),
                             with: .color(dark ? Color.ink.opacity(0.07 * strength) : Color.white.opacity(0.25 * strength)))
            }
            for _ in 0..<max(1, count / 40) {
                let x = CGFloat.random(in: 0...size.width, using: &generator)
                let y = CGFloat.random(in: 0...size.height, using: &generator)
                var fiber = Path()
                fiber.move(to: CGPoint(x: x, y: y))
                fiber.addQuadCurve(to: CGPoint(x: x + CGFloat.random(in: -6...6, using: &generator), y: y + 5),
                                   control: CGPoint(x: x + 3, y: y + 2))
                context.stroke(fiber, with: .color(Color.ink.opacity(0.05 * strength)), lineWidth: 0.5)
            }
        }
        .allowsHitTesting(false)
    }
}

/// A thick rule over a thin one, as under a newspaper's nameplate.
struct DoubleRule: View {
    var color: Color = .ink

    var body: some View {
        VStack(spacing: 2) {
            Rectangle().fill(color).frame(height: 2.5)
            Rectangle().fill(color).frame(height: 0.8)
        }
    }
}

/// A button face that looks stamped onto the page: square-ish corners and an inner hairline.
struct InkButtonLabel: View {
    let text: String
    var filled = true
    var symbol: String?
    var height: CGFloat = 40
    var color: Color = Color(uiColor: UIColor(hex: 0x4A4656))

    /// A cut-paper button: a solid sheet on a darker sheet, no outlines.
    var body: some View {
        HStack(spacing: 7) {
            Text(text)
                .font(.mapBold(height * 0.34))
                .kerning(1.2)
            if let symbol {
                Image(systemName: symbol)
                    .font(.system(size: height * 0.28, weight: .bold))
            }
        }
        .foregroundStyle(filled ? Color.newsprint : color)
        .padding(.horizontal, height * 0.45)
        .frame(minHeight: height)
        .background(
            ZStack {
                RoundedRectangle(cornerRadius: 8).fill(filled ? Color.black.opacity(0.28) : Color(uiColor: UIColor(hex: 0xDCCDB2))).offset(y: 2.5)
                RoundedRectangle(cornerRadius: 8).fill(filled ? color : Color.card)
                PaperGrain(seed: 9, strength: 1.2).clipShape(RoundedRectangle(cornerRadius: 8))
            }
        )
    }
}

/// A strip of paper tape holding a note to the screen.
struct PaperTape: View {
    var color: Color = Color(uiColor: UIColor(hex: 0xE8C77A))

    var body: some View {
        Rectangle()
            .fill(color.opacity(0.75))
            .frame(width: 54, height: 14)
            .overlay(PaperGrain(seed: 3, strength: 1.4))
            .rotationEffect(.degrees(-4))
            .offset(y: -7)
            .allowsHitTesting(false)
    }
}

/// A ticket stub: a rectangle with half-round notches on both ends.
struct TicketShape: Shape {
    var notch: CGFloat = 6

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let r = notch
        path.move(to: CGPoint(x: rect.minX + 3, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX - 3, y: rect.minY))
        path.addQuadCurve(to: CGPoint(x: rect.maxX, y: rect.minY + 3), control: CGPoint(x: rect.maxX, y: rect.minY))
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.midY - r))
        path.addArc(center: CGPoint(x: rect.maxX, y: rect.midY), radius: r, startAngle: .degrees(-90), endAngle: .degrees(90), clockwise: true)
        path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - 3))
        path.addQuadCurve(to: CGPoint(x: rect.maxX - 3, y: rect.maxY), control: CGPoint(x: rect.maxX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX + 3, y: rect.maxY))
        path.addQuadCurve(to: CGPoint(x: rect.minX, y: rect.maxY - 3), control: CGPoint(x: rect.minX, y: rect.maxY))
        path.addLine(to: CGPoint(x: rect.minX, y: rect.midY + r))
        path.addArc(center: CGPoint(x: rect.minX, y: rect.midY), radius: r, startAngle: .degrees(90), endAngle: .degrees(-90), clockwise: true)
        path.addLine(to: CGPoint(x: rect.minX, y: rect.minY + 3))
        path.addQuadCurve(to: CGPoint(x: rect.minX + 3, y: rect.minY), control: CGPoint(x: rect.minX, y: rect.minY))
        path.closeSubpath()
        return path
    }
}

/// An ink checkbox, used instead of the system toggle.
struct InkCheckbox: View {
    @Binding var isOn: Bool
    let label: String

    var body: some View {
        Button {
            isOn.toggle()
        } label: {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 2).stroke(Color.ink, lineWidth: 1.6)
                    if isOn {
                        Path { path in
                            path.move(to: CGPoint(x: 4, y: 10))
                            path.addLine(to: CGPoint(x: 8, y: 14))
                            path.addLine(to: CGPoint(x: 16, y: 4))
                        }
                        .stroke(Color.ink, style: StrokeStyle(lineWidth: 2.4, lineCap: .round, lineJoin: .round))
                    }
                }
                .frame(width: 20, height: 18)
                Text(label)
                    .font(.bodySerif(15))
                    .foregroundStyle(Color.ink)
                Spacer()
            }
            .frame(minHeight: 44)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
        .accessibilityValue(isOn ? "On" : "Off")
    }
}

/// Printed paper for documents (the Gazette, letters): heavier grain, a few faint blotches,
/// and edges a touch darker than the middle, like a sheet that's been handled.
struct PrintedPaper: View {
    var color: Color = .newsprint
    var seed: UInt64 = 21

    var body: some View {
        ZStack {
            Rectangle().fill(color)
            Canvas { context, size in
                var generator = SeededGenerator(seed: seed &+ 99)
                for _ in 0..<6 {
                    let w = CGFloat.random(in: 80...220, using: &generator)
                    let rect = CGRect(x: CGFloat.random(in: -40...size.width, using: &generator),
                                      y: CGFloat.random(in: -40...size.height, using: &generator),
                                      width: w, height: w * CGFloat.random(in: 0.5...0.9, using: &generator))
                    context.fill(Path(ellipseIn: rect), with: .color(Color(uiColor: UIColor(hex: 0x8A6A3A)).opacity(0.035)))
                }
            }
            .blur(radius: 18)
            PaperGrain(seed: seed, strength: 2.4)
            RadialGradient(colors: [Color.clear, Color(uiColor: UIColor(hex: 0x6E5530)).opacity(0.13)],
                           center: .center, startRadius: 160, endRadius: 620)
        }
        .allowsHitTesting(false)
    }
}


/// A heading in serif capitals, lightly spaced, instead of wide-tracked sans capitals.
struct SmallCapsHeading: View {
    let text: String
    var size: CGFloat = 11
    var color: Color = .ink

    var body: some View {
        Text(text.uppercased())
            .font(.smallCaps(size))
            .kerning(size * 0.12)
            .foregroundStyle(color)
    }
}

/// A stamp on an album page: perforated paper edge, grain, a flat shadow.
struct StampMount: View {
    var body: some View {
        ZStack {
            PerforatedRect(hole: 3.6)
                .fill(Color.ink.opacity(0.3), style: FillStyle(eoFill: true))
                .clipShape(Rectangle())
                .offset(x: 2, y: 3)
            PerforatedRect(hole: 3.6)
                .fill(Color.card, style: FillStyle(eoFill: true))
                .clipShape(Rectangle())
            PaperGrain(seed: 17, strength: 1.6)
                .padding(7)
        }
    }
}

/// An empty spot on an album page, waiting for its stamp: a pencilled outline.
struct EmptyMount: View {
    var color: Color = Color.white.opacity(0.55)

    var body: some View {
        Rectangle()
            .fill(Color.black.opacity(0.12))
            .overlay(Rectangle().stroke(color, style: StrokeStyle(lineWidth: 1.2, dash: [4, 4])))
    }
}

/// Four photo corners holding a stamp to the page.
struct MountingCorners: View {
    var size: CGFloat = 20
    var color: Color = Color(uiColor: UIColor(hex: 0x2A2A30)).opacity(0.78)

    var body: some View {
        GeometryReader { proxy in
            ForEach(0..<4, id: \.self) { corner in
                let right = corner % 2 == 1
                let bottom = corner >= 2
                Path { path in
                    let w = proxy.size.width, h = proxy.size.height
                    let x = right ? w : 0, y = bottom ? h : 0
                    let dx: CGFloat = right ? -size : size, dy: CGFloat = bottom ? -size : size
                    path.move(to: CGPoint(x: x - dx * 0.2, y: y - dy * 0.2))
                    path.addLine(to: CGPoint(x: x + dx, y: y - dy * 0.2))
                    path.addLine(to: CGPoint(x: x - dx * 0.2, y: y + dy))
                    path.closeSubpath()
                }
                .fill(color)
            }
        }
        .allowsHitTesting(false)
    }
}
