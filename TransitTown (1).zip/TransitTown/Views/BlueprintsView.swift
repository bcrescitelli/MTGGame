import SwiftUI
import UIKit

/// The city blueprints: every district's landmarks and heritage site. Open districts
/// show what's built, what's ready to build, and what it takes to unlock the rest.
/// Districts still to come are drawn as blueprint outlines until their term arrives.
struct BlueprintsView: View {
    @ObservedObject var state: GameState

    private let columns = [GridItem(.adaptive(minimum: 186, maximum: 236), spacing: 14)]

    var body: some View {
        ZStack {
            Color.blueprint.ignoresSafeArea()
            BlueprintGrid(spacing: 24).ignoresSafeArea()

            VStack(spacing: 0) {
                header
                    .padding(.horizontal, 24)
                    .padding(.top, 14)
                    .padding(.bottom, 8)
                districtTabs
                    .padding(.horizontal, 24)
                Rectangle()
                    .fill(Color.blueprintLine.opacity(0.4))
                    .frame(height: 1)
                    .padding(.horizontal, 24)

                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        districtIntro
                        if state.isOpened(state.bookDistrict) {
                            HubCard(state: state)
                            PermitBar(state: state, district: state.bookDistrict)
                        }
                        LazyVGrid(columns: columns, alignment: .leading, spacing: 14) {
                            ForEach(LandmarkKind.landmarks(in: state.bookDistrict)) { kind in
                                LandmarkCard(state: state, kind: kind)
                            }
                            ForEach(LandmarkKind.heritage(in: state.bookDistrict)) { kind in
                                HeritageCard(state: state, kind: kind)
                            }
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.vertical, 14)
                }
            }
        }
    }

    // MARK: Header

    private var header: some View {
        HStack(alignment: .center, spacing: 18) {
            VStack(alignment: .leading, spacing: 2) {
                Text("CITY BLUEPRINTS")
                    .font(.mapBold(26))
                    .kerning(1.6)
                    .foregroundStyle(Color.white)
                Text("Every landmark \(state.townName) could have")
                    .font(.bodySerif(13, italic: true))
                    .foregroundStyle(Color.blueprintLine)
            }
            Spacer(minLength: 8)
            if state.landmarkGrantAvailable {
                Label("FIRST LANDMARK FREE", systemImage: "gift.fill")
                    .font(.mapBold(12))
                    .kerning(0.8)
                    .foregroundStyle(Color.ink)
                    .padding(.horizontal, 10)
                    .frame(height: 26)
                    .background(RoundedRectangle(cornerRadius: 3).fill(Color.gold))
            }
            HStack(spacing: 5) {
                Image(systemName: "dollarsign.circle.fill")
                    .foregroundStyle(Color.gold)
                Text("\(state.fares)")
                    .font(.mapBold(15))
                    .foregroundStyle(Color.white)
            }
            Button {
                state.closeBook()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(Color.blueprint)
                    .frame(width: 34, height: 34)
                    .background(Circle().fill(Color.white))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Close blueprints")
        }
    }

    private var districtTabs: some View {
        HStack(spacing: 6) {
            ForEach(District.allCases.filter { state.isOpened($0) }) { district in
                let selected = state.bookDistrict == district
                let isOpen = state.isOpened(district)
                Button {
                    state.bookDistrict = district
                } label: {
                    VStack(spacing: 4) {
                        HStack(spacing: 6) {
                            Image(systemName: isOpen ? district.symbol : "lock.fill")
                                .font(.system(size: 11, weight: .bold))
                            Text((state.isSingleMap ? state.townName : district.name).uppercased())
                                .font(.mapBold(13))
                                .kerning(0.8)
                                .lineLimit(1)
                        }
                        .foregroundStyle(selected ? Color.white : Color.blueprintLine.opacity(isOpen ? 1 : 0.6))
                        Rectangle()
                            .fill(selected ? Color(uiColor: district.accent) : Color.clear)
                            .frame(height: 3)
                    }
                    .padding(.horizontal, 8)
                    .padding(.top, 4)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
            }
            Spacer(minLength: 0)
        }
    }

    private var districtIntro: some View {
        let district = state.bookDistrict
        let isOpen = state.isOpened(district)
        let kinds = LandmarkKind.landmarks(in: district)
        let movedIn = kinds.filter { state.hasMovedIn($0) }.count
        return HStack(spacing: 10) {
            RoundedRectangle(cornerRadius: 3)
                .fill(Color(uiColor: district.accent))
                .frame(width: 6, height: 22)
            Text(isOpen ? "\(movedIn) of \(kinds.count) shops have moved in" : "Opens at a later milestone")
                .font(.bodySerif(14))
                .foregroundStyle(Color.white)
        }
    }
}

// MARK: - Landmark card

private struct LandmarkCard: View {
    @ObservedObject var state: GameState
    let kind: LandmarkKind

    var body: some View {
        let info = kind.info
        let isOpenDistrict = state.isOpened(info.district)
        Group {
            // Every shop is a surprise until someone moves in. (The onboarding park is the one
            // landmark you place yourself.)
            if state.hasMovedIn(kind) || (kind == .park && isOpenDistrict && state.landmarkGrantAvailable) {
                availableCard
            } else {
                lockedCard(isFuture: !isOpenDistrict)
            }
        }
        .frame(height: 284)
        .overlay(alignment: .topTrailing) {
            if state.unseenBlueprints.contains(kind) {
                Text("NEW")
                    .font(.mapBold(11))
                    .kerning(1)
                    .foregroundStyle(Color.ink)
                    .padding(.horizontal, 8)
                    .frame(height: 20)
                    .background(RoundedRectangle(cornerRadius: 3).fill(Color.gold))
                    .offset(x: 6, y: -8)
            }
        }
    }

    private var availableCard: some View {
        let info = kind.info
        let built = state.isBuilt(kind)
        let cost = state.buildCost(kind)
        return VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .top) {
                StampView(kind: kind, size: 44)
                Spacer()
                VStack(alignment: .trailing, spacing: 4) {
                    CategoryTag(category: info.category)
                    Text("≈ \(info.expectedRidersPerDay) RIDERS A DAY")
                        .font(.mapSemibold(10))
                        .kerning(0.4)
                        .foregroundStyle(Color.inkSoft)
                }
            }
            Text(info.name)
                .font(.display(19))
                .foregroundStyle(Color.ink)
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)
            Text(info.blurb)
                .font(.bodySerif(12))
                .foregroundStyle(Color.inkSoft)
                .lineLimit(3)
                .fixedSize(horizontal: false, vertical: true)
            DemandRow(profile: info.demand)
            if let pair = info.pair, let pairName = info.pairName {
                PairLine(name: pairName, partner: pair.info.name)
            }
            if let perk = info.perk.text {
                PerkLine(text: perk)
            }
            Spacer(minLength: 0)
            if built {
                Text("ON THE MAP")
                    .font(.mapBold(12))
                    .kerning(1)
                    .foregroundStyle(Color.inkSoft)
                    .frame(maxWidth: .infinity, minHeight: 34)
            } else {
                if cost == 0 && kind == .park {
                    BuildButton(title: "BUILD FOR FREE",
                                disabledTitle: "NEEDS $\(cost)",
                                enabled: state.canBuild(kind),
                                highlight: state.tutorial == .openAlbum) {
                        state.beginPlacing(kind)
                    }
                } else {
                    Text("MOVES IN BY PERMIT")
                        .font(.mapBold(11))
                        .kerning(1)
                        .foregroundStyle(Color.inkSoft)
                        .frame(maxWidth: .infinity, minHeight: 34)
                }
            }
        }
        .padding(12)
        .background(StampMount())
        .overlay(MountingCorners())
        .overlay {
            if built {
                RubberStamp(text: "BUILT", color: .stampRed)
            }
        }
    }

    /// Locked landmarks stay a mystery: a "?" stamp and a teaser instead of the name.
    /// The way to unlock is shown, except for secrets, which only show clue progress.
    private func lockedCard(isFuture: Bool) -> some View {
        let info = kind.info
        let progress = state.progress(for: info.unlock, landmarkID: nil, district: info.district)
        let hideName = true
        return VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .top) {
                StampView(kind: kind, style: .mystery, size: 44)
                Spacer()
                Image(systemName: "lock.fill")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(Color.blueprintLine)
            }
            Text(hideName ? "? ? ?" : info.name)
                .font(.display(19))
                .foregroundStyle(Color.white)
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)
            Text(info.isSecret && !isFuture ? (info.rumor ?? kind.teaser) : kind.teaser)
                .font(.bodySerif(12, italic: hideName))
                .foregroundStyle(Color.blueprintLine.opacity(0.85))
                .lineLimit(4)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            if isFuture {
                Text("OPENS AT A LATER MILESTONE")
                    .font(.mapBold(12))
                    .kerning(1)
                    .foregroundStyle(Color.blueprintLine)
            } else if info.isSecret {
                VStack(alignment: .leading, spacing: 4) {
                    Text("CLUES FOUND")
                        .font(.mapSemibold(10))
                        .kerning(1.4)
                        .foregroundStyle(Color.blueprintLine)
                    ProgressStrip(fraction: progress.fraction, tint: .gold, track: Color.white.opacity(0.15))
                    Text("\(Int(progress.current)) of \(Int(progress.target))")
                        .font(.mapSemibold(11))
                        .foregroundStyle(Color.blueprintLine)
                }
            } else {
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 5) {
                        Circle().fill(Color(uiColor: info.category.color)).frame(width: 8, height: 8)
                        Text(info.category.name.uppercased())
                            .font(.mapBold(11))
                            .kerning(1.2)
                            .foregroundStyle(Color.white)
                    }
                    Text(state.isBuilt(kind) ? "Building now. Who could it be?" : "Still a surprise. Arrives with a \(info.category.name.lowercased()) permit.")
                        .font(.bodySerif(12, italic: true))
                        .foregroundStyle(Color.blueprintLine)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding(12)
        .background(EmptyMount(color: Color.blueprintLine.opacity(0.75)))
        .overlay(MountingCorners(size: 16, color: Color.blueprintLine.opacity(0.35)))
    }
}

// MARK: - Heritage card

private struct HeritageCard: View {
    @ObservedObject var state: GameState
    let kind: LandmarkKind

    var body: some View {
        let info = kind.info
        let site = state.landmarks.first { $0.kind == kind }
        Group {
            if let site {
                siteCard(site, info: info)
            } else {
                futureCard(info: info)
            }
        }
        .frame(height: 284)
    }

    private func siteCard(_ site: Landmark, info: LandmarkInfo) -> some View {
        let requirement = state.progress(for: info.unlock, landmarkID: site.id, district: info.district)
        let cost = state.restorationCost(kind)
        return VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .top) {
                StampView(kind: kind, style: site.isOpen ? .normal : .derelict, size: 44)
                Spacer()
                Text(site.isOpen ? "RESTORED" : "HERITAGE, BOARDED UP")
                    .font(.mapBold(10))
                    .kerning(1)
                    .foregroundStyle(site.isOpen ? Color.good : Color.inkSoft)
            }
            Text(info.name)
                .font(.display(19))
                .foregroundStyle(Color.ink)
                .lineLimit(2)
            Text(info.blurb)
                .font(.bodySerif(12))
                .foregroundStyle(Color.inkSoft)
                .lineLimit(3)
                .fixedSize(horizontal: false, vertical: true)
            if let perk = info.perk.text {
                PerkLine(text: perk)
            }
            Spacer(minLength: 0)
            if site.isOpen {
                DemandRow(profile: info.demand)
            } else {
                VStack(alignment: .leading, spacing: 5) {
                    RequirementLine(met: requirement.isMet, text: requirement.text,
                                    detail: ProgressText.describe(info.unlock, requirement))
                    RequirementLine(met: state.canAfford(cost),
                                    text: state.heritageGrantAvailable ? "Restoration (half price)" : "Restoration cost",
                                    detail: "$\(cost)")
                }
                BuildButton(title: "RESTORE FOR $\(cost)", disabledTitle: "RESTORE FOR $\(cost)",
                            enabled: state.canRestore(site.id), tint: .gold, labelColor: .ink) {
                    state.restore(site.id)
                }
            }
        }
        .padding(12)
        .background(PaperCard(fill: site.isOpen ? .card : Color(uiColor: UIColor(hex: 0xEFE7D6))))
        .overlay {
            if site.isOpen {
                RubberStamp(text: "RESTORED", color: .good)
            }
        }
    }

    private func futureCard(info: LandmarkInfo) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .top) {
                StampView(kind: kind, style: .silhouette, size: 44)
                Spacer()
                Text("HERITAGE")
                    .font(.mapBold(10))
                    .kerning(1)
                    .foregroundStyle(Color.blueprintLine)
            }
            Text(info.name)
                .font(.display(19))
                .foregroundStyle(Color.white)
            Text(info.blurb)
                .font(.bodySerif(12))
                .foregroundStyle(Color.blueprintLine.opacity(0.85))
                .lineLimit(3)
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            Text("OPENS AT A LATER MILESTONE")
                .font(.mapBold(12))
                .kerning(1)
                .foregroundStyle(Color.blueprintLine)
        }
        .padding(12)
        .background(EmptyMount(color: Color.blueprintLine.opacity(0.75)))
        .overlay(MountingCorners(size: 16, color: Color.blueprintLine.opacity(0.35)))
    }
}

// MARK: - Pieces

private struct CategoryTag: View {
    let category: LandmarkCategory

    var body: some View {
        Text(category.name.uppercased())
            .font(.mapBold(10))
            .kerning(1)
            .foregroundStyle(Color.ink)
            .padding(.horizontal, 7)
            .frame(height: 18)
            .background(RoundedRectangle(cornerRadius: 3).fill(Color(uiColor: category.color)))
    }
}

/// When a landmark draws riders: brighter icons and longer bars mean busier.
private struct DemandRow: View {
    let profile: DemandProfile

    var body: some View {
        HStack(spacing: 10) {
            ForEach(DayPhase.allCases, id: \.self) { phase in
                let weight = profile.weight(phase)
                VStack(spacing: 2) {
                    Image(systemName: phase.symbol)
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(Color.ink.opacity(0.25 + 0.75 * min(1, weight / 1.6)))
                    RoundedRectangle(cornerRadius: 3)
                        .fill(Color.ink.opacity(0.75))
                        .frame(width: max(2, 22 * min(1, weight / 1.8)), height: 3)
                        .frame(width: 22, alignment: .leading)
                }
                .accessibilityLabel("\(phase.name): \(weight >= 1.2 ? "busy" : weight >= 0.5 ? "steady" : "quiet")")
            }
        }
    }
}

private struct PairLine: View {
    let name: String
    let partner: String

    var body: some View {
        HStack(alignment: .top, spacing: 5) {
            Image(systemName: "link")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(Color.stampRed)
            Text("\(name) with the \(partner): more trips, +$1 fares")
                .font(.mapSemibold(11))
                .foregroundStyle(Color.ink)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

private struct PerkLine: View {
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 5) {
            Image(systemName: "sparkles")
                .font(.system(size: 10, weight: .bold))
                .foregroundStyle(Color.gold)
            Text(text)
                .font(.mapSemibold(11))
                .foregroundStyle(Color.ink)
                .lineLimit(2)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}

private struct RequirementLine: View {
    let met: Bool
    let text: String
    let detail: String

    var body: some View {
        HStack(spacing: 6) {
            Image(systemName: met ? "checkmark.circle.fill" : "circle")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(met ? Color.good : Color.inkSoft)
            Text(text)
                .font(.mapSemibold(11))
                .foregroundStyle(Color.ink)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
            Spacer(minLength: 4)
            Text(detail)
                .font(.mapBold(11))
                .foregroundStyle(Color.inkSoft)
        }
    }
}

private struct BuildButton: View {
    let title: String
    let disabledTitle: String
    let enabled: Bool
    var highlight = false
    var tint: Color = .ink
    var labelColor: Color = .card
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(enabled ? title : disabledTitle)
                .font(.mapBold(14))
                .kerning(0.8)
                .foregroundStyle(enabled ? labelColor : Color.inkSoft)
                .frame(maxWidth: .infinity, minHeight: 34)
                .background(RoundedRectangle(cornerRadius: 3).fill(enabled ? tint : Color.ink.opacity(0.08)))
                .overlay(RoundedRectangle(cornerRadius: 3).stroke(Color.ink, lineWidth: enabled ? 0 : 1))
                .overlay(
                    RoundedRectangle(cornerRadius: 3)
                        .stroke(Color.gold, lineWidth: 3)
                        .padding(-4)
                        .opacity(highlight && enabled ? 1 : 0)
                )
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
    }
}

struct PaperCard: View {
    var fill: Color = .card

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 12).fill(Color.black.opacity(0.25)).offset(x: 3, y: 4)
            RoundedRectangle(cornerRadius: 12).fill(fill)
            RoundedRectangle(cornerRadius: 12).stroke(Color.ink, lineWidth: 2)
        }
    }
}

/// An inked rubber stamp laid across a card.
/// An inked rubber stamp for game moments: APPROVED, BUILT, RESTORED, ANSWERED...
/// Double border, and speckled gaps where the ink didn't take.
struct RubberStamp: View {
    let text: String
    let color: Color
    var angle: Double = -14
    var size: CGFloat = 24

    var body: some View {
        Text(text)
            .font(.mapBold(size))
            .kerning(size * 0.14)
            .foregroundStyle(color)
            .padding(.horizontal, size * 0.5)
            .padding(.vertical, size * 0.1)
            .overlay(RoundedRectangle(cornerRadius: size * 0.16).stroke(color, lineWidth: size * 0.11))
            .padding(size * 0.17)
            .overlay(RoundedRectangle(cornerRadius: size * 0.24).stroke(color, lineWidth: size * 0.045))
            .mask(InkSpeckle(seed: text.unicodeScalars.reduce(7) { $0 &* 31 &+ Int($1.value) }))
            .rotationEffect(.degrees(angle))
            .opacity(0.88)
            .allowsHitTesting(false)
    }
}

/// A mask that's solid except for tiny gaps, like ink on paper.
struct InkSpeckle: View {
    let seed: Int

    var body: some View {
        Canvas { context, size in
            context.fill(Path(CGRect(origin: .zero, size: size)), with: .color(.black))
            var generator = SeededGenerator(seed: UInt64(abs(seed % 1_000_000) + 1))
            context.blendMode = .destinationOut
            for _ in 0..<Int(size.width * size.height / 16) {
                let x = CGFloat.random(in: 0...size.width, using: &generator)
                let y = CGFloat.random(in: 0...size.height, using: &generator)
                let r = CGFloat.random(in: 0.4...1.3, using: &generator)
                context.fill(Path(ellipseIn: CGRect(x: x, y: y, width: r, height: r)), with: .color(.black))
            }
        }
    }
}

struct ProgressStrip: View {
    let fraction: Double
    var tint: Color = .ink
    var track: Color = Color.ink.opacity(0.1)

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 3).fill(track)
                RoundedRectangle(cornerRadius: 3).fill(tint).frame(width: proxy.size.width * fraction)
            }
        }
        .frame(height: 4)
    }
}

/// Faint blueprint grid lines.
struct BlueprintGrid: View {
    var spacing: CGFloat = 24

    var body: some View {
        Canvas { context, size in
            var path = Path()
            var x: CGFloat = 0
            while x <= size.width {
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
                x += spacing
            }
            var y: CGFloat = 0
            while y <= size.height {
                path.move(to: CGPoint(x: 0, y: y))
                path.addLine(to: CGPoint(x: size.width, y: y))
                y += spacing
            }
            context.stroke(path, with: .color(Color.blueprintLine.opacity(0.16)), lineWidth: 0.5)
        }
        .allowsHitTesting(false)
    }
}

/// "12 of 25"-style progress text appropriate to each kind of condition.
enum ProgressText {
    static func describe(_ condition: UnlockCondition, _ progress: ConditionProgress) -> String {
        switch condition {
        case .rating:
            return "\(Format.stars(progress.current)) of \(Format.stars(progress.target))"
        case .revived:
            return "\(Format.percent(progress.current)) of \(Format.percent(progress.target))"
        case .faresEarned:
            return "$\(Int(progress.current)) of $\(Int(progress.target))"
        case .foodLine, .start:
            return progress.isMet ? "Done" : "Not yet"
        default:
            return "\(Int(min(progress.current, progress.target))) of \(Int(progress.target))"
        }
    }
}


/// Buy a permit for a kind of shop. Someone moves in when it's built, and which shop it
/// becomes is a surprise, drawn from the blueprints that kind of lot could become.
private struct PermitBar: View {
    @ObservedObject var state: GameState
    let district: District

    private var categories: [LandmarkCategory] {
        let present = Set(LandmarkKind.landmarks(in: district).map(\.info.category))
        return [.food, .culture, .nature, .civic, .spiritual].filter { present.contains($0) }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Permits")
                    .font(.display(20))
                    .foregroundStyle(Color.white)
                Text("A permit buys a lot for one kind of shop. Place it on the map, and it's built over most of a day. When it's done, someone moves in, and which shop it is stays a surprise until then.")
                    .font(.bodySerif(12.5))
                    .foregroundStyle(Color.blueprintLine)
                    .fixedSize(horizontal: false, vertical: true)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(categories, id: \.self) { category in
                        permit(category)
                    }
                }
            }
        }
    }

    private func permit(_ category: LandmarkCategory) -> some View {
        let cost = state.permitCost(category, in: district)
        let options = state.permitCandidates(category, in: district).count
        let open = state.isPermitOpen(category)
        let enabled = open && options > 0 && (state.landmarkGrantAvailable || state.canAfford(cost))
        return Button {
            AudioManager.shared.play(.stamp)
            state.beginPermit(category, in: district)
        } label: {
            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Circle().fill(Color(uiColor: category.color)).frame(width: 10, height: 10)
                    Text(category.name)
                        .font(.display(16))
                        .foregroundStyle(Color.ink)
                }
                Text(!open ? state.permitLockHint(category) : (options == 0 ? "Every shop has moved in" : (options == 1 ? "1 shop left to arrive" : "\(options) shops left to arrive")))
                    .font(.bodySerif(11.5, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(height: 30, alignment: .topLeading)
                Label(open ? (state.landmarkGrantAvailable ? "FREE" : "$\(cost)") : "LOCKED", systemImage: open ? "doc.text.fill" : "lock.fill")
                    .font(.mapBold(13))
                    .foregroundStyle(Color.ink)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .frame(width: 168, height: 92, alignment: .topLeading)
            .background(StampMount())
            .overlay(MountingCorners(size: 12))
            .opacity(enabled ? 1 : 0.55)
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .accessibilityLabel("\(category.name) permit, $\(cost)")
    }
}


/// Transit hubs: the only places riders can change lines.
private struct HubCard: View {
    @ObservedObject var state: GameState

    var body: some View {
        HStack(alignment: .center, spacing: 14) {
            if let art = UIImage(named: "stamp-transitHub") {
                Image(uiImage: art).resizable().scaledToFit().frame(width: 120)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("Transit Hubs")
                    .font(.display(20))
                    .foregroundStyle(Color.white)
                Text("Riders can only change lines at a hub. Build hubs where your lines cross, so nobody has to ride all the way across town just to change trains and come back. Hubs serve every line, and you name each one.")
                    .font(.bodySerif(12.5))
                    .foregroundStyle(Color.blueprintLine)
                    .fixedSize(horizontal: false, vertical: true)
                Text(state.hubsBuilt == 0 ? "You have Central Station so far." : "You've built \(state.hubsBuilt) so far, plus Central Station.")
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.blueprintLine)
            }
            Spacer(minLength: 8)
            Button {
                AudioManager.shared.play(.stamp)
                state.beginHub()
            } label: {
                InkButtonLabel(text: "BUILD A HUB, $\(state.nextHubCost)", symbol: "arrow.triangle.swap", height: 36,
                               color: Color(uiColor: UIColor(hex: 0x3A968E)))
            }
            .buttonStyle(.plain)
            .disabled(!state.canAfford(state.nextHubCost))
            .opacity(state.canAfford(state.nextHubCost) ? 1 : 0.5)
        }
        .padding(12)
        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white.opacity(0.08)))
    }
}
