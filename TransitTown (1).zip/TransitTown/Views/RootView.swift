import SwiftUI
import UIKit

/// Opens with a short loading screen, then the first-launch intro (once), the title screen
/// (when there's a saved city), or straight into the game. Starting a new city gives the
/// game a fresh identity, so everything starts clean.
struct RootView: View {
    private enum Stage { case loading, intro, title, game }

    @State private var stage: Stage = .loading
    @State private var session = UUID()

    var body: some View {
        ZStack {
            switch stage {
            case .loading:
                LoadingView()
                    .transition(.opacity)
            case .intro:
                IntroView {
                    UserDefaults.standard.set(true, forKey: "intro.seen")
                    stage = .game
                }
                .transition(.opacity)
            case .title:
                if let summary = SaveStore.summary() {
                    TitleView(town: summary.town, detail: summary.detail,
                              onContinue: { stage = .game },
                              onNewCity: startNewCity)
                        .transition(.opacity)
                } else {
                    ContentView(onNewCity: startNewCity).id(session)
                }
            case .game:
                ContentView(onNewCity: startNewCity)
                    .id(session)
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.45), value: stage)
        .task {
            AudioManager.shared.start()
            try? await Task.sleep(for: .seconds(2.0))
            if SaveStore.summary() != nil {
                stage = .title
            } else if !UserDefaults.standard.bool(forKey: "intro.seen") {
                stage = .intro
            } else {
                stage = .game
            }
        }
    }

    private func startNewCity() {
        SaveStore.delete()
        // Every new city starts with the onboarding (it can still be skipped).
        UserDefaults.standard.removeObject(forKey: "tutorial.done")
        session = UUID()
        stage = .game
    }
}

/// The eight lines draw themselves into a loop while a little tram runs around it.
struct LoadingView: View {
    @State private var start = Date()

    var body: some View {
        ZStack {
            PrintedPaper(color: Color.paper, seed: 3).ignoresSafeArea()
            VStack(spacing: 22) {
                TimelineView(.animation) { timeline in
                    let elapsed = timeline.date.timeIntervalSince(start)
                    let drawn = min(1, elapsed / 1.4)
                    ZStack {
                        ForEach(0..<Palette.lineCount, id: \.self) { index in
                            let from = Double(index) / Double(Palette.lineCount)
                            let to = from + 1 / Double(Palette.lineCount)
                            Circle()
                                .trim(from: from + 0.006, to: from + 0.006 + (to - from - 0.012)
                                      * min(1, max(0, drawn * Double(Palette.lineCount) - Double(index))))
                                .stroke(Color(uiColor: Palette.lines[index]),
                                        style: StrokeStyle(lineWidth: 9, lineCap: .butt))
                                .rotationEffect(.degrees(-90))
                        }
                        let angle = Angle(radians: elapsed * 2.4 - .pi / 2)
                        RoundedRectangle(cornerRadius: 4)
                            .fill(Color.stampRed)
                            .overlay(RoundedRectangle(cornerRadius: 4).stroke(Color.ink, lineWidth: 2))
                            .overlay(
                                HStack(spacing: 2.5) {
                                    ForEach(0..<3, id: \.self) { _ in
                                        RoundedRectangle(cornerRadius: 1).fill(Color(uiColor: UIColor(hex: 0xF7D57A)))
                                            .frame(width: 4.5, height: 4.5)
                                    }
                                }
                            )
                            .frame(width: 26, height: 13)
                            .rotationEffect(angle + .degrees(90))
                            .offset(x: 46 * cos(angle.radians), y: 46 * sin(angle.radians))
                            .opacity(drawn >= 1 ? 1 : 0)
                    }
                    .frame(width: 92, height: 92)
                }
                VStack(spacing: 4) {
                    Text("Transit Town")
                        .font(.display(34))
                    Text("Laying the track…")
                        .font(.bodySerif(14, italic: true))
                        .foregroundStyle(Color.inkSoft)
                }
                .foregroundStyle(Color.ink)
            }
        }
    }
}

/// The first time the game opens: a letter arrives, a wax seal is pressed onto it, the name
/// is stamped above, and the mayor opens it.
struct IntroView: View {
    let onFinish: () -> Void
    @State private var step = 0

    var body: some View {
        ZStack {
            PrintedPaper(color: Color.paper, seed: 8).ignoresSafeArea()
            VStack(spacing: 18) {
                ZStack {
                    if step >= 3 {
                        RubberStamp(text: "TRANSIT TOWN", color: .stampRed, angle: -4, size: 26)
                            .transition(.scale(scale: 2.2).combined(with: .opacity))
                    }
                }
                .frame(height: 50)

                ZStack {
                    envelope
                        .offset(y: step >= 1 ? 0 : -420)
                        .rotationEffect(.degrees(step >= 1 ? -2 : -14))
                    if step >= 2 {
                        WaxSeal()
                            .frame(width: 54, height: 54)
                            .offset(y: 8)
                            .transition(.scale(scale: 2.4).combined(with: .opacity))
                    }
                }
                .frame(width: 280, height: 170)

                VStack(spacing: 12) {
                    Text("A letter for the new mayor")
                        .font(.bodySerif(16, italic: true))
                        .foregroundStyle(Color.ink)
                    Button(action: onFinish) {
                        InkButtonLabel(text: "OPEN THE LETTER", symbol: "envelope.open.fill", height: 44)
                    }
                    .buttonStyle(.plain)
                }
                .opacity(step >= 4 ? 1 : 0)
            }
        }
        .task {
            for next in 1...4 {
                try? await Task.sleep(for: .seconds(next == 1 ? 0.3 : 0.8))
                withAnimation(.spring(response: 0.45, dampingFraction: 0.7)) { step = next }
                if next == 2 || next == 3 {
                    UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
                    AudioManager.shared.playPlaceLandmark()
                }
            }
        }
    }

    private var envelope: some View {
        ZStack {
            Rectangle().fill(Color.black.opacity(0.25)).offset(x: 3, y: 5)
            Rectangle().fill(Color(uiColor: UIColor(hex: 0xEADFC6)))
            PaperGrain(seed: 4, strength: 1.6)
            // The flap and the folds of the envelope back.
            Path { path in
                path.move(to: CGPoint(x: 0, y: 0))
                path.addLine(to: CGPoint(x: 140, y: 92))
                path.addLine(to: CGPoint(x: 280, y: 0))
            }
            .fill(Color(uiColor: UIColor(hex: 0xE2D4B6)))
            Path { path in
                path.move(to: CGPoint(x: 0, y: 0))
                path.addLine(to: CGPoint(x: 140, y: 92))
                path.addLine(to: CGPoint(x: 280, y: 0))
                path.move(to: CGPoint(x: 0, y: 170))
                path.addLine(to: CGPoint(x: 112, y: 76))
                path.move(to: CGPoint(x: 280, y: 170))
                path.addLine(to: CGPoint(x: 168, y: 76))
            }
            .stroke(Color.ink.opacity(0.25), lineWidth: 1)
            Rectangle().stroke(Color.ink.opacity(0.5), lineWidth: 1)
        }
        .frame(width: 280, height: 170)
    }
}

/// The title screen: a sunny little scene with the town's skyline, a tram running across the
/// front, the wordmark, and your saved city as a train ticket. All aboard.
struct TitleView: View {
    let town: String
    let detail: String
    let onContinue: () -> Void
    let onNewCity: () -> Void
    @State private var confirmNew = false
    @State private var appeared = false
    @State private var start = Date()

    private let sky = Color(uiColor: UIColor(hex: 0xF4E2BE))
    private let hillBack = Color(uiColor: UIColor(hex: 0xBFD4A6))
    private let hillFront = Color(uiColor: UIColor(hex: 0x9DBF86))
    private let groundColor = Color(uiColor: UIColor(hex: 0xE9DCC0))

    var body: some View {
        GeometryReader { proxy in
            let w = proxy.size.width, h = proxy.size.height
            let horizon = h * 0.62
            ZStack(alignment: .topLeading) {
                sky
                PaperGrain(seed: 31, strength: 1.2)

                // Sun and drifting clouds.
                Circle()
                    .fill(Color(uiColor: UIColor(hex: 0xF6CF6E)))
                    .frame(width: 92, height: 92)
                    .shadow(color: Color(uiColor: UIColor(hex: 0x8A6A3A)).opacity(0.15), radius: 0, x: 2, y: 3)
                    .position(x: w * 0.53, y: h * 0.13)
                TimelineView(.animation) { timeline in
                    let t = timeline.date.timeIntervalSince(start)
                    ZStack {
                        cloud(scale: 1).position(x: drift(t, speed: 9, from: w * 0.15, width: w + 200), y: h * 0.14)
                        cloud(scale: 0.7).position(x: drift(t, speed: 6, from: w * 0.62, width: w + 200), y: h * 0.3)
                        cloud(scale: 0.85).position(x: drift(t, speed: 7.5, from: w * 0.92, width: w + 200), y: h * 0.09)
                    }
                }

                // Hills, then the ground.
                Path { path in
                    path.move(to: CGPoint(x: 0, y: horizon))
                    path.addCurve(to: CGPoint(x: w, y: horizon - 10), control1: CGPoint(x: w * 0.3, y: horizon - 70),
                                  control2: CGPoint(x: w * 0.65, y: horizon + 10))
                    path.addLine(to: CGPoint(x: w, y: h)); path.addLine(to: CGPoint(x: 0, y: h))
                }
                .fill(hillBack)
                Path { path in
                    path.move(to: CGPoint(x: 0, y: horizon + 30))
                    path.addCurve(to: CGPoint(x: w, y: horizon + 16), control1: CGPoint(x: w * 0.4, y: horizon - 6),
                                  control2: CGPoint(x: w * 0.7, y: horizon + 46))
                    path.addLine(to: CGPoint(x: w, y: h)); path.addLine(to: CGPoint(x: 0, y: h))
                }
                .fill(hillFront)
                Rectangle().fill(groundColor)
                    .frame(width: w, height: h - (horizon + 56))
                    .offset(y: horizon + 56)

                skyline(width: w)
                    .frame(width: w, height: 120, alignment: .bottom)
                    .offset(y: horizon - 52)

                // Track with sleepers, and a tram running along it.
                track(width: w).offset(y: horizon + 62)
                TimelineView(.animation) { timeline in
                    let t = timeline.date.timeIntervalSince(start)
                    tram.position(x: drift(t, speed: 70, from: -120, width: w + 240), y: horizon + 50)
                }
            }
            // The scene is scenery only: it never takes a touch.
            .allowsHitTesting(false)
        }
        .ignoresSafeArea()
        // The wordmark and the ticket sit on their own layer above the scene, so the buttons
        // always receive taps.
        .overlay(alignment: .topLeading) {
            wordmark
                .padding(.leading, 64)
                .padding(.top, 26)
                .opacity(appeared ? 1 : 0)
                .offset(y: appeared ? 0 : -12)
                .allowsHitTesting(false)
        }
        .overlay(alignment: .trailing) {
            ticketBlock
                .padding(.trailing, 56)
                .padding(.bottom, 60)
                .opacity(appeared ? 1 : 0)
                .offset(x: appeared ? 0 : 60)
        }
        .onAppear {
            withAnimation(.spring(response: 0.7, dampingFraction: 0.8).delay(0.1)) { appeared = true }
        }
        .paperAlert("Start a new city?", isPresented: $confirmNew,
                    message: "\(town) will be replaced. This can't be undone.",
                    confirm: "Start over", confirmColor: Color.stampRed, action: onNewCity)
    }

    /// Something moving steadily left to right, wrapping around.
    private func drift(_ t: Double, speed: Double, from: CGFloat, width: CGFloat) -> CGFloat {
        let x = Double(from) + t * speed
        return CGFloat(x.truncatingRemainder(dividingBy: Double(width))) - 100
    }

    // MARK: Pieces


    private var wordmark: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Transit Town")
                .font(.display(56))
                .foregroundStyle(Color.ink)
            Text("Bring the trains back. The town will follow.")
                .font(.bodySerif(16, italic: true))
                .foregroundStyle(Color.ink)
        }
    }

    private var ticketBlock: some View {
        VStack(spacing: 10) {
            Button(action: onContinue) {
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("ADMIT ONE MAYOR")
                            .font(.mapBold(10))
                            .kerning(1.6)
                            .foregroundStyle(Color.stampRed)
                        Spacer()
                        Text("No. 0001")
                            .font(.bodySerif(11, italic: true))
                            .foregroundStyle(Color.inkSoft)
                    }
                    Text(town)
                        .font(.display(28))
                        .foregroundStyle(Color.ink)
                    Text(detail)
                        .font(.bodySerif(13, italic: true))
                        .foregroundStyle(Color.ink)
                    Path { path in
                        path.move(to: .zero)
                        path.addLine(to: CGPoint(x: 260, y: 0))
                    }
                    .stroke(Color.ink.opacity(0.35), style: StrokeStyle(lineWidth: 1, dash: [3, 3]))
                    .frame(height: 1)
                    .padding(.vertical, 4)
                    InkButtonLabel(text: "ALL ABOARD", symbol: "arrow.right", height: 42)
                        .frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 22)
                .padding(.vertical, 16)
                .frame(width: 290)
                .contentShape(Rectangle())
                .background(
                    ZStack {
                        TicketShape(notch: 10).fill(Color.ink.opacity(0.2)).offset(x: 3, y: 4)
                        TicketShape(notch: 10).fill(Color(uiColor: UIColor(hex: 0xFBF4E4)))
                        PaperGrain(seed: 33, strength: 1.4).clipShape(TicketShape(notch: 10))
                        TicketShape(notch: 10).stroke(Color.ink, lineWidth: 1.6)
                    }
                )
            }
            .buttonStyle(.plain)
            .rotationEffect(.degrees(-3))
            .accessibilityLabel("Continue \(town). \(detail)")

            Button {
                confirmNew = true
            } label: {
                Text("or start a new city")
                    .font(.bodySerif(14, italic: true))
                    .underline()
                    .foregroundStyle(Color.ink)
                    .padding(8)
            }
            .buttonStyle(.plain)
        }
    }

    /// The new paper cut-outs, lined up as a skyline.
    private func skyline(width: CGFloat) -> some View {
        let pieces: [(String, CGFloat)] = [("decor-tree", 66), ("stamp-bakery", 120), ("stamp-clockTower", 120), ("decor-lamp", 58),
                                           ("stamp-central", 150), ("decor-tree", 78), ("stamp-park", 120), ("decor-bench", 64)]
        return HStack(alignment: .bottom, spacing: max(2, (width - 820) / 10)) {
            ForEach(Array(pieces.enumerated()), id: \.offset) { item in
                if let image = UIImage(named: item.element.0) {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(width: item.element.1)
                }
            }
        }
        .frame(maxWidth: .infinity)
    }

    private func track(width: CGFloat) -> some View {
        ZStack(alignment: .topLeading) {
            HStack(spacing: 14) {
                ForEach(0..<Int(width / 20) + 2, id: \.self) { _ in
                    RoundedRectangle(cornerRadius: 1).fill(Color(uiColor: UIColor(hex: 0xA9774A))).frame(width: 6, height: 12)
                }
            }
            .offset(y: -3)
            Rectangle().fill(Color(uiColor: UIColor(hex: 0x5B5866))).frame(width: width, height: 3)
            Rectangle().fill(Color(uiColor: UIColor(hex: 0x5B5866))).frame(width: width, height: 3).offset(y: 6)
        }
        .frame(width: width, alignment: .leading)
    }

    /// A little paper tram: red body, butter windows, a pantograph on top.
    private var tram: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 9).fill(Color(uiColor: UIColor(hex: 0x6E3A2E)).opacity(0.25)).offset(x: 2, y: 3)
            RoundedRectangle(cornerRadius: 9).fill(Color(uiColor: UIColor(hex: 0xD2694F)))
            HStack(spacing: 6) {
                ForEach(0..<4, id: \.self) { _ in
                    RoundedRectangle(cornerRadius: 2).fill(Color(uiColor: UIColor(hex: 0xF2CF7A))).frame(width: 14, height: 11)
                }
            }
            .offset(y: -3)
            Rectangle().fill(Color(uiColor: UIColor(hex: 0xF4EAD7))).frame(height: 3).offset(y: 9)
            Path { path in
                path.move(to: CGPoint(x: 50, y: 0))
                path.addLine(to: CGPoint(x: 42, y: -12))
                path.addLine(to: CGPoint(x: 58, y: -12))
            }
            .stroke(Color(uiColor: UIColor(hex: 0x5B5866)), lineWidth: 2)
            .frame(width: 100, height: 0)
            .offset(y: -17)
        }
        .frame(width: 100, height: 34)
    }

    private func cloud(scale: CGFloat) -> some View {
        ZStack {
            Group {
                Circle().frame(width: 46, height: 46).offset(x: -24, y: 6)
                Circle().frame(width: 62, height: 62)
                Circle().frame(width: 42, height: 42).offset(x: 28, y: 8)
                Capsule().frame(width: 110, height: 30).offset(y: 16)
            }
            .foregroundStyle(Color(uiColor: UIColor(hex: 0x8A6A3A)).opacity(0.12))
            .offset(x: 2, y: 3)
            Group {
                Circle().frame(width: 46, height: 46).offset(x: -24, y: 6)
                Circle().frame(width: 62, height: 62)
                Circle().frame(width: 42, height: 42).offset(x: 28, y: 8)
                Capsule().frame(width: 110, height: 30).offset(y: 16)
            }
            .foregroundStyle(Color(uiColor: UIColor(hex: 0xFBF5EA)))
        }
        .scaleEffect(scale)
    }
}
