import SwiftUI
import UIKit

/// The end-of-term ceremony: each goal is read out, ribbons are pinned, and the mayor gets a title.
struct TermReviewView: View {
    @ObservedObject var state: GameState
    @State private var revealed = 0
    @State private var showGrade = false

    var body: some View {
        ZStack {
            Color.ink.opacity(0.65).ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                certificate
                    .frame(maxWidth: 600)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
            }
        }
        .task {
            for step in 1...max(1, state.goals.count) {
                try? await Task.sleep(for: .seconds(0.7))
                withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) { revealed = step }
                if step <= state.goals.count, state.progress(for: state.goals[step - 1]).isMet {
                    UIImpactFeedbackGenerator(style: .medium).impactOccurred()
                }
            }
            try? await Task.sleep(for: .seconds(0.6))
            withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) { showGrade = true }
        }
    }

    private var certificate: some View {
        let ribbons = state.ribbonsEarned
        return VStack(spacing: 14) {
            VStack(spacing: 6) {
                Text("A Milestone for the Town")
                    .font(.nameplate(36))
                    .foregroundStyle(Color.ink)
                Text("presented to the Mayor of \(state.townName), for bringing \(state.currentDistrict.name) back to life")
                    .font(.bodySerif(14, italic: true))
                    .foregroundStyle(Color.ink)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)
            }
            HStack(spacing: 8) {
                Rectangle().fill(Color.gold).frame(height: 1)
                Rectangle().fill(Color.gold).frame(width: 7, height: 7).rotationEffect(.degrees(45))
                Rectangle().fill(Color.gold).frame(height: 1)
            }

            VStack(spacing: 10) {
                ForEach(Array(state.goals.enumerated()), id: \.offset) { item in
                    goalRow(item.element, visible: revealed > item.offset)
                }
            }

            if showGrade {
                VStack(spacing: 6) {
                    HStack(spacing: 6) {
                        ForEach(0..<3, id: \.self) { index in
                            Image(systemName: index < ribbons ? "rosette" : "circle.dashed")
                                .font(.system(size: 24, weight: .bold))
                                .foregroundStyle(index < ribbons ? Color.gold : Color.inkSoft.opacity(0.5))
                        }
                    }
                    Text(TermGoal.gradeTitle(ribbons: ribbons))
                        .font(.display(32))
                        .foregroundStyle(Color.ink)
                    Text(TermGoal.gradeLine(ribbons: ribbons, town: state.townName))
                        .font(.bodySerif(14, italic: true))
                        .foregroundStyle(Color.inkSoft)
                        .multilineTextAlignment(.center)
                }
                .transition(.scale(scale: 0.8).combined(with: .opacity))

                stats

                VStack(spacing: 8) {
                    if let next = state.nextDistrict {
                        Button {
                            state.openNextDistrict()
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: next.symbol)
                                Text("OPEN \(next.name.uppercased())")
                                    .kerning(1)
                            }
                            .font(.mapBold(15))
                            .foregroundStyle(Color.newsprint)
                            .padding(.horizontal, 22)
                            .frame(height: 44)
                            .background(RoundedRectangle(cornerRadius: 3).fill(Color.ink))
                        }
                        .buttonStyle(.plain)
                        Text("Your network carries over. \(next.name) joins the city by light rail.")
                            .font(.bodySerif(12, italic: true))
                            .foregroundStyle(Color.inkSoft)
                    } else {
                        Button {
                            state.continueEndless()
                        } label: {
                            Text("STAY A WHILE")
                                .font(.mapBold(15))
                                .kerning(1)
                                .foregroundStyle(Color.newsprint)
                                .padding(.horizontal, 22)
                                .frame(height: 44)
                                .background(RoundedRectangle(cornerRadius: 3).fill(Color.ink))
                        }
                        .buttonStyle(.plain)
                        Text("Every district is open. The city is yours to keep growing.")
                            .font(.bodySerif(12, italic: true))
                            .foregroundStyle(Color.inkSoft)
                    }
                }
                .transition(.opacity)
            }
        }
        .padding(.horizontal, 40)
        .padding(.vertical, 30)
        .background(
            ZStack {
                Rectangle().fill(Color.black.opacity(0.3)).offset(x: 4, y: 6)
                PrintedPaper(color: Color(uiColor: UIColor(hex: 0xF7F1E2)), seed: 77)
                Rectangle().stroke(Color.gold, lineWidth: 3).padding(9)
                Rectangle().stroke(Color.gold.opacity(0.6), lineWidth: 1).padding(15)
                CertificateCorners().padding(9)
            }
        )
        .overlay(alignment: .bottomTrailing) {
            WaxSeal()
                .frame(width: 64, height: 64)
                .rotationEffect(.degrees(-12))
                .offset(x: -26, y: -22)
                .opacity(showGrade ? 1 : 0)
                .scaleEffect(showGrade ? 1 : 1.8)
        }
    }

    private func goalRow(_ goal: TermGoal, visible: Bool) -> some View {
        let progress = state.progress(for: goal)
        return HStack(spacing: 12) {
            Image(systemName: progress.isMet ? "rosette" : "xmark.circle")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(progress.isMet ? Color.gold : Color.inkSoft)
                .scaleEffect(visible ? 1 : 0.2)
            VStack(alignment: .leading, spacing: 2) {
                Text(progress.text)
                    .font(.bodySerif(15))
                    .foregroundStyle(Color.ink)
                Text(progressLine(goal, progress))
                    .font(.mapSemibold(12))
                    .kerning(0.5)
                    .foregroundStyle(progress.isMet ? Color.good : Color.inkSoft)
            }
            Spacer()
        }
        .opacity(visible ? 1 : 0.15)
    }

    private func progressLine(_ goal: TermGoal, _ progress: ConditionProgress) -> String {
        let status = progress.isMet ? "RIBBON EARNED" : "NOT THIS TERM"
        switch goal {
        case .ratingAtEnd:
            return "FINISHED AT \(Format.stars(progress.current)), \(status)"
        case .revived:
            return "\(Format.percent(progress.current)) REVIVED, \(status)"
        case .heritage:
            return progress.isMet ? "RESTORED, \(status)" : "STILL BOARDED UP, \(status)"
        case .riders, .crossDistrictRiders, .landmarks:
            return "\(Int(progress.current)) OF \(Int(progress.target)), \(status)"
        }
    }

    private var stats: some View {
        HStack(spacing: 22) {
            stat("\(state.stats.ridersServed)", "RIDERS")
            stat("\(state.stats.crossDistrictRiders)", "BETWEEN DISTRICTS")
            stat("$\(state.stats.totalFares)", "FARES")
            stat("\(state.stats.heritageRestored)", "RESTORED")
            stat(Format.percent(state.revivedFraction), "REVIVED")
        }
    }

    private func stat(_ value: String, _ label: String) -> some View {
        VStack(spacing: 0) {
            Text(value)
                .font(.mapBold(20))
                .foregroundStyle(Color.ink)
            Text(label)
                .font(.mapSemibold(10))
                .kerning(1.2)
                .foregroundStyle(Color.inkSoft)
        }
    }
}


/// Small gold diamonds at each corner of the certificate's border.
private struct CertificateCorners: View {
    var body: some View {
        GeometryReader { proxy in
            ForEach(0..<4, id: \.self) { corner in
                Rectangle()
                    .fill(Color.gold)
                    .frame(width: 10, height: 10)
                    .rotationEffect(.degrees(45))
                    .position(x: corner % 2 == 0 ? 0 : proxy.size.width, y: corner < 2 ? 0 : proxy.size.height)
            }
        }
        .allowsHitTesting(false)
    }
}

/// A red wax seal, pressed with the town's mark.
struct WaxSeal: View {
    var body: some View {
        ZStack {
            Circle().fill(Color.stampRed).shadow(color: .black.opacity(0.25), radius: 1, x: 1, y: 2)
            Circle().stroke(Color.black.opacity(0.18), lineWidth: 3).padding(5)
            Circle().stroke(Color.white.opacity(0.25), lineWidth: 1).padding(9)
            Image(systemName: "tram.fill")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(Color.black.opacity(0.25))
                .offset(x: 0.8, y: 0.8)
            Image(systemName: "tram.fill")
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(Color.white.opacity(0.35))
        }
        .accessibilityHidden(true)
    }
}
