import SwiftUI
import UIKit

/// The Town Album: a postcard for every place that has opened (and an empty spot for each one
/// still to come), and a two-page spread for each place with its week, its regulars, and the
/// comment cards people leave.
struct AlbumView: View {
    @ObservedObject var state: GameState
    @State private var district: District?

    var body: some View {
        ZStack {
            Color.ink.opacity(0.5).ignoresSafeArea()
                .onTapGesture { close() }
            Group {
                if let id = state.albumLandmarkID, let landmark = state.landmark(id: id) {
                    ShopSpread(state: state, landmark: landmark, pinned: pinned)
                } else {
                    index
                }
            }
            .padding(16)
            .background(
                ZStack {
                    PaperPanel(cornerRadius: 14)
                    PrintedPaper(color: Color.card, seed: 31).clipShape(RoundedRectangle(cornerRadius: 14))
                    MountingCorners(size: 18, color: Color(uiColor: UIColor(hex: 0xC8B48E)).opacity(0.7)).padding(8)
                }
            )
            .padding(.horizontal, 22)
            .padding(.vertical, 10)
        }
    }

    private func close() {
        state.isAlbumOpen = false
        state.albumLandmarkID = nil
    }

    private var pinned: [Landmark] {
        state.landmarks.filter { $0.isOpen && $0.kind.info.category != .canal }
            .sorted { ($0.kind.info.district.rawValue, $0.id) < ($1.kind.info.district.rawValue, $1.id) }
    }

    private var openDistricts: [District] { District.allCases.filter { state.isOpened($0) } }
    private var shownDistrict: District { district ?? state.focusedDistrict }

    // MARK: Index

    private var index: some View {
        let totals = state.albumTotals
        let possible = openDistricts.reduce(0) { $0 + LandmarkKind.landmarks(in: $1).count + 1 }
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline, spacing: 10) {
                Text("The Town Album")
                    .font(.display(26))
                Text("\(pinned.count) of \(possible) places")
                    .font(.bodySerif(13, italic: true))
                    .foregroundStyle(Color.inkSoft)
                Spacer()
                Button(action: close) {
                    Image(systemName: "xmark")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color.inkSoft)
                        .frame(width: 30, height: 30)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Close the album")
            }
            HStack(spacing: 8) {
                total("\(totals.visitors)", "visitors so far", "person.2.fill")
                total("\(totals.regulars)", "regulars", "heart.fill")
                total("\(totals.cards)", "comment cards", "envelope.fill")
                total("\(pinned.count)", "places open", "building.2.fill")
            }
            if openDistricts.count > 1 {
                HStack(spacing: 6) {
                    ForEach(openDistricts) { d in
                        Button {
                            AudioManager.shared.play(.tick)
                            district = d
                        } label: {
                            InkButtonLabel(text: d.name.uppercased(), filled: d == shownDistrict, height: 28)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            ScrollView(showsIndicators: false) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 230, maximum: 320), spacing: 16)], spacing: 22) {
                    ForEach(Array(placesShown.enumerated()), id: \.offset) { item in
                        Group {
                            switch item.element {
                            case let .pinned(landmark): postcard(landmark)
                            case let .toCome(kind): emptySpot(kind)
                            }
                        }
                        .rotationEffect(.degrees(item.offset % 3 == 0 ? -1.2 : (item.offset % 3 == 1 ? 0.8 : -0.4)))
                    }
                }
                .padding(.top, 16)
                .padding(.bottom, 10)
                .padding(.horizontal, 6)
            }
        }
        .foregroundStyle(Color.ink)
    }

    private enum Place { case pinned(Landmark), toCome(LandmarkKind) }

    private var placesShown: [Place] {
        let here = pinned.filter { $0.kind.info.district == shownDistrict }
        let missing = LandmarkKind.landmarks(in: shownDistrict).filter { kind in !here.contains { $0.kind == kind } }
        return here.map(Place.pinned) + missing.map(Place.toCome)
    }

    private func total(_ value: String, _ label: String, _ symbol: String) -> some View {
        HStack(spacing: 6) {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.stampRed)
            Text(value).font(.display(18)).monospacedDigit()
            Text(label).font(.bodySerif(11.5, italic: true)).foregroundStyle(Color.inkSoft)
        }
        .padding(.horizontal, 10)
        .frame(height: 34)
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.ink.opacity(0.05)))
    }

    /// A proper postcard: picture on the left; stamp, postmark, and address lines on the right.
    private func postcard(_ landmark: Landmark) -> some View {
        let record = state.shopRecords[landmark.id]
        let tint = Color(uiColor: landmark.kind.info.category.color)
        let newCard = record?.comments.first?.day == state.day
        let regularCount = record?.regulars.values.filter { $0 >= 3 }.count ?? 0
        return Button {
            AudioManager.shared.play(.whoosh, volume: 0.6)
            state.albumLandmarkID = landmark.id
        } label: {
            HStack(spacing: 0) {
                PostcardScene(kind: landmark.kind, tint: tint)
                    .frame(width: 124)
                Rectangle().fill(Color.ink.opacity(0.15)).frame(width: 1).padding(.vertical, 12)
                VStack(alignment: .leading, spacing: 5) {
                    HStack(alignment: .top) {
                        Spacer()
                        PostageStamp(symbol: landmark.kind.info.symbol, tint: tint)
                    }
                    Text(landmark.name)
                        .font(.display(15))
                        .foregroundStyle(Color.ink)
                        .lineLimit(2)
                        .minimumScaleFactor(0.85)
                    Rectangle().fill(Color.ink.opacity(0.15)).frame(height: 0.8)
                    Text("\(record?.visits ?? 0) visitors")
                        .font(.bodySerif(11.5, italic: true))
                    Rectangle().fill(Color.ink.opacity(0.15)).frame(height: 0.8)
                    Text(regularCount == 1 ? "1 regular" : "\(regularCount) regulars")
                        .font(.bodySerif(11.5, italic: true))
                }
                .foregroundStyle(Color.inkSoft)
                .padding(10)
            }
            .frame(height: 150)
            .background(ZStack { Color(uiColor: UIColor(hex: 0xFBF4E4)); PaperGrain(seed: 22, strength: 1.5) })
            .clipShape(RoundedRectangle(cornerRadius: 4))
            .shadow(color: .black.opacity(0.14), radius: 3, x: 1, y: 3)
            .overlay(alignment: .top) { PaperTape() }
            .overlay(alignment: .topLeading) {
                if newCard {
                    Text("NEW CARD")
                        .font(.mapBold(9))
                        .kerning(1)
                        .foregroundStyle(Color.card)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 3)
                        .background(RoundedRectangle(cornerRadius: 4).fill(Color.stampRed))
                        .offset(x: 6, y: 8)
                }
            }
        }
        .buttonStyle(.plain)
    }

    /// A place that hasn't opened yet: an empty spot on the page.
    private func emptySpot(_ kind: LandmarkKind) -> some View {
        let tint = Color(uiColor: kind.info.category.color)
        return VStack(spacing: 6) {
            Text("?")
                .font(.display(34))
                .foregroundStyle(Color.inkSoft.opacity(0.6))
            HStack(spacing: 5) {
                Circle().fill(tint).frame(width: 8, height: 8)
                Text(kind.info.isHeritage ? "Waiting to be restored" : "\(kind.info.category.name), still to come")
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 150)
        .background(RoundedRectangle(cornerRadius: 4).stroke(Color.ink.opacity(0.25), style: StrokeStyle(lineWidth: 1.2, dash: [5, 4])))
    }
}

/// A small perforated postage stamp in a category's color.
private struct PostageStamp: View {
    let symbol: String
    let tint: Color

    var body: some View {
        ZStack {
            PerforatedRect(hole: 2.2).fill(Color.white, style: FillStyle(eoFill: true)).clipShape(Rectangle())
            Rectangle().fill(tint.opacity(0.85)).padding(4)
            Image(systemName: symbol).font(.system(size: 12, weight: .bold)).foregroundStyle(Color.white)
        }
        .frame(width: 34, height: 40)
        .shadow(color: .black.opacity(0.1), radius: 1, x: 1, y: 1)
        .background(alignment: .leading) {
            // Wavy cancellation lines running into the stamp.
            Path { path in
                for row in 0..<3 {
                    let y = 12 + CGFloat(row) * 7
                    path.move(to: CGPoint(x: 0, y: y))
                    for step in 0..<4 {
                        let x = CGFloat(step) * 9
                        path.addQuadCurve(to: CGPoint(x: x + 9, y: y), control: CGPoint(x: x + 4.5, y: y + (step % 2 == 0 ? -3 : 3)))
                    }
                }
            }
            .stroke(Color.ink.opacity(0.3), lineWidth: 1)
            .frame(width: 36, height: 40)
            .offset(x: -30)
        }
    }
}

/// One place's two-page spread.
private struct ShopSpread: View {
    @ObservedObject var state: GameState
    let landmark: Landmark
    let pinned: [Landmark]

    private var record: ShopRecord { state.shopRecords[landmark.id] ?? ShopRecord(openedDay: state.day) }
    private var tint: Color { Color(uiColor: landmark.kind.info.category.color) }

    var body: some View {
        VStack(spacing: 8) {
            HStack {
                Button {
                    AudioManager.shared.play(.tick)
                    state.albumLandmarkID = nil
                } label: {
                    Label("All postcards", systemImage: "square.grid.2x2")
                        .font(.bodySerif(13, italic: true))
                        .foregroundStyle(Color.ink)
                }
                .buttonStyle(.plain)
                Spacer()
                pageButton(-1, "chevron.left")
                pageButton(1, "chevron.right")
                Button {
                    state.isAlbumOpen = false
                    state.albumLandmarkID = nil
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color.inkSoft)
                        .frame(width: 30, height: 30)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Close the album")
            }
            HStack(alignment: .top, spacing: 0) {
                ScrollView(showsIndicators: false) { leftPage.padding(.trailing, 14) }
                    .frame(maxWidth: .infinity)
                // The fold between the two pages.
                LinearGradient(colors: [Color.black.opacity(0), Color.black.opacity(0.12), Color.black.opacity(0)],
                               startPoint: .leading, endPoint: .trailing)
                    .frame(width: 18)
                ScrollView(showsIndicators: false) { rightPage.padding(.leading, 14).padding(.top, 12) }
                    .frame(maxWidth: .infinity)
            }
        }
        .foregroundStyle(Color.ink)
    }

    private func pageButton(_ step: Int, _ symbol: String) -> some View {
        Button {
            guard let index = pinned.firstIndex(where: { $0.id == landmark.id }), !pinned.isEmpty else { return }
            AudioManager.shared.play(.whoosh, volume: 0.5)
            let next = (index + step + pinned.count) % pinned.count
            withAnimation(.easeInOut(duration: 0.2)) { state.albumLandmarkID = pinned[next].id }
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.ink)
                .frame(width: 30, height: 30)
                .background(Circle().fill(Color.ink.opacity(0.06)))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(step < 0 ? "Previous page" : "Next page")
    }

    // MARK: Left page: the place and its people

    private var leftPage: some View {
        VStack(alignment: .leading, spacing: 10) {
            PostcardScene(kind: landmark.kind, tint: tint)
                .frame(height: 176)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 3))
                .padding(6)
                .background(RoundedRectangle(cornerRadius: 4).fill(Color.white).shadow(color: .black.opacity(0.12), radius: 2, x: 1, y: 2))
                .overlay(alignment: .top) { PaperTape() }
                .padding(.top, 12)
            Text(landmark.name)
                .font(.display(24))
            Text(landmark.shopkeeper.map { "Opened by \($0) on day \(record.openedDay)" } ?? "Part of the town since day \(record.openedDay)")
                .font(.bodySerif(12.5, italic: true))
                .foregroundStyle(Color.inkSoft)
            Text(landmark.kind.info.blurb)
                .font(.typewriter(11.5))
                .fixedSize(horizontal: false, vertical: true)
            section("On the lines")
            let lines = state.lines.filter { $0.stops.count > 1 && $0.stops.contains(landmark.id) }
            if lines.isEmpty {
                note("No line stops here yet.")
            } else {
                HStack(spacing: 6) {
                    ForEach(lines) { line in
                        HStack(spacing: 5) {
                            Circle().fill(Color(uiColor: line.color)).frame(width: 9, height: 9)
                            Text(line.name).font(.bodySerif(12))
                        }
                        .padding(.horizontal, 8)
                        .frame(height: 24)
                        .background(Capsule().fill(Color(uiColor: line.color).opacity(0.14)))
                    }
                }
            }
            section("Visitors come from")
            let origins = state.topOrigins(of: landmark.id)
            if origins.isEmpty {
                note("No one has arrived yet.")
            } else {
                ForEach(origins, id: \.name) { origin in
                    HStack {
                        Text(origin.name).font(.bodySerif(12.5))
                        Spacer()
                        Text("\(origin.visits)").font(.mapBold(12)).monospacedDigit()
                    }
                }
            }
        }
    }

    // MARK: Right page: the numbers, regulars, and comment cards

    private var rightPage: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                stat("\(record.visits)", "visitors so far")
                stat("$\(record.earned)", "made here")
                stat("\(record.bestDayVisits)", "on its best day")
            }
            if state.adsUnlocked {
                section("Advertise")
                advertise
            }
            section("This week")
            weekChart
            section("When they come")
            phaseChart
            section("Regulars")
            regulars
            section("Comment cards")
            if let progress = state.collectionProgress(at: landmark.id) {
                Text(state.unlockedDecor.contains(progress.decor.rawValue)
                     ? "Collection complete: the town's \(progress.decor.title.lowercased()) is in the Decorate menu."
                     : "\(progress.count) of \(Collections.cardsNeeded) cards toward a \(progress.decor.title.lowercased()) for the town.")
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .fixedSize(horizontal: false, vertical: true)
            }
            comments
        }
    }

    /// Frenchie LaRue's options: what each would bring today, and the price.
    private var advertise: some View {
        VStack(alignment: .leading, spacing: 6) {
            if let campaign = state.activeCampaign(at: landmark.id) {
                Text("\(campaign.kindName) running today. Visitors are on their way.")
                    .font(.bodySerif(12.5, italic: true))
                    .foregroundStyle(Color.ink)
                    .fixedSize(horizontal: false, vertical: true)
            } else {
                ForEach(AdOption.allCases) { option in
                    let forecast = state.adForecast(option, at: landmark.id)
                    HStack(spacing: 10) {
                        VStack(alignment: .leading, spacing: 1) {
                            Text(option.title).font(.display(14))
                            Text("\(option.detail) Forecast: +\(forecast.low) to +\(forecast.high) visitors today.")
                                .font(.bodySerif(11.5, italic: true))
                                .foregroundStyle(Color.inkSoft)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                        Spacer(minLength: 6)
                        Button {
                            if state.buyAd(option, at: landmark.id) { AudioManager.shared.play(.stamp) }
                        } label: {
                            InkButtonLabel(text: "$\(option.cost)", height: 30, color: Color(uiColor: UIColor(hex: 0xC8553F)))
                        }
                        .buttonStyle(.plain)
                        .disabled(!state.canAfford(option.cost))
                        .opacity(state.canAfford(option.cost) ? 1 : 0.5)
                    }
                    .padding(8)
                    .background(RoundedRectangle(cornerRadius: 8).fill(tint.opacity(0.1)))
                }
            }
        }
    }

    private func section(_ title: String) -> some View {
        Text(title).font(.display(16)).padding(.top, 2)
    }

    private func note(_ text: String) -> some View {
        Text(text).font(.bodySerif(12, italic: true)).foregroundStyle(Color.inkSoft)
    }

    private func stat(_ value: String, _ label: String) -> some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(value).font(.display(20)).monospacedDigit()
            Text(label).font(.bodySerif(11, italic: true)).foregroundStyle(Color.inkSoft)
        }
        .padding(8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(RoundedRectangle(cornerRadius: 8).fill(tint.opacity(0.12)))
    }

    /// The last seven days plus today, as paper bars in eight fixed slots.
    private var weekChart: some View {
        let past = Array(record.week.suffix(7))
        let slots: [Int?] = Array(repeating: nil, count: 7 - past.count) + past.map { Optional($0) } + [record.todayVisits]
        let peak = max(1, slots.compactMap { $0 }.max() ?? 1)
        return HStack(alignment: .bottom, spacing: 8) {
            ForEach(Array(slots.enumerated()), id: \.offset) { item in
                let isToday = item.offset == slots.count - 1
                let daysAgo = slots.count - 1 - item.offset
                VStack(spacing: 3) {
                    Text(item.element.map { "\($0)" } ?? "")
                        .font(.mapBold(9)).foregroundStyle(Color.inkSoft)
                    if let value = item.element {
                        RoundedRectangle(cornerRadius: 3)
                            .fill(isToday ? tint : tint.opacity(0.45))
                            .frame(width: 18, height: max(3, 54 * CGFloat(value) / CGFloat(peak)))
                    } else {
                        Rectangle().fill(Color.ink.opacity(0.12)).frame(width: 18, height: 1.5)
                    }
                    Text(isToday ? "Today" : (state.day - daysAgo >= 1 ? "D\(state.day - daysAgo)" : ""))
                        .font(.bodySerif(9.5, italic: true))
                        .foregroundStyle(Color.inkSoft)
                        .fixedSize()
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(height: 86)
    }

    /// Visits by time of day.
    private var phaseChart: some View {
        let phases = record.byPhase.count == 4 ? record.byPhase : [0, 0, 0, 0]
        let total = max(1, phases.reduce(0, +))
        let labels = [("sunrise.fill", "Morning"), ("sun.max.fill", "Midday"), ("sunset.fill", "Evening"), ("moon.stars.fill", "Night")]
        return VStack(spacing: 4) {
            ForEach(0..<4, id: \.self) { index in
                HStack(spacing: 8) {
                    Image(systemName: labels[index].0).font(.system(size: 11, weight: .bold)).foregroundStyle(Color.gold).frame(width: 16)
                    Text(labels[index].1).font(.bodySerif(12)).frame(width: 62, alignment: .leading)
                    GeometryReader { proxy in
                        RoundedRectangle(cornerRadius: 3).fill(tint.opacity(0.55))
                            .frame(width: max(3, proxy.size.width * CGFloat(phases[index]) / CGFloat(total)))
                    }
                    .frame(height: 10)
                    Text("\(Int((Double(phases[index]) / Double(total) * 100).rounded()))%")
                        .font(.mapBold(10)).monospacedDigit().foregroundStyle(Color.inkSoft).frame(width: 34, alignment: .trailing)
                }
            }
        }
    }

    private var regulars: some View {
        let people = state.regulars(of: landmark.id, limit: 8)
        return Group {
            if people.isEmpty {
                note("No familiar faces yet.")
            } else {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 8)], alignment: .leading, spacing: 8) {
                    ForEach(people, id: \.name) { person in
                        HStack(spacing: 8) {
                            Text(initials(person.name))
                                .font(.mapBold(11))
                                .foregroundStyle(Color.card)
                                .frame(width: 28, height: 28)
                                .background(Circle().fill(tint))
                            VStack(alignment: .leading, spacing: 0) {
                                Text(person.name).font(.bodySerif(11.5)).lineLimit(2).fixedSize(horizontal: false, vertical: true)
                                Text(person.visits >= 3 ? "Regular, \(person.visits) visits" : (person.visits == 1 ? "Once" : "\(person.visits) visits"))
                                    .font(.bodySerif(10.5, italic: true)).foregroundStyle(Color.inkSoft)
                            }
                        }
                    }
                }
            }
        }
    }

    private func initials(_ name: String) -> String {
        let first = name.split(separator: ",").first.map(String.init) ?? name
        let words = first.split(separator: " ").filter { $0 != "the" }
        return words.prefix(2).compactMap { $0.first.map(String.init) }.joined()
    }

    private var comments: some View {
        Group {
            if record.comments.isEmpty {
                note("Visitors leave cards now and then. The first one will turn up here.")
            } else {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(alignment: .top, spacing: 10) {
                        ForEach(Array(record.comments.enumerated()), id: \.element.id) { item in
                            commentCard(item.element)
                                .rotationEffect(.degrees(item.offset % 2 == 0 ? -1.5 : 1.2))
                        }
                    }
                    .padding(.vertical, 6)
                    .padding(.horizontal, 2)
                }
            }
        }
    }

    private func commentCard(_ card: CommentCard) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 2) {
                ForEach(0..<card.hearts, id: \.self) { _ in
                    Image(systemName: "heart.fill").font(.system(size: 8)).foregroundStyle(Color.stampRed)
                }
                Spacer()
                Text("Day \(card.day)").font(.bodySerif(10, italic: true)).foregroundStyle(Color.inkSoft)
            }
            Text(card.text).font(.typewriter(11)).fixedSize(horizontal: false, vertical: true)
            Text("— \(card.author)").font(.bodySerif(10.5, italic: true)).foregroundStyle(Color.inkSoft)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(10)
        .frame(width: 180, alignment: .leading)
        .background(
            ZStack(alignment: .leading) {
                Rectangle().fill(Color(uiColor: UIColor(hex: 0xFBF4DA)))
                Rectangle().fill(Color.stampRed.opacity(0.35)).frame(width: 1).padding(.leading, 6)
            }
            .shadow(color: .black.opacity(0.12), radius: 2, x: 1, y: 2)
        )
    }
}


/// A building on a little paper hill against a soft sky in its category's color. The art's own
/// paper base is cropped away, so the building stands in a scene instead of on a shelf.
private struct PostcardScene: View {
    let kind: LandmarkKind
    let tint: Color

    var body: some View {
        GeometryReader { proxy in
            let w = proxy.size.width, h = proxy.size.height
            ZStack(alignment: .bottom) {
                LinearGradient(colors: [tint.opacity(0.10), Color(uiColor: UIColor(hex: 0xFBF4E4))], startPoint: .top, endPoint: .bottom)
                Ellipse()
                    .fill(Color(uiColor: UIColor(hex: 0xBFD4A6)))
                    .frame(width: w * 1.3, height: h * 0.34)
                    .offset(y: h * 0.2)
                if let art = UIImage(named: kind.artName) {
                    // Show the drawing down to the top of its base (84% of its height), so it stands
                    // on the hill rather than on a shelf.
                    let artWidth = min(w * 0.92, h * 0.92 * 240 / 200 / 0.86)
                    let artHeight = artWidth * 200 / 240
                    Image(uiImage: art)
                        .resizable()
                        .frame(width: artWidth, height: artHeight)
                        .frame(width: artWidth, height: artHeight * 0.85, alignment: .top)
                        .clipped()
                        .padding(.bottom, h * 0.08)
                }
            }
            .frame(width: w, height: h)
            .clipped()
        }
    }
}
