import SwiftUI
import UIKit

/// The council session between days, in cut paper: three proposals fanned out like a hand of
/// cards. Tap one to lift it, then approve it, or table them all.
struct CouncilView: View {
    @ObservedObject var state: GameState
    @State private var selected: CouncilCard?
    @State private var approved: CouncilCard?
    @State private var appeared = false

    var body: some View {
        ZStack {
            CouncilBackdrop().ignoresSafeArea()
            GeometryReader { proxy in
                let cards = state.councilOffer
                let count = max(1, cards.count)
                let width = min(250, (proxy.size.width - 90) / CGFloat(count))
                let height = min(320, proxy.size.height - 112)
                VStack(spacing: 10) {
                    header
                    HStack(spacing: -14) {
                        ForEach(Array(cards.enumerated()), id: \.element.id) { item in
                            let card = item.element
                            let tilt = (Double(item.offset) - Double(count - 1) / 2) * 6
                            let isSelected = selected == card
                            ProposalCard(card: card, tint: tint(for: card), isSelected: isSelected,
                                         isApproved: approved == card)
                                .frame(width: width, height: height)
                                .rotationEffect(.degrees(isSelected ? 0 : tilt))
                                .offset(y: isSelected ? -16 : abs(tilt) * 1.4)
                                .scaleEffect(isSelected ? 1.07 : 1)
                                .opacity(approved != nil && approved != card ? 0.35 : 1)
                                .offset(y: approved == card ? -proxy.size.height : 0)
                                .zIndex(isSelected ? 2 : Double(item.offset) * 0.1)
                                .onTapGesture { select(card) }
                                .offset(y: appeared ? 0 : 240)
                                .animation(.spring(response: 0.5, dampingFraction: 0.78).delay(Double(item.offset) * 0.07), value: appeared)
                                .animation(.spring(response: 0.35, dampingFraction: 0.7), value: selected)
                                .accessibilityAddTraits(.isButton)
                        }
                    }
                    actions
                }
                .frame(width: proxy.size.width, height: proxy.size.height)
            }
            .padding(.vertical, 14)
        }
        .onAppear {
            AudioManager.shared.play(.whoosh)
            appeared = true
        }
    }

    private var header: some View {
        VStack(spacing: 1) {
            Text("Council session, day \(state.day)")
                .font(.bodySerif(14, italic: true))
                .foregroundStyle(Color.inkSoft)
            Text(selected == nil ? "Pick a proposal for \(state.townName)" : "Approve this one?")
                .font(.display(24))
                .foregroundStyle(Color.ink)
        }
    }

    private var actions: some View {
        HStack(spacing: 20) {
            Button {
                approve(nil)
            } label: {
                InkButtonLabel(text: "TABLE THEM ALL", symbol: "tray.full.fill", height: 40)
            }
            .buttonStyle(.plain)
            .disabled(approved != nil)
            if let selected {
                Button {
                    approve(selected)
                } label: {
                    InkButtonLabel(text: "APPROVE", symbol: "checkmark.seal.fill", height: 40,
                                   color: Color(uiColor: UIColor(hex: 0xC8553F)))
                }
                .buttonStyle(.plain)
                .disabled(approved != nil)
                .transition(.scale.combined(with: .opacity))
            }
        }
        .animation(.spring(response: 0.3, dampingFraction: 0.75), value: selected)
        .frame(height: 44)
    }

    /// Each department gets its own paper color.
    private func tint(for card: CouncilCard) -> Color {
        let palette: [UInt32] = [0xD98C6F, 0x7FAE69, 0x6F93B5, 0xA597D6, 0xE0A21B, 0xC98A9B]
        let seed = card.department.unicodeScalars.reduce(0) { $0 &+ Int($1.value) }
        return Color(uiColor: UIColor(hex: palette[seed % palette.count]))
    }

    private func select(_ card: CouncilCard) {
        guard approved == nil else { return }
        AudioManager.shared.play(.tick)
        UISelectionFeedbackGenerator().selectionChanged()
        selected = selected == card ? nil : card
    }

    private func approve(_ card: CouncilCard?) {
        guard approved == nil else { return }
        guard let card else {
            AudioManager.shared.play(.whoosh)
            state.closeCouncil(approving: nil)
            return
        }
        AudioManager.shared.play(.stamp)
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        withAnimation(.spring(response: 0.6, dampingFraction: 0.8).delay(0.5)) { approved = card }
        Task {
            try? await Task.sleep(for: .seconds(1.1))
            state.closeCouncil(approving: card)
        }
    }
}

/// Cut-paper chamber: a warm backdrop, the council's columns, and hills along the bottom.
private struct CouncilBackdrop: View {
    var body: some View {
        GeometryReader { proxy in
            let w = proxy.size.width, h = proxy.size.height
            ZStack(alignment: .bottom) {
                Color(uiColor: UIColor(hex: 0xF3E6CC))
                PaperGrain(seed: 41, strength: 1.2)
                HStack(spacing: w / 7) {
                    ForEach(0..<6, id: \.self) { _ in
                        VStack(spacing: 0) {
                            Rectangle().fill(Color(uiColor: UIColor(hex: 0xE7D6B6))).frame(width: 36, height: 10)
                            Rectangle().fill(Color(uiColor: UIColor(hex: 0xEADCC0))).frame(width: 26, height: h * 0.62)
                            Rectangle().fill(Color(uiColor: UIColor(hex: 0xE7D6B6))).frame(width: 36, height: 10)
                        }
                    }
                }
                .frame(maxHeight: .infinity, alignment: .bottom)
                .padding(.bottom, h * 0.12)
                Path { path in
                    path.move(to: CGPoint(x: 0, y: h * 0.86))
                    path.addCurve(to: CGPoint(x: w, y: h * 0.84), control1: CGPoint(x: w * 0.3, y: h * 0.76),
                                  control2: CGPoint(x: w * 0.7, y: h * 0.92))
                    path.addLine(to: CGPoint(x: w, y: h)); path.addLine(to: CGPoint(x: 0, y: h))
                }
                .fill(Color(uiColor: UIColor(hex: 0xBFD4A6)))
                Path { path in
                    path.move(to: CGPoint(x: 0, y: h * 0.93))
                    path.addCurve(to: CGPoint(x: w, y: h * 0.9), control1: CGPoint(x: w * 0.4, y: h * 0.86),
                                  control2: CGPoint(x: w * 0.75, y: h * 0.98))
                    path.addLine(to: CGPoint(x: w, y: h)); path.addLine(to: CGPoint(x: 0, y: h))
                }
                .fill(Color(uiColor: UIColor(hex: 0x9DBF86)))
            }
        }
    }
}

/// One proposal: a paper card with a colored department band, a medallion, the pitch, and the
/// effect.
private struct ProposalCard: View {
    let card: CouncilCard
    let tint: Color
    let isSelected: Bool
    let isApproved: Bool

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                Image(systemName: card.symbol)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.card)
                Text(card.department.uppercased())
                    .font(.mapBold(9.5))
                    .kerning(1)
                    .foregroundStyle(Color.card)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 2)
                Text(card.duration.label)
                    .font(.bodySerif(10.5, italic: true))
                    .foregroundStyle(Color.card.opacity(0.92))
                    .fixedSize()
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(tint)
            // Everything is shown in full; a long proposal scrolls inside the card rather than
            // being cut short.
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 7) {
                    Text(card.title)
                        .font(.display(17))
                        .foregroundStyle(Color.ink)
                        .fixedSize(horizontal: false, vertical: true)
                    (Text("“\(card.quote)”").font(.bodySerif(11.5, italic: true)).foregroundColor(Color.ink)
                     + Text("  — \(card.councillor)").font(.bodySerif(11)).foregroundColor(Color.inkSoft))
                        .lineSpacing(1.5)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(card.effect)
                        .font(.mapBold(12))
                        .foregroundStyle(Color.ink)
                        .fixedSize(horizontal: false, vertical: true)
                        .padding(8)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(RoundedRectangle(cornerRadius: 8).fill(tint.opacity(0.16)))
                }
                .padding(10)
            }
        }
        .background(PaperPanel(cornerRadius: 12))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(tint, lineWidth: isSelected ? 3 : 0))
        .overlay {
            if isApproved {
                RubberStamp(text: "APPROVED", color: .stampRed)
                    .transition(.scale(scale: 2.4).combined(with: .opacity))
            }
        }
    }
}
