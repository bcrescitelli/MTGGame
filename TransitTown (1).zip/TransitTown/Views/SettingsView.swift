import SwiftUI
import UIKit

/// Sound, how to play, and starting over.
struct SettingsView: View {
    @ObservedObject var state: GameState
    @ObservedObject private var audio = AudioManager.shared
    let showHelp: () -> Void
    let onNewCity: () -> Void
    let dismiss: () -> Void
    @State private var confirmNew = false

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Settings")
                    .font(.display(26))
                    .foregroundStyle(Color.ink)
                Spacer()
                Button(action: dismiss) {
                    Image(systemName: "xmark")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(Color.ink)
                        .frame(width: 30, height: 30)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Close settings")
            }

            InkCheckbox(isOn: Binding(get: { !audio.isMuted }, set: { audio.isMuted = !$0 }), label: "Sound on")

            slider("Music", symbol: "music.note", value: $audio.musicVolume)
            slider("City sounds", symbol: "building.2.fill", value: $audio.cityVolume)
            slider("Effects", symbol: "hand.draw.fill", value: $audio.effectsVolume)

            Rectangle().fill(Color.ink.opacity(0.15)).frame(height: 1)

            HStack(spacing: 10) {
                Button(action: showHelp) {
                    InkButtonLabel(text: "HOW TO PLAY", filled: false, height: 36)
                }
                .buttonStyle(.plain)
                Spacer()
                Button {
                    confirmNew = true
                } label: {
                    InkButtonLabel(text: "NEW CITY", filled: false, height: 36, color: .bad)
                }
                .buttonStyle(.plain)
            }
            Text("\(state.townName) saves automatically at the end of each day and whenever you leave.")
                .font(.bodySerif(12, italic: true))
                .foregroundStyle(Color.inkSoft)
        }
        .foregroundStyle(Color.ink)
        .padding(20)
        .frame(width: 380)
        .background(PaperCard())
        .paperAlert("Start a new city?", isPresented: $confirmNew,
                    message: "\(state.townName) will be replaced. This can't be undone.",
                    confirm: "Start over", confirmColor: Color.stampRed, action: onNewCity)
    }

    private func slider(_ title: String, symbol: String, value: Binding<Double>) -> some View {
        HStack(spacing: 10) {
            Label(title, systemImage: symbol)
                .font(.bodySerif(15))
                .frame(width: 140, alignment: .leading)
            Slider(value: value, in: 0...1)
                .tint(Color.ink)
                .disabled(audio.isMuted)
        }
    }
}
