import SwiftUI
import UIKit

/// A resident out and about: who they are, where they're headed, and whether a line will get
/// them there. Get them to their stop and they'll wave when they arrive.
struct SpotlightCardView: View {
    @ObservedObject var state: GameState
    let info: SpotlightInfo

    var body: some View {
        let resident = Cast.resident(info.residentID)
        let origin = state.landmark(id: info.originID)?.kind.info.name ?? "the station"
        let destination = state.landmark(id: info.destinationID)?.kind.info.name ?? "somewhere"
        let routed = state.waiting[info.originID]?.first(where: { $0.id == info.id })?.hasRoute ?? false
        return HStack(alignment: .top, spacing: 12) {
            Image(systemName: "star.fill")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(Color.gold)
                .frame(width: 36, height: 36)
                .background(Circle().fill(Color.gold.opacity(0.16)))
            VStack(alignment: .leading, spacing: 4) {
                Text(resident.map { "\($0.name), \($0.role)" } ?? "A familiar face")
                    .font(.display(16))
                    .fixedSize(horizontal: false, vertical: true)
                Text("Waiting at the \(origin), off to the \(destination).")
                    .font(.bodySerif(13))
                    .fixedSize(horizontal: false, vertical: true)
                Text(routed ? "A line will take them there. Watch for a wave when they arrive."
                            : "No line goes there yet. Connect the two, and they'll be on their way.")
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 8) {
                    Button {
                        AudioManager.shared.play(.tick)
                        state.cameraFocusLandmarkID = info.destinationID
                    } label: {
                        InkButtonLabel(text: "SHOW ME WHERE", symbol: "mappin.and.ellipse", height: 30)
                    }
                    .buttonStyle(.plain)
                    Button {
                        state.spotlightCard = nil
                    } label: {
                        InkButtonLabel(text: "CLOSE", filled: false, height: 30)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.top, 2)
            }
        }
        .foregroundStyle(Color.ink)
        .padding(14)
        .frame(width: 400)
        .background(PaperPanel(cornerRadius: 12))
        .overlay(alignment: .top) { PaperTape() }
    }
}
