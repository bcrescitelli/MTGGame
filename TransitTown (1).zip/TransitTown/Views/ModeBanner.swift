import SwiftUI
import UIKit

/// One slim strip that says what your next touch will do, with that tool's controls:
/// a line's trains and delete, or Cancel while placing. Done puts the tool down.
struct ModeBanner: View {
    @ObservedObject var state: GameState

    var body: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(color)
                .frame(width: 12, height: 12)
            Text(state.message ?? title)
                .font(state.message == nil ? .display(15) : .bodySerif(13, italic: true))
                .foregroundStyle(state.message == nil ? Color.ink : Color.stampRed)
                .lineLimit(1)
                .minimumScaleFactor(0.85)
            if let step = state.tunnelStep {
                Text(tunnelHint(step))
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .lineLimit(1)
                    .minimumScaleFactor(0.85)
                Button {
                    AudioManager.shared.play(.tick)
                    state.cancelTunnel()
                } label: {
                    InkButtonLabel(text: "CANCEL TUNNEL", filled: false, height: 28)
                }
                .buttonStyle(.plain)
            } else if let line = editableLine {
                let trains = state.trainsPerLine[line.id] ?? 0
                Text("\(Format.count(line.stops.count, "stop")), \(Format.count(trains, "train"))")
                    .font(.bodySerif(12, italic: true))
                    .foregroundStyle(Color.inkSoft)
                    .lineLimit(1)
                    .fixedSize()
                Button {
                    AudioManager.shared.play(.chunk, volume: 0.8)
                    state.addTrain(to: line.id)
                } label: {
                    InkButtonLabel(text: trains >= GameState.maxTrainsPerLine ? "MAX" : "+ TRAIN $\(state.nextTrainCost)",
                                   filled: false, height: 28)
                }
                .buttonStyle(.plain)
                .disabled(!state.canAddTrain(to: line.id))
                .opacity(state.canAddTrain(to: line.id) ? 1 : 0.5)
                if state.trainCount(for: line.id) > 0 {
                    Button {
                        AudioManager.shared.play(.tick)
                        state.upgradingLineID = line.id
                    } label: {
                        InkButtonLabel(text: "UPGRADE", filled: false, symbol: "arrow.up.circle.fill", height: 28)
                    }
                    .buttonStyle(.plain)
                }
                Button {
                    AudioManager.shared.play(.stamp)
                    state.beginTunnel(for: line.id)
                } label: {
                    InkButtonLabel(text: "+ TUNNEL $\(GameState.tunnelCost)", filled: false, height: 28)
                }
                .buttonStyle(.plain)
                .disabled(!state.canAfford(GameState.tunnelCost))
                .opacity(state.canAfford(GameState.tunnelCost) ? 1 : 0.5)
                Button {
                    if let line = editableLine { state.deleteLinePrompt = line.id }
                } label: {
                    Image(systemName: "trash")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color.stampRed)
                        .frame(width: 28, height: 28)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Delete the \(line.name)")
            }
            Button {
                state.placingKind = nil
                state.placingIsPermit = false
                state.setSelectedLine(nil)
                state.armedColorIndex = nil
            } label: {
                InkButtonLabel(text: state.placingKind != nil ? "CANCEL" : "DONE", height: 28)
            }
            .buttonStyle(.plain)
        }
        .padding(.leading, 12)
        .padding(.trailing, 5)
        .frame(height: 38)
        .background(PaperPill())
    }

    /// The next step of digging a tunnel, in plain words.
    private func tunnelHint(_ step: TunnelStep) -> String {
        let name = state.line(id: step.lineID)?.name ?? "line"
        switch step {
        case .entrance: return "Tap open ground to dig the entrance"
        case .exit: return "Tap open ground for the exit"
        case .connectIn: return "Drag the \(name) into the tunnel entrance"
        case .connectOut: return "Now drag it out of the tunnel to a landmark. You pay when it connects."
        }
    }

    /// The subway line being edited, if any (light rail keeps its own tray).
    private var editableLine: TransitLine? {
        guard state.placingKind == nil, let id = state.selectedLineID, let line = state.line(id: id), !line.isLightRail else { return nil }
        return line
    }

    private var color: Color {
        if let kind = state.placingKind { return Color(uiColor: kind.info.category.color) }
        if let id = state.selectedLineID, let line = state.line(id: id) { return Color(uiColor: line.color) }
        if let index = state.armedColorIndex { return Color(uiColor: Palette.lines[index]) }
        return .ink
    }

    private var title: String {
        if let kind = state.placingKind {
            return state.placingIsPermit ? "Tap a marked square for the \(kind.info.category.name.lowercased()) lot" : "Tap a marked square"
        }
        if let id = state.selectedLineID, let line = state.line(id: id) { return line.name }
        if let index = state.armedColorIndex { return "Drag from a station to start the \(Palette.lineNames[index])" }
        return ""
    }
}
