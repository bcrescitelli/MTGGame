import SwiftUI
import UIKit

/// The letter that opens each term, written like a real letter from the Town Clerk: letterhead,
/// fold creases, typed paragraphs, a signature with a flourish, an official stamp, and the
/// council's hopes on an index card clipped to the corner.
struct AppointmentLetterView: View {
    @ObservedObject var state: GameState
    let onAccept: () -> Void
    @State private var appeared = false

    var body: some View {
        ZStack {
            Color.ink.opacity(0.55).ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                letter
                    .frame(maxWidth: 780)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .rotationEffect(.degrees(appeared ? 0.4 : -3))
            .offset(y: appeared ? 0 : 40)
            .opacity(appeared ? 1 : 0)
        }
        .onAppear {
            withAnimation(.spring(response: 0.55, dampingFraction: 0.85)) { appeared = true }
        }
    }

    private var district: District { state.currentDistrict }

    private var letter: some View {
        VStack(spacing: 12) {
            letterhead
            HStack(alignment: .top, spacing: 26) {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("Dear Mayor,")
                            .font(.displayItalic(19))
                        Spacer()
                        Text(state.termNumber == 1 ? "Your first day as mayor" : "Day 1")
                            .font(.bodySerif(12, italic: true))
                    }
                    ForEach(Array(paragraphs.enumerated()), id: \.offset) { item in
                        Text(item.element)
                            .font(.typewriter(13))
                            .lineSpacing(4)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    signature
                }
                .foregroundStyle(Color.ink)
                .frame(maxWidth: .infinity, alignment: .leading)

                VStack(alignment: .center, spacing: 18) {
                    hopesCard
                    Button(action: onAccept) {
                        InkButtonLabel(text: state.termNumber == 1 ? "ACCEPT THE KEYS" : "ON TO \(district.name.uppercased())",
                                       symbol: state.termNumber == 1 ? "key.fill" : "arrow.right", height: 44)
                    }
                    .buttonStyle(.plain)
                }
                .frame(width: 240)
            }
        }
        .padding(.horizontal, 30)
        .padding(.vertical, 22)
        .background(
            ZStack {
                Rectangle().fill(Color.black.opacity(0.3)).offset(x: 4, y: 6)
                PrintedPaper(color: Color(uiColor: UIColor(hex: 0xF6F0E1)), seed: 41)
                folds
            }
        )
    }

    // MARK: Letterhead

    private var letterhead: some View {
        VStack(spacing: 4) {
            HStack(alignment: .center, spacing: 14) {
                crest
                VStack(spacing: 2) {
                    Text("TOWN OF \(state.townName.uppercased())")
                        .font(.mapBold(13))
                        .kerning(3)
                    Text(state.termNumber == 1 ? "Office of the Town Clerk" : "Office of the Town Clerk")
                        .font(.bodySerif(13, italic: true))
                }
                crest
            }
            .foregroundStyle(Color.ink)
            DoubleRule()
                .padding(.top, 4)
        }
    }

    /// The town crest: the clock tower, pressed in ink inside a ring.
    private var crest: some View {
        ZStack {
            Circle().stroke(Color.ink, lineWidth: 1.4)
            Circle().stroke(Color.ink.opacity(0.5), lineWidth: 0.6).padding(3)
            if let art = UIImage(named: "line-clockTower") {
                Image(uiImage: art)
                    .renderingMode(.template)
                    .resizable()
                    .scaledToFit()
                    .foregroundStyle(Color.ink)
                    .padding(8)
            }
        }
        .frame(width: 40, height: 40)
    }

    // MARK: Signature and stamp

    private var signature: some View {
        HStack(alignment: .bottom, spacing: 16) {
            VStack(alignment: .leading, spacing: 0) {
                Text("Yours, with keys enclosed,")
                    .font(.bodySerif(13))
                Text("Edna Pike")
                    .font(.displayItalic(30))
                    .padding(.top, 2)
                // A pen flourish under the name.
                Path { path in
                    path.move(to: CGPoint(x: 2, y: 6))
                    path.addCurve(to: CGPoint(x: 120, y: 3), control1: CGPoint(x: 40, y: 14), control2: CGPoint(x: 80, y: -6))
                    path.addQuadCurve(to: CGPoint(x: 100, y: 9), control: CGPoint(x: 128, y: 10))
                }
                .stroke(Color.ink, style: StrokeStyle(lineWidth: 1.4, lineCap: .round))
                .frame(width: 130, height: 14)
                Text("Town Clerk")
                    .font(.mapSemibold(10))
                    .kerning(1.2)
            }
            RubberStamp(text: "OFFICIAL", color: .stampRed, angle: -11, size: 15)
                .padding(.bottom, 16)
        }
        .padding(.top, 4)
    }

    // MARK: The council's hopes

    /// An index card clipped to the letter, with a red margin line and ruled lines.
    private var hopesCard: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("The council hopes you will…")
                .font(.bodySerif(13, italic: true))
                .padding(.bottom, 6)
            ForEach(Array(state.goals.enumerated()), id: \.offset) { item in
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(["i.", "ii.", "iii.", "iv."][min(item.offset, 3)])
                        .font(.bodySerif(12, italic: true))
                        .frame(width: 20, alignment: .trailing)
                    Text(state.progress(for: item.element).text)
                        .font(.bodySerif(13))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.vertical, 5)
                .overlay(alignment: .bottom) {
                    Rectangle().fill(Color(uiColor: UIColor(hex: 0x8FB4D9)).opacity(0.6)).frame(height: 0.7)
                }
            }
        }
        .foregroundStyle(Color.ink)
        .padding(.leading, 18)
        .padding(.trailing, 12)
        .padding(.vertical, 12)
        .background(
            ZStack(alignment: .leading) {
                Rectangle().fill(Color.ink.opacity(0.18)).offset(x: 2, y: 3)
                Rectangle().fill(Color.card)
                PaperGrain(seed: 9, strength: 1.5)
                Rectangle().fill(Color.stampRed.opacity(0.55)).frame(width: 1).padding(.leading, 10)
            }
        )
        .overlay(alignment: .topTrailing) { paperclip.offset(x: -18, y: -12) }
        .rotationEffect(.degrees(1.6))
    }

    private var paperclip: some View {
        Path { path in
            path.move(to: CGPoint(x: 4, y: 30))
            path.addLine(to: CGPoint(x: 4, y: 6))
            path.addArc(center: CGPoint(x: 9, y: 6), radius: 5, startAngle: .degrees(180), endAngle: .degrees(0), clockwise: false)
            path.addLine(to: CGPoint(x: 14, y: 34))
            path.addArc(center: CGPoint(x: 10, y: 34), radius: 4, startAngle: .degrees(0), endAngle: .degrees(180), clockwise: false)
            path.addLine(to: CGPoint(x: 6, y: 10))
        }
        .stroke(Color(uiColor: UIColor(hex: 0x8C8F96)), style: StrokeStyle(lineWidth: 2, lineCap: .round, lineJoin: .round))
        .frame(width: 18, height: 40)
    }

    /// Two creases where the letter was folded into thirds.
    private var folds: some View {
        GeometryReader { proxy in
            ForEach([1.0 / 3.0, 2.0 / 3.0], id: \.self) { fraction in
                LinearGradient(colors: [Color.black.opacity(0.06), Color.white.opacity(0.35), Color.clear],
                               startPoint: .top, endPoint: .bottom)
                    .frame(height: 6)
                    .offset(y: proxy.size.height * fraction - 3)
            }
        }
        .allowsHitTesting(false)
    }

    private var paragraphs: [String] {
        let town = state.townName
        switch district {
        case .oldTown:
            return [
                "Congratulations on your appointment. You'll find \(town) a little worse for wear. The trains have sat silent for twenty years, half of Main Street is boarded up, and the bakery keeps asking when you'll stop by.",
                "The council has one request: bring the trains back. People will follow, and so will everything else.",
                "There's no deadline. Take your time, and enjoy it. The keys to Central Station are enclosed.",
            ]
        case .harborside:
            return [
                "The council has voted to reopen Harborside. Its station has been shut since the last ferry left, but the fish market still opens at five, and the gulls never stopped coming.",
                "Lay light rail across the canal from Central Station to Harbor Station, and the whole city can come down to the water. Riders crossing districts are patient, and pay well.",
                "Old Town will keep running on the lines you've built. Take Harborside at your own pace.",
            ]
        case .hillQuarter:
            return [
                "The Hill Quarter has been waiting patiently above the rest of us: greenhouses, studios, and the Grand Hotel's dusty chandelier.",
                "Extend the light rail from Harbor Station up to Hilltop Station. Midday is when the Hill comes alive.",
                "The city you've built so far will look after itself. Take the Hill at your own pace.",
            ]
        case .lanternRow:
            return [
                "And now, Lantern Row. The theatre district wakes when the rest of the city goes to bed: the night market, the cinema, and, if you can manage it, the Lyric Theatre.",
                "Carry the light rail to Lantern Row Station, and plan for evenings that run late.",
                "This is the last district on the map. Take all the time you like. Make it a good show.",
            ]
        }
    }
}
