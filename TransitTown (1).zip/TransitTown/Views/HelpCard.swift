import SwiftUI
import UIKit

/// How to play, printed like a railway timetable: numbered duties, dotted leaders, and where
/// to find each one.
struct HelpCard: View {
    let dismiss: () -> Void

    private struct Duty: Identifiable {
        let id: Int
        let duty: String
        let how: String
        let place: String
    }

    private let duties: [Duty] = [
        Duty(id: 1, duty: "Draw a line", how: "Drag from one place to another", place: "Map"),
        Duty(id: 2, duty: "Extend a line", how: "Drag either end onward", place: "Map"),
        Duty(id: 3, duty: "Add a stop", how: "Drag a line's middle onto a place", place: "Map"),
        Duty(id: 4, duty: "Pick up a pen", how: "Lines, trains, and upgrades", place: "Menu"),
        Duty(id: 5, duty: "Change trains", how: "Only at transit hubs, $1 a change", place: "Hubs"),
        Duty(id: 6, duty: "Dig a tunnel", how: "A faster shortcut under town, $300", place: "Line strip"),
        Duty(id: 7, duty: "Move a landmark", how: "Hold it, then drag", place: "Map"),
        Duty(id: 8, duty: "Decorate", how: "Trees and benches; shake trees for fruit", place: "Green pen"),
        Duty(id: 9, duty: "Mind closures", how: "Redraw around storms and roadworks", place: "The bell"),
        Duty(id: 10, duty: "Read the paper", how: "Tomorrow's weather and events", place: "Gazette"),
    ]

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Timetable of the Mayor's Duties")
                        .font(.display(24))
                    Text("Posted at every platform, by order of the Town Clerk")
                        .font(.bodySerif(12, italic: true))
                }
                Spacer()
                Button(action: dismiss) {
                    InkButtonLabel(text: "GOT IT", height: 34)
                }
                .buttonStyle(.plain)
            }
            DoubleRule()
            HStack(alignment: .top, spacing: 18) {
                column(Array(duties.prefix(5)))
                Rectangle().fill(Color.ink.opacity(0.4)).frame(width: 0.8)
                column(Array(duties.suffix(5)))
            }
            .fixedSize(horizontal: false, vertical: true)
            Rectangle().fill(Color.ink).frame(height: 0.8)
            HStack(spacing: 6) {
                ForEach(0..<Palette.lineCount, id: \.self) { index in
                    Rectangle().fill(Color(uiColor: Palette.lines[index])).frame(width: 22, height: 4)
                }
                Text("Services run daily, weather permitting.")
                    .font(.bodySerif(11, italic: true))
                    .padding(.leading, 6)
            }
        }
        .foregroundStyle(Color.ink)
        .padding(.horizontal, 22)
        .padding(.vertical, 16)
        .frame(maxWidth: 700)
        .background(
            ZStack {
                Rectangle().fill(Color.black.opacity(0.3)).offset(x: 4, y: 6)
                PrintedPaper(seed: 61)
                Rectangle().stroke(Color.ink, lineWidth: 1.2).padding(6)
            }
        )
        .padding(.horizontal, 20)
    }

    private func column(_ items: [Duty]) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                SmallCapsHeading(text: "No.", size: 9.5)
                    .frame(width: 26, alignment: .leading)
                SmallCapsHeading(text: "Duty", size: 9.5)
                Spacer()
                SmallCapsHeading(text: "Where", size: 9.5)
            }
            .padding(.bottom, 4)
            ForEach(items) { item in
                HStack(alignment: .firstTextBaseline, spacing: 0) {
                    Text("\(item.id)")
                        .font(.mapBold(12))
                        .frame(width: 26, alignment: .leading)
                    VStack(alignment: .leading, spacing: 1) {
                        HStack(alignment: .lastTextBaseline, spacing: 4) {
                            Text(item.duty)
                                .font(.bodySerif(14))
                            Leader()
                            Text(item.place)
                                .font(.bodySerif(12, italic: true))
                        }
                        Text(item.how)
                            .font(.bodySerif(11.5, italic: true))
                            .foregroundStyle(Color.inkSoft)
                    }
                }
                .padding(.vertical, 5)
                .overlay(alignment: .bottom) {
                    Rectangle().fill(Color.ink.opacity(0.15)).frame(height: 0.6)
                }
            }
        }
    }
}

/// Dotted line between a duty and where to find it.
private struct Leader: View {
    var body: some View {
        GeometryReader { proxy in
            Path { path in
                path.move(to: CGPoint(x: 0, y: proxy.size.height - 3))
                path.addLine(to: CGPoint(x: proxy.size.width, y: proxy.size.height - 3))
            }
            .stroke(Color.ink.opacity(0.4), style: StrokeStyle(lineWidth: 1, dash: [1, 3]))
        }
        .frame(height: 12)
    }
}
