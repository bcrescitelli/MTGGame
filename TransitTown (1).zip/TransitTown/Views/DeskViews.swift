import SwiftUI
import UIKit

/// Letters to the Mayor, dropping down from the envelope in the top bar.
struct LettersView: View {
    @ObservedObject var state: GameState
    let dismiss: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Letters to the Mayor")
                    .font(.display(19))
                    .foregroundStyle(Color.ink)
                Spacer()
                Button(action: dismiss) {
                    Image(systemName: "xmark")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.inkSoft)
                        .frame(width: 26, height: 26)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Close letters")
            }
            if state.letters.isEmpty {
                Text("No post today. Residents write in from the second day on.")
                    .font(.bodySerif(13, italic: true))
                    .foregroundStyle(Color.inkSoft)
            } else {
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(state.letters.reversed()) { letter in
                            letterCard(letter)
                        }
                    }
                }
                .frame(maxHeight: 250)
            }
        }
        .padding(14)
        .frame(width: 350)
        .background(PaperPanel(cornerRadius: 16))
        .onAppear { state.unreadLetters = 0 }
    }

    private func letterCard(_ letter: Letter) -> some View {
        let settled = letter.status != .open
        return VStack(alignment: .leading, spacing: 5) {
            HStack(alignment: .firstTextBaseline) {
                Text(letter.sender)
                    .font(.display(16))
                    .foregroundStyle(Color.ink)
                Text(letter.role)
                    .font(.bodySerif(11, italic: true))
                    .foregroundStyle(Color.inkSoft)
                Spacer()
                Text(status(letter))
                    .font(.mapBold(9))
                    .kerning(1)
                    .foregroundStyle(letter.status == .answered ? Color.good : (letter.status == .missed ? Color.bad : Color.inkSoft))
            }
            Text(letter.body)
                .font(.typewriter(12))
                .foregroundStyle(Color.ink)
                .fixedSize(horizontal: false, vertical: true)
            if !settled {
                HStack(alignment: .top, spacing: 6) {
                    Image(systemName: "envelope.open.fill")
                        .font(.system(size: 10, weight: .bold))
                    Text(state.letterProgressText(letter))
                        .font(.mapSemibold(11))
                        .fixedSize(horizontal: false, vertical: true)
                }
                .foregroundStyle(Color.ink)
                Text("REWARD $\(letter.reward)\(letter.conflictsWith != nil ? "   A NEIGHBOR DISAGREES" : "")")
                    .font(.mapBold(9))
                    .kerning(0.8)
                    .foregroundStyle(Color.inkSoft)
            }
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 6)
                .fill(Color.newsprint)
                .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.ink.opacity(0.25), lineWidth: 1))
        )
        .opacity(settled ? 0.75 : 1)
        .overlay(alignment: .topTrailing) {
            if settled {
                RubberStamp(text: letter.status == .answered ? "ANSWERED" : "MISSED",
                            color: letter.status == .answered ? .good : .stampRed, angle: -9, size: 13)
                    .padding(.top, 22)
                    .padding(.trailing, 8)
            }
        }
    }

    private func status(_ letter: Letter) -> String {
        switch letter.status {
        case .answered: return "ANSWERED"
        case .missed: return "MISSED"
        case .open: return letter.dueDay <= state.day ? "DUE TODAY" : "DUE DAY \(letter.dueDay)"
        }
    }
}

/// A quick choice mid-day. The day waits until the mayor picks one.
struct SnapDecisionView: View {
    @ObservedObject var state: GameState
    let decision: SnapDecision

    var body: some View {
        ZStack {
            Color.ink.opacity(0.35).ignoresSafeArea()
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 8) {
                    Image(systemName: decision.symbol)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(Color.card)
                        .frame(width: 28, height: 28)
                        .background(Circle().fill(Color.ink))
                    Text("A quick decision")
                        .font(.bodySerif(13, italic: true))
                        .foregroundStyle(Color.inkSoft)
                }
                Text(decision.title)
                    .font(.display(24))
                    .foregroundStyle(Color.ink)
                Text(decision.body)
                    .font(.bodySerif(14))
                    .foregroundStyle(Color.ink)
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 12) {
                    choiceButton(decision.first, primary: true)
                    choiceButton(decision.second, primary: false)
                }
            }
            .padding(20)
            .frame(width: 440)
            .background(PaperCard())
        }
    }

    private func choiceButton(_ choice: DecisionChoice, primary: Bool) -> some View {
        Button {
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
            state.choose(choice)
        } label: {
            InkButtonLabel(text: choice.label.uppercased(), filled: primary, height: 40)
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.plain)
    }
}

/// Tap any open station: what's happening there, and upgrades to buy.
struct StationCardView: View {
    @ObservedObject var state: GameState
    let stationID: Int
    let dismiss: () -> Void

    var body: some View {
        if let landmark = state.landmark(id: stationID), landmark.isUnderConstruction {
            construction(landmark)
        } else if let landmark = state.landmark(id: stationID) {
            let info = landmark.kind.info
            VStack(alignment: .leading, spacing: 10) {
                HStack(alignment: .top) {
                    StampView(kind: landmark.kind, style: .normal, size: 40)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(info.name)
                            .font(.display(19))
                            .foregroundStyle(Color.ink)
                        Text(summary(landmark))
                            .font(.mapSemibold(10))
                            .kerning(0.6)
                            .foregroundStyle(Color.inkSoft)
                        if let keeper = landmark.shopkeeper {
                            Text("Run by \(keeper)")
                                .font(.bodySerif(12, italic: true))
                                .foregroundStyle(Color.ink)
                        }
                    }
                    Spacer()
                    Button(action: dismiss) {
                        Image(systemName: "xmark")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(Color.inkSoft)
                            .frame(width: 26, height: 26)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Close")
                }
                SmallCapsHeading(text: "Station upgrades", size: 11, color: .inkSoft)
                ForEach(StationUpgrade.allCases) { upgrade in
                    upgradeRow(upgrade)
                }
            }
            .padding(14)
            .frame(width: 330)
            .background(PaperPanel(cornerRadius: 16))
        }
    }

    /// A building site: how far along it is, and the option to finish now for a Golden Ticket.
    private func construction(_ landmark: Landmark) -> some View {
        let remaining = Int((landmark.constructionRemaining ?? 0).rounded(.up))
        let ticketCost = state.rushTickets(for: landmark)
        return VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Under construction")
                        .font(.display(19))
                    Text("Someone's moving in. Who could it be?")
                        .font(.bodySerif(12, italic: true))
                        .foregroundStyle(Color.inkSoft)
                }
                Spacer()
                Button(action: dismiss) {
                    Image(systemName: "xmark")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(Color.inkSoft)
                        .frame(width: 26, height: 26)
                }
                .buttonStyle(.plain)
            }
            ProgressStrip(fraction: landmark.constructionProgress, tint: .gold)
            Text("Opening in about \(Format.duration(remaining)). Building carries on while you're away.")
                .fixedSize(horizontal: false, vertical: true)
                .font(.bodySerif(12))
            Button {
                AudioManager.shared.play(.chunk)
                state.rushConstruction(landmark.id)
                dismiss()
            } label: {
                InkButtonLabel(text: "FINISH NOW FOR \(ticketCost) GOLDEN TICKET\(ticketCost == 1 ? "" : "S")", symbol: "ticket.fill", height: 34)
            }
            .buttonStyle(.plain)
            .disabled(state.tickets < ticketCost)
            .opacity(state.tickets < ticketCost ? 0.5 : 1)
        }
        .foregroundStyle(Color.ink)
        .padding(14)
        .frame(width: 330)
        .background(PaperPanel(cornerRadius: 16))
        .overlay(alignment: .top) { PaperTape() }
    }

    private func summary(_ landmark: Landmark) -> String {
        let lines = state.subwayLinesServing(stationID).count
        let waiting = state.waitingCount(at: stationID)
        var parts = ["\(lines)/\(state.maxLines(at: stationID)) LINES",
                     "\(waiting)/\(state.maxWaiting(at: stationID)) WAITING"]
        if state.isStationClosed(stationID) { parts.append("CLOSED TODAY") }
        return parts.joined(separator: "   ")
    }

    private func upgradeRow(_ upgrade: StationUpgrade) -> some View {
        let owned = state.hasUpgrade(upgrade, at: stationID)
        return HStack(spacing: 10) {
            Image(systemName: upgrade.symbol)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(owned ? Color.good : Color.ink)
                .frame(width: 22)
            VStack(alignment: .leading, spacing: 1) {
                Text(upgrade.title)
                    .font(.display(14))
                    .foregroundStyle(Color.ink)
                Text(upgrade.effect)
                    .font(.bodySerif(11))
                    .foregroundStyle(Color.ink)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 4)
            if owned {
                Text("BUILT")
                    .font(.mapBold(10))
                    .kerning(0.8)
                    .foregroundStyle(Color.good)
            } else {
                Button {
                    state.buyUpgrade(upgrade, at: stationID)
                    AudioManager.shared.playPlaceLandmark()
                } label: {
                    Text("$\(upgrade.cost)")
                        .font(.mapBold(12))
                        .foregroundStyle(Color.card)
                        .padding(.horizontal, 10)
                        .frame(height: 26)
                        .background(RoundedRectangle(cornerRadius: 3).fill(state.canBuyUpgrade(upgrade, at: stationID) ? Color.ink : Color.inkSoft.opacity(0.5)))
                }
                .buttonStyle(.plain)
                .disabled(!state.canBuyUpgrade(upgrade, at: stationID))
            }
        }
    }
}
