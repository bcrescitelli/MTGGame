import SwiftUI

/// Short message shown under the top bar, printed on a ticket stub.
struct ToastView: View {
    let text: String

    var body: some View {
        // Typed as Text so `.font` resolves to Text's own modifier, not the general View version.
        let label: Text = Text(text)
            .font(Font.bodySerif(14))
        let tag: Text = Text("NOTICE")
            .font(Font.mapBold(9))

        return HStack(spacing: 10) {
            tag
                .kerning(1.6)
                .foregroundStyle(Color.stampRed)
            Rectangle()
                .fill(Color.ink.opacity(0.3))
                .frame(width: 1, height: 16)
            label
                .foregroundStyle(Color.ink)
                .multilineTextAlignment(.leading)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 8)
        .background(
            ZStack {
                TicketShape().fill(Color.ink.opacity(0.16)).offset(x: 1, y: 2)
                TicketShape().fill(Color.card)
                PaperGrain(seed: 3).clipShape(TicketShape())
                TicketShape().stroke(Color.ink, lineWidth: 1.4)
            }
        )
    }
}
