import SwiftUI

/// Five stars with halves, for the town rating.
struct StarRating: View {
    let rating: Double
    var size: CGFloat = 11
    var color: Color = .gold

    var body: some View {
        HStack(spacing: 1) {
            ForEach(0..<5, id: \.self) { index in
                Image(systemName: symbol(for: index))
                    .font(.system(size: size, weight: .bold))
                    .foregroundStyle(color)
            }
        }
        .accessibilityElement()
        .accessibilityLabel("Town rating \(String(format: "%.1f", rating)) of 5")
    }

    private func symbol(for index: Int) -> String {
        let value = rating - Double(index)
        if value >= 0.75 { return "star.fill" }
        if value >= 0.25 { return "star.leadinghalf.filled" }
        return "star"
    }
}
