import SwiftUI
import UIKit

/// The top bar. Left: the town, day, and today's conditions (tap for details and goals).
/// Right: treasury, rating with the on-screen district's revival, attention, Blueprints, settings.
/// Nothing here truncates: everything is either short or an icon.
struct HUDView: View {
    @ObservedObject var state: GameState
    @Binding var showTownPanel: Bool
    @Binding var showSettings: Bool
    @Binding var showLetters: Bool

    var body: some View {
        HStack(spacing: 8) {
            dayPill
            Spacer(minLength: 4)
            faresPill.fixedSize()
            ratingPill.fixedSize()
            if state.hotlineUnlocked { lettersButton }
            attentionButton
            blueprintsButton.fixedSize()
            iconButton("book.fill", label: "The Town Album") {
                AudioManager.shared.play(.whoosh, volume: 0.6)
                state.albumLandmarkID = nil
                state.isAlbumOpen = true
            }
        }
    }

    // MARK: Town and day

    private var dayPill: some View {
        let hud = state.hud
        let dayText = "DAY \(hud.day)"
        return Button {
            showTownPanel.toggle()
        } label: {
            HStack(spacing: 6) {
                Image(systemName: hud.phase.symbol)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.gold)
                Text("\(dayText), \(hud.phase.name.uppercased())")
                    .font(.mapBold(13))
                    .kerning(0.5)
                    .foregroundStyle(Color.ink)
                    .lineLimit(1)
                    .fixedSize()
                todayIcons
                Image(systemName: "chevron.down")
                    .font(.system(size: 8, weight: .heavy))
                    .foregroundStyle(Color.inkSoft)
                    .rotationEffect(.degrees(showTownPanel ? 180 : 0))
            }
            .padding(.horizontal, 12)
            .frame(height: 32)
            .background(PaperPill())
            .overlay(alignment: .bottomLeading) {
                GeometryReader { proxy in
                    Capsule().fill(Color.gold)
                        .frame(width: max(4, (proxy.size.width - 16) * hud.dayProgress), height: 2.5)
                        .offset(x: 8, y: proxy.size.height - 5)
                }
                .allowsHitTesting(false)
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel("\(state.townName), \(dayText), \(hud.phase.name). Show today, revival, and goals")
    }

    /// Today's weather, theme, council card, and events, as small icons. Details live in the town panel.
    private var todayIcons: some View {
        let hud = state.hud
        return HStack(spacing: 5) {
            if hud.weather != .fair {
                Image(systemName: hud.weather.symbol)
            }
            if let featured = hud.featured {
                Circle().fill(Color(uiColor: featured.color)).frame(width: 8, height: 8)
            }
            if hud.dayCardTitle != nil {
                Image(systemName: "building.columns.fill")
            }
            if let event = state.todayEvents.first {
                Image(systemName: event.symbol)
            }
        }
        .font(.system(size: 10, weight: .bold))
        .foregroundStyle(Color.ink)
    }

    // MARK: Right side

    /// Money and Golden Tickets; tapping opens the shop of bundles.
    private var faresPill: some View {
        Button {
            AudioManager.shared.play(.tick)
            state.isShopOpen = true
        } label: {
            faresPillContent
                .overlay(alignment: .bottomTrailing) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(Color.gold)
                        .background(Circle().fill(Color.card))
                        .offset(x: 4, y: 4)
                }
        }
        .buttonStyle(.plain)
    }

    private var faresPillContent: some View {
        HStack(spacing: 4) {
            Image(systemName: "dollarsign.circle.fill")
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(Color.good)
            Text("\(state.fares)")
                .font(.mapBold(15))
                .foregroundStyle(Color.ink)
                .monospacedDigit()
                .contentTransition(.numericText())
                .animation(.snappy, value: state.fares)
            Rectangle().fill(Color.ink.opacity(0.15)).frame(width: 1, height: 14)
            Image(systemName: "ticket.fill")
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(Color.gold)
                .rotationEffect(.degrees(-12))
            Text("\(state.tickets)")
                .font(.mapBold(15))
                .foregroundStyle(Color.ink)
                .monospacedDigit()
                .contentTransition(.numericText())
                .animation(.snappy, value: state.tickets)
        }
        .padding(.horizontal, 10)
        .frame(height: 32)
        .background(PaperPill())
        .accessibilityLabel("Treasury \(state.fares) dollars, \(state.tickets) Golden Tickets")
    }

    /// Tap to see why the rating moved.
    private var ratingPill: some View {
        let hud = state.hud
        return Button {
            showTownPanel.toggle()
        } label: {
            ratingContent(hud)
        }
        .buttonStyle(.plain)
    }

    private func ratingContent(_ hud: HUDSnapshot) -> some View {
        HStack(spacing: 6) {
            Image(systemName: "star.fill")
                .font(.system(size: 11, weight: .bold))
                .foregroundStyle(Color.gold)
            Text(String(format: "%.1f", hud.rating))
                .font(.mapBold(14))
                .foregroundStyle(Color.ink)
                .monospacedDigit()
            Rectangle().fill(Color.ink.opacity(0.15)).frame(width: 1, height: 14)
            Circle()
                .fill(Color(uiColor: hud.district.accent))
                .frame(width: 7, height: 7)
            Text("\(state.townName.uppercased()) \(Format.percent(hud.revived))")
                .font(.mapSemibold(10))
                .kerning(0.4)
                .foregroundStyle(Color.inkSoft)
                .lineLimit(1)
        }
        .padding(.horizontal, 10)
        .frame(height: 32)
        .background(PaperPill())
        .accessibilityLabel("Town rating \(String(format: "%.1f", hud.rating)). \(state.townName) \(Format.percent(hud.revived)) revived")
    }

    /// The Town Hotline: the phone wobbles while it rings; a dot means a task is open.
    private var lettersButton: some View {
        let ringing = state.ringingCall != nil || state.ringingFeature || state.ringingNews
        let hasTask = state.hasOpenTask
        return Button {
            showLetters.toggle()
        } label: {
            Image(systemName: ringing ? "phone.and.waveform.fill" : "phone.fill")
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(ringing ? Color.stampRed : Color.ink)
                .rotationEffect(.degrees(ringing ? 14 : 0))
                .animation(ringing ? .easeInOut(duration: 0.09).repeatForever(autoreverses: true) : .default, value: ringing)
                .frame(width: 32, height: 32)
                .background(PaperPill())
                .overlay(alignment: .topTrailing) {
                    if ringing || hasTask {
                        Circle()
                            .fill(ringing ? Color.stampRed : Color.ink)
                            .frame(width: 10, height: 10)
                            .offset(x: 3, y: -3)
                    }
                }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(ringing ? "The Town Hotline is ringing" : (hasTask ? "Town Hotline, one task open" : "Town Hotline"))
    }

    private var attentionButton: some View {
        let count = state.hud.issueCount
        return Button {
            state.attentionFocusID = nil
            state.isAttentionOpen.toggle()
        } label: {
            Image(systemName: count > 0 ? "bell.badge.fill" : "bell.fill")
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(Color.ink)
                .frame(width: 32, height: 32)
                .background(PaperPill())
                .overlay(alignment: .topTrailing) {
                    if count > 0 {
                        Text("\(count)")
                            .font(.mapBold(10))
                            .foregroundStyle(Color.card)
                            .frame(minWidth: 16, minHeight: 16)
                            .background(Circle().fill(Color.ink))
                            .offset(x: 4, y: -4)
                    }
                }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(count > 0 ? "\(Format.count(count, "thing")) need attention" : "Nothing needs attention")
    }

    private var blueprintsButton: some View {
        let highlight = state.tutorial == .openAlbum
        let unseen = state.unseenBlueprints.count
        return Button {
            state.openBook()
        } label: {
            HStack(spacing: 6) {
                Image(systemName: "book.closed.fill")
                    .font(.system(size: 12, weight: .bold))
                Text("BLUEPRINTS")
                    .font(.mapBold(12))
                    .kerning(0.8)
                if unseen > 0 {
                    Text("\(unseen)")
                        .font(.mapBold(10))
                        .foregroundStyle(Color.blueprint)
                        .frame(minWidth: 16, minHeight: 16)
                        .background(Circle().fill(Color.white))
                }
            }
            .foregroundStyle(Color.white)
            .padding(.horizontal, 12)
            .frame(height: 32)
            .background(
                ZStack {
                    RoundedRectangle(cornerRadius: 9).fill(Color.black.opacity(0.10)).offset(x: 1, y: 3).blur(radius: 2)
                    RoundedRectangle(cornerRadius: 9).fill(Color(uiColor: UIColor(hex: 0x1F3A5C))).offset(x: 1, y: 2)
                    RoundedRectangle(cornerRadius: 9).fill(Color.blueprint)
                    PaperGrain(seed: 6, strength: 1.2).clipShape(RoundedRectangle(cornerRadius: 9))
                }
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.ink, lineWidth: 3)
                    .padding(-5)
                    .opacity(highlight ? 1 : 0)
                    .scaleEffect(highlight ? 1.06 : 1)
                    .animation(highlight ? .easeInOut(duration: 0.7).repeatForever(autoreverses: true) : .default,
                               value: highlight)
            )
        }
        .buttonStyle(.plain)
        .accessibilityLabel(unseen > 0 ? "Blueprints, \(unseen) new" : "Blueprints")
    }

    private func iconButton(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(Color.ink)
                .frame(width: 32, height: 32)
                .background(PaperPill())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

/// Pause, play, and fast-forward, in the lower right.
struct SpeedControl: View {
    @ObservedObject var state: GameState

    var body: some View {
        HStack(spacing: 0) {
            button(.paused, symbol: "pause.fill", label: "Pause")
            button(.normal, symbol: "play.fill", label: "Normal speed")
            button(.fast, symbol: "forward.fill", label: "Fast forward")
        }
        .padding(3)
        .background(PaperPanel(cornerRadius: 22))
    }

    private func button(_ speed: GameSpeed, symbol: String, label: String) -> some View {
        let selected = state.speed == speed
        return Button {
            state.speed = speed
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(selected ? Color.card : Color.ink)
                .frame(width: 40, height: 38)
                .background(RoundedRectangle(cornerRadius: 3).fill(selected ? Color.ink : Color.clear))
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }
}

/// A paper tag for the top bar: small square-ish card, ink border, flat print shadow.
struct PaperPill: View {
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 9).fill(Color.black.opacity(0.10)).offset(x: 1, y: 3).blur(radius: 2)
            RoundedRectangle(cornerRadius: 9).fill(Color(uiColor: UIColor(hex: 0xDCCDB2))).offset(x: 1, y: 2)
            RoundedRectangle(cornerRadius: 9).fill(Color.card)
            PaperGrain(seed: 5, strength: 1.2).clipShape(RoundedRectangle(cornerRadius: 9))
        }
    }
}
