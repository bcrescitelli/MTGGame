import SwiftUI
import UIKit

/// Shown while decorating: pick what to place, or Remove, with a line saying what a tap does.
struct DecorateBar: View {
    @ObservedObject var state: GameState

    private static let icons: [DecorKind: UIImage] = Dictionary(uniqueKeysWithValues:
        DecorKind.allCases.map { ($0, MarkerFactory.decorImage($0, size: 40)) })

    var body: some View {
        VStack(spacing: 4) {
            HStack(spacing: 6) {
                Text("Decorate")
                    .font(.display(17))
                    .foregroundStyle(Color.ink)
                    .padding(.trailing, 2)
                // The everyday five, plus any themed decorations the town's regulars have unlocked.
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(DecorKind.allCases.filter { !$0.isThemed || state.unlockedDecor.contains($0.rawValue) }) { kind in
                            chip(kind)
                        }
                    }
                }
                .frame(maxWidth: 440)
                Rectangle().fill(Color.ink.opacity(0.15)).frame(width: 1, height: 24)
                Button {
                    state.startRemovingDecor()
                } label: {
                    Image(systemName: "eraser.fill")
                        .font(.system(size: 13, weight: .bold))
                        .foregroundStyle(state.removingDecor ? Color.card : Color.stampRed)
                        .frame(width: 34, height: 32)
                        .background(RoundedRectangle(cornerRadius: 8).fill(state.removingDecor ? Color.stampRed : Color.stampRed.opacity(0.12)))
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Remove decorations")
                Button {
                    state.stopDecorating()
                } label: {
                    InkButtonLabel(text: "DONE", height: 32)
                }
                .buttonStyle(.plain)
            }
            Text(state.message ?? instruction)
                .font(.bodySerif(12, italic: true))
                .foregroundStyle(state.message == nil ? Color.ink : Color.stampRed)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(PaperPanel(cornerRadius: 10))
    }

    private func chip(_ kind: DecorKind) -> some View {
        let selected = state.placingDecor == kind
        return Button {
            AudioManager.shared.play(.tick)
            state.startDecorating(kind)
        } label: {
            HStack(spacing: 4) {
                if let image = DecorateBar.icons[kind] {
                    Image(uiImage: image).resizable().frame(width: 24, height: 24)
                }
                Text("$\(kind.cost)")
                    .font(.mapBold(11))
                    .foregroundStyle(Color.ink)
            }
            .padding(.horizontal, 7)
            .frame(height: 32)
            .background(RoundedRectangle(cornerRadius: 8).fill(selected ? Color(uiColor: UIColor(hex: 0xD8E8CC)) : Color.ink.opacity(0.05)))
            .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color(uiColor: UIColor(hex: 0x5FA14B)), lineWidth: selected ? 2 : 0))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("\(kind.title), $\(kind.cost)\(selected ? ", selected" : "")")
    }

    private var instruction: String {
        if state.removingDecor { return "Tap a decoration to take it away." }
        guard let kind = state.placingDecor else { return "" }
        let what: String
        switch kind {
        case .tree: what = "a tree. Fruit ripens through the day; tap it to shake some down"
        case .bench: what = "a bench"
        case .lamp: what = "a lamp post. It lights the street at night"
        case .planter: what = "a box of flowers"
        case .mailbox: what = "a post box"
        default: what = "a \(kind.title.lowercased())"
        }
        return "Tap a square or a street to set down \(what). $\(kind.cost) each."
    }
}
