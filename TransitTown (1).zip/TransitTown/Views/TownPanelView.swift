import SwiftUI
import UIKit

/// Drops down from the town name: the districts, this term's goals, and every pair bonus.
struct TownPanelView: View {
    @ObservedObject var state: GameState
    var openSettings: () -> Void = {}
    let dismiss: () -> Void

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 12) {
                header
                rule
                rating
                rule
                today
                rule
                districts
                revivalNote
                rule
                goals
                rule
                pairs
            }
            .padding(16)
        }
        .frame(width: 320)
        .frame(maxHeight: 290)
        .background(PaperPanel(cornerRadius: 16))
    }

    private var rule: some View {
        Rectangle().fill(Color.ink.opacity(0.15)).frame(height: 1)
    }

    /// How a district's percentage grows, in plain words.
    private var revivalNote: some View {
        VStack(alignment: .leading, spacing: 4) {
            sectionTitle("How revival works")
            Text("Streets come back to life along your lines and around stations that trains serve. Busier stations reach further. Once a street revives, it stays revived.")
                .font(.bodySerif(12.5))
                .foregroundStyle(Color.ink)
                .fixedSize(horizontal: false, vertical: true)
            Text("The town earns the right to open new lines as it revives. Each one then costs money and Golden Tickets to open, and runs anywhere in town.")
                .font(.bodySerif(12, italic: true))
                .foregroundStyle(Color.inkSoft)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private func sectionTitle(_ text: String) -> some View {
        SmallCapsHeading(text: text, size: 12, color: .inkSoft)
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 2) {
                Text("THE MAYOR'S \(Format.ordinal(state.termNumber).uppercased()) TERM")
                    .font(.mapSemibold(11))
                    .kerning(1.4)
                    .foregroundStyle(Color.inkSoft)
                Text(state.townName)
                    .font(.display(26))
                    .foregroundStyle(Color.ink)
            }
            Spacer()
            Button(action: openSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(Color.inkSoft)
                    .frame(width: 30, height: 30)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Settings")
            Button(action: dismiss) {
                Image(systemName: "xmark")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.inkSoft)
                    .frame(width: 26, height: 26)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Close")
        }
    }

    // MARK: Rating

    /// Why the rating moved today, in plain words.
    private var rating: some View {
        let change = state.ratingChangeToday
        return VStack(alignment: .leading, spacing: 6) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                sectionTitle("RATING")
                Text(Format.stars(state.townRating))
                    .font(.mapBold(14))
                    .foregroundStyle(Color.ink)
                Text(abs(change) < 0.05 ? "steady today" : String(format: "%@%.1f today", change > 0 ? "+" : "−", abs(change)))
                    .font(.mapSemibold(11))
                    .foregroundStyle(change >= 0 ? Color.good : Color.bad)
            }
            ForEach(state.ratingReasons()) { reason in
                HStack(alignment: .top, spacing: 8) {
                    Text(reason.isPositive ? "+" : "−")
                        .font(.mapBold(14))
                        .foregroundStyle(reason.isPositive ? Color.good : Color.bad)
                        .frame(width: 12)
                    Text(reason.text)
                        .font(.bodySerif(12))
                        .foregroundStyle(Color.ink)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
    }

    // MARK: Today

    /// Everything shaping today, spelled out: weather, theme, council card, and events.
    private var today: some View {
        VStack(alignment: .leading, spacing: 6) {
            sectionTitle("TODAY")
            let weather = state.weatherToday
            todayRow(symbol: weather.symbol, title: weather.name,
                     detail: weather.effects.isEmpty ? "No effect on the day" : weather.effects.joined(separator: ". "))
            if let featured = state.featuredToday {
                todayRow(symbol: "circle.fill", title: "\(featured.name) Day",
                         detail: "\(featured.name) stops draw 40% more riders", tint: Color(uiColor: featured.color))
            }
            if let card = state.dayCard {
                todayRow(symbol: "building.columns.fill", title: card.title, detail: card.effect)
            }
            ForEach(state.todayEvents) { event in
                todayRow(symbol: event.symbol, title: event.title, detail: state.describe(event))
            }
        }
    }

    private func todayRow(symbol: String, title: String, detail: String, tint: Color = .ink) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: symbol)
                .font(.system(size: 12, weight: .bold))
                .foregroundStyle(tint)
                .frame(width: 20)
            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(.display(15))
                    .foregroundStyle(Color.ink)
                Text(detail)
                    .font(.bodySerif(12))
                    .foregroundStyle(Color.ink)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    // MARK: Districts

    private var districts: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionTitle("DISTRICTS")
            Text("Streets revive around busy stations, and once revived they stay that way.")
                .font(.bodySerif(12, italic: true))
                .foregroundStyle(Color.inkSoft)
            ForEach(District.allCases.filter { state.isOpened($0) }) { district in
                let isOpen = state.isOpened(district)
                Button {
                    guard isOpen else { return }
                    state.cameraFocusRequest = district
                    dismiss()
                } label: {
                    HStack(spacing: 10) {
                        Circle()
                            .fill(Color(uiColor: district.accent).opacity(isOpen ? 1 : 0.35))
                            .frame(width: 10, height: 10)
                        Text(state.isSingleMap ? state.townName : district.name)
                            .font(.bodySerif(14))
                            .foregroundStyle(isOpen ? Color.ink : Color.inkSoft)
                        Spacer()
                        Text(status(of: district))
                            .font(.mapBold(10))
                            .kerning(0.8)
                            .foregroundStyle(Color.inkSoft)
                        if isOpen {
                            Image(systemName: "arrow.right.circle.fill")
                                .font(.system(size: 14))
                                .foregroundStyle(Color.ink.opacity(0.6))
                        }
                    }
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .disabled(!isOpen)
            }
        }
    }

    private func status(of district: District) -> String {
        guard state.isOpened(district) else { return "OPENS AT A LATER MILESTONE" }
        let revived = Format.percent(state.districtRevived[district] ?? 0)
        if district == state.currentDistrict { return "\(revived)" }
        if state.isSettled(district) { return "SETTLED, \(revived)" }
        return "\(revived) REVIVED"
    }

    // MARK: Goals

    private var goals: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionTitle("MILESTONE STAMPS")
            if let next = state.nextDistrict {
                let revived = Int(((state.districtBestRevived[state.currentDistrict] ?? 0) * 100).rounded())
                VStack(alignment: .leading, spacing: 6) {
                    Text("To open \(next.name): \(revived)% of \(Int(GameState.milestoneRevival * 100))% revived, \(String(format: "%.1f", state.townRating))★ of \(String(format: "%.1f", GameState.milestoneRating))★")
                        .font(.bodySerif(12.5))
                        .foregroundStyle(Color.ink)
                        .fixedSize(horizontal: false, vertical: true)
                    if state.milestoneReached {
                        Button {
                            AudioManager.shared.play(.stamp)
                            state.openNextDistrictFromPanel()
                        } label: {
                            InkButtonLabel(text: "OPEN \(next.name.uppercased())", symbol: "arrow.right", height: 32)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            ForEach(Array(state.goals.enumerated()), id: \.offset) { item in
                let progress = state.progress(for: item.element)
                HStack(spacing: 10) {
                    Image(systemName: progress.isMet ? "rosette" : item.element.symbol)
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(progress.isMet ? Color.gold : Color.inkSoft)
                        .frame(width: 20)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(progress.text)
                            .font(.bodySerif(14))
                            .foregroundStyle(Color.ink)
                        ProgressStrip(fraction: progress.fraction, tint: progress.isMet ? .gold : .ink)
                    }
                }
            }
        }
    }

    // MARK: Pairs

    private var pairs: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionTitle("PAIR BONUSES")
            Text("Two partner landmarks on one line get more trips and +$1 fares.")
                .font(.bodySerif(12, italic: true))
                .foregroundStyle(Color.inkSoft)
            ForEach(state.pairStatuses()) { pair in
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: pair.isConnected ? "link.circle.fill" : "link.circle")
                        .font(.system(size: 16))
                        .foregroundStyle(pair.isConnected ? Color.good : Color.inkSoft)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(pair.name)
                            .font(.display(16))
                            .foregroundStyle(Color.ink)
                        Text("\(pair.first.info.name) + \(pair.second.info.name)")
                            .font(.bodySerif(12))
                            .foregroundStyle(Color.ink)
                        Text(pair.hint.uppercased())
                            .font(.mapBold(10))
                            .kerning(0.6)
                            .foregroundStyle(pair.isConnected ? Color.good : Color.inkSoft)
                    }
                }
            }
        }
    }
}
