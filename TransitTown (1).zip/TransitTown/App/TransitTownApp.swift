import SwiftUI

@main
struct TransitTownApp: App {
    init() {
        AppFont.registerBundledFonts()
    }

    var body: some Scene {
        WindowGroup {
            RootView()
        }
    }
}
