import CoreGraphics
import Foundation

/// Pure geometry helpers for transit-map style lines.
enum TransitGeometry {
    static func distance(_ a: CGPoint, _ b: CGPoint) -> CGFloat {
        hypot(a.x - b.x, a.y - b.y)
    }

    static func distance(from p: CGPoint, toSegment a: CGPoint, _ b: CGPoint) -> CGFloat {
        let ab = a.vector(to: b)
        let len2 = ab.dot(ab)
        let t = len2 > 0 ? min(max(a.vector(to: p).dot(ab) / len2, 0), 1) : 0
        return distance(p, a + ab * t)
    }

    /// Free-form routing between any two points using only 90° and 45° angles (used for drag previews).
    static func octilinear(from a: CGPoint, to b: CGPoint) -> [CGPoint] {
        let dx = b.x - a.x, dy = b.y - a.y
        let adx = abs(dx), ady = abs(dy)
        if adx < 0.5 || ady < 0.5 || abs(adx - ady) < 0.5 { return [a, b] }
        let diagonal = min(adx, ady)
        let mid: CGPoint
        if adx > ady {
            mid = CGPoint(x: a.x + (dx > 0 ? 1 : -1) * (adx - diagonal), y: a.y)
        } else {
            mid = CGPoint(x: a.x, y: a.y + (dy > 0 ? 1 : -1) * (ady - diagonal))
        }
        return [a, mid, b]
    }

    /// A path through the points with rounded corners.
    static func roundedPath(through points: [CGPoint], radius: CGFloat = 14) -> CGPath {
        let path = CGMutablePath()
        guard let first = points.first else { return path }
        path.move(to: first)
        if points.count > 2 {
            for i in 1..<(points.count - 1) {
                let r = min(radius,
                            distance(points[i - 1], points[i]) / 2,
                            distance(points[i], points[i + 1]) / 2)
                if r < 0.5 {
                    path.addLine(to: points[i])
                } else {
                    path.addArc(tangent1End: points[i], tangent2End: points[i + 1], radius: r)
                }
            }
        }
        if points.count > 1, let last = points.last {
            path.addLine(to: last)
        }
        return path
    }

    /// The part of a polyline between two distances measured from its start.
    static func subpath(_ points: [CGPoint], from start: CGFloat, to end: CGFloat) -> [CGPoint] {
        guard points.count >= 2, end > start else { return [] }
        var result: [CGPoint] = []
        var walked: CGFloat = 0
        for i in 1..<points.count {
            let a = points[i - 1], b = points[i]
            let length = distance(a, b)
            let segmentStart = walked
            let segmentEnd = walked + length
            walked = segmentEnd
            if length == 0 || segmentEnd < start { continue }
            if segmentStart > end { break }
            let t0 = max(0, (start - segmentStart) / length)
            let t1 = min(1, (end - segmentStart) / length)
            let p0 = a + a.vector(to: b) * t0
            let p1 = a + a.vector(to: b) * t1
            if let last = result.last {
                if distance(last, p0) > 0.01 { result.append(p0) }
            } else {
                result.append(p0)
            }
            result.append(p1)
        }
        return result
    }
}
