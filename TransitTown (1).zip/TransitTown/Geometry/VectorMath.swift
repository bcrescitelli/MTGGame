import CoreGraphics

extension CGPoint {
    static func + (lhs: CGPoint, rhs: CGVector) -> CGPoint {
        CGPoint(x: lhs.x + rhs.dx, y: lhs.y + rhs.dy)
    }

    static func - (lhs: CGPoint, rhs: CGVector) -> CGPoint {
        CGPoint(x: lhs.x - rhs.dx, y: lhs.y - rhs.dy)
    }

    func vector(to other: CGPoint) -> CGVector {
        CGVector(dx: other.x - x, dy: other.y - y)
    }
}

extension CGVector {
    static func * (lhs: CGVector, rhs: CGFloat) -> CGVector {
        CGVector(dx: lhs.dx * rhs, dy: lhs.dy * rhs)
    }

    var length: CGFloat { (dx * dx + dy * dy).squareRoot() }

    var normalized: CGVector {
        let l = length
        return l > 0 ? CGVector(dx: dx / l, dy: dy / l) : CGVector(dx: 0, dy: 0)
    }

    /// 2D cross product (z component).
    func cross(_ other: CGVector) -> CGFloat { dx * other.dy - dy * other.dx }

    func dot(_ other: CGVector) -> CGFloat { dx * other.dx + dy * other.dy }
}
