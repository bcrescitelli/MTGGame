import CoreGraphics

/// A line ready to draw: its grid route and the lane-offset polyline.
struct RoutedLine {
    let lineID: Int
    let cells: [GridPoint]
    let points: [CGPoint]
    /// Index into `points` for each stop, in stop order.
    let stopIndices: [Int]
}

/// Routes every line and spreads lines that share track into parallel lanes.
enum LaneLayout {
    /// Equal to the line width, so parallel lines sit flush against each other.
    static let laneSpacing: CGFloat = 6

    struct Input {
        let lineID: Int
        let colorIndex: Int
        let stopCells: [GridPoint]
    }

    private struct Route {
        let input: Input
        let cells: [GridPoint]
        let stopIndices: [Int]
    }

    static func layout(_ inputs: [Input], stations: Set<GridPoint>, center: (GridPoint) -> CGPoint) -> [Int: RoutedLine] {
        // 1. Route each line, preferring bends that avoid track already used.
        var occupied: [TrackEdge: Int] = [:]
        var routes: [Route] = []
        for input in inputs where input.stopCells.count >= 2 {
            let avoid = stations.subtracting(input.stopCells)
            let route = GridRouter.route(stops: input.stopCells, occupied: occupied, avoid: avoid)
            for edge in Set(GridRouter.edges(of: route.cells)) {
                occupied[edge, default: 0] += 1
            }
            routes.append(Route(input: input, cells: route.cells, stopIndices: route.stopIndices))
        }

        // 2. Which lines share each piece of track. Sorted by color so lane order is stable everywhere.
        var sharing: [TrackEdge: [Int]] = [:]
        for route in routes {
            for edge in Set(GridRouter.edges(of: route.cells)) {
                sharing[edge, default: []].append(route.input.colorIndex)
            }
        }
        sharing = sharing.mapValues { $0.sorted() }

        // 3. Offset each line into its lane.
        var result: [Int: RoutedLine] = [:]
        for route in routes {
            let offset = offsetPolyline(route: route, sharing: sharing, center: center)
            result[route.input.lineID] = RoutedLine(lineID: route.input.lineID,
                                                    cells: route.cells,
                                                    points: offset.points,
                                                    stopIndices: offset.stopIndices)
        }
        return result
    }

    private static func offsetPolyline(route: Route, sharing: [TrackEdge: [Int]], center: (GridPoint) -> CGPoint) -> (points: [CGPoint], stopIndices: [Int]) {
        let cells = route.cells
        guard cells.count >= 2 else { return ([], []) }
        let colorIndex = route.input.colorIndex

        // Direction and lane offset for every unit step of the route.
        var directions: [CGVector] = []
        var offsets: [CGVector] = []
        for k in 1..<cells.count {
            directions.append(center(cells[k - 1]).vector(to: center(cells[k])).normalized)
            let edge = TrackEdge(cells[k - 1], cells[k])
            let lanes = sharing[edge] ?? [colorIndex]
            let lane = CGFloat(lanes.firstIndex(of: colorIndex) ?? 0)
            let shift = (lane - CGFloat(lanes.count - 1) / 2) * laneSpacing
            // Measure the perpendicular from the edge's canonical direction so lines
            // traveling either way along it agree on which side is which.
            let canonical = center(edge.a).vector(to: center(edge.b)).normalized
            offsets.append(CGVector(dx: -canonical.dy * shift, dy: canonical.dx * shift))
        }

        let stopSet = Set(route.stopIndices)
        var points: [(CGPoint, Bool)] = [(center(cells[0]) + offsets[0], true)]

        if cells.count > 2 {
            for k in 1..<(cells.count - 1) {
                let c = center(cells[k])
                let isStop = stopSet.contains(k)
                let d1 = directions[k - 1], d2 = directions[k]
                let o1 = offsets[k - 1], o2 = offsets[k]
                let p1 = c + o1, p2 = c + o2
                let cross = d1.cross(d2)

                if abs(cross) < 0.001 && d1.dot(d2) > 0 {
                    // Straight through. If the lane changes here, shift over at 45°.
                    let gap = CGVector(dx: o2.dx - o1.dx, dy: o2.dy - o1.dy).length
                    if gap < 0.01 {
                        points.append((p1, isStop))
                    } else {
                        let half = gap / 2
                        points.append((p1 - d1 * half, isStop))
                        points.append((p2 + d2 * half, false))
                    }
                } else if abs(cross) < 0.001 {
                    // The route doubles back on itself.
                    points.append((p1, isStop))
                    points.append((p2, false))
                } else {
                    // A corner: meet where the two offset lanes intersect.
                    let s = p1.vector(to: p2).cross(d2) / cross
                    if abs(s) < 40 {
                        points.append((p1 + d1 * s, isStop))
                    } else {
                        points.append((p1, isStop))
                        points.append((p2, false))
                    }
                }
            }
        }

        points.append((center(cells[cells.count - 1]) + offsets[offsets.count - 1], true))
        return simplify(points)
    }

    /// Removes duplicate points and points in the middle of straight runs. Stops are always kept.
    private static func simplify(_ input: [(CGPoint, Bool)]) -> (points: [CGPoint], stopIndices: [Int]) {
        var deduped: [(CGPoint, Bool)] = []
        for item in input {
            if let last = deduped.last, TransitGeometry.distance(last.0, item.0) < 0.5 {
                if item.1 { deduped[deduped.count - 1].1 = true }
                continue
            }
            deduped.append(item)
        }

        var result: [(CGPoint, Bool)] = []
        for (i, item) in deduped.enumerated() {
            if i > 0, i < deduped.count - 1, !item.1, let previous = result.last {
                let incoming = previous.0.vector(to: item.0)
                let outgoing = item.0.vector(to: deduped[i + 1].0)
                if abs(incoming.normalized.cross(outgoing.normalized)) < 0.001, incoming.dot(outgoing) > 0 {
                    continue
                }
            }
            result.append(item)
        }

        let points = result.map { $0.0 }
        let stopIndices = result.indices.filter { result[$0].1 }
        return (points, stopIndices)
    }
}
