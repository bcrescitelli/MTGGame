/// One unit of track between two neighboring grid cells (direction-independent).
struct TrackEdge: Hashable {
    let a: GridPoint
    let b: GridPoint

    init(_ p: GridPoint, _ q: GridPoint) {
        if (p.col, p.row) < (q.col, q.row) {
            a = p
            b = q
        } else {
            a = q
            b = p
        }
    }
}

/// Routes lines over the grid using only straight and 45° steps.
enum GridRouter {
    /// Cells visited from `a` to `b`: a straight run plus a diagonal run, in either order.
    static func leg(from a: GridPoint, to b: GridPoint, diagonalFirst: Bool) -> [GridPoint] {
        let dc = b.col - a.col, dr = b.row - a.row
        let adc = abs(dc), adr = abs(dr)
        let diagonalCount = min(adc, adr)
        let straightCount = max(adc, adr) - diagonalCount
        let straightStep = adc > adr ? GridPoint(col: dc.signum(), row: 0) : GridPoint(col: 0, row: dr.signum())
        let diagonalStep = GridPoint(col: dc.signum(), row: dr.signum())

        var cells = [a]
        var current = a
        func walk(_ step: GridPoint, _ count: Int) {
            for _ in 0..<count {
                current = GridPoint(col: current.col + step.col, row: current.row + step.row)
                cells.append(current)
            }
        }
        if diagonalFirst {
            walk(diagonalStep, diagonalCount)
            walk(straightStep, straightCount)
        } else {
            walk(straightStep, straightCount)
            walk(diagonalStep, diagonalCount)
        }
        return cells
    }

    static func edges(of cells: [GridPoint]) -> [TrackEdge] {
        guard cells.count > 1 else { return [] }
        return (1..<cells.count).map { TrackEdge(cells[$0 - 1], cells[$0]) }
    }

    /// The same track between two stations no matter which one the line was drawn from.
    /// Without this, A→B and B→A bend in different places and can't run side by side.
    static func canonicalLeg(from a: GridPoint, to b: GridPoint, diagonalFirst: Bool) -> [GridPoint] {
        if (a.col, a.row) <= (b.col, b.row) {
            return leg(from: a, to: b, diagonalFirst: diagonalFirst)
        }
        return Array(leg(from: b, to: a, diagonalFirst: diagonalFirst).reversed())
    }

    /// Full route through a line's stops. For each leg, picks the bend that:
    /// 1. never passes through another station,
    /// 2. never doubles back over track this line just laid,
    /// 3. runs alongside other lines' track where it can, so they bundle into lanes.
    static func route(stops: [GridPoint], occupied: [TrackEdge: Int], avoid: Set<GridPoint>) -> (cells: [GridPoint], stopIndices: [Int]) {
        guard let first = stops.first else { return ([], []) }
        var cells = [first]
        var stopIndices = [0]
        for k in 1..<stops.count {
            let options = [
                canonicalLeg(from: stops[k - 1], to: stops[k], diagonalFirst: false),
                canonicalLeg(from: stops[k - 1], to: stops[k], diagonalFirst: true),
            ]
            let own = Set(edges(of: cells))
            let previous: GridPoint? = cells.count >= 2 ? cells[cells.count - 2] : nil
            let chosen = options.min { a, b in
                cost(of: a, occupied: occupied, avoid: avoid, own: own, previous: previous)
                    < cost(of: b, occupied: occupied, avoid: avoid, own: own, previous: previous)
            } ?? options[0]
            cells.append(contentsOf: chosen.dropFirst())
            stopIndices.append(cells.count - 1)
        }
        return (cells, stopIndices)
    }

    /// Lower is better.
    private static func cost(of leg: [GridPoint], occupied: [TrackEdge: Int], avoid: Set<GridPoint>,
                             own: Set<TrackEdge>, previous: GridPoint?) -> Int {
        let legEdges = edges(of: leg)
        let throughStations = leg.dropFirst().dropLast().filter { avoid.contains($0) }.count
        let doublesBack = (previous != nil && leg.count > 1 && leg[1] == previous) ? 1 : 0
        let retraced = legEdges.filter { own.contains($0) }.count
        let shared = legEdges.filter { (occupied[$0] ?? 0) > 0 }.count
        return throughStations * 100 + doublesBack * 60 + retraced * 40 - shared
    }
}
