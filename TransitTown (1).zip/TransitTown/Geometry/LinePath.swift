import CoreGraphics
import Foundation

/// A line's route as a polyline, measured by distance so trains can travel along it.
struct LinePath {
    let points: [CGPoint]
    let cumulative: [CGFloat]
    /// Distance along the path at which each stop sits, in stop order.
    let stopDistances: [CGFloat]

    var total: CGFloat { cumulative.last ?? 0 }

    init(points: [CGPoint], stopIndices: [Int]) {
        self.points = points
        var cum: [CGFloat] = [0]
        if points.count > 1 {
            for i in 1..<points.count {
                cum.append(cum[i - 1] + TransitGeometry.distance(points[i], points[i - 1]))
            }
        }
        cumulative = cum
        stopDistances = stopIndices.compactMap { $0 < cum.count ? cum[$0] : nil }
    }

    /// The polyline between two distances along the path (for drawing only part of a line).
    func points(from start: CGFloat, to end: CGFloat) -> [CGPoint] {
        guard points.count >= 2, end > start else { return [] }
        var result = [sample(at: start).point]
        for (index, distance) in cumulative.enumerated() where distance > start && distance < end {
            result.append(points[index])
        }
        result.append(sample(at: end).point)
        return result
    }

    /// Position and heading at a distance along the path.
    /// Distances before the start or past the end continue straight off the ends.
    func sample(at distance: CGFloat) -> (point: CGPoint, angle: CGFloat) {
        guard points.count >= 2 else { return (points.first ?? .zero, 0) }

        if distance < 0 {
            let d = points[0].vector(to: points[1]).normalized
            return (points[0] + d * distance, atan2(d.dy, d.dx))
        }
        if distance > total {
            let n = points.count
            let d = points[n - 2].vector(to: points[n - 1]).normalized
            return (points[n - 1] + d * (distance - total), atan2(d.dy, d.dx))
        }

        var i = 1
        while i < points.count - 1 && cumulative[i] < distance { i += 1 }
        let a = points[i - 1], b = points[i]
        let segmentLength = cumulative[i] - cumulative[i - 1]
        let t = segmentLength > 0 ? (distance - cumulative[i - 1]) / segmentLength : 0
        return (a + a.vector(to: b) * t, atan2(b.y - a.y, b.x - a.x))
    }

    /// Distance along the path of the point on it closest to `p`.
    func closestDistance(to p: CGPoint) -> CGFloat {
        guard points.count >= 2 else { return 0 }
        var best: CGFloat = 0
        var bestGap = CGFloat.greatestFiniteMagnitude
        for i in 1..<points.count {
            let a = points[i - 1]
            let ab = a.vector(to: points[i])
            let len2 = ab.dot(ab)
            let t = len2 > 0 ? min(max(a.vector(to: p).dot(ab) / len2, 0), 1) : 0
            let gap = TransitGeometry.distance(p, a + ab * t)
            if gap < bestGap {
                bestGap = gap
                best = cumulative[i - 1] + t * len2.squareRoot()
            }
        }
        return best
    }
}
