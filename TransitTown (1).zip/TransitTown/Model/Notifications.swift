import Foundation
import UserNotifications

/// Local notifications (no server): a building finished, earnings full, someone ringing in the
/// morning. At most two scheduled at a time; permission is asked after the first building opens.
enum Notifications {

    static func requestPermissionOnce() {
        let key = "notifications.asked"
        guard !UserDefaults.standard.bool(forKey: key) else { return }
        UserDefaults.standard.set(true, forKey: key)
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    static func clearPending() {
        let center = UNUserNotificationCenter.current()
        center.removeAllPendingNotificationRequests()
        center.removeAllDeliveredNotifications()
    }

    static func schedule(for state: GameState) {
        clearPending()
        var planned: [(id: String, title: String, body: String, at: Date)] = []
        // The next building to finish.
        if let next = state.landmarks.compactMap({ $0.constructionEnds }).filter({ $0 > Date() }).min() {
            planned.append(("building", "A new neighbor has moved in",
                            "Something new just opened in \(state.townName). Come and see who it is.", next))
        }
        // Earnings full after eight hours away.
        planned.append(("earnings", "\(state.townName) has been busy",
                        "The town has earned all it can while you're away. Come and collect it.",
                        Date().addingTimeInterval(GameState.awayCap)))
        // A morning call, if nothing else is planned.
        if planned.count < 2, state.hotlineUnlocked {
            var parts = Calendar.current.dateComponents([.year, .month, .day], from: Date().addingTimeInterval(86_400))
            parts.hour = 9
            if let morning = Calendar.current.date(from: parts) {
                planned.append(("call", "The Town Hotline is ringing", "Someone in \(state.townName) would like a word, Mayor.", morning))
            }
        }
        for item in planned.prefix(2) {
            let content = UNMutableNotificationContent()
            content.title = item.title
            content.body = item.body
            content.sound = .default
            let seconds = max(5, item.at.timeIntervalSinceNow)
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: seconds, repeats: false)
            UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: item.id, content: content, trigger: trigger))
        }
    }
}
