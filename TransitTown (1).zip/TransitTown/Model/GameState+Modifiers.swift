import Foundation

/// Every lasting or one-day effect on the simulation, gathered in one place: council cards,
/// snap decisions, station upgrades, and the light rail service.
extension GameState {

    func isServed(_ id: Int) -> Bool {
        builtLines.contains { $0.stops.contains(id) }
    }

    // MARK: Riders

    /// How patient riders starting at a station are, before weather and settled districts.
    func patienceModifier(at stationID: Int) -> Double {
        var value = todayPatienceMultiplier
        if hasCard(.quietCarriages) { value *= 1.15 }
        if hasCard(.fareRise) { value *= 0.9 }
        if dayCard == .peakPricing { value *= 0.8 }
        if dayCard == .dayOfRest { value *= 2 }
        if hasUpgrade(.canopy, at: stationID) {
            value *= (weatherToday == .rain || isStorming) ? 1.6 : 1.3
        }
        return value
    }

    /// Weather's effect on patience, softened by the Weather Watch.
    var weatherPatience: Double {
        let base = weatherToday.patienceMultiplier
        return hasCard(.weatherWatch) ? 1 - (1 - base) / 2 : base
    }

    var isStorming: Bool {
        todayEvents.contains { $0.kind == .storm && $0.isActive(at: dayClock) }
    }

    /// How many more (or fewer) riders set out, from cards and today's decisions.
    func riderRateModifier(_ phase: DayPhase) -> Double {
        var value = todayRiderMultiplier
        if phase == .night && hasCard(.lateTimetable) { value *= 1.3 }
        if dayCard == .carFreeDay { value *= 1.25 }
        if dayCard == .dayOfRest { value *= 0.7 }
        return value
    }

    /// Extra pull for a kind of landmark today.
    func categoryBoost(_ category: LandmarkCategory) -> Double {
        var value = todayCategoryBoost[category] ?? 1
        if dayCard == .bookFair && category == .culture { value *= 1.8 }
        if dayCard == .picnicDay && category == .nature { value *= 1.8 }
        return value
    }

    /// Extra dollars on every fare.
    var fareBonus: Int {
        (hasCard(.fareRise) ? 1 : 0) + (dayCard == .peakPricing ? 2 : 0)
    }

    /// Riders who can wait on one platform.
    func maxWaiting(at stationID: Int) -> Int {
        GameState.maxWaitingPerStation + (hasCard(.stationMasters) ? 4 : 0)
            + (hasUpgrade(.longPlatform, at: stationID) ? 6 : 0)
    }

    /// How much patience a rider changing trains here gets back.
    func transferRelief(at stationID: Int) -> Double {
        hasCard(.transferTickets) || hasUpgrade(.footbridge, at: stationID) ? 0.2 : 0.5
    }

    // MARK: Light rail services

    var unlockedServices: [LightRailService] {
        LightRailService.allCases.filter { lightRailRiders >= $0.ridersNeeded }
    }

    func setService(_ service: LightRailService) {
        guard lightRailRiders >= service.ridersNeeded, service != lightRailService else { return }
        lightRailService = service
        networkChanged()
        show("Light rail: \(service.title)")
        changed()
    }

    /// How the light rail service shifts riders crossing between districts.
    func serviceWeight(for destination: Landmark, phase: DayPhase) -> Double {
        let category = destination.kind.info.category
        switch lightRailService {
        case .marketExpress: return category == .food ? 2 : 1
        case .schoolSpecial: return phase == .morning && category == .culture ? 2 : 1
        case .theatreTrain: return (phase == .evening || phase == .night) && category == .culture ? 2 : 1
        default: return 1
        }
    }

    /// Tourists setting out from canal quays.
    var quayTouristModifier: Double {
        switch lightRailService {
        case .scenic: return 2
        case .marketExpress: return 0.3
        default: return 1
        }
    }

    // MARK: Building and buying

    var landmarkCostMultiplier: Double {
        (hasCard(.architectsGuild) ? 0.85 : 1) * (lightRailService == .freightHour && lightRail != nil ? 0.8 : 1)
    }

    var restorationMultiplier: Double { hasCard(.railHeritage) ? 0.75 : 1 }

    var cardRevivalMultiplier: Double {
        (hasCard(.streetTrees) ? 1.3 : 1) * (hasCard(.cornerShops) ? 1.2 : 1) * (dayCard == .openHouse ? 1.5 : 1)
    }

    // MARK: Station upgrades

    func hasUpgrade(_ upgrade: StationUpgrade, at stationID: Int) -> Bool {
        stationUpgrades[stationID]?.contains(upgrade) == true
    }

    func canBuyUpgrade(_ upgrade: StationUpgrade, at stationID: Int) -> Bool {
        !hasUpgrade(upgrade, at: stationID) && canAfford(upgrade.cost) && landmark(id: stationID)?.isOpen == true
    }

    func buyUpgrade(_ upgrade: StationUpgrade, at stationID: Int) {
        guard canBuyUpgrade(upgrade, at: stationID) else {
            if !canAfford(upgrade.cost) { show("\(upgrade.title) costs $\(upgrade.cost)") }
            return
        }
        fares -= upgrade.cost
        stationUpgrades[stationID, default: []].insert(upgrade)
        show("\(upgrade.title) built at the \(landmark(id: stationID)?.kind.info.name ?? "station")")
        refreshHUD()
        changed()
    }
}
