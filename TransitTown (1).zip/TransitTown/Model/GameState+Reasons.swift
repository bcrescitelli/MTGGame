import Foundation

/// One reason the town rating moved today, for the panel under the town name.
struct RatingReason: Identifiable {
    let id: String
    let symbol: String
    let text: String
    let isPositive: Bool
}

extension GameState {

    /// How much the rating has moved since this morning.
    var ratingChangeToday: Double {
        townRating - report.ratingStart
    }

    /// Plain-language reasons the rating went up or down today, biggest first.
    /// The rating is half service (riders arriving vs. giving up) and half how revived the
    /// open districts look on average, so both sides are explained here.
    func ratingReasons() -> [RatingReason] {
        var reasons: [RatingReason] = []

        if report.riders > 0 {
            reasons.append(RatingReason(id: "riders", symbol: "checkmark.circle.fill",
                                        text: "\(Format.count(report.riders, "rider")) reached their stops",
                                        isPositive: true))
        }
        let worstStations = report.gaveUpAt.sorted { $0.value > $1.value }.prefix(2)
        for (stationID, count) in worstStations where count > 0 {
            let name = landmark(id: stationID)?.kind.info.name ?? "a station"
            reasons.append(RatingReason(id: "gaveup-\(stationID)", symbol: "figure.walk",
                                        text: "\(Format.count(count, "rider")) gave up waiting at the \(name)",
                                        isPositive: false))
        }
        if report.overcrowded > 0 {
            reasons.append(RatingReason(id: "full", symbol: "person.3.fill",
                                        text: "\(Format.count(report.overcrowded, "rider")) turned away from full platforms",
                                        isPositive: false))
        }
        let unserved = openLandmarks.filter { landmark in
            isOpened(landmark.kind.info.district) && landmark.kind.info.category != .canal
                && !builtLines.contains { $0.stops.contains(landmark.id) }
        }
        if let first = unserved.first {
            let text = unserved.count == 1
                ? "The \(first.kind.info.name) isn't on a line yet"
                : "\(Format.count(unserved.count, "landmark")) aren't on a line yet, like the \(first.kind.info.name)"
            reasons.append(RatingReason(id: "unserved", symbol: "mappin.slash", text: text, isPositive: false))
        }
        for district in openedDistricts where district == currentDistrict && district != .oldTown {
            let revived = districtRevived[district] ?? 0
            if revived < 0.3 {
                reasons.append(RatingReason(id: "new-\(district.rawValue)", symbol: "paintbrush.pointed.fill",
                                            text: "\(district.name) is newly opened and still faded, which pulls the average down",
                                            isPositive: false))
            }
        }
        let revivedNow = openedDistricts.compactMap { districtRevived[$0] }.reduce(0, +)
        if revivedNow > 0 {
            reasons.append(RatingReason(id: "revival", symbol: "paintbrush.pointed.fill",
                                        text: "Revived streets stay revived and keep lifting the rating",
                                        isPositive: true))
        }
        switch weatherToday {
        case .rain:
            reasons.append(RatingReason(id: "weather", symbol: weatherToday.symbol,
                                        text: "Rain makes riders less patient", isPositive: false))
        case .fog:
            reasons.append(RatingReason(id: "weather", symbol: weatherToday.symbol,
                                        text: "Fog slows the trains", isPositive: false))
        case .windy:
            reasons.append(RatingReason(id: "weather", symbol: weatherToday.symbol,
                                        text: "Wind slows the trains and empties the parks", isPositive: false))
        case .sunny, .fair:
            break
        }
        for event in todayEvents where event.isActive(at: dayClock) && event.kind != .festival {
            reasons.append(RatingReason(id: "event-\(event.id)", symbol: event.symbol,
                                        text: describe(event, includeTiming: false), isPositive: false))
        }
        return reasons
    }
}
