import Foundation

/// What it takes to unlock a blueprint or restore a heritage site.
enum UnlockCondition: Equatable {
    case start
    case ridersServed(Int)
    case faresEarned(Int)
    case rating(Double)
    case stationsConnected(Int)
    case linesBuilt(Int)
    case day(Int)
    case revived(Double)
    case heritageRestored(Int)
    case nightRiders(Int)
    /// Secret: one line that stops at three food landmarks.
    case foodLine
    /// Heritage only: how many lines must serve the site.
    case servedBy(Int)
}

/// How close the player is to meeting a condition or goal.
struct ConditionProgress {
    let current: Double
    let target: Double
    let text: String

    var isMet: Bool { current >= target - 0.0001 }
    var fraction: Double { target > 0 ? min(1, max(0, current / target)) : 1 }
}

enum Format {
    /// A length of real time in plain words: "45 seconds", "12 minutes", "2 hours 5 minutes".
    static func duration(_ seconds: Int) -> String {
        if seconds < 60 { return seconds == 1 ? "1 second" : "\(max(1, seconds)) seconds" }
        let minutes = (seconds + 59) / 60
        if minutes < 60 { return minutes == 1 ? "1 minute" : "\(minutes) minutes" }
        let hours = minutes / 60, rest = minutes % 60
        let hourText = hours == 1 ? "1 hour" : "\(hours) hours"
        return rest == 0 ? hourText : "\(hourText) \(rest) minute\(rest == 1 ? "" : "s")"
    }

    static func stars(_ rating: Double) -> String {
        "★" + String(format: "%.1f", rating)
    }

    static func percent(_ fraction: Double) -> String {
        "\(Int((fraction * 100).rounded()))%"
    }

    static func ordinal(_ n: Int) -> String {
        let words = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth"]
        return n >= 1 && n <= words.count ? words[n - 1] : "\(n)th"
    }

    /// "1 rider", "2 riders". Pass `plural` for irregular words ("1 person", "3 people").
    static func count(_ n: Int, _ singular: String, _ plural: String? = nil) -> String {
        "\(n) \(n == 1 ? singular : (plural ?? singular + "s"))"
    }

    /// "Rider" or "Riders" on its own, for headlines and labels.
    static func noun(_ n: Int, _ singular: String, _ plural: String? = nil) -> String {
        n == 1 ? singular : (plural ?? singular + "s")
    }

    static func seconds(_ value: Double) -> String {
        "\(Int(value.rounded()))s"
    }
}
