import Combine
import Foundation

/// Source of truth for the game. SwiftUI observes the published values; GameScene reads
/// the simulation values every frame and calls `tick` to advance time.
///
/// Split across files:
/// - GameState.swift             storage, queries, messages, tips
/// - GameState+Town.swift        preparing the town, building, moving, restoring, the album
/// - GameState+Lines.swift       lines, pens, trains, line unlocks
/// - GameState+Riders.swift      the passenger simulation and route planning
/// - GameState+Revival.swift     neighborhood revival
/// - GameState+Progress.swift    rating, unlocks, tutorial, days, council, terms
@MainActor
final class GameState: ObservableObject {

    // MARK: Rules
    static let maxLinesPerStation = 3
    static let maxTrainsPerLine = 4
    static let maxWaitingPerStation = 12
    static let termLength = 7
    static let dayLength: Double = 150
    static let baseLines = 2
    static let baseCapacity = 6
    /// Matches the scene, so travel-time estimates line up with what the player sees.
    static let trainSpeed: Double = 70
    static let cellPoints: Double = 48
    static let dwellSeconds: Double = 0.7
    /// Columns of canal between neighboring districts.
    static let gapCols = 2
    /// A street at or above this vitality counts as revived, and never fades back.
    static let revivedThreshold = 0.5
    static let townNames = ["Willow Bend"]

    // MARK: Published (drives SwiftUI)
    @Published var phase: GamePhase = .appointment
    @Published var townName: String
    @Published var termNumber = 1
    /// There's no day limit any more: a district opens when its neighbor reaches a milestone.
    @Published var isEndless = true
    /// Districts whose milestone certificate has been shown (so it's offered once).
    var milestonesShown: Set<Int> = []
    @Published var landmarks: [Landmark] = []
    @Published var lines: [TransitLine] = []
    @Published var trainsPerLine: [Int: Int] = [:]
    @Published var fares = 40 {
        // A safety net: the treasury never shows less than nothing.
        didSet { if fares < 0 { fares = 0 } }
    }
    @Published var placingKind: LandmarkKind?
    @Published var selectedLineID: Int?
    /// An unbuilt line's pen, picked up from the dock: the next line drawn uses its color.
    @Published var armedColorIndex: Int?
    @Published var message: String?
    @Published var coachTip: CoachTip?
    /// Whether the showing tip is still true; checked as the game runs.
    var coachTipCheck: (() -> Bool)?
    @Published var tutorial: TutorialStep?
    @Published var hud = HUDSnapshot()
    @Published var unlocked: Set<LandmarkKind> = []
    @Published var unseenBlueprints: Set<LandmarkKind> = []
    @Published var isBookOpen = false
    @Published var bookDistrict: District = .oldTown
    @Published var councilOffer: [CouncilCard] = []
    @Published var approvedCards: [CouncilCard] = []
    @Published var gazette: GazetteEdition?
    @Published var goals: [TermGoal] = TermGoal.goals(forTerm: 1, district: .oldTown)
    @Published var speed: GameSpeed = .normal
    @Published var heritageGrantAvailable = false
    /// The council covers the first landmark of each term.
    @Published var landmarkGrantAvailable = true
    /// The district the camera is looking at. The menu's pens belong to this district.
    @Published var focusedDistrict: District = .oldTown
    /// Set to ask the scene to glide the camera to a district.
    @Published var cameraFocusRequest: District?
    /// Set to ask the scene to glide the camera to a landmark (from the attention list).
    @Published var cameraFocusLandmarkID: Int?
    @Published var isAttentionOpen = false
    /// The issue to highlight when the attention list opens from a map pin.
    @Published var attentionFocusID: String?
    /// The issue the scene should ring after "Show me".
    @Published var highlightIssueID: String?
    /// Which events were in effect last tick, to notice when one starts or ends.
    var activeEventSignature = ""
    @Published var lightRailUpgrades: Set<LightRailUpgrade> = []
    @Published var lightRailService: LightRailService = .standard
    /// Letters to the Mayor: open ones and the recent past.
    @Published var letters: [Letter] = []
    @Published var unreadLetters = 0
    /// Groups traveling together today: school trips, wedding parties, the inspector.
    @Published var trips: [SpecialTrip] = []
    /// A quick choice waiting for the mayor. The day pauses until it's answered.
    @Published var pendingDecision: SnapDecision?
    /// The station whose upgrade card is open.
    @Published var inspectedStationID: Int?
    var stationUpgrades: [Int: Set<StationUpgrade>] = [:]
    /// Trees and other decorations the mayor has placed.
    @Published var decorItems: [Decor] = []
    /// What's being placed, while the decorating tool is on.
    @Published var placingDecor: DecorKind?
    /// True while the decorating tool is set to remove.
    @Published var removingDecor = false
    var nextDecorID = 1
    /// Golden Tickets: the special currency. Earned by playing well; spent to finish building
    /// early or to invite a particular shop.
    @Published var tickets = 3
    /// True while placing a permit: the shop that moves in is a surprise.
    @Published var placingIsPermit = false
    /// Town Hotline: a call that's ringing now, and the call being read on screen.
    @Published var ringingCall: Letter?
    @Published var openCall: Letter?
    /// News by phone: a few notices worth hearing, from Pip at the station or a grateful caller.
    var newsQueue: [NewsCall] = []
    @Published var ringingNews = false
    @Published var openNews: NewsCall?
    var newsCooldown: Double = 6
    /// How far along each resident's story is, and the place their story centers on.
    var residentProgress: [String: Int] = [:]
    /// The Town Hotline opens once the town is up and running; Pip rings to say so.
    @Published var hotlineUnlocked = false
    /// Community: themed decorations unlocked, lost items already used, spotlight timing,
    /// tip jars by station, and advertising.
    var unlockedDecor: Set<String> = []
    /// Permits built so far: each one takes longer than the last.
    var buildsStarted = 0
    /// Lines opened (paid for) so far; Red and Blue are open from the start.
    @Published var openedLines = 2
    @Published var openLinePrompt: Int?
    /// The day number shown briefly when a new day rolls over quietly.
    @Published var dayBanner: Int?
    /// Rewards and pacing: ads, streaks, away earnings, queued reveals, and loud alerts.
    @Published var isAdPlaying = false
    var adsDate = ""
    var adsWatched = 0
    var streakDays = 0
    var lastPlayDay = ""
    var lastActive: Date?
    var earningRate: Double = 0
    var lastFaresTotal = 0
    var autosaveClock: Double = 0
    @Published var awayRecap: AwayRecap?
    var pendingReveals: [Int] = []
    var phoneQuietUntil = Date.distantPast
    @Published var alertNote: String?
    /// A small note when a Golden Ticket arrives, saying what it was for.
    @Published var ticketNote: String?
    var ticketNoteID = 0
    /// Away earnings: the town's typical takings per day, and today's starting total.
    var averageDayFares: Double = 0
    var dayFaresStart = 0
    var alertNoteID = 0
    /// Per-train upgrades by "line-slot", and which slot each live train fills.
    var trainUpgrades: [String: TrainUpgrade] = [:]
    var riverCache: Set<GridPoint>?
    var trainSlots: [Int: (lineID: Int, slot: Int)] = [:]
    @Published var upgradingLineID: Int?
    @Published var deleteLinePrompt: Int?
    /// Tunnel digging in progress, and placing a transit hub.
    @Published var tunnelStep: TunnelStep?
    @Published var placingHub = false
    /// A hub that just finished building, waiting for its name.
    @Published var hubNamingID: Int?
    var lostItemsUsed: Set<String> = []
    var spotlightTimer: Double = 60
    @Published var spotlightCard: SpotlightInfo?
    var tipJars: [Int: Int] = [:]
    /// Where the lost item is lying (in half squares), placed in view when the call comes in,
    /// and the return being confirmed.
    @Published var lostItemSpot: GridPoint?
    @Published var returnPrompt: Int?
    @Published var adsUnlocked = false
    var adCampaigns: [Int: AdCampaign] = [:]
    var residentHome: [String: Int] = [:]
    var hotlineTimer: Double = 30
    /// Decorating is unlocked by carrying riders; City Planning calls to announce it.
    @Published var decorUnlocked = false
    @Published var ringingFeature = false
    @Published var featureCallOpen = false
    var decorAnnounced = false
    /// UI requests: open the menu, and point at the decorating pen.
    @Published var dockOpenRequest = false
    @Published var decorSpotlight = false
    /// The Town Album: every shop's page, and the page being looked at.
    var shopRecords: [Int: ShopRecord] = [:]
    var nextCommentID = 0
    @Published var isAlbumOpen = false
    @Published var albumLandmarkID: Int?
    /// The shop of money and Golden Ticket bundles.
    @Published var isShopOpen = false
    /// A shop that just opened: its postcard is on screen (time holds while it is).
    @Published var revealedLandmarkID: Int?
    var ringTimer: Double = 0
    var freeTrainAvailable = false
    var recentCouncilCards: [CouncilCard] = []
    var seenDecisions: [String] = []
    var nextLetterID = 1
    var nextTripID = 1
    /// When today's snap decision appears, as a fraction of the day. Nil once shown.
    var decisionClock: Double?
    var tripClock: Double?
    /// One-day effects from snap decisions, cleared each morning.
    var todayRiderMultiplier = 1.0
    var todayPatienceMultiplier = 1.0
    var todayCategoryBoost: [LandmarkCategory: Double] = [:]

    // MARK: Town layout
    var onChange: (() -> Void)?
    var townSeed: UInt64
    /// Bumped for each new term so the scene knows to rebuild the city.
    var townVersion = 0
    /// Bumped when a district opens, so the scene redraws the city around it.
    var cityVersion = 0
    var isTownReady = false
    /// Width of one district in grid columns. The whole city is laid out in a row of districts.
    var districtCols = 0
    var rows = 0
    /// The newest district (this term's). Every district before it is open too.
    var currentDistrict: District = .oldTown

    // MARK: Simulation (read by the scene every frame; not published)
    var day = 1
    var dayClock: Double = 0
    var satisfaction: Double = 0.25
    var bestRating: Double = 1
    var vitalityGrid: [Double] = []
    var averageVitality: Double = 0.05
    /// Revived share of this term's district.
    var revivedFraction: Double = 0
    var districtRevived: [District: Double] = [:]
    var stationHealth: [Int: Double] = [:]
    var recentTraffic: [Int: Double] = [:]
    var waiting: [Int: [Rider]] = [:]
    var onboard: [Int: [Rider]] = [:]
    var trainLine: [Int: Int] = [:]
    /// For each destination: expected seconds to get there from every connected station,
    /// counting waits, rides, and changes. Rebuilt whenever the network changes.
    var travelCache: [Int: [Int: Double]] = [:]
    /// How busy the town feels right now (0...1): recent deliveries plus people waiting.
    var activity: Double = 0
    var deliveryPulse: Double = 0
    var stats = TermStats()
    var report = DayReport()
    var events: [SimEvent] = []
    var featuredToday: LandmarkCategory?
    var featuredTomorrow: LandmarkCategory?
    var weatherToday: Weather = .fair
    var weatherTomorrow: Weather = .fair
    /// Gazette quotes and briefs already printed, so the paper doesn't repeat itself.
    var usedGazetteKeys: Set<String> = []
    var completedPairs: Set<String> = []
    var dayCard: CouncilCard?
    var pendingDayCard: CouncilCard?
    /// Extra lines granted by a council charter, per district.
    var bonusLines: [District: Int] = [:]
    /// The most revived each district has ever been, so earned lines never lock again.
    var districtBestRevived: [District: Double] = [:]
    var announcedLineSlots: [District: Int] = [:]
    var todayEvents: [TownEvent] = []
    var tomorrowEvents: [TownEvent] = []
    var nextEventID = 1
    /// Riders who have boarded the light rail, ever. Unlocks light rail upgrades.
    var lightRailRiders = 0

    var spawnAccumulator: Double = 0
    var revivalAccumulator: Double = 0
    var hudAccumulator: Double = 0
    var progressAccumulator: Double = 0
    var nextID = 1
    var nextRiderID = 1
    var tipsShown: Set<String> = []
    var tutorialLandmarkID: Int?

    init(save: SaveGame? = nil) {
        townSeed = UInt64.random(in: 1...UInt64.max)
        townName = GameState.townNames[0]
        unlocked = Set(LandmarkKind.starters(in: .oldTown))
        if let save {
            restore(from: save)
        }
    }

    // MARK: Queries

    func landmark(id: Int) -> Landmark? { landmarks.first { $0.id == id } }
    func landmark(at cell: GridPoint) -> Landmark? { landmarks.first { $0.cell == cell } }
    func line(id: Int) -> TransitLine? { lines.first { $0.id == id } }
    /// Lines are citywide now: one of each color.
    func line(colorIndex: Int, in district: District) -> TransitLine? {
        lines.first { $0.colorIndex == colorIndex && !$0.isLightRail }
    }
    var lightRail: TransitLine? { lines.first { $0.isLightRail } }

    var openLandmarks: [Landmark] { landmarks.filter(\.isOpen) }
    var builtLines: [TransitLine] { lines.filter { $0.stops.count >= 2 } }

    func isBuilt(_ kind: LandmarkKind) -> Bool {
        landmarks.contains { $0.kind == kind }
    }

    func isOpen(_ kind: LandmarkKind) -> Bool {
        landmarks.contains { $0.kind == kind && $0.isOpen }
    }

    func linesServing(_ landmarkID: Int) -> [TransitLine] {
        lines.filter { $0.stops.contains(landmarkID) }
    }

    /// Hubs can serve every subway line; other stations are capped. The light rail doesn't count.
    func maxLines(at landmarkID: Int) -> Int {
        landmark(id: landmarkID)?.kind.info.category == .hub ? Palette.lineCount : GameState.maxLinesPerStation
    }

    func subwayLinesServing(_ landmarkID: Int) -> [TransitLine] {
        lines.filter { !$0.isLightRail && $0.stops.contains(landmarkID) }
    }

    func isStationFull(_ landmarkID: Int, ignoring lineID: Int? = nil) -> Bool {
        subwayLinesServing(landmarkID).filter { $0.id != lineID }.count >= maxLines(at: landmarkID)
    }

    func waitingCount(at landmarkID: Int) -> Int {
        waiting[landmarkID]?.count ?? 0
    }

    var currentDayPhase: DayPhase { DayPhase.at(progress: dayClock) }

    /// True while time should pass and trains should move. Time holds still until the
    /// first line is laid, so the opening moments of the tutorial are never rushed.
    var isSimulating: Bool {
        phase == .playing && isTownReady && !isBookOpen && speed != .paused && tutorial != .drawLine
            && revealedLandmarkID == nil && !isShopOpen && !isAlbumOpen && !isAdPlaying && awayRecap == nil
    }

    func hasCard(_ card: CouncilCard) -> Bool { approvedCards.contains(card) }

    // MARK: Messages, tips, and events

    func show(_ text: String) {
        guard message != text else { return }
        message = text
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(2.4))
            guard let self, self.message == text else { return }
            self.message = nil
        }
    }

    /// Shows a tip the first time something happens; never again after that.
    /// Show a helper tip once. `stillTrue` is checked as the game runs: the moment the tip
    /// stops being true (the site's been restored, say), it closes itself.
    func showTip(_ id: String, symbol: String, title: String, text: String, stillTrue: (() -> Bool)? = nil) {
        guard !tipsShown.contains(id) else { return }
        if let stillTrue, !stillTrue() { return }
        tipsShown.insert(id)
        let tip = CoachTip(id: id, symbol: symbol, title: title, text: text)
        coachTipCheck = stillTrue
        coachTip = tip
        Task { [weak self] in
            try? await Task.sleep(for: .seconds(8))
            guard let self, self.coachTip == tip else { return }
            self.coachTip = nil
        }
    }

    func dismissTip() {
        coachTip = nil
    }

    func drainEvents() -> [SimEvent] {
        guard !events.isEmpty else { return [] }
        let drained = events
        events.removeAll()
        return drained
    }

    func makeID() -> Int {
        defer { nextID += 1 }
        return nextID
    }

    /// Tells the scene the town's structure changed (landmarks, lines, trains).
    func changed() {
        onChange?()
    }
}
