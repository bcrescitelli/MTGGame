import Foundation

/// One stretch of track between two neighboring stops on a line, in either direction.
struct TrackKey: Hashable, Codable {
    let lineID: Int
    let a: Int
    let b: Int

    init(lineID: Int, _ first: Int, _ second: Int) {
        self.lineID = lineID
        a = min(first, second)
        b = max(first, second)
    }
}

/// A disruption or occasion, announced in advance. Each runs for part of the day: some
/// start in the morning, some arrive mid-day, so the network has to be redrawn around them.
struct TownEvent: Codable, Identifiable {
    enum Kind: String, Codable {
        /// Closes one station for part of the day.
        case parade
        /// Closes one station in the morning; food stops in that district draw more riders.
        case streetMarket
        /// Closes one stretch of track all day.
        case roadworks
        /// Floods up to two stations in one district for the afternoon.
        case storm
        /// Stops every train on one line for a few hours.
        case powerCut
        /// Rocks on the line: closes one stretch of track until evening.
        case rockfall
        /// Citywide: riders from every linked district head to one district.
        case festival
    }

    let id: Int
    let kind: Kind
    let day: Int
    /// Part of the day the event runs, as fractions of the day (0 is first light, 1 is the last train).
    var start: Double = 0
    var end: Double = 1
    var stationIDs: [Int] = []
    var track: TrackKey?
    var lineID: Int?
    var district: District?

    func isActive(at clock: Double) -> Bool { clock >= start && clock < end }

    var symbol: String {
        switch kind {
        case .parade: return "flag.fill"
        case .streetMarket: return "basket.fill"
        case .roadworks: return "cone.fill"
        case .storm: return "cloud.bolt.rain.fill"
        case .powerCut: return "bolt.slash.fill"
        case .rockfall: return "mountain.2.fill"
        case .festival: return "sparkles"
        }
    }

    var title: String {
        switch kind {
        case .parade: return "Parade"
        case .streetMarket: return "Street market"
        case .roadworks: return "Roadworks"
        case .storm: return "Storm"
        case .powerCut: return "Power cut"
        case .rockfall: return "Rockfall"
        case .festival: return district.map { TownEvent.festivalName($0) } ?? "Festival"
        }
    }

    /// When it happens, in plain words.
    var timing: String {
        if start <= 0.01 && end >= 0.99 { return "all day" }
        return "\(TownEvent.timeName(start)) to \(TownEvent.timeName(end))"
    }

    static func timeName(_ clock: Double) -> String {
        switch clock {
        case ..<0.05: return "first light"
        case ..<0.3: return "mid-morning"
        case ..<0.45: return "late morning"
        case ..<0.55: return "midday"
        case ..<0.7: return "mid-afternoon"
        case ..<0.8: return "evening"
        case ..<0.95: return "nightfall"
        default: return "the last train"
        }
    }

    static func festivalName(_ district: District) -> String {
        switch district {
        case .oldTown: return "Old Town Fair"
        case .harborside: return "Harborside Regatta"
        case .hillQuarter: return "Hill Quarter Garden Show"
        case .lanternRow: return "Lantern Festival"
        }
    }
}

/// Something on the map worth knowing about, for the bell list and the map pins.
struct AttentionIssue: Identifiable, Equatable {
    enum Kind: Equatable {
        /// A disruption happening now.
        case disruption
        /// A disruption coming later today.
        case upcoming
        case crowded
        case festival
        /// A group traveling together today.
        case trip
    }

    let id: String
    let kind: Kind
    let title: String
    let detail: String
    let symbol: String
    let district: District
    let track: TrackKey?
    let stationID: Int?

    /// Whether this counts toward the bell: things to act on now.
    var needsAction: Bool { kind == .disruption || kind == .upcoming || kind == .crowded || kind == .trip }
}

/// Earned through use, then bought: improvements to the light rail.
enum LightRailUpgrade: String, CaseIterable, Codable, Identifiable {
    case longerCars, expressService, nightService

    var id: String { rawValue }

    var title: String {
        switch self {
        case .longerCars: return "Longer Cars"
        case .expressService: return "Express Service"
        case .nightService: return "Night Service"
        }
    }

    var effect: String {
        switch self {
        case .longerCars: return "Light rail trains carry 18 riders instead of 12."
        case .expressService: return "Light rail runs as fast as the subway."
        case .nightService: return "More riders cross between districts after dark."
        }
    }

    var symbol: String {
        switch self {
        case .longerCars: return "tram.fill"
        case .expressService: return "hare.fill"
        case .nightService: return "moon.stars.fill"
        }
    }

    var ridersNeeded: Int {
        switch self {
        case .longerCars: return 40
        case .expressService: return 120
        case .nightService: return 220
        }
    }

    var cost: Int {
        switch self {
        case .longerCars: return 120
        case .expressService: return 200
        case .nightService: return 240
        }
    }
}
