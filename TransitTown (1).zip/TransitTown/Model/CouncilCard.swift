import Foundation

/// A proposal brought to the mayor at the end of each day. Approve one per session.
/// Some are plain good news; the dilemmas trade one thing for another.
enum CouncilCard: String, CaseIterable, Identifiable, Codable {
    // The original twelve
    case longerTrains, expressTimetable, benches, tourismPosters, streetTrees, heritageGrant
    case newLineCharter, festivalOfLights, marketDay, freeFareDay, transitBond, gardenClub
    // Permanent
    case lateTimetable, quietCarriages, fareRise, civicPride, cornerShops, welcomeSigns
    case transferTickets, stationMasters, railHeritage, rollingStockDeal, architectsGuild
    case weatherWatch, disruptionPlan, communityRadio
    // Tomorrow only
    case bookFair, picnicDay, carFreeDay, peakPricing, dayOfRest, openHouse, tourDay
    // Takes effect now
    case sellDepot, paintTheTown, pressConference
    // Until used
    case landmarkVoucher, trainVoucher

    enum Duration {
        case permanent, tomorrow, instant, untilUsed

        var label: String {
            switch self {
            case .permanent: return "PERMANENT"
            case .tomorrow: return "TOMORROW ONLY"
            case .instant: return "TAKES EFFECT NOW"
            case .untilUsed: return "UNTIL USED"
            }
        }
    }

    var id: String { rawValue }

    var department: String {
        switch self {
        case .longerTrains, .expressTimetable, .newLineCharter, .lateTimetable, .quietCarriages,
             .transferTickets, .rollingStockDeal, .trainVoucher:
            return "Department of Transit"
        case .benches, .streetTrees, .gardenClub, .cornerShops, .picnicDay, .paintTheTown, .stationMasters:
            return "Parks & Streets"
        case .tourismPosters, .welcomeSigns, .tourDay: return "Tourism Board"
        case .heritageGrant, .railHeritage, .architectsGuild, .landmarkVoucher: return "Heritage Trust"
        case .festivalOfLights, .marketDay, .bookFair, .openHouse, .carFreeDay: return "Events Office"
        case .freeFareDay, .civicPride, .pressConference, .communityRadio, .dayOfRest: return "Mayor's Office"
        case .transitBond, .fareRise, .peakPricing, .sellDepot: return "Treasury"
        case .weatherWatch, .disruptionPlan: return "Public Safety"
        }
    }

    var title: String {
        switch self {
        case .longerTrains: return "Longer Trains"
        case .expressTimetable: return "Express Timetable"
        case .benches: return "Benches & Awnings"
        case .tourismPosters: return "Visit Us! Posters"
        case .streetTrees: return "Street Tree Program"
        case .heritageGrant: return "Heritage Grant"
        case .newLineCharter: return "New Line Charter"
        case .festivalOfLights: return "Festival of Lights"
        case .marketDay: return "Market Day"
        case .freeFareDay: return "Free Fare Day"
        case .transitBond: return "Transit Bond"
        case .gardenClub: return "Garden Club Weekend"
        case .lateTimetable: return "Late Timetable"
        case .quietCarriages: return "Quiet Carriages"
        case .fareRise: return "Fare Rise"
        case .civicPride: return "Civic Pride Week"
        case .cornerShops: return "Corner Shop Grants"
        case .welcomeSigns: return "Welcome Signs"
        case .transferTickets: return "Through Tickets"
        case .stationMasters: return "Station Masters"
        case .railHeritage: return "Rail Heritage Society"
        case .rollingStockDeal: return "Rolling Stock Deal"
        case .architectsGuild: return "Architects' Guild"
        case .weatherWatch: return "Weather Watch"
        case .disruptionPlan: return "Disruption Plan"
        case .communityRadio: return "Community Radio"
        case .bookFair: return "Book Fair"
        case .picnicDay: return "Picnic Day"
        case .carFreeDay: return "Car-Free Day"
        case .peakPricing: return "Peak Pricing"
        case .dayOfRest: return "Day of Rest"
        case .openHouse: return "Open House"
        case .tourDay: return "Coach Tour Day"
        case .sellDepot: return "Sell the Old Depot"
        case .paintTheTown: return "Paint the Town"
        case .pressConference: return "Press Conference"
        case .landmarkVoucher: return "Builders' Voucher"
        case .trainVoucher: return "Spare Train"
        }
    }

    var quote: String {
        switch self {
        case .longerTrains: return "Folks are pressing their noses to the glass. Give them room."
        case .expressTimetable: return "Shave a minute here, a minute there, and the whole town runs on time."
        case .benches: return "Nobody minds a wait with a good bench and a little shade."
        case .tourismPosters: return "Put our town on every station wall from here to the coast."
        case .streetTrees: return "Plant a tree, and the street remembers it's a street."
        case .heritageGrant: return "Those old buildings are the town's memory. Let's pay for a little remembering."
        case .newLineCharter: return "One more line. We'll find the paint."
        case .festivalOfLights: return "Lanterns on every lamppost. Nobody's going home early."
        case .marketDay: return "Pies, jams, and a man selling one very large marrow."
        case .freeFareDay: return "Let them ride free once and they'll ride forever."
        case .transitBond: return "The bank's feeling generous. Don't tell them I said so."
        case .gardenClub: return "Two hundred volunteers and every trowel in town."
        case .lateTimetable: return "The last train leaves too early. Ask anyone at the cinema."
        case .quietCarriages: return "Fewer seats, more peace. People will thank us."
        case .fareRise: return "A dollar more won't break anyone. It might mend the roof."
        case .civicPride: return "If we tell people the town is wonderful, they start to agree."
        case .cornerShops: return "A street with a shop on the corner is a street people walk down."
        case .welcomeSigns: return "Big letters at every hub. Welcome, and mind the gap."
        case .transferTickets: return "One ticket, any train. It's only fair."
        case .stationMasters: return "Someone in a good hat to keep the platforms moving."
        case .railHeritage: return "We have volunteers who know every rivet by name."
        case .rollingStockDeal: return "The next town over is selling trains. Barely used."
        case .architectsGuild: return "They'll draw it for free if we let them put their name on it."
        case .weatherWatch: return "A barometer at every station. It's not complicated."
        case .disruptionPlan: return "Every closure needs a plan B. Let's write them down."
        case .communityRadio: return "Read the mayor's mail on air. People love a good letter."
        case .bookFair: return "Tables of secondhand books from here to the bandstand."
        case .picnicDay: return "Blankets on every lawn. Bring a cake."
        case .carFreeDay: return "Close the roads for a day and see who takes the train."
        case .peakPricing: return "Charge a little more when it's busy. Every big city does it."
        case .dayOfRest: return "Let the town have a quiet day. We've earned it."
        case .openHouse: return "Every front door open, every garden on show."
        case .tourDay: return "Three coaches of visitors, all with cameras."
        case .sellDepot: return "That old depot is just collecting pigeons. Someone wants to buy it."
        case .paintTheTown: return "Fresh paint on every hub, by Friday."
        case .pressConference: return "Say something nice about the trains. On camera."
        case .landmarkVoucher: return "A builder owes us a favor. Let's cash it in."
        case .trainVoucher: return "There's a train in the shed nobody's using."
        }
    }

    var councillor: String {
        switch self {
        case .longerTrains, .heritageGrant, .transitBond, .fareRise, .railHeritage, .sellDepot, .landmarkVoucher:
            return "Cllr. Ada Brook"
        case .expressTimetable, .newLineCharter, .freeFareDay, .lateTimetable, .transferTickets,
             .rollingStockDeal, .peakPricing, .trainVoucher:
            return "Cllr. Otis Grey"
        case .benches, .streetTrees, .marketDay, .gardenClub, .cornerShops, .picnicDay, .paintTheTown,
             .dayOfRest, .quietCarriages:
            return "Cllr. June Mallow"
        case .tourismPosters, .festivalOfLights, .welcomeSigns, .bookFair, .tourDay, .openHouse,
             .carFreeDay, .civicPride, .pressConference, .communityRadio:
            return "Cllr. Bea Fenwick"
        case .stationMasters, .architectsGuild, .weatherWatch, .disruptionPlan:
            return "Cllr. Rufus Wren"
        }
    }

    var effect: String {
        switch self {
        case .longerTrains: return "Every train carries 2 more riders."
        case .expressTimetable: return "Trains run 15% faster."
        case .benches: return "Riders wait 30% longer before giving up."
        case .tourismPosters: return "50% more visitors arrive at the hubs."
        case .streetTrees: return "Neighborhoods revive 30% faster."
        case .heritageGrant: return "Your next restoration costs half."
        case .newLineCharter: return "The town can open another line right away."
        case .festivalOfLights: return "Twice as many night riders, and night fares double."
        case .marketDay: return "Food stops draw 80% more riders, and food trips pay $1 more."
        case .freeFareDay: return "No fares, but the town rating rises twice as fast."
        case .transitBond: return "Receive $150."
        case .gardenClub: return "Revives the streets around every open landmark."
        case .lateTimetable: return "30% more riders at night."
        case .quietCarriages: return "Riders are 15% more patient, but subway trains carry 1 fewer."
        case .fareRise: return "Every fare pays $1 more, but riders are 10% less patient."
        case .civicPride: return "The town rating rises 15% faster."
        case .cornerShops: return "Neighborhoods revive 20% faster."
        case .welcomeSigns: return "25% more visitors arrive at the hubs."
        case .transferTickets: return "Changing trains no longer costs $1, and riders changing trains keep their patience."
        case .stationMasters: return "Every platform holds 4 more waiting riders."
        case .railHeritage: return "Restorations cost 25% less."
        case .rollingStockDeal: return "New trains cost $20 less."
        case .architectsGuild: return "Landmarks cost 15% less."
        case .weatherWatch: return "Rain, fog, and wind have half the effect."
        case .disruptionPlan: return "Disruptions are a quarter shorter."
        case .communityRadio: return "Letters to the Mayor pay 50% more."
        case .bookFair: return "Culture stops draw 80% more riders."
        case .picnicDay: return "Parks and gardens draw 80% more riders."
        case .carFreeDay: return "25% more riders take the train."
        case .peakPricing: return "Every fare pays $2 more, but riders are 20% less patient."
        case .dayOfRest: return "30% fewer riders, and they're twice as patient."
        case .openHouse: return "Neighborhoods revive 50% faster."
        case .tourDay: return "Twice as many visitors arrive at the hubs."
        case .sellDepot: return "Receive $250, but the town rating drops."
        case .paintTheTown: return "Revives the streets around every hub."
        case .pressConference: return "The town rating rises a little."
        case .landmarkVoucher: return "Your next landmark is free."
        case .trainVoucher: return "Your next train is free."
        }
    }

    var symbol: String {
        switch self {
        case .longerTrains: return "tram.fill"
        case .expressTimetable: return "timer"
        case .benches: return "chair.lounge.fill"
        case .tourismPosters: return "photo.artframe"
        case .streetTrees: return "tree.fill"
        case .heritageGrant: return "building.columns.fill"
        case .newLineCharter: return "arrow.triangle.branch"
        case .festivalOfLights: return "lightbulb.fill"
        case .marketDay: return "basket.fill"
        case .freeFareDay: return "ticket.fill"
        case .transitBond: return "banknote.fill"
        case .gardenClub: return "leaf.fill"
        case .lateTimetable: return "moon.fill"
        case .quietCarriages: return "speaker.slash.fill"
        case .fareRise: return "dollarsign.circle.fill"
        case .civicPride: return "rosette"
        case .cornerShops: return "storefront.fill"
        case .welcomeSigns: return "signpost.right.fill"
        case .transferTickets: return "arrow.triangle.swap"
        case .stationMasters: return "person.badge.shield.checkmark.fill"
        case .railHeritage: return "gearshape.2.fill"
        case .rollingStockDeal: return "train.side.front.car"
        case .architectsGuild: return "pencil.and.ruler.fill"
        case .weatherWatch: return "barometer"
        case .disruptionPlan: return "list.clipboard.fill"
        case .communityRadio: return "radio.fill"
        case .bookFair: return "books.vertical.fill"
        case .picnicDay: return "sun.max.fill"
        case .carFreeDay: return "car.fill"
        case .peakPricing: return "chart.line.uptrend.xyaxis"
        case .dayOfRest: return "cup.and.saucer.fill"
        case .openHouse: return "house.fill"
        case .tourDay: return "bus.fill"
        case .sellDepot: return "building.2.fill"
        case .paintTheTown: return "paintbrush.fill"
        case .pressConference: return "mic.fill"
        case .landmarkVoucher: return "hammer.fill"
        case .trainVoucher: return "ticket"
        }
    }

    var duration: Duration {
        switch self {
        case .longerTrains, .expressTimetable, .benches, .tourismPosters, .streetTrees, .newLineCharter,
             .lateTimetable, .quietCarriages, .fareRise, .civicPride, .cornerShops, .welcomeSigns,
             .transferTickets, .stationMasters, .railHeritage, .rollingStockDeal, .architectsGuild,
             .weatherWatch, .disruptionPlan, .communityRadio:
            return .permanent
        case .festivalOfLights, .marketDay, .freeFareDay, .bookFair, .picnicDay, .carFreeDay,
             .peakPricing, .dayOfRest, .openHouse, .tourDay:
            return .tomorrow
        case .transitBond, .gardenClub, .sellDepot, .paintTheTown, .pressConference:
            return .instant
        case .heritageGrant, .landmarkVoucher, .trainVoucher:
            return .untilUsed
        }
    }

    /// Three different proposals the mayor hasn't already made permanent. Cards seen recently
    /// are held back so the deck feels fresh through the whole game.
    static func draw(count: Int, approved: [CouncilCard], canAddLine: Bool, hasHeritageLeft: Bool,
                     grantPending: Bool, recentlySeen: [CouncilCard] = []) -> [CouncilCard] {
        let eligible = allCases.filter { card in
            if card.duration == .permanent && approved.contains(card) { return false }
            if card == .newLineCharter && !canAddLine { return false }
            if card == .heritageGrant && (!hasHeritageLeft || grantPending) { return false }
            return true
        }
        let fresh = eligible.filter { !recentlySeen.contains($0) }
        let pool = fresh.count >= count ? fresh : eligible
        return Array(pool.shuffled().prefix(count))
    }
}
