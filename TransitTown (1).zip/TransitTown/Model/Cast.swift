import Foundation

/// The people of the town. Each resident has their own voice and a story told across a few
/// calls: a request, and when it's done, a follow-up call that moves their story along.
/// Places are filled in when they call: {a} and {b} are landmark names, {n} a number.
struct ResidentChapter {
    enum Goal {
        /// Put {a} and {b} on one line.
        case connect
        /// Give {a} its first line.
        case serve
        /// Give {a} a second line.
        case twoLines
        /// Carry {n} riders to {a}.
        case carry(Int)
        /// Place a decoration beside {a}.
        case decor
        /// Put one more train into service.
        case train
        /// Open one more transit hub.
        case hub
        /// Give {a} and {b} a train stop each.
        case serveBoth
    }

    let goal: Goal
    /// Use the place from this resident's earlier calls as {a}, if it's still open.
    var usesHome = false
    let ask: String
    let thanks: String
    /// The comment card they leave at the place once it's done.
    let card: String
}

struct Resident {
    let id: String
    let name: String
    let role: String
    let pitch: Double
    let chapters: [ResidentChapter]
}

enum Cast {
    static let residents: [Resident] = [
        Resident(id: "bertram", name: "Bertram Puddle", role: "retired tuba player", pitch: 0.82, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Bertram Puddle here. My sister Agatha lives by the {a}, I live by the {b}, and we haven't had tea in eleven years. Would you put us on the same line? I'll bring the biscuits.",
                thanks: "We had tea. The tea was piping hot. Agatha was not. Still, she kept the biscuits, which I'm told is a breakthrough.",
                card: "Had tea here with my sister. One of us enjoyed it."),
            ResidentChapter(goal: .carry(12), usesHome: true,
                ask: "Agatha's playing the recorder at the {a} on Sunday. She says if twelve people come, she'll forgive me for missing her last recital. That was in 1987. Could you bring twelve people?",
                thanks: "Thirteen came. Agatha has officially forgiven me for 1987. We're now working through 1988.",
                card: "Recorder recital: thirteen in the audience, one apology accepted."),
            ResidentChapter(goal: .serve,
                ask: "Agatha wants to visit me for once, but there's no train to the {a} and she refuses to walk past the geese. Would you give it a stop?",
                thanks: "She came by train and stayed for supper. She even laughed at my tuba joke. Eleven years, Mayor. Thank you.",
                card: "Agatha visited. Tea again on Thursday."),
        ]),
        Resident(id: "clementine", name: "Clementine Dart", role: "age nine, future train driver", pitch: 1.45, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Hi Mayor, it's Clementine, I'm nine. The {a} only has one line and that is not enough lines. Can you give it a second one? Please and thank you.",
                thanks: "TWO LINES! I rode both of them twice. Mum says I'm only allowed to call you once a week now, so see you next week.",
                card: "Two lines! 10 out of 10. (Clementine, age 9)"),
            ResidentChapter(goal: .carry(10),
                ask: "It's Clementine again! I'm doing a school project on trains. Can you get ten people to the {a} so I can count them for my graph?",
                thanks: "My graph has a VERY tall bar now. I got a gold star. You can have half of it. I cut it very carefully.",
                card: "I counted everybody. My graph is very tall."),
            ResidentChapter(goal: .connect,
                ask: "Mayor, I designed a new line in crayon. It goes from the {a} to the {b}. Will you build it? It's mostly red.",
                thanks: "You built my crayon line! When I grow up I'm going to be mayor. Or a train. I haven't decided.",
                card: "This is MY line. I designed it. Ask anyone."),
        ]),
        Resident(id: "brine", name: "Captain Morwenna Brine", role: "retired sea captain", pitch: 0.78, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Captain Brine, retired. The {a} hasn't a single train calling. A port with no ships is just a puddle, Mayor. Will you give it a stop?",
                thanks: "Trains calling at the {a} like gulls round a fishing boat. Splendid work. I've stopped shouting at the harbor. Mostly.",
                card: "Finally, a proper port of call. Fair winds."),
            ResidentChapter(goal: .connect, usesHome: true,
                ask: "Every sailor needs a route home. Mine runs from the {a} to the {b}. Will you chart it with one line?",
                thanks: "Sailed it twice. Smooth as a millpond, and I don't hand out millponds lightly.",
                card: "Smooth sailing. Would board again."),
            ResidentChapter(goal: .carry(15), usesHome: true,
                ask: "Captain's orders: I need fifteen hands at the {a} for my ninetieth birthday. Can you get them aboard?",
                thanks: "Fifteen came and sang sea shanties, terribly. Best birthday since the storm of sixty-two, and I was shipwrecked for that one.",
                card: "Ninety today. Still the loudest voice in the room."),
        ]),
        Resident(id: "ottoline", name: "Ottoline Fairweather", role: "amateur meteorologist", pitch: 1.2, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Ottoline Fairweather, the barometer lady. The crowds at the {a} are building like storm clouds. Could you add a second line before they break?",
                thanks: "The crowd cleared like a summer squall. I've written you up in the Weather Society newsletter. Page four. With a diagram.",
                card: "Forecast: sunny, with light crowds. Accurate!"),
            ResidentChapter(goal: .serve,
                ask: "The best cloud-watching in town is at the {a}, and nobody can get there. Would you give it a stop?",
                thanks: "Fourteen people watched the clouds yesterday. One cloud looked exactly like you. I meant that kindly.",
                card: "Saw a cloud shaped like a teapot. Five stars."),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "I'm forecasting the sunset of the year at the {a}. Ninety percent certain. Can you bring ten people to watch it with me?",
                thanks: "It was ninety-eight percent perfect. The other two percent was a pigeon, sitting directly in front of it.",
                card: "Sunset: 98%. Pigeon: 2%."),
        ]),
        Resident(id: "ambrose", name: "Ambrose Tuttle", role: "the town's oldest resident", pitch: 0.7, chapters: [
            ResidentChapter(goal: .connect,
                ask: "This is Ambrose Tuttle. I'm a hundred and three. When I was a boy, a train ran from the {a} to the {b}. Would you put them on one line, so I can ride it once more?",
                thanks: "I rode it. The seats are softer and the tickets are cheaper. Everything else was exactly as I remembered.",
                card: "First rode this line in 1931. Still lovely."),
            ResidentChapter(goal: .carry(12), usesHome: true,
                ask: "I'm telling stories at the {a} on Saturday. Could you bring me twelve listeners? It would be my biggest audience in eighty years.",
                thanks: "They laughed in all the right places, and one young man cried at the story about the goat. Rightly so. It was a very good goat.",
                card: "Come for the stories. Stay for the goat."),
            ResidentChapter(goal: .twoLines, usesHome: true,
                ask: "Since the stories, the {a} has been terribly busy. Would you give it a second line, so the young ones can get there?",
                thanks: "Two lines, just like when I was a lad. People stop me in the street now. At a hundred and three, that takes a while.",
                card: "A hundred and three and still a regular."),
        ]),
        Resident(id: "priya", name: "Priya Nandakumar", role: "night-shift jazz pianist", pitch: 0.95, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Hey, Mayor. Priya. I play piano most nights at the {a}, and there's no train to get there. Could you give it a stop?",
                thanks: "Full room last night. The last train went past outside right on the beat. You can't book that kind of timing.",
                card: "Played here till midnight. The trains kept time."),
            ResidentChapter(goal: .connect, usesHome: true,
                ask: "My drummer lives by the {b} and gets lost every single night. Will you put him on a line straight to the {a}?",
                thanks: "He made soundcheck for the first time in three years. He's very suspicious about it. So is the band.",
                card: "Drummer arrived on time. Unprecedented."),
            ResidentChapter(goal: .carry(14), usesHome: true,
                ask: "We're recording a live album at the {a}. Can you bring fourteen people? A good crowd makes a good record.",
                thanks: "You can hear the trains on the record if you listen closely. We've named the album Last Stop.",
                card: "Recorded live here. Listen for the 11:40."),
        ]),
        Resident(id: "fergus", name: "Fergus Oakley", role: "the town gardener", pitch: 0.9, chapters: [
            ResidentChapter(goal: .carry(10),
                ask: "Fergus, the gardener. My tulips by the {a} are finally out, and nobody's seen them. Could you bring ten people by?",
                thanks: "Ten visitors and only one stepped on a tulip. He apologized to it, so I've decided to like him.",
                card: "Mind the tulips. They're mine. (Fergus)"),
            ResidentChapter(goal: .serve,
                ask: "I've a wheelbarrow of seedlings for the {a}, and no train to put them on. Would you give it a stop?",
                thanks: "The conductor carried the seedlings on his lap the whole way. He has a real gift for petunias. We're friends now.",
                card: "Brought seedlings by train. Conductor very gentle."),
            ResidentChapter(goal: .connect,
                ask: "I'm planting matching flower beds at the {a} and the {b}. Would you put them on the same line? My back would thank you.",
                thanks: "Matching beds at both ends. People are calling it the Petal Line. I didn't name it, but I'm not stopping them.",
                card: "Ride the Petal Line in spring. Trust me."),
        ]),
        Resident(id: "philippa", name: "Lady Philippa Snodgrass", role: "of the Snodgrasses", pitch: 1.1, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Philippa Snodgrass speaking. The {a} is far too popular for one little line. I'd like it to have two. Can you arrange that?",
                thanks: "Adequate. More than adequate. Fine, it's wonderful. Don't make a fuss about it.",
                card: "Acceptable. (P. Snodgrass)"),
            ResidentChapter(goal: .connect,
                ask: "My bridge club meets at the {a} and my dressmaker is by the {b}. Could they share a line? I refuse to change trains in this hat.",
                thanks: "Not a single change of train. The hat arrived intact, and the bridge club is jealous of it. As they should be.",
                card: "Excellent service. The hat agrees."),
            ResidentChapter(goal: .carry(12),
                ask: "I'm hosting a charity tea at the {a}. I've promised twelve guests. Can you see that twelve arrive?",
                thanks: "Fourteen came and we raised enough for new benches. I may have enjoyed myself. Tell no one.",
                card: "A charming tea. Not that I'm charmed."),
        ]),
        Resident(id: "finch", name: "Marlowe Finch", role: "retired detective", pitch: 0.85, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Finch, retired detective. I've been watching the {a}. Long queues, long faces, one line. Would you add a second and close the case?",
                thanks: "Case closed. The culprit was too few trains. In my experience, it usually is.",
                card: "Investigated. Found delightful. Case closed."),
            ResidentChapter(goal: .serve,
                ask: "A mystery: nobody ever reaches the {a}. No train, no witnesses. Would you give it a stop so I can look into it?",
                thanks: "Plenty of witnesses now. Turns out there was no mystery. Just no train. My favorite kind of case.",
                card: "Nothing suspicious here except the excellent scones."),
            ResidentChapter(goal: .connect,
                ask: "Someone at the {a} keeps leaving notes for someone by the {b}. Would you put them on one line, so I can find out who?",
                thanks: "It was Wendell the postman and Bea the florist all along. Love notes. My heart is a little full, which is very unprofessional.",
                card: "Solved: the case of the secret notes."),
        ]),
        Resident(id: "wendell", name: "Wendell Spry", role: "the postman", pitch: 1.25, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Wendell, post! I've parcels piling up for the {a} and no train to carry them. Could you give it a stop, quick as you can?",
                thanks: "Every parcel delivered, including one that was ticking. It was a clock. I'm almost sure it was a clock.",
                card: "Delivered with care. And speed. Mostly speed."),
            ResidentChapter(goal: .connect,
                ask: "Don't tell anyone, but there's a florist by the {b}. Could my round run from the {a} to her on one line? Purely for efficiency.",
                thanks: "I bought a daisy and gave it to her. She gave it back, with a second daisy. That's good, isn't it? I think that's good.",
                card: "Lovely flowers nearby. No reason. (W.)"),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "Bea and I are having a small party at the {a}. It's not a date. Could you bring ten guests so it looks less like a date?",
                thanks: "It was a date. It was the best date. I'm off to deliver letters now. All of them to Bea.",
                card: "Not a date. (It was a date.)"),
        ]),
        Resident(id: "bea", name: "Bea Kowalski", role: "the florist", pitch: 1.3, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Bea, from the flower stall! The {a} is so crowded I can't get a bouquet through. Would you give it a second line?",
                thanks: "I can breathe again! I sold forty tulips, one to a very nervous postman. He said they were for himself. Hmm.",
                card: "Fresh flowers, short queues, good day."),
            ResidentChapter(goal: .carry(12),
                ask: "I'm making free flower crowns at the {a} this week. Could you bring twelve people? I'll make one for you too, Mayor.",
                thanks: "Twelve crowns, and yours is in the post. It's mostly daisies. Somebody told me you like daisies. It was Wendell.",
                card: "Free flower crowns! Wearing mine right now."),
            ResidentChapter(goal: .serve,
                ask: "I'd love to put flowers at the {a}, but no one goes there yet. Would you give it a train stop? Flowers need people.",
                thanks: "The {a} has flowers and visitors now. Wendell carried every pot. We're very good at carrying things together.",
                card: "Planted with love. And Wendell."),
        ]),
        Resident(id: "marmalade", name: "A Mysterious Caller", role: "won't say who", pitch: 0.75, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "...hello. I can't say who I am. But the {a} needs a second line. Will you add one? You didn't hear it from me.",
                thanks: "...the second line is perfect. This call never happened. Neither did the last one.",
                card: "...very nice. (Anonymous)"),
            ResidentChapter(goal: .serve,
                ask: "...it's me again. Nobody. The {a} needs a train stop. Someone small is waiting there. Will you help?",
                thanks: "...fine. I'm Marmalade's owner. Marmalade is the café cat. She made me call. She makes me do a lot of things.",
                card: "Marmalade approves. (Marmalade is a cat.)"),
            ResidentChapter(goal: .carry(10),
                ask: "Marmalade's owner. No more secrets. It's Marmalade's birthday party at the {a}, and she'd like ten guests. Can you bring them?",
                thanks: "Marmalade sat on every single lap. She's now the most popular resident in town. She'd like it known she expected this.",
                card: "Best birthday party. Lots of laps. (M.)"),
        ]),
        Resident(id: "dot", name: "Dot Merriweather", role: "the town gossip", pitch: 1.35, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Mayor, it's Dot. Have you heard? Everybody at the {a} wants to get to the {b}. Could you put them on one line before I have to tell them you said no?",
                thanks: "Line's in, and the news is flowing beautifully. I can't repeat a word of it. I'll tell you everything Thursday.",
                card: "Overheard: everyone loves this place. You heard it here first."),
            ResidentChapter(goal: .carry(10),
                ask: "I'm making an announcement at the {a} and I need an audience. Ten people, Mayor. Can you bring them?",
                thanks: "I announced that next week I'll be making an announcement. They loved it. Suspense is everything.",
                card: "Big news coming. Watch this space."),
            ResidentChapter(goal: .twoLines,
                ask: "The {a} is where all the news happens now, and the crowds are dreadful. Would you give it a second line?",
                thanks: "Two lines, twice the news. Wendell and Bea are an item! You knew? Of course you knew. But I knew first.",
                card: "Gossip travels faster than trains here. Both excellent."),
        ]),
        Resident(id: "hamish", name: "Hamish Gale", role: "the stationmaster's nephew", pitch: 1.05, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Mayor, Hamish here, Pip's nephew. First week on the platforms! Uncle Pip says the {a} still needs a train. Could you give it a stop?",
                thanks: "I told Uncle Pip it was sorted and he said well done. He's never said well done to me before. I wrote down the time.",
                card: "Sorted! (Hamish, Junior Platform Assistant)"),
            ResidentChapter(goal: .twoLines,
                ask: "I've been timing the crowds at the {a}, and one line can't keep up. Could you add a second? I've got graphs.",
                thanks: "Waiting times halved. I made another graph. Uncle Pip says I'm becoming insufferable, but he was smiling.",
                card: "Average wait: 2 minutes. I timed it."),
            ResidentChapter(goal: .connect,
                ask: "I'd love to make my first announcement: 'Next stop, the {b}!' Could you put the {a} and the {b} on one line?",
                thanks: "'Next stop, the {b}!' My voice only cracked a little. Uncle Pip clapped. On the inside, he says.",
                card: "Next stop: here! (My first announcement.)"),
        ]),
        Resident(id: "edith", name: "Edith Crumb", role: "competitive cake baker", pitch: 1.0, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Edith Crumb. I bake. Better than the Corner Bakery, but let's not get into that. Could you put the {a} and the {b} on one line so my cakes arrive in one piece?",
                thanks: "Cakes arrived intact. Not a crumb lost, which, given my name, is a point of pride.",
                card: "Lovely spot. Bring cake. Mine, ideally."),
            ResidentChapter(goal: .carry(12),
                ask: "The town bake-off is at the {a}. I need twelve judges. Honest ones. Can you bring them?",
                thanks: "I came second. The Corner Bakery won. We're having tea about it. Tense, delicious tea.",
                card: "Second place. Still the best sponge in town."),
            ResidentChapter(goal: .twoLines, usesHome: true,
                ask: "Since the bake-off, there's a queue round the corner at the {a}. Could you give it a second line? People are getting peckish.",
                thanks: "Two lines and a queue that moves. I've named a cake after you: the Mayor's Lemon Drizzle. Very sharp, like you.",
                card: "Try the Mayor's Lemon Drizzle."),
        ]),
        Resident(id: "theo", name: "Theo Varga", role: "brand-new dad", pitch: 1.0, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Hi, it's Theo. New dad. Very tired. The baby only stops crying on trains, and there's no train to the {a}. Could you give it a stop?",
                thanks: "She slept the whole way there and back. Twice. I might just ride it all night. I'm not even joking.",
                card: "Baby slept. Dad cried (happy). Ten stars."),
            ResidentChapter(goal: .connect,
                ask: "The baby's grandma lives by the {b} and we're by the {a}. Could you put them on one line? Every time we change trains, we lose a sock. Her sock.",
                thanks: "One train, zero lost socks, one very happy grandma. She says you're welcome for dinner. Bring a container.",
                card: "Grandma visits by train now. Socks intact."),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "It's the baby's first birthday at the {a}. We'd love ten guests. Can you bring them?",
                thanks: "Ten guests, one cake, and she said her first word: 'train.' Her mother is pretending not to be upset.",
                card: "Her first word was 'train.'"),
        ]),
        Resident(id: "rufus", name: "Rufus Bell", role: "church bell ringer", pitch: 0.9, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Rufus Bell, I ring the church bells! Sorry, I'm shouting. Occupational hazard. The {a} needs a second line! Can you add one?",
                thanks: "Two lines! I'll ring the bells for you at noon! Sorry, I'm still shouting!",
                card: "Very good! Sorry, I'm shouting! (Rufus)"),
            ResidentChapter(goal: .serve,
                ask: "Rufus again! People want to hear the bells from the {a}, but there's no train there! Could you give it a stop?",
                thanks: "A whole crowd came to listen! One man asked me to stop! I didn't hear him!",
                card: "Come hear the bells! You can't miss them!"),
            ResidentChapter(goal: .carry(12),
                ask: "I'm teaching a bell-ringing class at the {a}! I need twelve students! Can you bring them?",
                thanks: "Twelve students, and only one went a bit deaf! Just for the afternoon! A triumph!",
                card: "Took a bell class. Ears still ringing. Worth it."),
        ]),
        Resident(id: "juniper", name: "Juniper Wren", role: "tour guide (very nearly)", pitch: 1.25, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Juniper Wren, tour guide! Well, I will be once there's a tour. Could you put the {a} and the {b} on one line? It would make the perfect route.",
                thanks: "First tour done! Four tourists, one map, nobody lost. I'm basically a professional now.",
                card: "Join Juniper's tours! Ask for Juniper."),
            ResidentChapter(goal: .carry(12), usesHome: true,
                ask: "The tour's catching on! Could you bring twelve people to the {a} for the grand tour?",
                thanks: "Twelve on the tour! Someone asked a question I couldn't answer, so I made something up. It's local legend now.",
                card: "Ask about the legend of the singing tram. (Juniper made it up.)"),
            ResidentChapter(goal: .serve,
                ask: "I want to add the {a} to the tour, but there's no train to it. Would you give it a stop?",
                thanks: "The {a} is officially Stop Seven on the Grand Tour. I printed leaflets. They're slightly crooked. I love them.",
                card: "Stop Seven on the Grand Tour. Highly rated (by me)."),
        ]),
        Resident(id: "pemberton", name: "Dr. Ivy Pemberton", role: "the town vet", pitch: 1.05, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Dr. Pemberton, the vet. Half my patients live near the {a}, and their owners can't get there. Could you give it a stop? The tortoise is especially slow.",
                thanks: "Clinic was full today. Six dogs, two cats, and the tortoise, who made it in record time. For a tortoise.",
                card: "Good for pets. Better for owners. (Dr. P)"),
            ResidentChapter(goal: .connect,
                ask: "I do house calls by train now. Could you put the {a} and the {b} on one line? I've changed trains with a goat once, and once was plenty.",
                thanks: "One train, no changes, and the goat behaved beautifully. Better than some passengers.",
                card: "Goat-friendly. Highly recommended."),
            ResidentChapter(goal: .carry(10),
                ask: "It's Pet Parade day at the {a}! Could you bring ten people, and ideally their pets?",
                thanks: "Ten people, eleven dogs. Nobody knows whose the eleventh is, so he's staying with me. His name is Eleven.",
                card: "Pet Parade winner: a dog named Eleven."),
        ]),
        Resident(id: "barnaby", name: "Barnaby Quill", role: "poet, mostly", pitch: 0.95, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Barnaby Quill, poet. 'The {a} is crowded, the queue is too long; a second line, Mayor, would right this wrong.' Could you add one?",
                thanks: "'The trains come in pairs, the crowds melt away; the Mayor did splendidly, I'm happy to say.' I'm still working on that last line.",
                card: "'This place is lovely, it's really quite nice.' (Draft.)"),
            ResidentChapter(goal: .serve,
                ask: "My new poem begins 'There's no train to the {a}, and that's a disgrace.' I can't finish it until there is one. Would you give it a stop?",
                thanks: "Finished! 'Now trains reach the {a}, and smiles fill the place.' It rhymes with disgrace. I'm thrilled.",
                card: "A poem about this place is now complete. Ask me."),
            ResidentChapter(goal: .carry(12),
                ask: "I'm giving a poetry reading at the {a}. Could you bring me twelve listeners? I'll settle for eleven. I'll settle for one.",
                thanks: "Twelve listeners, and three stayed to the end. One cried. He says it was hay fever. I say it was art.",
                card: "Poetry reading: moving. Possibly hay fever."),
        ]),
        Resident(id: "norman", name: "Norman Pike", role: "Edna's husband, model railway man", pitch: 0.85, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Norman Pike, Edna's husband. I've built a model of the whole town in our garage. Could you put the {a} and the {b} on one line? I'd like the real one to match my model.",
                thanks: "Real town and model town now match exactly. Edna says I'm not allowed to build a model of the model. We'll see.",
                card: "Matches my model perfectly. (N. Pike)"),
            ResidentChapter(goal: .serve,
                ask: "My model has a little station at the {a}, but the real town doesn't. It's keeping me up at night. Could you give it a stop?",
                thanks: "Real station, model station, both perfect. I've added a tiny Mayor to the model platform. It's you. You're waving.",
                card: "There's a tiny Mayor on my model platform now."),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "I'm opening the model railway to visitors at the {a}. Could you bring ten people? Edna says it's that or the garage gets a lock.",
                thanks: "Ten visitors, and a little girl asked if she could be the driver. Her name was Clementine. I think I've found a successor.",
                card: "Model railway open Sundays. Clementine approved."),
        ]),
        Resident(id: "mo", name: "Mo Adebayo", role: "the ice cream man", pitch: 1.1, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Mo here, ice cream! It's hot, the queue at the {a} is melting, and so is my stock. Could you add a second line?",
                thanks: "Queue moved, ice cream sold, nothing melted. I've invented a flavor called Rush Hour. It's mostly toffee.",
                card: "Try the Rush Hour. It's mostly toffee."),
            ResidentChapter(goal: .carry(12),
                ask: "Free ice cream at the {a} this afternoon! Could you bring twelve people before it all melts?",
                thanks: "Twelve happy customers, one dropped cone, and one dog who ate the dropped cone. So thirteen happy customers.",
                card: "Free ice cream day! 13 happy customers (one dog)."),
            ResidentChapter(goal: .serve,
                ask: "I'd like to open a second spot at the {a}, but nobody can get there. Will you give it a stop?",
                thanks: "Second spot's open. The conductor stops for a scoop every afternoon. Technically on duty. Technically.",
                card: "Best scoop on the line. Ask the conductor."),
        ]),
        Resident(id: "odalys", name: "Odalys Reyes", role: "dominoes champion", pitch: 0.88, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Odalys Reyes. My domino club meets at the {a}, and my rival lives by the {b}. Could you put them on one line? I want her to have no excuses.",
                thanks: "She came. I won. She says the train made her tired. The train did not make her tired.",
                card: "Dominoes champion three years running. Come and try."),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "Domino tournament at the {a} this week! Could you bring me ten challengers? I'm getting bored of winning.",
                thanks: "Ten challengers, ten wins. One boy came close. I let him think so. He'll be good one day.",
                card: "Lost to Odalys. Everyone does. Still fun."),
            ResidentChapter(goal: .twoLines, usesHome: true,
                ask: "Since the tournament, everyone wants to play at the {a}. Could you give it a second line? The table's full, and so is the platform.",
                thanks: "Two lines and a waiting list for the domino table. I'm teaching my rival to play properly. We're nearly friends.",
                card: "Waiting list for dominoes. Worth it."),
        ]),
        Resident(id: "stanley", name: "Stanley Brooks", role: "drove the old town bus", pitch: 0.8, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Stanley Brooks. I drove the town bus for thirty years, until your trains came along. I'm not thrilled. But my mother lives by the {a} and there's no stop. Would you give it one?",
                thanks: "Mother says the train's very nice. I said the bus was nicer. She said, 'Was it, Stanley?' I've no answer to that.",
                card: "Fine. It's nice. (S. Brooks)"),
            ResidentChapter(goal: .connect,
                ask: "Stanley again. I've taken a job at the {a}, and I live by the {b}. Would you put them on one line? Don't tell anyone I take the train.",
                thanks: "I take the train to work every day now. Nobody knows. Please don't tell Dot.",
                card: "Excellent service. Don't tell Dot I said so."),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "I'm turning my old bus into a café at the {a}. Could you bring ten people to the opening? I'd ask the bus, but it doesn't run anymore.",
                thanks: "Ten people, coffee on the old bus, and Pip came to cut the ribbon. We shook hands. Trains and buses, friends at last.",
                card: "The Bus Stop Café. Opened by a bus, fed by a train."),
        ]),
        Resident(id: "rosalind", name: "Rosalind Achebe", role: "the librarian", pitch: 0.92, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Rosalind Achebe, the librarian. Quietly, please: the crowds at the {a} are getting loud. Could you add a second line to spread them out?",
                thanks: "Much quieter now. I nearly shushed someone out of habit, and there was nobody to shush. It was strange. I liked it.",
                card: "Quiet, peaceful, lovely. Please return your books."),
            ResidentChapter(goal: .serve,
                ask: "The old book bus used to stop at the {a}. It's gone now. Could the train stop there instead, so people can still borrow books?",
                thanks: "Books are flying out on the train. One came back with a pressed flower in it. Bea's, I suspect.",
                card: "Borrowed a book. Returned it on time. Proud."),
            ResidentChapter(goal: .carry(12),
                ask: "Story time at the {a}! Could you bring twelve listeners? I'll do all the voices.",
                thanks: "I did the dragon's voice and a child fainted with joy. She's fine. She wants to come back tomorrow.",
                card: "Story time: the dragon voice is incredible."),
        ]),
        Resident(id: "hugo", name: "Hugo Marchetti", role: "retired opera singer", pitch: 0.83, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Hugo Marchetti, tenor, retired. The acoustics at the {a} are magnificent, and nobody can get there to hear them. Would you give it a stop?",
                thanks: "I sang one note on the platform and the whole carriage applauded. The conductor wept. I may come out of retirement.",
                card: "Magnifico. The acoustics and the trains."),
            ResidentChapter(goal: .connect, usesHome: true,
                ask: "My accompanist lives by the {b}. Could you put her on one line to the {a}? We'll rehearse on the way.",
                thanks: "We rehearsed the whole journey. The other passengers asked for an encore. I gave them three.",
                card: "Sang here. Was asked to leave. Came back. Sang again."),
            ResidentChapter(goal: .carry(14), usesHome: true,
                ask: "A farewell concert at the {a}! Could you bring fourteen people? I promise to make them cry. Happily.",
                thanks: "Fourteen came and everyone cried, including me, twice. I've decided it wasn't a farewell after all. Same time next year.",
                card: "Not his farewell concert. Thank goodness."),
        ]),
        Resident(id: "zuri", name: "Zuri Okonkwo", role: "muralist, aged seventeen", pitch: 1.15, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Hey Mayor, it's Zuri. I paint murals. I want to do one at the {a} and one at the {b}. Could you put them on one line so people can see both?",
                thanks: "Both murals done. Someone painted a mustache on one of them. Honestly, it's an improvement.",
                card: "Mural by Zuri. Mustache by somebody. Both good."),
            ResidentChapter(goal: .serve,
                ask: "There's a massive blank wall by the {a}. Prime mural spot. No train, though. Could you give it a stop?",
                thanks: "Mural's up: a giant tram. Fergus says it's 'a bit much.' Fergus is wrong.",
                card: "Giant tram mural. Fergus thinks it's a bit much."),
            ResidentChapter(goal: .carry(10),
                ask: "I'm having my first art show at the {a}! Ten people would make it feel real. Can you bring them?",
                thanks: "Ten people came and I sold a painting. To my mum. But it still counts.",
                card: "First art sale! (Thanks, Mum.)"),
        ]),
        Resident(id: "thorne", name: "Councillor Percival Thorne", role: "of the town council", pitch: 0.8, chapters: [
            ResidentChapter(goal: .twoLines,
                ask: "Councillor Thorne. The {a} reflects poorly on the council with only one line. Would you add a second at your earliest convenience?",
                thanks: "The council is satisfied. I am satisfied. Write that down. It doesn't happen often.",
                card: "Satisfactory. (Cllr. P. Thorne)"),
            ResidentChapter(goal: .connect,
                ask: "Council business takes me between the {a} and the {b} rather often. Would you kindly put them on one line?",
                thanks: "I took the train myself. A child offered me half her sandwich, and I accepted. Do not put that in the Gazette.",
                card: "Shared a sandwich on the train. Very good sandwich."),
            ResidentChapter(goal: .carry(12),
                ask: "I'm holding an open meeting at the {a}, to hear what people actually want. Could you bring twelve residents?",
                thanks: "They want more benches, more trees, and for me to smile more. I've agreed to two of those.",
                card: "Open meeting: good ideas. The councillor smiled. Once."),
        ]),
        Resident(id: "fisk", name: "Lou Fisk", role: "the elder Fisk twin, by four minutes", pitch: 0.95, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Lou Fisk, of the Fisk twins. My brother Lionel lives by the {b}, I'm by the {a}. Could you put us on one line? He owes me a fishing rod.",
                thanks: "Got the rod back. Lionel says it was his rod. It was not his rod. We're going fishing on Saturday.",
                card: "Asked for a twins discount. No. Fair enough."),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "It's the Fisk twins' birthday at the {a}! Could you bring ten guests? Five for me, five for Lionel, or he'll say I got more.",
                thanks: "I got six and he got four. He's demanding a recount. We'll be counting until next birthday.",
                card: "Happy birthday to us. (Lou is the handsome one.)"),
            ResidentChapter(goal: .twoLines, usesHome: true,
                ask: "This is Lionel, not Lou. Lou's busy. The {a} needs a second line, and I'd like the credit this time. Can you add one?",
                thanks: "Lionel again. Two lines! This one's mine. Lou says it's his. It is not his. Thank you, Mayor.",
                card: "Lionel's line. Not Lou's. (Lionel)"),
        ]),
        Resident(id: "mabel", name: "Mabel Hooper", role: "knits on the 8:15", pitch: 1.2, chapters: [
            ResidentChapter(goal: .decor,
                ask: "Mabel Hooper, the one who knits on the 8:15. The bench outside the {a} is gone and my knees have opinions. Could you put something nice right beside it?",
                thanks: "A seat, a view, and a train every few minutes. I've finished one scarf and started another.",
                card: "Knitted here. Two scarves so far."),
            ResidentChapter(goal: .train,
                ask: "Mabel again. The 8:15 is so full I knit standing up, and my stitches go wonky. Could you put another train on?",
                thanks: "A seat on the 8:15! My stitches are straight as rails now.",
                card: "Even stitches, thanks to the extra train."),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "I'm teaching a knitting class at the {a}, and I've made ten pairs of needles. Could you bring ten people?",
                thanks: "Ten students, one dropped stitch, and a scarf long enough to wrap the station. We're trying it on Thursday.",
                card: "Knitting class: ten students, one very long scarf."),
        ]),
        Resident(id: "hale", name: "Professor Edmund Hale", role: "retired astronomer", pitch: 0.8, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Professor Hale, astronomy, retired. The {a} has the darkest skies in town and no train at all. Would you give it a stop?",
                thanks: "Twelve people saw Saturn last night. One of them cried. Saturn has that effect.",
                card: "Saw Saturn. Recommend Saturn."),
            ResidentChapter(goal: .decor, usesHome: true,
                ask: "Stargazers at the {a} need somewhere to sit while they wait for the dark. Could you place a decoration right beside it?",
                thanks: "They sit, they look up, they forget their phones. Exactly as intended.",
                card: "Sat and looked up. Lovely."),
            ResidentChapter(goal: .connect,
                ask: "There's a meteor shower on Thursday. Could you put the {a} and the {b} on one line, so the whole town can get there?",
                thanks: "Forty-one meteors and one confused owl. A very good Thursday.",
                card: "Counted 41 meteors. And an owl."),
        ]),
        Resident(id: "rosa", name: "Rosa Esposito", role: "everybody's nonna", pitch: 1.0, chapters: [
            ResidentChapter(goal: .connect,
                ask: "Rosa Esposito. I cook for my grandchildren at the {a}, but my son lives by the {b}. Could you put us on one line? The lasagne gets cold.",
                thanks: "The lasagne arrived hot and my son arrived hungry. Everybody's happy, especially me.",
                card: "Hot lasagne, delivered by train."),
            ResidentChapter(goal: .carry(12), usesHome: true,
                ask: "Sunday lunch at the {a}, and I've cooked for twelve. I always cook for twelve. Could you bring twelve people?",
                thanks: "Twelve came, and every one of them took leftovers. My freezer thanks you.",
                card: "Sunday lunch: twelve guests, no leftovers left."),
            ResidentChapter(goal: .serveBoth,
                ask: "My cousins live by the {a} and the {b}, and neither has a train. Could you give both a stop? I'm tired of posting them biscotti.",
                thanks: "Both cousins came for dinner. They argued about tomatoes. It was perfect.",
                card: "Family dinner. Tomato argument. Ten out of ten."),
        ]),
        Resident(id: "felix", name: "Felix the Fabulous", role: "the town's only magician", pitch: 1.25, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Felix the Fabulous, magician. I'd like to make a crowd appear at the {a}, but I'll need a train to help. Could you give it a stop?",
                thanks: "A whole crowd appeared, just like that. I'm taking credit, but between us, it was the train.",
                card: "Saw a magic show. The rabbit was real."),
            ResidentChapter(goal: .train,
                ask: "For my next trick, I'll need one more train running in town. Could you put another one on?",
                thanks: "Another train, out of thin air! Well, out of the depot. The audience doesn't need to know.",
                card: "The extra train is his best trick yet."),
            ResidentChapter(goal: .carry(12), usesHome: true,
                ask: "Grand finale at the {a}: I'll saw a pumpkin in half. Could you bring twelve people to watch?",
                thanks: "Twelve gasps and one pumpkin, sawn and restored. Mostly restored.",
                card: "The pumpkin survived. Mostly."),
        ]),
        Resident(id: "okafor", name: "Dr. Amara Okafor", role: "the night-shift doctor", pitch: 0.95, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Dr. Okafor, night shift. My nurses walk to the {a} in the dark after their shifts. Could you give it a train stop?",
                thanks: "The nurses take the last train home now. One fell asleep and missed her stop. She says it was the best sleep she's had all year.",
                card: "A safe, warm ride home after a long shift."),
            ResidentChapter(goal: .train,
                ask: "The late trains are packed with tired people. Could you add one more train, so nobody stands after a twelve-hour shift?",
                thanks: "Everyone gets a seat now. I've prescribed it to the whole ward.",
                card: "Prescribed: one extra train. Works wonders."),
            ResidentChapter(goal: .hub,
                ask: "Our patients come from all over town and change trains three times. Could you build a transit hub, so it's easier for them?",
                thanks: "Fewer changes, fewer sore feet, fewer grumbling patients. You've done the hospital a kindness.",
                card: "Easy to get here now. Thank you, Mayor."),
        ]),
        Resident(id: "ollie", name: "Ollie Pennywhistle", role: "busker and fiddler", pitch: 1.3, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Ollie, I play the fiddle for coins. No trains at the {a} means no crowds, and no crowds means no coins. Could you give it a stop?",
                thanks: "Thirty-one coins and a button. I'm keeping the button for luck.",
                card: "Great fiddler outside. Tip him."),
            ResidentChapter(goal: .decor, usesHome: true,
                ask: "Could you put something beside the {a} for me to stand next to? A busker needs a backdrop.",
                thanks: "I stand next to it every day now. People think it's part of the act. It is now.",
                card: "The fiddler and the decoration: both lovely."),
            ResidentChapter(goal: .carry(10), usesHome: true,
                ask: "I'm playing my first proper concert at the {a}. Ten's an audience; nine's a queue. Could you bring ten listeners?",
                thanks: "Ten listeners and an encore. I've never had an encore. I played the same song again, and nobody minded.",
                card: "Encore! (Same song. Still great.)"),
        ]),
        Resident(id: "agatha", name: "Agatha Puddle", role: "Bertram's sister", pitch: 1.05, chapters: [
            ResidentChapter(goal: .decor,
                ask: "This is Agatha Puddle. Yes, Bertram's sister. I'd like somewhere to sit beside the {a} while I wait for him to be late. Could you place something there?",
                thanks: "He was eleven minutes late. I timed it from my lovely new seat. It's very comfortable to be annoyed in.",
                card: "Waited for my brother here. Comfortably."),
            ResidentChapter(goal: .connect,
                ask: "Agatha again. Bertram insists on a day trip from the {a} to the {b}. Would you put them on one line? He'll only complain otherwise.",
                thanks: "We went. He complained anyway, about the weather this time. That's progress.",
                card: "Day trip with my brother. Mostly pleasant."),
            ResidentChapter(goal: .carry(12), usesHome: true,
                ask: "I'm throwing Bertram a surprise seventieth at the {a}. I've even forgiven him for 1988. Could you bring twelve guests?",
                thanks: "He cried, then said it was hay fever. Our family has a lot of hay fever. Thank you, Mayor.",
                card: "Surprise party for my brother. He was surprised."),
        ]),
        Resident(id: "ruiz", name: "Coach Benny Ruiz", role: "the school football coach", pitch: 0.9, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Coach Ruiz! My team practises at the {a}, and half of them turn up late because there's no train. Could you give it a stop?",
                thanks: "Everyone on time! We still lost, but on time. That's character.",
                card: "Team arrived on time. Lost anyway. Proud."),
            ResidentChapter(goal: .train,
                ask: "Match day, and the trains to the ground are bursting with fans. Could you put another train on?",
                thanks: "The fans made kickoff, and we scored! Once. In the last minute. Still counts.",
                card: "We scored! (Once.)"),
            ResidentChapter(goal: .carry(14), usesHome: true,
                ask: "Championship final at the {a}! Fourteen fans would make it sound like a stadium. Can you bring them?",
                thanks: "Fourteen fans, one chant, and a trophy. Smallest trophy in the county, but it's ours.",
                card: "Champions! (Small trophy, big heart.)"),
        ]),
        Resident(id: "winifred", name: "Winifred Cole", role: "mayor before you", pitch: 0.8, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Winifred Cole, mayor before you. I closed the stop at the {a} the year the trains stopped. I'd love to see it open again. Would you give it a stop?",
                thanks: "I stood on the platform and watched the first train pull in. Years too late, and right on time.",
                card: "Reopened at last. Well done, Mayor. (W.C.)"),
            ResidentChapter(goal: .hub,
                ask: "The one thing I never managed was a proper interchange. Could you build a transit hub? I'd like to see what I couldn't.",
                thanks: "A real hub, full of people changing trains. You've done what I couldn't, and I'm glad it was you.",
                card: "The interchange I always dreamed of."),
            ResidentChapter(goal: .connect,
                ask: "My last request, I promise. The {a} and the {b} were on the old line together. Would you put them back on one?",
                thanks: "The old line, running again. I rode it twice and waved at everyone. Retirement suits me.",
                card: "Rode the old line again. Waved at everyone."),
        ]),
        Resident(id: "pierre", name: "Pierre Lumière", role: "the projectionist", pitch: 1.1, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Pierre, projectionist. My little films at the {a} play to empty seats, because there's no train. Could you give it a stop?",
                thanks: "A full house! They laughed in the right places and cried in the wrong ones. Perfect.",
                card: "Wonderful film. Bring tissues."),
            ResidentChapter(goal: .carry(12), usesHome: true,
                ask: "Opening night of my film festival at the {a}. It's a red rug rather than a red carpet, but still. Could you bring twelve guests?",
                thanks: "Twelve guests on the red rug, and one wore a tiara. The festival is now an institution.",
                card: "Film festival opening. Someone wore a tiara."),
            ResidentChapter(goal: .decor, usesHome: true,
                ask: "The {a} needs something out front to make people stop and look. Could you place a decoration right beside it?",
                thanks: "People stop, they look, they come in. Cinema is mostly what's outside.",
                card: "Couldn't walk past. Went in."),
        ]),
        Resident(id: "tilly", name: "Tilly Marchbanks", role: "the beekeeper", pitch: 1.2, chapters: [
            ResidentChapter(goal: .decor,
                ask: "Tilly, beekeeper. My bees need somewhere pretty to visit by the {a}. Could you place a decoration right beside it? Flowers, ideally.",
                thanks: "The bees approve. They've told the other bees. We may have a situation.",
                card: "Bees love it here. So do I."),
            ResidentChapter(goal: .serve,
                ask: "My honey stall's at the {a}, and nobody can reach it without a train. Could you give it a stop?",
                thanks: "Sold out by noon! One man bought six jars and said they were for his bees. I didn't ask.",
                card: "Best honey in town. Sold out by noon."),
            ResidentChapter(goal: .serveBoth,
                ask: "I'm moving hives to the {a} and the {b}. Bees don't take trains, but I do. Could you give both a stop?",
                thanks: "Both hives settled. The bees are calm, I'm calm, the trains are calm. A calm town.",
                card: "Bees, honey, trains. Very calm."),
        ]),
        Resident(id: "paloma", name: "Paloma Vidal", role: "the tango teacher", pitch: 1.0, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Paloma Vidal, I teach tango. My students can't reach the {a}, and tango takes two. Could you give it a stop?",
                thanks: "Twelve couples and one very brave widower. The floor has never been busier.",
                card: "Learned the tango. Stepped on only one foot."),
            ResidentChapter(goal: .connect, usesHome: true,
                ask: "My partner teaches by the {b}. Could you put her studio and the {a} on one line? We dance between classes.",
                thanks: "We dance the whole way between stops. The passengers clap. One joined in.",
                card: "Danced on the train. Recommended."),
            ResidentChapter(goal: .carry(14), usesHome: true,
                ask: "A grand ball at the {a}! Fourteen dancers would fill the floor. Could you bring them?",
                thanks: "Fourteen dancers, one spilled punch, no regrets. We're doing it again in spring.",
                card: "The grand ball. Spilled punch. Glorious."),
        ]),
        Resident(id: "barty", name: "Barty Quint", role: "conductor, thirty years on the rails", pitch: 0.85, chapters: [
            ResidentChapter(goal: .train,
                ask: "Barty Quint, conductor. My train's so full I can't get down the aisle to check tickets. Could you add another train?",
                thanks: "I can reach every seat again. Found two fare dodgers and a lost hamster. Returned all three.",
                card: "Friendly conductor. Found my hamster."),
            ResidentChapter(goal: .hub,
                ask: "Riders keep asking me where to change trains, and I keep pointing at nothing. Could you build a transit hub?",
                thanks: "Now I point at the hub, and off they go. Thirty years I've waited for something to point at.",
                card: "Asked the conductor. He pointed. Very helpful."),
            ResidentChapter(goal: .connect,
                ask: "For my retirement, I'd love one last new route, from the {a} to the {b}. Would you put them on one line?",
                thanks: "I drove the first train on the new route myself and rang the bell the whole way. They're letting me keep the hat.",
                card: "Final ride with Barty. He rang the bell a lot."),
        ]),
        Resident(id: "hetty", name: "Hetty Holloway", role: "Pip's mum", pitch: 1.15, chapters: [
            ResidentChapter(goal: .decor,
                ask: "Hetty Holloway, Pip's mum. He never sits down, my Pip. Could you put something beside the {a}, so he rests now and then?",
                thanks: "I caught him sitting! Four whole minutes. I took a photograph for the mantelpiece.",
                card: "Caught my son resting. Historic."),
            ResidentChapter(goal: .carry(10),
                ask: "It's Pip's birthday, and he thinks nobody remembers. Could you bring ten people to the {a}? Keep it quiet.",
                thanks: "He was so surprised he forgot to announce the next train. First time in forty years. Everyone cheered.",
                card: "Happy birthday, Pip. (He was surprised.)"),
            ResidentChapter(goal: .serve,
                ask: "I'd like to visit Pip at work without the long walk from the {a}. Could you give it a stop? I'll bring sandwiches.",
                thanks: "I came by train with sandwiches. Pip pretended to be embarrassed and ate three.",
                card: "Brought my son sandwiches. He ate three."),
        ]),
        Resident(id: "ignatius", name: "Ignatius Fenwick", role: "inventor", pitch: 0.9, chapters: [
            ResidentChapter(goal: .train,
                ask: "Ignatius Fenwick, inventor. I've built a machine that counts trains, and it's very bored. Could you put another one on?",
                thanks: "The machine counted the new train and whistled. I didn't build it to whistle. Progress.",
                card: "Saw the train-counting machine. It whistled."),
            ResidentChapter(goal: .serve,
                ask: "My workshop by the {a} is full of inventions and empty of visitors. Would you give it a stop?",
                thanks: "Visitors! One pressed a button I told them not to. We now have a fountain indoors.",
                card: "Inventor's workshop. Don't press the red button."),
            ResidentChapter(goal: .hub,
                ask: "I've designed the perfect transit hub, on paper. Could you build a real one so I can check my sums?",
                thanks: "My sums were right! Mostly. The hub works beautifully, and I've drawn you a medal.",
                card: "The inventor's hub works. He's very pleased."),
        ]),
        Resident(id: "kit", name: "Kit Marlow", role: "the bicycle courier", pitch: 1.3, chapters: [
            ResidentChapter(goal: .serveBoth,
                ask: "Kit, bike courier. My parcels for the {a} and the {b} keep arriving late. Could you give both a train stop? I'll bring the bike aboard.",
                thanks: "Parcels on time, bike on the train, legs on holiday. Best week of my career.",
                card: "Courier arrived on time. By train!"),
            ResidentChapter(goal: .connect,
                ask: "Could my round run from the {a} to the {b} on one line? I'll race it every morning, and lose happily.",
                thanks: "I raced the train and lost by four minutes. A personal best, for the train.",
                card: "Lost a race to the train. Worth it."),
            ResidentChapter(goal: .train,
                ask: "Rush hour's a scrum and my parcels get squashed. Could you put another train on?",
                thanks: "Not one squashed parcel all week. Even the eggs survived. Mostly the eggs.",
                card: "Eggs delivered intact. A miracle."),
        ]),
        Resident(id: "cuthbert", name: "Cuthbert", role: "butler to Lady Philippa", pitch: 0.82, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Cuthbert, butler to Lady Philippa Snodgrass. Her Ladyship requires a train stop at the {a}. She hasn't said please, so I'll say it for her. Please?",
                thanks: "Her Ladyship rode the train and called it 'not awful.' That's the highest praise I've heard in thirty years of service.",
                card: "Her Ladyship approves. Quietly."),
            ResidentChapter(goal: .decor, usesHome: true,
                ask: "Her Ladyship would like something elegant beside the {a}. Could you place a decoration there? I'll tell her it was her idea.",
                thanks: "She believes it was her idea, and she's very proud of it. Everyone is happy, Mayor.",
                card: "Elegant. Her Ladyship's idea. (It wasn't.)"),
            ResidentChapter(goal: .carry(12), usesHome: true,
                ask: "Her Ladyship is hosting a garden party at the {a}, and I've polished twelve spoons. Could you bring twelve guests?",
                thanks: "Twelve guests, twelve spoons, and Her Ladyship laughed out loud. I may need to sit down.",
                card: "Garden party. Lady Snodgrass laughed. Out loud."),
        ]),
        Resident(id: "sunny", name: "Sunny Tran", role: "runs the noodle bar", pitch: 1.1, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Sunny, noodle bar. My broth's been simmering since dawn, and nobody can reach the {a}. Could you give it a stop?",
                thanks: "Bowls everywhere! A man ordered seconds before he'd finished his firsts. I respect him.",
                card: "Ordered seconds before firsts. Worth it."),
            ResidentChapter(goal: .train,
                ask: "The lunchtime train comes so full that nobody can get off at my stop. Could you put another train on?",
                thanks: "Now they get off, they eat, they get back on. Broth tastes better when nobody's in a hurry.",
                card: "Unhurried noodles. The best kind."),
            ResidentChapter(goal: .connect, usesHome: true,
                ask: "My mum lives by the {b}, and she taught me the recipe. Could you put her and the {a} on one line? She tests the broth daily.",
                thanks: "Mum tasted the broth and said 'fine.' From her, that's a standing ovation.",
                card: "Mum says the broth is fine. Very high praise."),
        ]),
        Resident(id: "archie", name: "Archie Lowe", role: "leads the ghost tours", pitch: 0.75, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Archie Lowe, ghost tours. My ghosts at the {a} are lonely, and so am I. Could you give it a train stop?",
                thanks: "Fourteen brave souls on the tour, and only three screamed. The ghost was delighted, I'm fairly sure.",
                card: "Ghost tour: spooky, cozy, three screams."),
            ResidentChapter(goal: .decor, usesHome: true,
                ask: "The {a} needs a little something spooky out front. Could you place a decoration right beside it?",
                thanks: "Perfectly spooky. A child asked if it was haunted. I said 'only on Tuesdays.' She's coming back Tuesday.",
                card: "Haunted on Tuesdays, apparently."),
            ResidentChapter(goal: .carry(13), usesHome: true,
                ask: "Midnight ghost walk at the {a}! Thirteen guests, naturally. Can you bring them?",
                thanks: "Thirteen guests, one owl, and a creak nobody can explain. Best tour yet.",
                card: "Midnight walk. Unexplained creak. Loved it."),
        ]),
        Resident(id: "margot", name: "Margot Finch", role: "wedding planner", pitch: 1.2, chapters: [
            ResidentChapter(goal: .serve,
                ask: "Margot Finch, wedding planner, and yes, my father's the detective. I've a wedding at the {a} and no train for the guests. Could you give it a stop?",
                thanks: "The guests arrived on time and the bride arrived fashionably late. Perfect order of events.",
                card: "Beautiful wedding. Guests on time!"),
            ResidentChapter(goal: .serveBoth,
                ask: "The ceremony's at the {a} and the party's at the {b}. Brides don't walk far in those shoes. Could you give both a train stop?",
                thanks: "Not one blister all day. The bride wants to thank you in her speech.",
                card: "Ceremony to party, all by train. No blisters."),
            ResidentChapter(goal: .carry(15), usesHome: true,
                ask: "The big one: Wendell and Bea are getting married at the {a}! Could you bring fifteen guests? Dad's giving a speech. Pray for us.",
                thanks: "They said 'I do,' Dad cried, and Dot announced it before the vicar did. The loveliest day this town has had.",
                card: "Wendell and Bea, married at last."),
        ]),
    ]

    static func resident(_ id: String) -> Resident? { residents.first { $0.id == id } }
}

extension GameState {

    /// A call from one of the town's residents, continuing their story, if any can call now.
    func makeResidentCall() -> Letter? {
        let candidates = openLandmarks.filter {
            isOpened($0.kind.info.district) && $0.kind.info.category != .hub && $0.kind.info.category != .canal
        }
        guard candidates.count >= 2 else { return nil }
        // Someone who's just called waits a little before calling again.
        let recent = Set(letters.suffix(2).compactMap(\.residentID))
        for resident in Cast.residents.shuffled() where !recent.contains(resident.id) {
            let chapterIndex = residentProgress[resident.id] ?? 0
            guard chapterIndex < resident.chapters.count else { continue }
            let chapter = resident.chapters[chapterIndex]
            // "Bring people" requests wait until advertising opens, so they're something you can act on.
            if case .carry = chapter.goal, !adsUnlocked { continue }
            let home = chapter.usesHome ? residentHome[resident.id].flatMap { id in candidates.first { $0.id == id } } : nil
            guard let picked = pick(chapter.goal, home: home, from: candidates) else { continue }
            let fill: (String) -> String = { text in
                text.replacingOccurrences(of: "{a}", with: picked.a.kind.info.name)
                    .replacingOccurrences(of: "{b}", with: picked.b?.kind.info.name ?? "")
            }
            defer { nextLetterID += 1 }
            let reward: Int
            switch chapter.goal {
            case .connect: reward = 80
            case .serve: reward = 60
            case .twoLines: reward = 90
            case let .carry(count): reward = 50 + count * 3
            case .decor: reward = 50
            case .train: reward = 70
            case .hub: reward = 120
            case .serveBoth: reward = 90
            }
            var letter = Letter(id: nextLetterID, sender: resident.name, role: resident.role, body: fill(chapter.ask),
                                goal: picked.goal, receivedDay: day, dueDay: day + 2,
                                reward: hasCard(.communityRadio) ? reward * 3 / 2 : reward)
            letter.residentID = resident.id
            letter.thanks = fill(chapter.thanks)
            letter.cardText = fill(chapter.card)
            letter.homeID = picked.a.id
            return letter
        }
        return nil
    }

    private func pick(_ goal: ResidentChapter.Goal, home: Landmark?, from candidates: [Landmark])
        -> (goal: LetterGoal, a: Landmark, b: Landmark?)? {
        let pool = candidates.shuffled()
        switch goal {
        case .connect:
            let firsts = home.map { [$0] } ?? pool
            for a in firsts {
                // Subway lines stay inside one district, so both places must share a district.
                if let b = pool.first(where: { b in
                    b.id != a.id && b.kind.info.district == a.kind.info.district
                        && !builtLines.contains { $0.stops.contains(a.id) && $0.stops.contains(b.id) }
                }) {
                    return (.connect(a.id, b.id), a, b)
                }
            }
            return nil
        case .serve:
            guard let a = (home.map { [$0] } ?? pool).first(where: { subwayLinesServing($0.id).isEmpty }) else { return nil }
            return (.serve(a.id), a, nil)
        case .twoLines:
            guard let a = (home.map { [$0] } ?? pool).first(where: { subwayLinesServing($0.id).count == 1 }) else { return nil }
            return (.lines(a.id, 2), a, nil)
        case let .carry(count):
            guard let a = home ?? pool.first else { return nil }
            return (.carryTo(a.id, count), a, nil)
        case .decor:
            guard decorUnlocked, let a = (home.map { [$0] } ?? pool).first(where: { !decorBeside($0.id) }) else { return nil }
            return (.decorNear(a.id), a, nil)
        case .train:
            guard !builtLines.isEmpty, let a = home ?? pool.first(where: { !subwayLinesServing($0.id).isEmpty }) else { return nil }
            return (.trains(totalTrains + 1), a, nil)
        case .hub:
            guard candidates.count >= 6, let a = home ?? pool.first else { return nil }
            return (.hubs(openHubs + 1), a, nil)
        case .serveBoth:
            let unserved = pool.filter { subwayLinesServing($0.id).isEmpty }
            let first = home.flatMap { h in unserved.contains(where: { $0.id == h.id }) ? h : nil } ?? unserved.first
            guard let a = first, let b = unserved.first(where: { $0.id != a.id }) else { return nil }
            return (.serveBoth(a.id, b.id), a, b)
        }
    }

    /// A decoration right beside a landmark (within a square).
    func decorBeside(_ id: Int) -> Bool {
        guard let place = landmark(id: id) else { return false }
        return decorItems.contains { max(abs($0.cell.col - place.cell.col), abs($0.cell.row - place.cell.row)) <= 1 }
    }

    var totalTrains: Int { lines.reduce(0) { $0 + trainCount(for: $1.id) } }
    var openHubs: Int { landmarks.filter { $0.kind == .transitHub && $0.isOpen }.count }

    /// A finished request: the resident's story moves on, and they ring back soon to say how it went.
    func residentRequestDone(_ letter: Letter) {
        guard let id = letter.residentID, let resident = Cast.resident(id) else { return }
        residentProgress[id, default: 0] += 1
        if residentHome[id] == nil, let home = letter.homeID { residentHome[id] = home }

        // Full circle: they become a regular at the place(s) involved and leave a comment card.
        let who = "\(resident.name), \(resident.role)"
        var places: [Int] = letter.homeID.map { [$0] } ?? []
        if case let .connect(a, b) = letter.goal { places = [a, b] }
        for (index, placeID) in places.enumerated() where landmark(id: placeID) != nil {
            var record = shopRecords[placeID] ?? ShopRecord(openedDay: day)
            record.regulars[who, default: 0] += 3
            if index == 0, let text = letter.cardText {
                nextCommentID += 1
                record.comments.insert(CommentCard(id: nextCommentID, author: who, text: text, day: day, hearts: 5), at: 0)
                if record.comments.count > 20 { record.comments.removeLast() }
            }
            shopRecords[placeID] = record
        }
        if let thanks = letter.thanks {
            announce(thanks + " (They've sent $\(letter.reward) and a Golden Ticket.)", from: resident.name, role: resident.role,
                     pitch: resident.pitch)
            newsCooldown = min(newsCooldown, 8)
        }
    }
}
