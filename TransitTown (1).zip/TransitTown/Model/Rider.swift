import Foundation

/// One person trying to get from one landmark to another.
struct Rider {
    let id: Int
    let origin: Int
    let destination: Int
    let patience: Double
    let isVisitor: Bool
    /// Seconds spent waiting on platforms.
    var waited: Double = 0
    /// True if the network connects this rider's current station to their destination.
    var hasRoute = false
    /// Where to get off the train they're on. Chosen when they board.
    var alightAt: Int?
    /// How many times this rider has changed trains. Each change adds to the fare.
    var transfers = 0
    /// True while waiting on a platform partway through a journey.
    var isTransferring = false
    /// Heading to another district by light rail: more patient, and pays more.
    var isCrossDistrict = false
    /// Part of a group traveling together (a school trip, the inspector...).
    var tripID: Int?
    /// A resident out and about: shown with a star, and remembered when they arrive.
    var spotlight: String?
}

/// What happened when a train stopped at a station.
struct TrainExchange {
    var delivered = 0
    var fares = 0
    var boarded = 0
    var transferred = 0
    var load = 0
}

/// Moments the scene animates. Drained by the scene each frame.
enum SimEvent {
    case gaveUp(stationID: Int)
    case restored(landmarkID: Int)
    /// An ink stamp over a station: "ARRIVED", "INSPECTED"...
    case stamp(text: String, stationID: Int)
    /// A small floating note over a station: "♥ Theo made it".
    case note(text: String, stationID: Int)
}

/// Running totals for the current term.
struct TermStats: Codable {
    var ridersServed = 0
    var totalFares = 0
    var nightRiders = 0
    var gaveUp = 0
    var heritageRestored = 0
    var landmarksBuilt = 0
    var trainsBought = 0
    var bestDayRiders = 0
    var transfers = 0
    var crossDistrictRiders = 0
}

/// Everything that happened today, for the Gazette.
struct DayReport: Codable {
    var riders = 0
    var fares = 0
    var transfers = 0
    var crossDistrictRiders = 0
    var lightRailOpened = false
    var pairsCompleted: [String] = []
    var events: [String] = []
    var lettersAnswered = 0
    var lettersMissed = 0
    var tripsCompleted = 0
    var tripsFailed = 0
    var decisions: [String] = []
    var weather: Weather = .fair
    var nightRiders = 0
    var gaveUp = 0
    var overcrowded = 0
    var gaveUpAt: [Int: Int] = [:]
    var traffic: [Int: Int] = [:]
    var longestWait: Double = 0
    var longestWaitStation: Int?
    var linesOpened: [Int] = []
    var landmarksBuilt: [LandmarkKind] = []
    var restored: [LandmarkKind] = []
    var ratingStart: Double = 0
    var ratingEnd: Double = 0
    var revivedStart: Double = 0
    var revivedEnd: Double = 0
    var isRecord = false
}
