import UIKit

/// Groups landmarks for the colored band on their stamp and for daily themes.
enum LandmarkCategory: String, CaseIterable, Codable {
    case hub, food, culture, nature, civic
    /// Canal quays: light rail stops on the water between districts.
    case canal
    /// Churches, cemeteries, fortune tellers: the town's quieter corners.
    case spiritual

    static let featurable: [LandmarkCategory] = [.food, .culture, .nature, .civic, .spiritual]

    var name: String {
        switch self {
        case .hub: return "Transit"
        case .food: return "Food"
        case .culture: return "Culture"
        case .nature: return "Nature"
        case .civic: return "Services"
        case .canal: return "Canal"
        case .spiritual: return "Spiritual"
        }
    }

    var color: UIColor {
        switch self {
        case .hub: return Palette.ink
        case .food: return UIColor(hex: 0xF0A07C)
        case .culture: return UIColor(hex: 0xA597D6)
        case .nature: return UIColor(hex: 0x98C487)
        case .civic: return UIColor(hex: 0x82BACB)
        case .canal: return UIColor(hex: 0x5FA7A0)
        case .spiritual: return UIColor(hex: 0xC98A9B)
        }
    }
}

/// A special ability a landmark gives once it's open.
enum LandmarkPerk: Equatable {
    case none, patience, revivalBoost, trainSpeed, visitors, rating

    var text: String? {
        switch self {
        case .none: return nil
        case .patience: return "Riders waiting nearby stay patient longer."
        case .revivalBoost: return "Revives a wider area around it."
        case .trainSpeed: return "Every train runs 15% faster."
        case .visitors: return "More visitors arrive at the hub."
        case .rating: return "Lifts the town rating by ★0.1."
        }
    }
}

/// How strongly a landmark draws riders in each part of the day.
struct DemandProfile {
    let morning: Double
    let midday: Double
    let evening: Double
    let night: Double

    func weight(_ phase: DayPhase) -> Double {
        switch phase {
        case .morning: return morning
        case .midday: return midday
        case .evening: return evening
        case .night: return night
        }
    }

    var total: Double { morning + midday + evening + night }
}

struct LandmarkInfo {
    let name: String
    let symbol: String
    let category: LandmarkCategory
    let district: District
    let blurb: String
    let cost: Int
    /// For landmarks: what unlocks the blueprint. For heritage sites: what restoration requires.
    let unlock: UnlockCondition
    let demand: DemandProfile
    let perk: LandmarkPerk
    let isHeritage: Bool
    /// A natural partner. When both share a line, trips between them are more common and pay more.
    let pair: LandmarkKind?
    let pairName: String?
    /// Hidden name in the album until unlocked.
    let isSecret: Bool
    let rumor: String?

    /// A rough guide shown on album cards.
    var expectedRidersPerDay: Int { Int((demand.total * 4).rounded()) }
}

/// Every place in the city, grouped by district. Each can be built once.
enum LandmarkKind: String, CaseIterable, Identifiable, Codable {
    // Old Town
    case central, bakery, park, cafe, library, school, market, catCafe, flowerStall, toyShop, tailor, church, clockTower
    // Harborside
    case harborStation, fishMarket, boardwalk, chowderHouse, aquarium, boatyard, ferryPier, sailorsPub
    case iceCreamKiosk, lifeboatStation, hauntedHouse, lighthouse
    // Hill Quarter
    case hilltopStation, greenhouse, studios, teaRoom, pool, observatory, vineyard, hedgeMaze
    case monasteryGardens, funicular, hospital, cemetery, grandHotel
    // Lantern Row
    case lanternStation, nightMarket, cinema, bandstand, museum, stadium, jazzClub, arcade
    case noodleBar, puppetTheatre, bank, fortuneTeller, theatre
    // Canal quays, served only by light rail
    case northQuay, westQuay, eastQuay, southQuay
    /// Built by the mayor, as many as needed: transit hubs, and the two ends of each tunnel.
    case transitHub, tunnelPortal

    var id: String { rawValue }

    /// Landmarks you can build in a district (not its hub, heritage site, or quays), in album order.
    static func landmarks(in district: District) -> [LandmarkKind] {
        allCases.filter { $0.info.district == district && $0.info.category != .hub
            && $0.info.category != .canal && !$0.info.isHeritage }
    }

    /// Quays that appear on the canals when a district opens.
    static func quays(openedBy district: District) -> [LandmarkKind] {
        allCases.filter { $0.info.category == .canal && $0.info.district == district }
    }

    static func heritage(in district: District) -> [LandmarkKind] {
        allCases.filter { $0.info.district == district && $0.info.isHeritage }
    }

    /// Landmarks a district's blueprints open with: its first landmark, plus the Pocket Park
    /// in Old Town, which the mayor places during onboarding.
    static func starters(in district: District) -> [LandmarkKind] {
        landmarks(in: district).filter { $0.info.unlock == .start }
    }

    /// The one landmark already standing when a district opens, open for business.
    static func preplaced(in district: District) -> [LandmarkKind] {
        switch district {
        case .oldTown: return [.bakery]
        case .harborside: return [.fishMarket]
        case .hillQuarter: return [.greenhouse]
        case .lanternRow: return [.nightMarket]
        }
    }

    var info: LandmarkInfo {
        switch self {

        // MARK: Old Town
        case .central:
            return Self.make("Central Station", "tram.fill", .hub, .oldTown, cost: 0, unlock: .start,
                             demand: (0.6, 0.6, 0.7, 0.4),
                             blurb: "The ticket hall still smells of brass polish. Every visitor to town arrives here.")
        case .bakery:
            return Self.make("Corner Bakery", "birthday.cake.fill", .food, .oldTown, cost: 0, unlock: .start,
                             demand: (1.7, 0.6, 0.3, 0.0), pair: .cafe, pairName: "Breakfast Run",
                             blurb: "Rolls out of the oven at six. The line out the door is the best advertising in town.")
        case .park:
            return Self.make("Pocket Park", "tree.fill", .nature, .oldTown, cost: 60, unlock: .start,
                             demand: (0.3, 1.1, 0.9, 0.1), perk: .revivalBoost, pair: .market, pairName: "Picnic Basket",
                             blurb: "A bench, a fountain, and one very confident pigeon.")
        case .cafe:
            return Self.make("Bluebell Café", "cup.and.saucer.fill", .food, .oldTown, cost: 80, unlock: .ridersServed(15),
                             demand: (1.2, 0.9, 0.4, 0.0), perk: .patience, pair: .bakery, pairName: "Breakfast Run",
                             blurb: "Window seats, strong coffee, and a regular at every table.")
        case .library:
            return Self.make("Lantern Library", "books.vertical.fill", .culture, .oldTown, cost: 100, unlock: .rating(2.0),
                             demand: (0.4, 1.3, 0.6, 0.0), pair: .school, pairName: "Homework Club",
                             blurb: "Quiet reading rooms and a librarian who knows everyone's overdue books by heart.")
        case .school:
            return Self.make("Willow School", "graduationcap.fill", .culture, .oldTown, cost: 110, unlock: .stationsConnected(4),
                             demand: (1.6, 0.4, 0.6, 0.0), pair: .library, pairName: "Homework Club",
                             blurb: "Morning bell, afternoon bell, and two hundred backpacks on the train.")
        case .market:
            return Self.make("Market Hall", "cart.fill", .food, .oldTown, cost: 120, unlock: .faresEarned(200),
                             demand: (0.5, 1.7, 0.6, 0.0), pair: .park, pairName: "Picnic Basket",
                             blurb: "Forty stalls under one glass roof, and all of them shouting about tomatoes.")
        case .catCafe:
            return Self.make("Whisker Café", "cat.fill", .food, .oldTown, cost: 120, unlock: .foodLine,
                             demand: (0.6, 1.0, 0.8, 0.2), perk: .patience, pair: .library, pairName: "Reading Nook",
                             secret: true, rumor: "Rumor has it the cats only move to towns with a proper food line.",
                             blurb: "Eleven cats, one espresso machine, and no one in a hurry to leave.")
        case .flowerStall:
            return Self.make("Flower Stall", "camera.macro", .nature, .oldTown, cost: 70, unlock: .revived(0.3),
                             demand: (1.0, 1.0, 0.4, 0.0), pair: .park, pairName: "Posies in the Park",
                             blurb: "Buckets of tulips on the pavement and a man who knows every customer's favorite.")
        case .toyShop:
            return Self.make("Toy Shop", "teddybear.fill", .culture, .oldTown, cost: 90, unlock: .day(4),
                             demand: (0.4, 1.2, 0.9, 0.0), pair: .school, pairName: "After School",
                             blurb: "Wooden trains in the window. Children press their noses to the glass.")
        case .tailor:
            return Self.make("Tailor", "scissors", .civic, .oldTown, cost: 140, unlock: .ridersServed(60),
                             demand: (0.6, 1.2, 0.8, 0.0), pair: .flowerStall, pairName: "Buttonholes",
                             blurb: "A dress form in the window and a tape measure around every neck in town.")
        case .church:
            return Self.make("Church", "bell.fill", .spiritual, .oldTown, cost: 150, unlock: .revived(0.25),
                             demand: (1.3, 0.5, 0.6, 0.2), perk: .patience,
                             blurb: "A rose window, a bell on Sundays, and pews worn smooth by a hundred years.")
        case .clockTower:
            return Self.make("Old Clock Tower", "clock.fill", .civic, .oldTown, cost: 150, unlock: .servedBy(1),
                             demand: (0.6, 0.6, 0.5, 0.2), perk: .trainSpeed, heritage: true,
                             blurb: "Stopped at 4:17 the day the trains did. Wind it, and every train runs on time.")

        // MARK: Harborside
        case .harborStation:
            return Self.make("Harbor Station", "tram.fill", .hub, .harborside, cost: 0, unlock: .start,
                             demand: (0.7, 0.5, 0.7, 0.3),
                             blurb: "Gulls on the roof and salt on the windows. The light rail from Old Town ends here.")
        case .fishMarket:
            return Self.make("Fish Market", "fish.fill", .food, .harborside, cost: 0, unlock: .start,
                             demand: (1.8, 0.5, 0.6, 0.1), pair: .chowderHouse, pairName: "Catch of the Day",
                             blurb: "Ice, scales, and bargaining by five in the morning.")
        case .boardwalk:
            return Self.make("Boardwalk", "beach.umbrella.fill", .nature, .harborside, cost: 90, unlock: .ridersServed(40),
                             demand: (0.3, 1.2, 1.3, 0.3), pair: .aquarium, pairName: "Day at the Shore",
                             blurb: "Planks, pinwheels, and a man who sells exactly one flavor of ice cream.")
        case .chowderHouse:
            return Self.make("Chowder House", "frying.pan.fill", .food, .harborside, cost: 100, unlock: .rating(2.5),
                             demand: (0.4, 1.0, 1.4, 0.3), pair: .fishMarket, pairName: "Catch of the Day",
                             blurb: "Bread bowls, steamed-up windows, and a queue that smells wonderful.")
        case .aquarium:
            return Self.make("Aquarium", "water.waves", .culture, .harborside, cost: 140, unlock: .faresEarned(400),
                             demand: (0.2, 1.4, 0.8, 0.0), perk: .rating, pair: .boardwalk, pairName: "Day at the Shore",
                             blurb: "An octopus named Mrs. Pennywhistle is the town's biggest celebrity.")
        case .boatyard:
            return Self.make("Boatyard", "sailboat.fill", .civic, .harborside, cost: 110, unlock: .stationsConnected(4),
                             demand: (1.4, 0.6, 1.1, 0.0), pair: .fishMarket, pairName: "Dockside",
                             blurb: "Half-finished hulls and the smell of fresh varnish.")
        case .lighthouse:
            return Self.make("Old Lighthouse", "light.beacon.max.fill", .civic, .harborside, cost: 220, unlock: .servedBy(1),
                             demand: (0.5, 0.5, 0.8, 0.7), perk: .visitors, heritage: true,
                             blurb: "Dark for twenty years. Light the lamp, and the ships come back.")

        // MARK: Hill Quarter
        case .hilltopStation:
            return Self.make("Hilltop Station", "tram.fill", .hub, .hillQuarter, cost: 0, unlock: .start,
                             demand: (0.5, 0.8, 0.6, 0.3),
                             blurb: "A little stone station with the best view in the city.")
        case .greenhouse:
            return Self.make("Glass Greenhouse", "leaf.fill", .nature, .hillQuarter, cost: 0, unlock: .start,
                             demand: (0.3, 1.2, 0.7, 0.0), perk: .revivalBoost, pair: .teaRoom, pairName: "Tea and Orchids",
                             blurb: "Orchids, lemon trees, and the warmest bench in the city.")
        case .studios:
            return Self.make("Artists' Studios", "paintpalette.fill", .culture, .hillQuarter, cost: 100, unlock: .ridersServed(40),
                             demand: (0.3, 1.2, 1.0, 0.2), pair: .teaRoom, pairName: "Sketch and Sip",
                             blurb: "Open doors, paint on the floor, and an exhibition every Friday.")
        case .teaRoom:
            return Self.make("Lookout Tea Room", "mug.fill", .food, .hillQuarter, cost: 90, unlock: .rating(2.5),
                             demand: (0.6, 1.3, 0.7, 0.0), pair: .greenhouse, pairName: "Tea and Orchids",
                             blurb: "Twelve kinds of tea and a terrace that looks over the whole city.")
        case .pool:
            return Self.make("Lido Pool", "figure.pool.swim", .nature, .hillQuarter, cost: 140, unlock: .revived(0.30),
                             demand: (0.4, 1.7, 0.6, 0.0), pair: .greenhouse, pairName: "Garden Swim",
                             blurb: "Striped umbrellas, a high dive, and pure chaos by noon.")
        case .observatory:
            return Self.make("Observatory", "moon.stars.fill", .culture, .hillQuarter, cost: 160, unlock: .nightRiders(30),
                             demand: (0.0, 0.1, 0.6, 1.7), pair: .studios, pairName: "Stars and Easels",
                             blurb: "A brass telescope and a guide who names every star after her cats.")
        case .grandHotel:
            return Self.make("Grand Hotel", "bed.double.fill", .civic, .hillQuarter, cost: 280, unlock: .rating(3.0),
                             demand: (0.8, 0.5, 0.8, 0.6), perk: .visitors, heritage: true,
                             blurb: "Two hundred rooms and one very dusty chandelier.")

        // MARK: Lantern Row
        case .lanternStation:
            return Self.make("Lantern Row Station", "tram.fill", .hub, .lanternRow, cost: 0, unlock: .start,
                             demand: (0.3, 0.5, 0.9, 0.8),
                             blurb: "Strung with paper lanterns from the platform to the street.")
        case .nightMarket:
            return Self.make("Night Market", "takeoutbag.and.cup.and.straw.fill", .food, .lanternRow, cost: 0, unlock: .start,
                             demand: (0.0, 0.1, 0.7, 2.0), pair: .cinema, pairName: "Dinner and a Movie",
                             blurb: "Noodle stalls and paper lanterns that open when the sun goes down.")
        case .cinema:
            return Self.make("Rialto Cinema", "film.fill", .culture, .lanternRow, cost: 120, unlock: .ridersServed(40),
                             demand: (0.0, 0.4, 1.7, 1.0), pair: .nightMarket, pairName: "Dinner and a Movie",
                             blurb: "Velvet seats and a marquee with every bulb lit.")
        case .bandstand:
            return Self.make("Bandstand", "music.note", .culture, .lanternRow, cost: 100, unlock: .rating(2.5),
                             demand: (0.1, 0.5, 1.4, 0.7), perk: .rating, pair: .nightMarket, pairName: "Music and Noodles",
                             blurb: "Brass band on Thursdays, everyone else every other night.")
        case .museum:
            return Self.make("Museum of Small Things", "building.columns.fill", .culture, .lanternRow, cost: 150,
                             unlock: .faresEarned(400), demand: (0.2, 1.3, 0.7, 0.0), perk: .rating,
                             pair: .bandstand, pairName: "Culture Night",
                             blurb: "Thimbles, keys, and the world's tiniest teapot.")
        case .stadium:
            return Self.make("Stadium", "sportscourt.fill", .civic, .lanternRow, cost: 220, unlock: .rating(3.5),
                             demand: (0.1, 0.3, 1.9, 0.8), pair: .nightMarket, pairName: "Match Night",
                             blurb: "On match nights, every train in the city is headed the same way.")
        case .ferryPier:
            return Self.make("Ferry Pier", "ferry.fill", .civic, .harborside, cost: 120, unlock: .stationsConnected(4),
                             demand: (1.4, 0.8, 1.2, 0.2), perk: .visitors, pair: .sailorsPub, pairName: "Off the Boat",
                             blurb: "Ferries to the islands twice a day, and a horn you can hear from the hills.")
        case .sailorsPub:
            return Self.make("Sailors' Pub", "mug.fill", .food, .harborside, cost: 80, unlock: .nightRiders(15),
                             demand: (0.0, 0.4, 1.2, 1.5), pair: .ferryPier, pairName: "Off the Boat",
                             blurb: "Low beams, salty stories, and a cat nobody admits to owning.")
        case .iceCreamKiosk:
            return Self.make("Ice Cream Kiosk", "snowflake", .food, .harborside, cost: 60, unlock: .rating(3.2),
                             demand: (0.1, 1.4, 1.2, 0.2), pair: .boardwalk, pairName: "Sundae Stroll",
                             blurb: "Twelve flavors and a queue that stretches down the sea wall in summer.")
        case .lifeboatStation:
            return Self.make("Lifeboat Station", "lifepreserver.fill", .civic, .harborside, cost: 110, unlock: .revived(0.35),
                             demand: (0.6, 0.7, 0.6, 0.4), perk: .patience,
                             blurb: "A bright orange boat and volunteers who drop everything when the bell rings.")
        case .vineyard:
            return Self.make("Hillside Vineyard", "wineglass.fill", .food, .hillQuarter, cost: 110, unlock: .faresEarned(250),
                             demand: (0.2, 1.0, 1.4, 0.5), pair: .grandHotel, pairName: "Wine and Dine",
                             blurb: "Terraced vines, a tasting room, and the best sunset in the city.")
        case .hedgeMaze:
            return Self.make("Hedge Maze", "square.grid.3x3.fill", .nature, .hillQuarter, cost: 100, unlock: .stationsConnected(4),
                             demand: (0.4, 1.4, 0.9, 0.0), perk: .revivalBoost, pair: .greenhouse, pairName: "Garden Trail",
                             blurb: "Tall yew hedges. Nobody has found the middle in years, but everybody tries.")
        case .monasteryGardens:
            return Self.make("Monastery Gardens", "bell.fill", .spiritual, .hillQuarter, cost: 130, unlock: .revived(0.4),
                             demand: (1.2, 0.7, 0.6, 0.1), perk: .patience,
                             blurb: "Herb beds, a bell at noon, and a silence the whole hill seems to share.")
        case .funicular:
            return Self.make("Funicular", "cablecar.fill", .civic, .hillQuarter, cost: 140, unlock: .rating(3.6),
                             demand: (1.0, 1.0, 1.0, 0.3), perk: .trainSpeed,
                             blurb: "Two little cars on one cable, passing politely halfway up.")
        case .jazzClub:
            return Self.make("Blue Note Club", "music.note", .culture, .lanternRow, cost: 110, unlock: .nightRiders(20),
                             demand: (0.0, 0.2, 1.0, 1.9), pair: .noodleBar, pairName: "Late Set",
                             blurb: "A saxophone through a basement door, until the last train and beyond.")
        case .arcade:
            return Self.make("Penny Arcade", "gamecontroller.fill", .culture, .lanternRow, cost: 90, unlock: .ridersServed(120),
                             demand: (0.1, 0.9, 1.3, 1.0), pair: .cinema, pairName: "Night Out",
                             blurb: "Pinball, claw machines, and a high score nobody has beaten since 1987.")
        case .noodleBar:
            return Self.make("Noodle Bar", "fork.knife", .food, .lanternRow, cost: 70, unlock: .faresEarned(200),
                             demand: (0.3, 1.3, 1.1, 0.8), pair: .jazzClub, pairName: "Late Set",
                             blurb: "Six stools, one enormous pot, and broth that's been going for days.")
        case .puppetTheatre:
            return Self.make("Puppet Theatre", "theatermask.and.paintbrush.fill", .culture, .lanternRow, cost: 100,
                             unlock: .rating(3.4), demand: (0.6, 1.3, 0.9, 0.0), perk: .rating,
                             blurb: "Marionettes, a tiny stage, and an audience half the height of the ticket desk.")
        case .hauntedHouse:
            return Self.make("Haunted House", "moon.fill", .spiritual, .harborside, cost: 160, unlock: .nightRiders(10),
                             demand: (0.1, 0.4, 1.0, 1.8), pair: .sailorsPub, pairName: "Ghost Stories",
                             blurb: "The old captain's house. One window is always lit, and nobody lives there.")
        case .hospital:
            return Self.make("Hospital", "cross.case.fill", .civic, .hillQuarter, cost: 220, unlock: .rating(3.4),
                             demand: (1.2, 1.0, 0.8, 0.6), perk: .patience,
                             blurb: "Clean sheets, kind nurses, and the best view on the hill from the third floor.")
        case .cemetery:
            return Self.make("Cemetery", "leaf.fill", .spiritual, .hillQuarter, cost: 120, unlock: .day(3),
                             demand: (0.8, 0.6, 0.5, 0.2), perk: .revivalBoost,
                             blurb: "Old yews, mossy stones, and a bench where people come to remember.")
        case .bank:
            return Self.make("Bank", "building.columns", .civic, .lanternRow, cost: 240, unlock: .faresEarned(300),
                             demand: (1.2, 1.1, 0.4, 0.0), pair: .museum, pairName: "Safe Keeping",
                             blurb: "Marble floors, brass lamps, and a vault nobody has opened since 1952.")
        case .fortuneTeller:
            return Self.make("Fortune Teller", "sparkles", .spiritual, .lanternRow, cost: 130, unlock: .nightRiders(15),
                             demand: (0.0, 0.5, 1.2, 1.6), pair: .nightMarket, pairName: "Read the Stars",
                             blurb: "A starry caravan and a crystal ball that is, she insists, never wrong.")
        case .transitHub:
            return Self.make("Transit Hub", "arrow.triangle.swap", .hub, .oldTown, cost: 0, unlock: .start,
                             demand: (0.8, 0.8, 0.8, 0.4),
                             blurb: "Where lines meet and riders change trains. Name it something they'll remember.")
        case .tunnelPortal:
            return Self.make("Tunnel", "arrow.down.forward.circle", .canal, .oldTown, cost: 0, unlock: .start,
                             demand: (0, 0, 0, 0),
                             blurb: "Down under the water, and up again on the other side.")
        case .northQuay:
            return Self.make("North Quay", "sailboat.fill", .canal, .harborside, cost: 0, unlock: .start,
                             demand: (0.3, 0.9, 1.0, 0.4),
                             blurb: "Where the canal meets the harbor road. Light rail only.")
        case .westQuay:
            return Self.make("West Quay", "sailboat.fill", .canal, .hillQuarter, cost: 0, unlock: .start,
                             demand: (0.3, 0.9, 1.0, 0.4),
                             blurb: "Narrowboats and a lock keeper's cottage. Light rail only.")
        case .eastQuay:
            return Self.make("East Quay", "sailboat.fill", .canal, .lanternRow, cost: 0, unlock: .start,
                             demand: (0.3, 0.9, 1.0, 0.4),
                             blurb: "Old warehouses waiting for a second life. Light rail only.")
        case .southQuay:
            return Self.make("South Quay", "sailboat.fill", .canal, .lanternRow, cost: 0, unlock: .start,
                             demand: (0.3, 0.9, 1.0, 0.4),
                             blurb: "A boathouse, a towpath, and the best view of the canal crossing. Light rail only.")
        case .theatre:
            return Self.make("Lyric Theatre", "theatermasks.fill", .culture, .lanternRow, cost: 340, unlock: .rating(4.0),
                             demand: (0.0, 0.3, 1.8, 0.9), perk: .rating, heritage: true,
                             blurb: "The stage where the whole city once gathered on a Saturday night.")
        }
    }

    // swiftlint:disable:next function_parameter_count
    private static func make(_ name: String, _ symbol: String, _ category: LandmarkCategory, _ district: District,
                             cost: Int, unlock: UnlockCondition, demand: (Double, Double, Double, Double),
                             perk: LandmarkPerk = .none, heritage: Bool = false,
                             pair: LandmarkKind? = nil, pairName: String? = nil,
                             secret: Bool = false, rumor: String? = nil, blurb: String) -> LandmarkInfo {
        // One big town: every landmark can turn up anywhere (the district is kept only for old saves'
        // stations), and the old heritage sites are simply culture landmarks that arrive by permit.
        let townDistrict: District = category == .hub ? district : .oldTown
        return LandmarkInfo(name: name, symbol: symbol, category: heritage ? .culture : category, district: townDistrict,
                            blurb: blurb, cost: cost, unlock: unlock,
                            demand: DemandProfile(morning: demand.0, midday: demand.1, evening: demand.2, night: demand.3),
                            perk: perk, isHeritage: false, pair: pair, pairName: pairName, isSecret: secret, rumor: rumor)
    }
}

extension LandmarkKind {
    /// A hint shown on a locked blueprint instead of its name, so every unlock is a small reveal.
    var teaser: String {
        switch self {
        case .central, .harborStation, .hilltopStation, .lanternStation: return "A station at the heart of town."
        case .bakery: return "Something warm, out of the oven before sunrise."
        case .park: return "A bench, a fountain, and someone who feeds the birds."
        case .cafe: return "Somewhere with window seats and very strong opinions about coffee."
        case .library: return "A quiet place where somebody always knows the answer."
        case .school: return "A bell, a playground, and a lot of backpacks."
        case .market: return "A glass roof, and a lot of people shouting prices."
        case .catCafe: return "Something soft is waiting for the right street."
        case .clockTower: return "It stopped the day the trains did."
        case .fishMarket: return "Up before the gulls."
        case .boardwalk: return "Planks, sea air, and ice cream that melts too fast."
        case .chowderHouse: return "Steamed-up windows and a bowl you can eat."
        case .aquarium: return "Someone very famous lives here. She has eight arms."
        case .boatyard: return "Half-built hulls and the smell of varnish."
        case .lighthouse: return "Dark for twenty years, still standing."
        case .greenhouse: return "Warm glass and things that flower in winter."
        case .studios: return "Paint on the floor and the doors left open."
        case .teaRoom: return "A terrace with a view of everything."
        case .pool: return "Striped umbrellas and a very high board."
        case .observatory: return "Best visited after dark."
        case .grandHotel: return "Two hundred rooms, all waiting."
        case .nightMarket: return "Opens when everything else closes."
        case .cinema: return "Velvet seats and a flickering marquee."
        case .bandstand: return "Thursdays, mostly brass."
        case .museum: return "Very small things, very lovingly kept."
        case .stadium: return "On some nights, everyone's headed the same way."
        case .theatre: return "The curtain's been down a long time."
        case .flowerStall: return "Buckets of something bright on the pavement."
        case .toyShop: return "Wooden things in the window, and a bell over the door."
        case .ferryPier: return "A horn you can hear from the hills."
        case .sailorsPub: return "Low beams and taller stories."
        case .iceCreamKiosk: return "Twelve flavors. One very long queue."
        case .lifeboatStation: return "Something bright orange, ready to go."
        case .vineyard: return "Rows of green on the sunny side of the hill."
        case .hedgeMaze: return "Easy to get into. Harder to get out of."
        case .monasteryGardens: return "A bell at noon, and a great deal of quiet."
        case .funicular: return "Two little cars, one long cable."
        case .jazzClub: return "Music coming up from a basement door."
        case .arcade: return "Bleeps, bells, and a very old high score."
        case .noodleBar: return "Steam on the window and six stools at the counter."
        case .puppetTheatre: return "Strings, a tiny stage, and a very small audience."
        case .northQuay, .westQuay, .eastQuay, .southQuay: return "A stop on the water."
        case .transitHub: return "Where lines meet and riders change trains."
        case .tunnelPortal: return "Down under the water and up again."
        case .tailor: return "A tape measure and a very sharp pair of scissors."
        case .church: return "A bell on Sundays and a window full of colors."
        case .hauntedHouse: return "One window is always lit. Nobody lives there."
        case .hospital: return "Clean sheets and kind faces."
        case .cemetery: return "Old stones, quiet paths, a bench to sit on."
        case .bank: return "Marble floors and a very heavy door."
        case .fortuneTeller: return "She already knows you're coming."
        }
    }
}
