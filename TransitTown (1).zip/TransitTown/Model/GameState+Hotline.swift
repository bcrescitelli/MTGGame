import Foundation

/// The Town Hotline. Every so often the phone rings; the mayor picks up when ready and a
/// resident asks for one thing. Only one request is open at a time, and requests never ask
/// for something that's already true or that undoes another.
extension GameState {

    /// Seconds between calls once the line is free, and how long a call rings before giving up.
    /// Roughly one resident's request per town day, so calls never pile up.
    private var callGap: ClosedRange<Double> { 70...130 }
    static let hotlineRating = 2.8
    static let hotlineRiders = 60
    /// The quiet time after any call before the phone rings again.
    static let callCooldown: Double = 30
    private var ringLength: Double { 18 }

    var hasOpenTask: Bool { !openLetters.isEmpty }

    /// Calls only start between early morning and about 7pm, never late in the evening.
    var isPhoneHours: Bool { dayClock > 0.1 && dayClock < 0.72 }

    var isPhoneBusy: Bool {
        ringingCall != nil || openCall != nil || ringingFeature || featureCallOpen || ringingNews || openNews != nil
    }

    func updateHotline(dt: Double) {
        checkDecorUnlock()
        guard phase == .playing else { return }
        if !hotlineUnlocked {
            guard (townRating >= GameState.hotlineRating && stats.ridersServed >= GameState.hotlineRiders) || termNumber > 1 else { return }
            hotlineUnlocked = true
            newsQueue.removeAll()
            announce("Pip here, at the station. Folk keep stopping me on the platform with ideas for the trains, so we've set up a Town Hotline, straight to you. Expect a ring now and then. Pick up when you can; nobody minds waiting.",
                     urgent: true)
            hotlineTimer = 60
            return
        }
        newsCooldown -= dt
        if ringingCall != nil {
            ringTimer -= dt
            if ringTimer <= 0 || !isPhoneHours {
                ringingCall = nil
                hotlineTimer = Double.random(in: callGap)
            }
            return
        }
        // Every call keeps to phone hours, so the evening paper never lands on top of one.
        guard !isPhoneBusy, newsCooldown <= 0, isPhoneHours || tutorial == .answerCall else { return }
        // News first (Pip's hotline welcome is always the first call), then City Planning,
        // then residents with a request.
        dropStaleNews()
        if !newsQueue.isEmpty {
            ringingNews = true
            return
        }
        if decorUnlocked && !decorAnnounced {
            ringingFeature = true
            return
        }
        guard day >= 2 || dayClock > 0.35, !hasOpenTask else { return }
        hotlineTimer -= dt
        guard hotlineTimer <= 0 else { return }
        if let call = makeCall() {
            ringingCall = call
            ringTimer = ringLength
        } else {
            hotlineTimer = 20
        }
    }

    /// The day is over: a ringing phone stops, and anything on the line hangs up. Tasks stay on
    /// the notepad; unheard news waits for tomorrow.
    func quietPhone() {
        ringingCall = nil
        ringingFeature = false
        featureCallOpen = false
        ringingNews = false
        if let news = openNews { newsQueue.insert(news, at: 0) }
        openNews = nil
        openCall = nil
        newsCooldown = 8
    }

    /// Queue a piece of news to be phoned in.
    /// Queue a piece of news to be phoned in. Urgent news (a new line) jumps the queue and
    /// rings as soon as the line is free.
    func announce(_ body: String, from sender: String = "Pip Holloway", role: String = "Station Master",
                  pitch: Double = 1.15, urgent: Bool = false, tripID: Int? = nil) {
        // Before the hotline opens, news arrives as a note instead.
        guard hotlineUnlocked else {
            showTip("news-\(body.prefix(40))", symbol: "megaphone.fill", title: sender, text: body)
            return
        }
        guard !newsQueue.contains(where: { $0.body == body }) else { return }
        var call = NewsCall(sender: sender, role: role, body: body, pitch: pitch)
        call.tripID = tripID
        if urgent {
            newsQueue.insert(call, at: 0)
            newsCooldown = 0
        } else {
            newsQueue.append(call)
        }
    }

    /// News about a trip that's already over isn't news any more.
    private func dropStaleNews() {
        newsQueue.removeAll { call in
            guard let id = call.tripID else { return false }
            return !trips.contains { $0.id == id && !$0.isResolved }
        }
    }

    func answerNews() {
        if tutorial == .answerCall { tutorial = .addTrain }
        dropStaleNews()
        guard !newsQueue.isEmpty else { ringingNews = false; return }
        ringingNews = false
        openNews = newsQueue.removeFirst()
    }

    func hangUpNews() {
        openNews = nil
        hushAfterCall()
        newsCooldown = GameState.callCooldown
    }

    /// The request in plain words, under the caller's own.
    func askSummary(_ letter: Letter) -> String {
        let name: (Int) -> String = { [weak self] id in self?.landmark(id: id)?.kind.info.name ?? "that stop" }
        switch letter.goal {
        case let .connect(a, b): return "Put the \(name(a)) and the \(name(b)) on the same line."
        case let .serve(a): return "Give the \(name(a)) a train stop."
        case let .lines(a, count): return count == 2 ? "Give the \(name(a)) a second line." : "Have \(count) lines stop at the \(name(a))."
        case let .atMost(a, count): return "Keep the \(name(a)) to \(count == 1 ? "one line" : "\(count) lines")."
        case let .carryTo(a, count): return "Bring \(count) riders to the \(name(a))."
        case let .find(a):
            let item = letter.lostItemID.flatMap { LostAndFound.item($0)?.item } ?? "lost item"
            return "Find the \(item) somewhere on the map, then bring it to the \(name(a))."
        case let .decorNear(a): return "Place a decoration right beside the \(name(a))."
        case let .trains(n): return "Have \(n) trains running in town."
        case let .hubs(n): return n == 1 ? "Build a transit hub." : "Have \(n) transit hubs open."
        case let .serveBoth(a, b): return "Give both the \(name(a)) and the \(name(b)) a train stop."
        }
    }

    /// Pick up: the call opens on screen, typing out, and becomes the open task.
    func answerPhone() {
        guard let call = ringingCall else { return }
        ringingCall = nil
        letters.append(call)
        openCall = call
    }

    /// Hang up after reading; the task stays on the notepad.
    func hangUp() {
        openCall = nil
        hushAfterCall()
        hotlineTimer = Double.random(in: callGap)
        newsCooldown = GameState.callCooldown
    }

    private func makeCall() -> Letter? {
        // Now and then something's been lost; otherwise the town's residents, each with a story.
        // The general calls are a fallback.
        if Int.random(in: 0..<4) == 0, let call = makeLostItemCall() { return call }
        if let call = makeResidentCall() { return call }
        let candidates = openLandmarks.filter { isOpened($0.kind.info.district) && $0.kind.info.category != .hub
            && $0.kind.info.category != .canal }
        guard candidates.count >= 2 else { return nil }
        var options: [(LetterGoal, Int, String)] = []
        let shuffled = candidates.shuffled()
        let a = shuffled[0]
        // A partner in the same district (subway lines don't cross districts).
        let b = shuffled.first { $0.id != a.id && $0.kind.info.district == a.kind.info.district } ?? shuffled[1]
        if b.kind.info.district == a.kind.info.district,
           !builtLines.contains(where: { $0.stops.contains(a.id) && $0.stops.contains(b.id) }) {
            options.append((.connect(a.id, b.id), 80, connectLine(a.kind.info.name, b.kind.info.name)))
        }
        if let lonely = candidates.first(where: { subwayLinesServing($0.id).isEmpty }) {
            options.append((.serve(lonely.id), 60, serveLine(lonely.kind.info.name)))
        }
        if let busy = candidates.first(where: { subwayLinesServing($0.id).count == 1 && waitingCount(at: $0.id) >= 4 }) {
            options.append((.lines(busy.id, 2), 90, twoLinesLine(busy.kind.info.name)))
        }
        if adsUnlocked {
            let count = Int.random(in: 10...16)
            options.append((.carryTo(a.id, count), 50 + count * 3, carryLine(a.kind.info.name, count)))
        }
        guard let pick = options.randomElement() else { return nil }
        defer { nextLetterID += 1 }
        return Letter(id: nextLetterID, sender: Residents.names.randomElement() ?? "A resident",
                      role: Residents.roles.randomElement() ?? "resident", body: pick.2, goal: pick.0,
                      receivedDay: day, dueDay: day + 2, reward: hasCard(.communityRadio) ? pick.1 * 3 / 2 : pick.1)
    }

    private func connectLine(_ a: String, _ b: String) -> String {
        ["Hello? Mayor? I work at the \(b) and live by the \(a). Could one line stop at both? My lunch hour would thank you.",
         "Mayor, it's about my sister. She's at the \(a), I'm at the \(b), and we haven't had tea in a month. One line between us?",
         "Is this the mayor? Lovely. The \(a) and the \(b) belong together, like bread and butter. Could you put them on one line?"].randomElement() ?? ""
    }

    private func serveLine(_ name: String) -> String {
        ["Mayor! Nobody can reach the \(name) by train. It seems a shame, with the whole town coming back to life.",
         "Hello, Mayor. I've walked to the \(name) every day for thirty years. My knees would like a train."].randomElement() ?? ""
    }

    private func twoLinesLine(_ name: String) -> String {
        ["Mayor, the \(name) platform is packed every morning. A second line would make all the difference.",
         "It's busy down at the \(name), Mayor. Ever so busy. Another line, perhaps?"].randomElement() ?? ""
    }

    private func carryLine(_ name: String, _ count: Int) -> String {
        ["Mayor, we're holding a fundraiser at the \(name). Could you get \(count) people there in the next couple of days?",
         "Hello! The \(name) is having its anniversary. We've baked for \(count) guests and would hate to eat it all ourselves."].randomElement() ?? ""
    }
}

/// A phoned-in notice: who's calling and what they say.
struct NewsCall: Identifiable, Equatable {
    let id = UUID()
    let sender: String
    let role: String
    let body: String
    let pitch: Double
    /// News about a group trip: no longer worth a call once the trip is over.
    var tripID: Int?
}
