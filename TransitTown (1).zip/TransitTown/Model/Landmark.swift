import Foundation

/// A landmark on the map. Heritage sites start closed (derelict) until restored.
struct Landmark: Identifiable, Codable {
    let id: Int
    let kind: LandmarkKind
    var cell: GridPoint
    var isOpen: Bool
    /// Seconds of building left while it's going up; nil once open (or for heritage sites).
    var constructionRemaining: Double?
    var constructionTotal: Double = 1
    /// When building finishes, on the real clock: it carries on while the app is closed.
    var constructionEnds: Date?
    /// Who opened the shop, revealed on opening day.
    var shopkeeper: String?
    /// A name the mayor gave it (transit hubs).
    var customName: String?
    /// For a tunnel opening: the opening at the other end, and whether the tunnel is finished.
    var portalPair: Int?
    var tunnelComplete: Bool?

    var name: String { customName ?? kind.info.name }

    /// The drawing to use: transit hubs borrow one of the four station looks.
    var artName: String {
        guard kind == .transitHub else { return kind.artName }
        let looks = ["stamp-central", "stamp-harborStation", "stamp-hilltopStation", "stamp-lanternStation"]
        return looks[abs(id) % looks.count]
    }

    var isUnderConstruction: Bool { constructionRemaining != nil }
    var constructionProgress: Double {
        guard let remaining = constructionRemaining else { return 1 }
        return max(0, min(1, 1 - remaining / max(constructionTotal, 1)))
    }
}
