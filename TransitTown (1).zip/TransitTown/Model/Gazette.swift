import Foundation

struct GazetteFigure: Identifiable {
    let id: Int
    let label: String
    let value: String
}

/// One edition of the town paper, written at the end of each day.
struct GazetteEdition {
    let masthead: String
    let dateline: String
    let kicker: String
    let headline: String
    let subhead: String
    let story: String
    let figures: [GazetteFigure]
    let talkQuote: String
    let talkAttribution: String
    let briefs: [String]
    let forecastWeather: Weather?
    let forecastTitle: String
    let forecastText: String
    /// What tomorrow's conditions will actually do, in plain words.
    let forecastEffects: [String]
    let ratingStart: Double
    let ratingEnd: Double
    let isFinalDay: Bool
    /// Quotes and briefs printed in this edition, so later editions don't repeat them.
    let usedKeys: [String]
}

/// Facts the writer needs. Gathered by GameState so the writer stays pure.
struct GazetteFacts {
    let townName: String
    let district: District
    let term: Int
    let day: Int
    let termLength: Int
    let isEndless: Bool
    let report: DayReport
    let stationNames: [Int: String]
    let openedLines: [(name: String, from: String, to: String)]
    let lineNames: [String]
    let landmarkNames: [String]
    let heritageNames: [String]
    let featuredTomorrow: LandmarkCategory?
    let weatherTomorrow: Weather
    let eventsTomorrow: [String]
    let usedKeys: Set<String>
}

/// Writes the Gazette from the day's events. The lead story is the most notable thing that
/// happened; quotes and briefs are drawn from large pools and never repeat within a game.
enum GazetteWriter {

    static func edition(from facts: GazetteFacts) -> GazetteEdition {
        let report = facts.report
        let seed = facts.day * 7 + facts.term * 13
        let busiest = report.traffic.max { $0.value < $1.value }
        let busiestName = busiest.flatMap { facts.stationNames[$0.key] }
        let worstWait = report.gaveUpAt.max { $0.value < $1.value }
        let worstWaitName = worstWait.flatMap { facts.stationNames[$0.key] }
        let words = Words(facts: facts, busiest: busiestName, worstWait: worstWaitName)
        var used: [String] = []

        // MARK: Lead story
        var kicker = "TRANSIT"
        var headline = ""
        var subhead = ""
        var leadMentionsBuilt = false

        if let restored = report.restored.first {
            let name = restored.info.name
            kicker = "HERITAGE"
            headline = pick(["The \(name) Reopens", "Lights Return to the \(name)", "Ribbon Cut at the \(name)"], seed)
            subhead = heritageLine(restored)
        } else if report.lightRailOpened {
            kicker = "LIGHT RAIL"
            headline = pick(["Light Rail Reaches \(facts.district.name)", "\(facts.district.name) Joins the Line",
                             "One City, Two Districts, One Ticket"], seed)
            subhead = "The first light rail car crossed the canal to cheers from both banks."
        } else if facts.day == 1 && facts.term == 1 {
            if let line = facts.openedLines.first {
                headline = "Trains Run Again in \(facts.townName)"
                subhead = "After years of silence, the \(line.name) carries its first passengers from \(line.from) to \(line.to)."
            } else {
                kicker = "TOWN HALL"
                headline = "New Mayor Takes the Keys"
                subhead = "Central Station's doors are open. The platforms are still waiting for a train."
            }
        } else if facts.day == 1 {
            kicker = "NEW DISTRICT"
            headline = pick(["A Town Wakes Up", "A New Chapter for the Town"], seed)
            subhead = "\(facts.district.rhythm). The mayor's office says there's plenty more to come."
        } else if let line = facts.openedLines.first {
            headline = pick(["\(line.name) Opens From \(line.from) to \(line.to)",
                             "All Aboard the \(line.name)",
                             "\(line.name) Links \(line.from) and \(line.to)"], seed)
            subhead = pick(["Riders were lining up before the paint had dried.",
                            "Commuters say the trip now takes minutes, not an afternoon.",
                            "The first train left on time and came back full."], seed + 1)
        } else if let built = report.landmarksBuilt.first {
            kicker = "AROUND TOWN"
            headline = pick(["The \(built.info.name) Opens Its Doors", "Doors Open at the \(built.info.name)"], seed)
            subhead = built.info.blurb
            leadMentionsBuilt = true
        } else if let pair = report.pairsCompleted.first {
            kicker = "GOOD NEIGHBORS"
            headline = "The \(pair) Is Running"
            subhead = "Two old friends now share a line, and the trips between them are adding up."
        } else if report.isRecord {
            kicker = "RIDERSHIP"
            headline = "Record Day: \(report.riders) \(Format.noun(report.riders, "Rider")) Take the Train"
            subhead = "The busiest day on the lines since the mayor took office."
        } else if report.transfers >= 10 {
            kicker = "TRANSIT"
            headline = pick(["Change Here for Everywhere", "The Art of the Transfer"], seed)
            subhead = "\(Format.count(report.transfers, "rider")) changed trains today, most without breaking stride."
        } else if report.ratingEnd - report.ratingStart >= 0.35 {
            kicker = "TOWN HALL"
            headline = pick(["Town Spirits Rise", "Approval Climbs at Town Hall"], seed)
            subhead = "The town rating rose to \(Format.stars(report.ratingEnd)), and people are saying hello on the platform."
        } else if report.gaveUp >= 5, let station = worstWaitName {
            kicker = "LETTERS"
            headline = pick(["Long Waits at \(station)", "Patience Runs Thin at \(station)"], seed)
            subhead = "\(Format.count(report.gaveUp, "rider")) gave up and walked. Residents ask the mayor for more trains."
        } else {
            headline = pick(["A Steady Day on the Lines", "Trains Keep Rolling", "Another Day, On Time",
                             "Nothing to Report, and Proud of It"], seed)
            subhead = report.riders > 0
                ? "\(Format.count(report.riders, "rider")) and not much fuss. Just the way a timetable should be."
                : "The tracks are ready whenever the mayor is."
        }

        // MARK: Story
        var sentences: [String] = []
        if report.riders == 0 {
            sentences.append("Nobody rode today. The trains are waiting for a line to run on.")
        } else {
            sentences.append("\(Format.count(report.riders, "rider")) took the train today, paying $\(report.fares) in fares.")
        }
        if report.weather != .fair {
            sentences.append(weatherRecap(report.weather))
        }
        if let name = busiestName, let count = busiest?.value, count > 0 {
            sentences.append("\(name) was the busiest stop, with \(count) \(count == 1 ? "arrival or departure" : "arrivals and departures").")
        }
        if report.crossDistrictRiders > 0 {
            sentences.append(report.crossDistrictRiders == 1
                ? "One of them rode all the way across town."
                : "\(report.crossDistrictRiders) of them rode all the way across town.")
        }
        let start = report.revivedStart, end = report.revivedEnd
        if end > start + 0.02 {
            sentences.append("Color is returning to town: \(Format.percent(end)) of it is now revived, up from \(Format.percent(start)).")
        } else if end < start - 0.02 {
            sentences.append("Some streets slipped back toward grey. \(Format.percent(end)) of the town is revived.")
        }
        if report.gaveUp > 0 {
            if let name = worstWaitName {
                sentences.append(report.gaveUp == 1
                    ? "One rider gave up waiting, at \(name)."
                    : "\(report.gaveUp) riders gave up waiting, most of them at \(name).")
            } else {
                sentences.append("\(Format.count(report.gaveUp, "rider")) gave up waiting.")
            }
        }
        if !report.events.isEmpty {
            sentences.append(report.events.count == 1
                ? "The day's disruption kept the network on its toes."
                : "Two disruptions kept the network on its toes.")
        }
        if report.tripsCompleted > 0 {
            sentences.append(report.tripsCompleted == 1
                ? "A group traveling together made it all the way, to cheers on the platform."
                : "\(report.tripsCompleted) groups traveling together made it all the way.")
        }
        if report.tripsFailed > 0 {
            sentences.append("Not every group arrived in one piece. Some are still talking about it.")
        }
        if report.lettersAnswered > 0 {
            sentences.append(report.lettersAnswered == 1
                ? "The mayor's office answered a letter from a resident, to their evident delight."
                : "The mayor's office answered \(report.lettersAnswered) letters from residents.")
        }
        if report.lettersMissed > 0 {
            sentences.append(report.lettersMissed == 1
                ? "One letter went unanswered. Its writer is said to be composing another."
                : "\(report.lettersMissed) letters went unanswered.")
        }
        let otherBuilt = leadMentionsBuilt ? Array(report.landmarksBuilt.dropFirst()) : report.landmarksBuilt
        if !otherBuilt.isEmpty {
            sentences.append("Also new in town: \(list(otherBuilt.map { "the " + $0.info.name })).")
        }

        // MARK: Figures
        var figures: [GazetteFigure] = [
            GazetteFigure(id: 0, label: "Riders", value: "\(report.riders)"),
            GazetteFigure(id: 1, label: "Fares", value: "$\(report.fares)"),
            GazetteFigure(id: 2, label: "Rating", value: "\(Format.stars(report.ratingStart)) → \(Format.stars(report.ratingEnd))"),
            GazetteFigure(id: 3, label: "Revived", value: Format.percent(report.revivedEnd)),
        ]
        if report.transfers > 0 {
            figures.append(GazetteFigure(id: 4, label: "Changes", value: "\(report.transfers)"))
        }
        if let name = busiestName {
            figures.append(GazetteFigure(id: 5, label: "Busiest", value: name))
        }

        // MARK: Town talk
        let talk = pickQuote(context: quoteContext(report: report, facts: facts), district: facts.district,
                             words: words, used: facts.usedKeys, seed: seed)
        used.append(talk.key)

        // MARK: In brief
        var briefs: [String] = []
        let pool = briefPool(words: words) + districtBriefs(facts.district, words)
        var available = pool.filter { !facts.usedKeys.contains($0.key) }
        if available.count < 2 { available = pool }
        var index = abs(seed * 5) % max(available.count, 1)
        while briefs.count < 2 && !available.isEmpty {
            let item = available.remove(at: index % available.count)
            briefs.append(item.text)
            used.append(item.key)
            index += 3
        }

        // MARK: Forecast
        let isFinal = !facts.isEndless && facts.day >= facts.termLength   // never true now: there are no terms
        let forecastWeather: Weather?
        let forecastTitle: String
        let forecastText: String
        var forecastEffects: [String] = []
        if isFinal {
            forecastWeather = nil
            forecastTitle = "TERM REVIEW TOMORROW"
            forecastText = "The council gathers to mark a milestone for the town."
        } else {
            let weather = facts.weatherTomorrow
            forecastWeather = weather
            forecastTitle = "TOMORROW: \(weather.name.uppercased())"
            forecastText = weather.gazetteLine
            forecastEffects = weather.effects
            if let category = facts.featuredTomorrow {
                forecastEffects.append(featuredEffect(category))
            }
            forecastEffects.append(contentsOf: facts.eventsTomorrow)
            if forecastEffects.isEmpty {
                forecastEffects.append("No surprises expected")
            }
        }

        let termLabel = "DAY \(facts.day)"
        return GazetteEdition(
            masthead: "The \(facts.townName) Gazette",
            dateline: "\(termLabel), WEEKLY EDITION, ONE FARE",
            kicker: kicker,
            headline: headline,
            subhead: subhead,
            story: sentences.joined(separator: " "),
            figures: figures,
            talkQuote: talk.quote,
            talkAttribution: talk.who,
            briefs: briefs,
            forecastWeather: forecastWeather,
            forecastTitle: forecastTitle,
            forecastText: forecastText,
            forecastEffects: forecastEffects,
            ratingStart: report.ratingStart,
            ratingEnd: report.ratingEnd,
            isFinalDay: isFinal,
            usedKeys: used)
    }

    // MARK: Names to drop into quotes and briefs

    private struct Words {
        let town: String
        let district: String
        let busiest: String
        let worstWait: String
        let line: String
        let landmark: String
        let otherLandmark: String
        let heritage: String

        init(facts: GazetteFacts, busiest: String?, worstWait: String?) {
            let busiestName = busiest ?? "Central Station"
            town = facts.townName
            district = facts.district.name
            self.busiest = busiestName
            self.worstWait = worstWait ?? busiestName
            let lines = facts.lineNames.isEmpty ? ["Red Line"] : facts.lineNames
            line = lines[facts.day % lines.count]
            let places = facts.landmarkNames.isEmpty ? ["Corner Bakery"] : facts.landmarkNames
            landmark = places[(facts.day * 3) % places.count]
            otherLandmark = places[(facts.day * 3 + 1) % places.count]
            heritage = facts.heritageNames.first ?? "old clock tower"
        }
    }

    // MARK: Town talk

    private enum QuoteContext {
        case longWaits, heritage, newLine, lightRail, transfers, rain, sunny, fog, windy, pair
        case repairs, closure, festival, general
    }

    private static func quoteContext(report: DayReport, facts: GazetteFacts) -> QuoteContext {
        if report.gaveUp >= 4 { return .longWaits }
        if report.events.contains(where: { $0.contains("Regatta") || $0.contains("Fair") || $0.contains("Festival") || $0.contains("Garden Show") }) { return .festival }
        if !report.events.isEmpty { return .closure }

        if !report.restored.isEmpty { return .heritage }
        if report.lightRailOpened { return .lightRail }
        if !facts.openedLines.isEmpty { return .newLine }
        if !report.pairsCompleted.isEmpty { return .pair }
        if report.transfers >= 8 { return .transfers }
        switch report.weather {
        case .rain: return .rain
        case .sunny: return .sunny
        case .fog: return .fog
        case .windy: return .windy
        case .fair: return .general
        }
    }

    private static func quotes(_ context: QuoteContext, _ w: Words) -> [(key: String, quote: String, who: String)] {
        switch context {
        case .longWaits:
            return [
                ("wait-1", "I waited so long at \(w.worstWait) I finished the crossword. Twice.", "a commuter"),
                ("wait-2", "I've made friends on that platform. I'd rather have made my appointment.", "a dentist's patient"),
                ("wait-3", "The pigeons at \(w.worstWait) have started to recognize me.", "a regular"),
                ("wait-4", "Lovely station. I've seen a great deal of it.", "a visitor"),
            ]
        case .heritage:
            return [
                ("heritage-1", "My grandmother had her first date at the \(w.heritage). She cried, then asked for a souvenir.", "a resident"),
                ("heritage-2", "I used to sneak in there as a boy. Now I can walk in the front door.", "a retired plumber"),
                ("heritage-3", "It smells exactly the same. I don't know how, but it does.", "a former usher"),
            ]
        case .newLine:
            return [
                ("line-1", "I rode the \(w.line) end to end just to watch the town go by.", "a schoolteacher"),
                ("line-2", "I've walked to work every day since the trains stopped. Today I sat down.", "a postwoman"),
                ("line-3", "The new line goes right past my window. I've started waving.", "a pensioner"),
            ]
        case .lightRail:
            return [
                ("rail-1", "I haven't been to \(w.district) since I was nine. It's lovely.", "a resident"),
                ("rail-2", "You can see the whole town from the train. Worth the fare alone.", "a painter"),
                ("rail-3", "My sister lives across town. Now I've no excuse not to visit.", "a guilty brother"),
            ]
        case .transfers:
            return [
                ("transfer-1", "Two trains, one ticket, and I still beat my husband home.", "a commuter"),
                ("transfer-2", "Change at \(w.busiest)? I could do it with my eyes closed.", "a regular"),
                ("transfer-3", "I've timed it. Ninety seconds between trains. Ninety!", "an enthusiast"),
            ]
        case .rain:
            return [
                ("rain-1", "Nobody walks in this. Nobody. Thank goodness for the trains.", "a shopkeeper"),
                ("rain-2", "My umbrella turned inside out twice before I reached the platform.", "a commuter"),
                ("rain-3", "Rain's good for business. Everyone wants soup.", "the \(w.landmark)"),
            ]
        case .sunny:
            return [
                ("sun-1", "Too nice to work. I took the train to the park instead.", "an honest accountant"),
                ("sun-2", "Half the town was at the \(w.landmark). I don't blame them.", "a gardener"),
                ("sun-3", "I've had three ice creams. It's not even two o'clock.", "a nine-year-old"),
            ]
        case .fog:
            return [
                ("fog-1", "Couldn't see the end of the platform, but I could hear the train coming.", "a commuter"),
                ("fog-2", "The driver took it slow. I didn't mind one bit.", "a nervous passenger"),
            ]
        case .windy:
            return [
                ("wind-1", "My umbrella caught an earlier train than I did.", "a commuter"),
                ("wind-2", "The trains don't mind the wind. My hat does.", "a gentleman"),
                ("wind-3", "Best kite day in years. I'm not going in.", "a retired engineer"),
            ]
        case .pair:
            return [
                ("pair-1", "Coffee at one end, rolls at the other. It's like they planned it.", "a regular"),
                ("pair-2", "My whole Saturday now fits on one line.", "a planner"),
            ]
        case .repairs:
            return [
                ("fix-1", "The crew had it done before my tea went cold. I timed it.", "a commuter"),
                ("fix-2", "I didn't mind the detour. I saw a street I'd never been down.", "a retired teacher"),
                ("fix-3", "You could hear the rattle for a week. Now you can't. That's the whole story.", "a light sleeper"),
                ("fix-4", "They waved at me from the tracks. I waved back. Very civic.", "a passerby"),
            ]
        case .closure:
            return [
                ("closed-1", "The station was shut, so I walked. I found a bakery I didn't know about.", "a commuter"),
                ("closed-2", "Worth the detour. There was a man with a tuba.", "a parade-goer"),
                ("closed-3", "I bought three jars of jam I don't need. No regrets.", "a market shopper"),
                ("closed-4", "Roadworks again. At least they're cheerful about it.", "a dog walker"),
            ]
        case .festival:
            return [
                ("fest-1", "Half the town was on the trains. I've never seen them so full.", "a conductor"),
                ("fest-2", "I came for an hour. I've been here since lunch.", "a visitor"),
                ("fest-3", "You could hear the crowd from across town.", "a fisherman"),
            ]
        case .general:
            return [
                ("gen-1", "The bakery line used to go round the block. Now it goes round the platform.", "a regular"),
                ("gen-2", "I've started waving at the driver. He waves back.", "a retired postman"),
                ("gen-3", "Somebody painted the bench at \(w.busiest). Nobody knows who.", "a neighbor"),
                ("gen-4", "My dog has learned the timetable. He's at the door by five past eight.", "a dog owner"),
                ("gen-5", "You can hear the trains from the hill now. It sounds like the town breathing.", "a gardener"),
                ("gen-6", "I took the long way home on purpose.", "a teenager"),
                ("gen-7", "The clock on Main Street is still wrong, but at least the trains aren't.", "a shopkeeper"),
                ("gen-8", "I met my wife on the \(w.line). Well, I'm working on it.", "a hopeful man"),
                ("gen-9", "The \(w.landmark) has never been busier. I've had to hire my nephew.", "a business owner"),
                ("gen-10", "\(w.town) feels like a town again. That's all I wanted.", "a lifelong resident"),
                ("gen-11", "I counted the stops on the way home. I count them every day. It's calming.", "a librarian"),
                ("gen-12", "We used to say nothing happens here. Now something happens every eight minutes.", "a barber"),
                ("gen-13", "The conductor knows my name. I don't know how I feel about that.", "a private person"),
                ("gen-14", "I bring a sandwich for the ride. It's a short ride. It's a good sandwich.", "a commuter"),
                ("gen-15", "From the \(w.line) you can see into every garden in \(w.district). Mine's the one with the gnome.", "a gardener"),
                ("gen-16", "I used to drive. I don't anymore. I don't miss it.", "a former driver"),
                ("gen-17", "My grandson says the trains are the best thing about visiting. Not me. The trains.", "a grandmother"),
                ("gen-18", "I read a whole chapter between stops. Then I missed mine.", "a reader"),
                ("gen-19", "The platform at \(w.busiest) has the best people-watching in town.", "an expert"),
                ("gen-20", "I knew the town was coming back when they fixed the station clock.", "a watchmaker"),
                ("gen-21", "We've started meeting at the \(w.landmark) on Fridays. All of us. It just happened.", "a book club"),
                ("gen-22", "There's always someone on the train who knows someone you know.", "a newcomer"),
                ("gen-23", "I give it a nod when it goes by. Seems polite.", "a gardener"),
                ("gen-24", "Busy morning. Good busy.", "a shopkeeper"),
                ("gen-25", "I timed the walk to the station. Four minutes. The walk to the old bus stop took twenty.", "a precise man"),
                ("gen-26", "My neighbor and I took the same train for a week before we realized we were neighbors.", "a newcomer"),
                ("gen-27", "The trains are punctual. The passengers, less so.", "a conductor"),
                ("gen-28", "I don't need to go anywhere. I just like riding to the end and back.", "a retiree"),
                ("gen-29", "There's a man who whistles on the \(w.line) every morning. Same tune. I've grown fond of it.", "a commuter"),
                ("gen-30", "We moved here for the quiet. We're staying for the trains.", "a couple"),
                ("gen-31", "I wrote to the mayor. I'll admit I didn't expect anything to happen. Something happened.", "a letter writer"),
                ("gen-32", "My dog knows which train we take. He waits by the right door.", "a dog owner"),
                ("gen-33", "The \(w.landmark) has a queue now. A queue! In this town!", "an astonished baker"),
                ("gen-34", "The window seats are the best seats. Everyone knows it. Nobody says it.", "a regular"),
                ("gen-35", "I found a glove on the \(w.line). I've left it on the same seat every day. Someone will come for it.", "a patient woman"),
                ("gen-36", "First time I've been late for work in a year, and it was because I was chatting on the platform.", "a teacher"),
                ("gen-37", "The new paint at \(w.busiest) is a lovely shade of green. I asked. It's called Station Green.", "a decorator"),
                ("gen-38", "I can get from my front door to my sister's in eleven minutes. She's not thrilled.", "a sister"),
                ("gen-39", "When the trains stopped, the town went quiet. Now listen to it.", "an old-timer"),
                ("gen-40", "Somebody left flowers at \(w.busiest). There's no note. There doesn't need to be.", "a cleaner"),
            ]
        }
    }

    /// Voices from the district this edition covers.
    private static func districtQuotes(_ district: District, _ w: Words) -> [(key: String, quote: String, who: String)] {
        switch district {
        case .oldTown:
            return [
                ("old-1", "The town's got its color back. I keep stopping to look at it.", "a postman"),
                ("old-2", "The bakery opens at six. The first train's at five past. I'm not complaining.", "an early riser"),
                ("old-3", "My shop's been here forty years. This is the first time I've needed a second till.", "a hardware seller"),
            ]
        case .harborside:
            return [
                ("harbor-1", "The gulls have noticed the trains. They wait at the station now.", "a fishmonger"),
                ("harbor-2", "Fish at five, chowder at noon, home by train. Perfect day.", "a deckhand"),
                ("harbor-3", "You can smell the sea from the platform. I'd forgotten.", "a returning resident"),
                ("harbor-4", "We had three visitors from across town today. Three! They bought everything.", "a stallholder"),
            ]
        case .hillQuarter:
            return [
                ("hill-1", "It's a long way up. The train makes it feel shorter.", "a gardener"),
                ("hill-2", "I painted the view from the tea room. The view was better.", "an honest artist"),
                ("hill-3", "My orchids have never had so many visitors.", "a greenhouse keeper"),
            ]
        case .lanternRow:
            return [
                ("lantern-1", "Nobody on the night trains goes to bed before midnight. It's practically a rule.", "a noodle cook"),
                ("lantern-2", "Dinner, a film, and the last train home. That's a whole evening.", "a couple"),
                ("lantern-3", "The lanterns go on one by one at dusk. I never get tired of it.", "a lamplighter"),
            ]
        }
    }

    private static func pickQuote(context: QuoteContext, district: District, words: Words, used: Set<String>, seed: Int)
        -> (key: String, quote: String, who: String) {
        if context != .general {
            let contextual = quotes(context, words).filter { !used.contains($0.key) }
            if let choice = contextual.first { return choice }
        }
        // Mostly the town at large, sometimes a voice from this district.
        let local = districtQuotes(district, words).filter { !used.contains($0.key) }
        let general = quotes(.general, words).filter { !used.contains($0.key) }
        if !local.isEmpty && (seed % 3 == 0 || general.isEmpty) { return local[abs(seed) % local.count] }
        if !general.isEmpty { return general[abs(seed) % general.count] }
        let all = quotes(.general, words)
        return all[abs(seed) % all.count]
    }

    // MARK: In brief

    private static func briefPool(words w: Words) -> [(key: String, text: String)] {
        [
            ("brief-1", "Lost property at \(w.busiest) now includes four umbrellas, a trumpet, and a very patient tortoise."),
            ("brief-2", "The \(w.line) driver has started announcing stops in rhyme. Complaints received: none."),
            ("brief-3", "Children have named the bench outside the \(w.landmark) \"Doris.\" Doris could not be reached for comment."),
            ("brief-4", "The council reminds riders that pigeons are not covered by the timetable."),
            ("brief-5", "A wedding party of thirty took the \(w.line) to the \(w.landmark). The bride insisted."),
            ("brief-6", "The station cat has been seen at \(w.busiest) again. She does not have a ticket."),
            ("brief-7", "The \(w.town) Knitting Circle has made cozies for every handrail at \(w.busiest)."),
            ("brief-8", "Someone has been leaving tulips outside the \(w.heritage). Nobody is admitting to it."),
            ("brief-9", "Schoolchildren voted the \(w.line) \"Best Line.\" The other lines were unavailable for comment."),
            ("brief-10", "A tourist asked for directions to \(w.town). He was standing in it."),
            ("brief-11", "Ticket inspector Mr. Hollis celebrates thirty years on the job. He has never once been late."),
            ("brief-12", "Fresh paint on the platform at \(w.busiest). Please don't lean on it until Thursday."),
            ("brief-13", "A dog named Biscuit has been riding the \(w.line) alone. His owner says he \"has errands.\""),
            ("brief-14", "The \(w.landmark) and the \(w.otherLandmark) are holding a friendly rivalry over who gets more visitors."),
            ("brief-15", "Night riders describe the last trains as \"very peaceful, like a library on wheels.\""),
            ("brief-16", "The clock at Central is now set two minutes fast, \"to keep everyone on their toes.\""),
            ("brief-17", "A choir rehearsed on the \(w.line) between stops. Applause was polite but sincere."),
            ("brief-18", "Window boxes have appeared along \(w.district)'s main street. The council denies everything."),
            ("brief-19", "A lost glove has been hanging on the railing at \(w.busiest) for a week. It's become a landmark."),
            ("brief-20", "The \(w.line) now has a regular who brings a thermos for the driver. Tea, two sugars."),
            ("brief-21", "Residents are reminded that the station benches are for sitting, not for pigeons' meetings."),
            ("brief-22", "A child asked the conductor whether the train sleeps at night. He said yes, briefly."),
            ("brief-23", "The \(w.landmark) has started a suggestions box. The first suggestion was \"more of this.\""),
            ("brief-24", "Somebody has been polishing the brass on the old ticket windows. It looks wonderful."),
            ("brief-25", "The Gazette regrets yesterday's crossword. Seven across was not a real word."),
            ("brief-26", "A wandering goose was escorted off the platform at \(w.busiest). It was not happy about it."),
            ("brief-27", "The \(w.otherLandmark) reports a run on umbrellas, scarves, and patience."),
            ("brief-28", "A marching band practiced on the \(w.line). Several passengers joined in."),
            ("brief-29", "The town's oldest resident, 101, rode the train for the first time in thirty years. Her review: \"Smooth.\""),
            ("brief-30", "A new mural near the \(w.landmark) shows the whole network. It's already out of date."),
            ("brief-31", "The council has approved a new bench at \(w.busiest). It has already been sat on."),
            ("brief-32", "A pair of ducks has been seen riding the \(w.line) between two stops. They did not pay."),
            ("brief-33", "The lost property office reports 41 umbrellas, 9 hats, and a trombone. The trombone's owner is asked to call."),
            ("brief-34", "The \(w.landmark) will stay open an hour later on Fridays, by popular demand."),
            ("brief-35", "Schoolchildren have voted to name the newest train. The council has asked them to vote again."),
            ("brief-36", "A knitting circle now meets in the last carriage of the \(w.line) every Tuesday. All welcome."),
            ("brief-37", "The station clock at \(w.busiest) was found to be two minutes fast. Nobody had complained."),
            ("brief-38", "The mayor was seen giving directions to a tourist. The tourist reached their stop."),
            ("brief-39", "A sign reading \"Please Do Not Feed the Conductor\" has appeared at \(w.busiest). The conductor denies involvement."),
            ("brief-40", "A cake competition at the \(w.otherLandmark) ended in a tie. Both cakes were eaten anyway."),
            ("brief-41", "Night riders report that the \(w.line) is \"very peaceful after nine.\" The Gazette agrees."),
            ("brief-42", "A small boy has been riding with a notebook, writing down every train. He is now considered staff."),
            ("brief-43", "Shopkeepers on \(w.district)'s main street have started a window display competition. It's getting competitive."),
            ("brief-44", "The town's bell-ringers would like it known that they are not responsible for the bell at the level crossing."),
        ]
    }

    private static func districtBriefs(_ district: District, _ w: Words) -> [(key: String, text: String)] {
        switch district {
        case .oldTown:
            return [
                ("old-brief-1", "The town's chimney sweep reports business is up. So are the chimneys."),
                ("old-brief-2", "A brass plaque marking the first train back has been installed at Central Station."),
            ]
        case .harborside:
            return [
                ("harbor-brief-1", "The harbormaster has asked riders not to feed the gulls from the train windows."),
                ("harbor-brief-2", "A fishing boat named after the mayor launched this week. It floated."),
                ("harbor-brief-3", "Tide tables are now posted at the station, next to the timetable."),
            ]
        case .hillQuarter:
            return [
                ("hill-brief-1", "The town flower show has added a new category: \"Best Window Box Seen From a Train.\""),
                ("hill-brief-2", "A runaway hat rolled from Hilltop Station to the bottom of the hill. It's been returned."),
            ]
        case .lanternRow:
            return [
                ("lantern-brief-1", "The late trains now carry a small library of books for night riders."),
                ("lantern-brief-2", "The cinema has added a matinee. Night owls are calling it \"breakfast.\""),
            ]
        }
    }

    // MARK: Helpers

    private static func pick(_ options: [String], _ seed: Int) -> String {
        options[abs(seed) % options.count]
    }

    private static func list(_ items: [String]) -> String {
        switch items.count {
        case 0: return ""
        case 1: return items[0]
        case 2: return "\(items[0]) and \(items[1])"
        default: return items.dropLast().joined(separator: ", ") + ", and " + (items.last ?? "")
        }
    }

    private static func heritageLine(_ kind: LandmarkKind) -> String {
        switch kind {
        case .clockTower: return "The hands moved for the first time since 4:17, and the whole square cheered."
        case .lighthouse: return "The lamp turned at dusk, and three fishing boats came home by its light."
        case .grandHotel: return "Two hundred rooms aired out, polished, and booked for the weekend."
        case .theatre: return "The curtain rose on a full house. Nobody could remember the last time."
        default: return "The doors are open again."
        }
    }

    private static func weatherRecap(_ weather: Weather) -> String {
        switch weather {
        case .rain: return "The rain kept the trains full and the platforms short-tempered."
        case .sunny: return "The sunshine sent half the town to the parks."
        case .fog: return "Drivers took it slow through the fog."
        case .windy: return "The wind had the trains crawling along."
        case .fair: return ""
        }
    }

    private static func featuredEffect(_ category: LandmarkCategory) -> String {
        switch category {
        case .food: return "Food stops draw 40% more riders"
        case .culture: return "Culture stops draw 40% more riders"
        case .nature: return "Parks and gardens draw 40% more riders"
        case .civic: return "Service stops draw 40% more riders"
        case .canal: return "Quays draw 40% more riders"
        case .spiritual: return "Spiritual stops draw 40% more riders"
        case .hub: return ""
        }
    }
}
