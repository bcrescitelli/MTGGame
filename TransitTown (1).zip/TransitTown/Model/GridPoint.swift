/// A cell on the map grid. Column 0 is the left edge, row 0 is the bottom edge.
struct GridPoint: Hashable, Codable {
    var col: Int
    var row: Int
}
