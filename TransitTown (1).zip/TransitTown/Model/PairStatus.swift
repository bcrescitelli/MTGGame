import Foundation

/// A landmark pair and how close the player is to its bonus.
struct PairStatus: Identifiable {
    let id: String
    let first: LandmarkKind
    let second: LandmarkKind
    let firstBuilt: Bool
    let secondBuilt: Bool
    let isConnected: Bool

    var name: String { id }

    var hint: String {
        if isConnected { return "Bonus active: +$1 a trip" }
        if !firstBuilt { return "Build the \(first.info.name)" }
        if !secondBuilt { return "Build the \(second.info.name)" }
        return "Put both on one line"
    }
}
