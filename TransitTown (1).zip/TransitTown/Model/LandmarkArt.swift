import SwiftUI
import UIKit

extension LandmarkKind {
    /// The artwork for this landmark in the asset catalog (Resources/Stamps.xcassets).
    var artName: String { "stamp-\(rawValue)" }

    /// The drawing, or nil if the asset is missing (callers fall back to the SF Symbol).
    var artImage: UIImage? { UIImage(named: artName) }

    /// A short name that fits around a map marker's ring.
    var markerName: String {
        switch self {
        case .central: return "CENTRAL"
        case .bakery: return "BAKERY"
        case .park: return "POCKET PARK"
        case .cafe: return "BLUEBELL CAFÉ"
        case .library: return "LIBRARY"
        case .school: return "SCHOOL"
        case .market: return "MARKET HALL"
        case .catCafe: return "WHISKER CAFÉ"
        case .flowerStall: return "FLOWERS"
        case .toyShop: return "TOY SHOP"
        case .clockTower: return "CLOCK TOWER"
        case .harborStation: return "HARBOR"
        case .fishMarket: return "FISH MARKET"
        case .boardwalk: return "BOARDWALK"
        case .chowderHouse: return "CHOWDER"
        case .aquarium: return "AQUARIUM"
        case .boatyard: return "BOATYARD"
        case .ferryPier: return "FERRY PIER"
        case .sailorsPub: return "SAILORS' PUB"
        case .iceCreamKiosk: return "ICE CREAM"
        case .lifeboatStation: return "LIFEBOATS"
        case .lighthouse: return "LIGHTHOUSE"
        case .hilltopStation: return "HILLTOP"
        case .greenhouse: return "GREENHOUSE"
        case .studios: return "STUDIOS"
        case .teaRoom: return "TEA ROOM"
        case .pool: return "LIDO"
        case .observatory: return "OBSERVATORY"
        case .vineyard: return "VINEYARD"
        case .hedgeMaze: return "HEDGE MAZE"
        case .monasteryGardens: return "MONASTERY"
        case .funicular: return "FUNICULAR"
        case .grandHotel: return "GRAND HOTEL"
        case .lanternStation: return "LANTERN ROW"
        case .nightMarket: return "NIGHT MARKET"
        case .cinema: return "CINEMA"
        case .bandstand: return "BANDSTAND"
        case .museum: return "MUSEUM"
        case .stadium: return "STADIUM"
        case .jazzClub: return "JAZZ CLUB"
        case .arcade: return "ARCADE"
        case .noodleBar: return "NOODLES"
        case .puppetTheatre: return "PUPPETS"
        case .theatre: return "THEATRE"
        case .northQuay: return "NORTH QUAY"
        case .westQuay: return "WEST QUAY"
        case .eastQuay: return "EAST QUAY"
        case .southQuay: return "SOUTH QUAY"
        case .transitHub: return "TRANSIT HUB"
        case .tunnelPortal: return "TUNNEL"
        case .tailor: return "TAILOR"
        case .church: return "CHURCH"
        case .hauntedHouse: return "HAUNTED HOUSE"
        case .hospital: return "HOSPITAL"
        case .cemetery: return "CEMETERY"
        case .bank: return "BANK"
        case .fortuneTeller: return "FORTUNES"
        }
    }

    /// The marker rim: the category's color, gold for heritage, ink for hubs.
    var rimColor: UIColor {
        if info.isHeritage { return UIColor(hex: 0xE0A21B) }
        switch info.category {
        case .hub: return Palette.ink
        case .food: return UIColor(hex: 0xE5794F)
        case .culture: return UIColor(hex: 0x8A78CF)
        case .nature: return UIColor(hex: 0x5FA14B)
        case .civic: return UIColor(hex: 0x4F9CBC)
        case .canal: return UIColor(hex: 0x3A968E)
        case .spiritual: return UIColor(hex: 0xC98A9B)
        }
    }

    /// The ink a landmark's rubber stamp is printed in: its category's color, deep enough
    /// to read on paper. Heritage sites print in old gold; hubs in plain ink.
    var inkColor: UIColor {
        if info.isHeritage { return UIColor(hex: 0xA8730F) }
        switch info.category {
        case .hub: return Palette.ink
        case .food: return UIColor(hex: 0xC9532E)
        case .culture: return UIColor(hex: 0x6650B0)
        case .nature: return UIColor(hex: 0x3F7F33)
        case .civic: return UIColor(hex: 0x2A7598)
        case .canal: return UIColor(hex: 0x23756E)
        case .spiritual: return UIColor(hex: 0x9E5F72)
        }
    }

    /// The pale tint behind the drawing, on markers and stamps.
    var tintColor: UIColor {
        if info.isHeritage { return UIColor(hex: 0xF4E6C0) }
        switch info.category {
        case .hub: return UIColor(hex: 0xE6DFCF)
        case .food: return UIColor(hex: 0xF6D9C6)
        case .culture: return UIColor(hex: 0xE1DBF2)
        case .nature: return UIColor(hex: 0xD8E8CC)
        case .civic: return UIColor(hex: 0xD3E7EE)
        case .canal: return UIColor(hex: 0xCFE8E4)
        case .spiritual: return UIColor(hex: 0xF1DCE2)
        }
    }
}
