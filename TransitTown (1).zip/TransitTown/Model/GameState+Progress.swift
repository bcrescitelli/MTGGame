import Foundation

extension GameState {

    // MARK: Rating

    /// 1 to 5 stars. Good service and a revived city both count; some landmarks add a little.
    var townRating: Double {
        let service = 0.55 * satisfaction
        let revival = 0.45 * min(1, averageVitality / 0.85)
        let perks = Double(openLandmarks.filter { $0.kind.info.perk == .rating }.count) * 0.1
        return min(5, 1 + 4 * (service + revival) + perks)
    }

    // MARK: Conditions

    func connectedStationCount(in district: District?) -> Int {
        let built = builtLines.filter { !$0.isLightRail }
        return openLandmarks.filter { landmark in
            (district == nil || landmark.kind.info.district == district) &&
                built.contains { $0.stops.contains(landmark.id) }
        }.count
    }

    /// The most food stops on any one line: the Whisker Café's clues.
    var mostFoodStopsOnOneLine: Int {
        builtLines.map { line in
            line.stops.filter { landmark(id: $0)?.kind.info.category == .food }.count
        }.max() ?? 0
    }

    var hasFoodLine: Bool { mostFoodStopsOnOneLine >= 3 }

    func progress(for condition: UnlockCondition, landmarkID: Int?, district: District? = nil) -> ConditionProgress {
        switch condition {
        case .start:
            return ConditionProgress(current: 1, target: 1, text: "Ready from day one")
        case .ridersServed(let n):
            return ConditionProgress(current: Double(stats.ridersServed), target: Double(n), text: "Carry \(Format.count(n, "rider")) so far")
        case .faresEarned(let n):
            return ConditionProgress(current: Double(stats.totalFares), target: Double(n), text: "Earn $\(n) in fares")
        case .rating(let r):
            return ConditionProgress(current: bestRating, target: r, text: "Reach a \(Format.stars(r)) town rating")
        case .stationsConnected(let n):
            let place = district.map { " in \($0.name)" } ?? ""
            return ConditionProgress(current: Double(connectedStationCount(in: district)), target: Double(n),
                                     text: "Connect \(Format.count(n, "station"))\(place)")
        case .linesBuilt(let n):
            return ConditionProgress(current: Double(builtLines.count), target: Double(n), text: "Run \(Format.count(n, "line")) at once")
        case .day(let n):
            return ConditionProgress(current: Double(day), target: Double(n), text: "Reach day \(n)")
        case .revived(let f):
            let target = district ?? currentDistrict
            return ConditionProgress(current: districtRevived[target] ?? 0, target: f,
                                     text: "Revive \(Format.percent(f)) of \(target.name)")
        case .heritageRestored(let n):
            return ConditionProgress(current: Double(stats.heritageRestored), target: Double(n),
                                     text: n == 1 ? "Restore a heritage site" : "Restore \(n) heritage sites")
        case .nightRiders(let n):
            return ConditionProgress(current: Double(stats.nightRiders), target: Double(n), text: "Carry \(Format.count(n, "rider")) at night")
        case .foodLine:
            return ConditionProgress(current: Double(min(3, mostFoodStopsOnOneLine)), target: 3,
                                     text: "One line with three food stops")
        case .servedBy(let n):
            let count = landmarkID.map { id in builtLines.filter { !$0.isLightRail && $0.stops.contains(id) }.count } ?? 0
            return ConditionProgress(current: Double(count), target: Double(n),
                                     text: n == 1 ? "Connect it with a line" : "Connect it with \(n) lines")
        }
    }

    func progress(for goal: TermGoal) -> ConditionProgress {
        switch goal {
        case .ratingAtEnd(let r):
            return ConditionProgress(current: townRating, target: r, text: "Reach \(Format.stars(r)) or better")
        case .riders(let n):
            return ConditionProgress(current: Double(stats.ridersServed), target: Double(n), text: "Carry \(Format.count(n, "rider")) so far")
        case .heritage(let district):
            let site = LandmarkKind.heritage(in: district).first
            let restored = landmarks.contains { $0.kind.info.isHeritage && $0.kind.info.district == district && $0.isOpen }
            return ConditionProgress(current: restored ? 1 : 0, target: 1,
                                     text: "Restore the \(site?.info.name ?? "heritage site")")
        case .revived(let district, let f):
            return ConditionProgress(current: districtRevived[district] ?? 0, target: f,
                                     text: "Revive \(Format.percent(f)) of the town")
        case .crossDistrictRiders(let n):
            return ConditionProgress(current: Double(stats.crossDistrictRiders), target: Double(n),
                                     text: "Carry \(Format.count(n, "rider")) between districts")
        case .landmarks(let district, let n):
            let built = landmarks.filter { $0.kind.info.district == district && !$0.kind.info.isHeritage
                && $0.kind.info.category != .hub && $0.kind.info.unlock != .start }.count
            return ConditionProgress(current: Double(built), target: Double(n), text: "Build \(Format.count(n, "landmark")) in town")
        }
    }

    var ribbonsEarned: Int {
        goals.filter { progress(for: $0).isMet }.count
    }

    // MARK: Pairs

    /// Every landmark pair in the open districts, and how close each is to its bonus.
    func pairStatuses() -> [PairStatus] {
        var seen: Set<String> = []
        var result: [PairStatus] = []
        for district in openedDistricts {
            for kind in LandmarkKind.landmarks(in: district) {
                guard let partner = kind.info.pair, let name = kind.info.pairName, !seen.contains(name) else { continue }
                seen.insert(name)
                let first = landmarks.first { $0.kind == kind }
                let second = landmarks.first { $0.kind == partner }
                let connected = first.flatMap { a in second.map { b in isPairTrip(from: a.id, to: b.id) } } ?? false
                result.append(PairStatus(id: name, first: kind, second: partner,
                                         firstBuilt: first != nil, secondBuilt: second != nil, isConnected: connected))
            }
        }
        return result
    }

    // MARK: Progress check

    /// Runs once a second: the best rating, line and blueprint unlocks, the tutorial,
    /// pair bonuses, and one-time tips.
    func checkProgress() {
        bestRating = max(bestRating, townRating)
        checkLetters()

        // The town earns the right to open more lines as it revives; opening one costs money
        // and Golden Tickets. Pip rings when a new one can be opened.
        let rights = lineRights
        let announcedRights = announcedLineSlots[.oldTown] ?? rights
        if rights > announcedRights, rights - 1 < Palette.lineCount {
            let index = rights - 1
            let cost = lineOpeningCost(index)
            announce("Pip at the station! The town's grown enough to run the \(Palette.lineNames[index]). Open it from the menu at the bottom, for $\(cost.money) and \(cost.tickets) Golden Tickets.",
                     urgent: true)
            changed()
        }
        announcedLineSlots[.oldTown] = rights

        for district in openedDistricts {
            for kind in LandmarkKind.landmarks(in: district) where !unlocked.contains(kind) {
                if progress(for: kind.info.unlock, landmarkID: nil, district: district).isMet {
                    unlocked.insert(kind)
                    unseenBlueprints.insert(kind)
                    if tutorial == .earnBlueprint {
                        tutorial = .openAlbum
                    } else {
                        _ = kind   // every shop stays a surprise: no announcement
                    }
                }
            }
        }

        if tutorial == .connectLandmark, let id = tutorialLandmarkID,
           builtLines.contains(where: { $0.stops.contains(id) }) {
            tutorial = .moveLandmark
            changed()
        }
        if tutorial == .connectDistricts, let newHub = hub(of: currentDistrict),
           lightRail?.stops.contains(newHub.id) == true {
            tutorial = nil
            showTip("light-rail", symbol: "tram.fill", title: "The districts are connected",
                    text: "Some riders now travel between districts. They're more patient and pay over twice the fare.")
        }

        for site in landmarks where site.kind.info.isHeritage && !site.isOpen && canRestore(site.id) {
            let siteID = site.id
            showTip("restore-\(site.kind.rawValue)", symbol: "hammer.fill",
                    title: "Ready to restore",
                    text: "The \(site.kind.info.name) can be restored. Tap it on the map.",
                    stillTrue: { [weak self] in self?.landmark(id: siteID)?.isOpen == false })
        }

        for pair in pairStatuses() where pair.isConnected && !completedPairs.contains(pair.id) {
            completedPairs.insert(pair.id)
            report.pairsCompleted.append(pair.id)
            if !tipsShown.contains("pairs") {
                tipsShown.insert("pairs")
                showTip("pair-\(pair.name)", symbol: "heart.fill", title: pair.name, text: "Pip again. Riders love the \(pair.name): two places that belong together, on one line. Pairs like that get more trips between them and a dollar extra on every fare. You can see every pair from the day button, top left.")
            }
        }
    }

    // MARK: Tutorial

    func startTutorialIfNeeded() {
        if termNumber == 1 {
            guard !UserDefaults.standard.bool(forKey: "tutorial.done") else { return }
            tutorial = .drawLine
            dockOpenRequest = true
        } else if let newHub = hub(of: currentDistrict), lightRail?.stops.contains(newHub.id) != true {
            tutorial = nil   // neighborhoods are joined by your own lines and tunnels now
        }
    }

    func finishTutorial(skipped: Bool) {
        let wasFirstMorning = tutorial?.isFirstMorning ?? true
        tutorial = nil
        tutorialLandmarkID = nil
        guard wasFirstMorning else { return }
        UserDefaults.standard.set(true, forKey: "tutorial.done")
        if !skipped {
            showTip("zoom", symbol: "arrow.up.left.and.arrow.down.right",
                    title: "You're the mayor now",
                    text: "Pinch to zoom in on the town. Drag empty streets to look around.")
        }
    }

    func refreshHUD() {
        hud = HUDSnapshot(
            day: day,
            phase: currentDayPhase,
            dayProgress: min(1, dayClock),
            rating: townRating,
            revived: districtRevived[focusedDistrict] ?? 0,
            ridersToday: report.riders,
            waiting: waiting.values.reduce(0) { $0 + $1.count },
            featured: featuredToday,
            dayCardTitle: dayCard?.title,
            weather: weatherToday,
            issueCount: attentionIssues().filter(\.needsAction).count,
            district: focusedDistrict)
    }

    // MARK: The day loop

    func acceptAppointment() {
        phase = .playing
        startTutorialIfNeeded()
        report.ratingStart = townRating
        report.revivedStart = revivedFraction
        report.weather = weatherToday
        cameraFocusRequest = focusedDistrict
        startShopDay()
        refreshHUD()
        autosave()
    }

    /// The last train has run. Riders head home and the Gazette goes to print.
    /// An ordinary day ends: no paper, no pause, nobody sent home. Riders stay where they are,
    /// the trains keep running, and a new day begins with fresh weather.
    func rollDayQuietly() {
        recordDayFares()
        settleDueLetters()
        checkProgress()
        day += 1
        dayClock = 0
        featuredToday = LandmarkCategory.featurable.randomElement()
        weatherToday = Weather.roll()
        todayEvents = scheduleEvents(forDay: day)
        todayRiderMultiplier = 1
        todayPatienceMultiplier = 1
        todayCategoryBoost = [:]
        trips.removeAll { $0.isResolved }
        deliverMorningLetters()
        scheduleTrip()
        activeEventSignature = ""
        startShopDay()
        updateStreak()
        dayBanner = day
        AudioManager.shared.play(.ping, volume: 0.5)
        networkChanged()
        refreshHUD()
        changed()
        autosave()
    }

    func endDay() {
        recordDayFares()
        dayClock = 1
        // Groups still traveling when the last train runs didn't make it.
        for trip in activeTrips {
            for _ in 0..<trip.remaining { tripRider(trip.id, delivered: false) }
        }
        waiting.removeAll()
        onboard.removeAll()
        checkProgress()
        settleDueLetters()

        report.ratingEnd = townRating
        report.revivedEnd = revivedFraction
        if report.riders > stats.bestDayRiders {
            report.isRecord = day > 1
            stats.bestDayRiders = report.riders
        }
        featuredTomorrow = LandmarkCategory.featurable.randomElement()
        weatherTomorrow = Weather.roll()
        tomorrowEvents = scheduleEvents(forDay: day + 1)

        var names: [Int: String] = [:]
        for landmark in landmarks { names[landmark.id] = landmark.kind.info.name }
        let opened: [(name: String, from: String, to: String)] = report.linesOpened.compactMap { id in
            guard let line = self.line(id: id), line.stops.count >= 2,
                  let first = line.stops.first, let last = line.stops.last,
                  let from = names[first], let to = names[last] else { return nil }
            return (name: line.name, from: from, to: to)
        }

        let edition = GazetteWriter.edition(from: GazetteFacts(
            townName: townName,
            district: currentDistrict,
            term: termNumber,
            day: day,
            termLength: GameState.termLength,
            isEndless: isEndless,
            report: report,
            stationNames: names,
            openedLines: opened,
            lineNames: lines.filter { $0.stops.count >= 2 }.map(\.name),
            landmarkNames: openLandmarks.filter { $0.kind.info.category != .hub }.map(\.kind.info.name),
            heritageNames: landmarks.filter { $0.kind.info.isHeritage }.map(\.kind.info.name),
            featuredTomorrow: featuredTomorrow,
            weatherTomorrow: weatherTomorrow,
            eventsTomorrow: tomorrowEvents.map { "\($0.title): \(describe($0))" },
            usedKeys: usedGazetteKeys))
        usedGazetteKeys.formUnion(edition.usedKeys)
        gazette = edition
        quietPhone()
        phase = .gazette
        placingKind = nil
        isBookOpen = false
        refreshHUD()
        autosave()
    }

    /// What it takes for the next district to open: half the current one revived, and a
    /// town rating of 3.5. There's no deadline.
    static let milestoneRevival = 0.5
    static let milestoneRating = 3.5

    var milestoneReached: Bool {
        nextDistrict != nil && (districtBestRevived[currentDistrict] ?? 0) >= GameState.milestoneRevival
            && townRating >= GameState.milestoneRating
    }

    /// After reading the paper: the milestone certificate the first time the next district can
    /// open, otherwise the council session.
    func finishGazette() {
        gazette = nil
        if milestoneReached && !milestonesShown.contains(currentDistrict.rawValue) {
            milestonesShown.insert(currentDistrict.rawValue)
            phase = .termReview
            return
        }
        openCouncil()
    }

    private func openCouncil() {
        councilOffer = CouncilCard.draw(
            count: 3,
            approved: approvedCards,
            canAddLine: lineSlots(in: currentDistrict) < Palette.lineCount,
            hasHeritageLeft: landmarks.contains { $0.kind.info.isHeritage && !$0.isOpen },
            grantPending: heritageGrantAvailable,
            recentlySeen: recentCouncilCards)
        recentCouncilCards = Array((recentCouncilCards + councilOffer).suffix(12))
        phase = .council
    }

    /// Approves one proposal (or none) and starts the next day.
    func closeCouncil(approving card: CouncilCard?) {
        // The weekly council sends a Golden Ticket with its thanks.
        if card != nil { earnTickets(1, reason: "the council's thanks") }
        if let card {
            apply(card)
        }
        councilOffer = []
        startNextDay()
    }

    private func apply(_ card: CouncilCard) {
        switch card.duration {
        case .permanent:
            approvedCards.append(card)
            if card == .newLineCharter {
                bonusLines[currentDistrict, default: 0] += 1
                changed()
            }
        case .tomorrow:
            pendingDayCard = card
        case .untilUsed:
            switch card {
            case .landmarkVoucher: landmarkGrantAvailable = true
            case .trainVoucher: freeTrainAvailable = true
            default: heritageGrantAvailable = true
            }
        case .instant:
            switch card {
            case .transitBond:
                fares += 150
            case .gardenClub:
                for landmark in openLandmarks {
                    reviveBurst(around: landmark.cell, radius: 2.2, amount: 0.25)
                }
            case .sellDepot:
                fares += 250
                satisfaction = max(0, satisfaction - 0.08)
            case .paintTheTown:
                for district in openedDistricts {
                    if let hub = hub(of: district) {
                        reviveBurst(around: hub.cell, radius: 3, amount: 0.35)
                    }
                }
            case .pressConference:
                satisfaction += (1 - satisfaction) * 0.08
            default:
                break
            }
        }
    }

    private func startNextDay() {
        day += 1
        dayClock = 0
        featuredToday = featuredTomorrow
        featuredTomorrow = nil
        weatherToday = weatherTomorrow
        dayCard = pendingDayCard
        pendingDayCard = nil
        report = DayReport()
        report.ratingStart = townRating
        report.revivedStart = revivedFraction
        report.weather = weatherToday
        todayEvents = tomorrowEvents
        tomorrowEvents = []
        todayRiderMultiplier = 1
        todayPatienceMultiplier = 1
        todayCategoryBoost = [:]
        trips.removeAll { $0.isResolved }
        deliverMorningLetters()
        scheduleTrip()
        scheduleDecision()
        report.events = todayEvents.map { "\($0.title): \(describe($0))" }
        activeEventSignature = ""
        phase = .playing
        networkChanged()
        checkProgress()
        refreshHUD()
        if let event = todayEvents.first {
            show("Today: \(event.title.lowercased()), \(event.timing)")
        } else if weatherToday != .fair {
            show("\(weatherToday.name) today: \(weatherToday.effects.first ?? "")")
        }
        changed()
        autosave()
    }

    // MARK: Terms

    /// One big town now: there's no next district to open.
    var nextDistrict: District? { nil }

    /// Stay in the current district a while longer; the next one can be opened any time from
    /// the town panel.
    func continueEndless() {
        isEndless = true
        openCouncil()
    }

    /// Open the next district from the town panel, once its milestone is reached.
    func openNextDistrictFromPanel() {
        guard milestoneReached else { return }
        openNextDistrict()
    }

    /// The city grows: the next district opens, connected by light rail, with a new term.
    func openNextDistrict() {
        earnTickets(ribbonsEarned * 2, reason: "milestone stamps")
        guard let next = nextDistrict else {
            continueEndless()
            return
        }
        currentDistrict = next
        termNumber += 1
        goals = TermGoal.goals(forTerm: termNumber, district: next)
        isEndless = true

        // Days keep counting: there are no terms to reset them.
        dayClock = 0
        stats = TermStats()
        report = DayReport()
        // No free landmark in later terms: only the Pocket Park, in the first.
        unlocked.formUnion(LandmarkKind.starters(in: next))
        councilOffer = []
        dayCard = nil
        pendingDayCard = nil
        featuredToday = nil
        weatherToday = .fair
        todayEvents = []
        tomorrowEvents = []
        placingKind = nil
        selectedLineID = nil
        armedColorIndex = nil
        isBookOpen = false
        bookDistrict = next

        layoutDistrict(next)
        cityVersion += 1
        networkChanged()
        cameraFocusRequest = next
        phase = .appointment
        refreshHUD()
        changed()
    }
}
