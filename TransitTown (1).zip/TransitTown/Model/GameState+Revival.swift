import Foundation

extension GameState {

    func gridIndex(_ cell: GridPoint) -> Int? {
        guard cell.col >= 0, cell.col < cols, cell.row >= 0, cell.row < worldRows else { return nil }
        return cell.row * cols + cell.col
    }

    /// How alive a cell is, 0 (faded) to 1 (fully revived).
    func vitality(at cell: GridPoint) -> Double {
        guard let index = gridIndex(cell), index < vitalityGrid.count else { return 0.05 }
        return vitalityGrid[index]
    }

    var revivalMultiplier: Double {
        cardRevivalMultiplier
    }

    /// Stations served by lines become healthy; healthy stations revive the streets around them.
    /// Once a street is revived it stays revived, so a district's revival only ever goes up.
    /// Streets that haven't revived yet can still fade back if their station is neglected.
    func updateRevival(dt: Double) {
        guard cols > 0, rows > 0, vitalityGrid.count == cols * worldRows else { return }
        let built = builtLines

        var sources: [(cell: GridPoint, strength: Double, radius: Double)] = []
        for landmark in landmarks where landmark.isOpen {
            let served = built.contains { $0.stops.contains(landmark.id) }
            let traffic = (recentTraffic[landmark.id] ?? 0) * exp(-dt / 40)
            recentTraffic[landmark.id] = traffic

            let target = served ? min(1, 0.6 + 0.4 * min(1, traffic / 6)) : 0
            var health = stationHealth[landmark.id] ?? 0
            health += (target - health) * min(1, 0.12 * dt)
            stationHealth[landmark.id] = health

            let boosted = landmark.kind.info.perk == .revivalBoost
            sources.append((landmark.cell, health * (boosted ? 1.15 : 1), boosted ? 5.4 : 4.2))
            if landmark.kind.info.isHeritage {
                sources.append((landmark.cell, 0.45, 3.0)) // a restored landmark keeps its street alive
            }
        }

        // Lines bring life too: the streets a subway line runs along revive, about two squares wide.
        var trackCells = Set<GridPoint>()
        for line in built where !line.isLightRail {
            let cells = line.stops.compactMap { landmark(id: $0)?.cell }
            for (from, to) in zip(cells, cells.dropFirst()) {
                let steps = max(abs(to.col - from.col), abs(to.row - from.row))
                guard steps > 0 else { continue }
                for step in 0...steps {
                    let t = Double(step) / Double(steps)
                    trackCells.insert(GridPoint(col: Int((Double(from.col) + Double(to.col - from.col) * t).rounded()),
                                                row: Int((Double(from.row) + Double(to.row - from.row) * t).rounded())))
                }
            }
        }
        for cell in trackCells { sources.append((cell, 0.75, 2.4)) }

        let upRate = 0.035 * revivalMultiplier
        let downRate = 0.006
        var sums: [District: Double] = [:]
        var revived: [District: Int] = [:]
        var counts: [District: Int] = [:]

        for row in 0..<worldRows {
            for col in 0..<cols {
                let index = row * cols + col
                var target = 0.05
                for source in sources {
                    let dc = abs(col - source.cell.col)
                    guard Double(dc) < source.radius else { continue }
                    let distance = hypot(Double(dc), Double(row - source.cell.row))
                    let falloff = max(0, 1 - distance / source.radius)
                    target = max(target, min(1, source.strength * falloff))
                }
                let current = vitalityGrid[index]
                if target > current {
                    vitalityGrid[index] = min(target, current + upRate * dt)
                } else if current < GameState.revivedThreshold {
                    vitalityGrid[index] = max(target, current - downRate * dt)
                }

                if let owner = self.district(at: GridPoint(col: col, row: row)), isOpened(owner) {
                    sums[owner, default: 0] += vitalityGrid[index]
                    counts[owner, default: 0] += 1
                    if vitalityGrid[index] >= GameState.revivedThreshold { revived[owner, default: 0] += 1 }
                }
            }
        }

        let openedSum = sums.values.reduce(0, +)
        let openedCount = counts.values.reduce(0, +)
        averageVitality = openedCount > 0 ? openedSum / Double(openedCount) : 0.05
        for (district, count) in counts where count > 0 {
            let fraction = Double(revived[district] ?? 0) / Double(count)
            districtRevived[district] = fraction
            districtBestRevived[district] = max(districtBestRevived[district] ?? 0, fraction)
        }
        revivedFraction = districtRevived[currentDistrict] ?? 0
    }

    /// An immediate lift around a cell (restorations, the Garden Club).
    func reviveBurst(around cell: GridPoint, radius: Double, amount: Double) {
        guard cols > 0, rows > 0, vitalityGrid.count == cols * worldRows else { return }
        for row in 0..<worldRows {
            for col in 0..<cols {
                let distance = hypot(Double(col - cell.col), Double(row - cell.row))
                let falloff = max(0, 1 - distance / radius)
                guard falloff > 0 else { continue }
                let index = row * cols + col
                vitalityGrid[index] = min(1, vitalityGrid[index] + amount * falloff)
            }
        }
    }
}
