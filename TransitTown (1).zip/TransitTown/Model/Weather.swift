import Foundation

/// Tomorrow's weather, printed in the Gazette's forecast. Each kind changes how the day plays.
enum Weather: String, CaseIterable, Equatable, Codable {
    case fair, sunny, rain, fog, windy

    var name: String {
        switch self {
        case .fair: return "Fair"
        case .sunny: return "Sunny"
        case .rain: return "Rain"
        case .fog: return "Fog"
        case .windy: return "Windy"
        }
    }

    var symbol: String {
        switch self {
        case .fair: return "cloud.sun.fill"
        case .sunny: return "sun.max.fill"
        case .rain: return "cloud.rain.fill"
        case .fog: return "cloud.fog.fill"
        case .windy: return "wind"
        }
    }

    /// What it does to the day, in plain words. Nil when it changes nothing.
    var effects: [String] {
        switch self {
        case .fair: return []
        case .sunny: return ["Parks and gardens draw 50% more riders", "10% more riders overall"]
        case .rain: return ["15% more riders take the train", "Riders are 20% less patient"]
        case .fog: return ["Trains run 15% slower"]
        case .windy: return ["Trains run a little slower", "Parks draw 30% fewer riders"]
        }
    }

    /// Short label for the HUD.
    var shortEffect: String? {
        switch self {
        case .fair: return nil
        case .sunny: return "PARKS BUSY"
        case .rain: return "LESS PATIENT"
        case .fog: return "SLOWER TRAINS"
        case .windy: return "SLOW LIGHT RAIL"
        }
    }

    var gazetteLine: String {
        switch self {
        case .fair: return "Fair skies and a light breeze. A good, ordinary day."
        case .sunny: return "Bright sunshine from first train to last."
        case .rain: return "Steady rain all day. Umbrellas up, and everyone wants a train."
        case .fog: return "Thick fog rolling in off the water. Drivers will take it slow."
        case .windy: return "Blustery all day. Hold onto your hat, and your newspaper."
        }
    }

    var riderMultiplier: Double {
        switch self {
        case .sunny: return 1.1
        case .rain: return 1.15
        default: return 1
        }
    }

    var patienceMultiplier: Double { self == .rain ? 0.8 : 1 }
    var trainSpeedMultiplier: Double { self == .fog ? 0.85 : 1 }
    var natureDemandMultiplier: Double {
        switch self {
        case .sunny: return 1.5
        case .windy: return 0.7
        default: return 1
        }
    }
    /// The light rail crosses open water and feels the wind.
    var lightRailSpeedMultiplier: Double { self == .windy ? 0.8 : 1 }

    static func roll() -> Weather {
        let roll = Double.random(in: 0..<1)
        switch roll {
        case ..<0.32: return .fair
        case ..<0.54: return .sunny
        case ..<0.76: return .rain
        case ..<0.88: return .windy
        default: return .fog
        }
    }
}
