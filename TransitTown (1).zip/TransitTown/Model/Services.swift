import Foundation

/// Improvements bought for one station, from its card (tap any open station).
enum StationUpgrade: String, CaseIterable, Codable, Identifiable {
    case canopy, longPlatform, footbridge, lamps

    var id: String { rawValue }

    var title: String {
        switch self {
        case .canopy: return "Canopy"
        case .longPlatform: return "Longer Platform"
        case .footbridge: return "Footbridge"
        case .lamps: return "Station Lamps"
        }
    }

    var effect: String {
        switch self {
        case .canopy: return "Riders here are 30% more patient, and 60% more in rain."
        case .longPlatform: return "Holds 6 more waiting riders."
        case .footbridge: return "Riders changing trains here keep their patience."
        case .lamps: return "40% more riders set out from here at night."
        }
    }

    var symbol: String {
        switch self {
        case .canopy: return "umbrella.fill"
        case .longPlatform: return "rectangle.split.3x1.fill"
        case .footbridge: return "point.topleft.down.to.point.bottomright.curvepath.fill"
        case .lamps: return "lamp.desk.fill"
        }
    }

    var cost: Int {
        switch self {
        case .canopy: return 60
        case .longPlatform: return 80
        case .footbridge: return 70
        case .lamps: return 50
        }
    }
}

/// How the light rail runs. One service at a time, switched from the light rail pen.
/// More unlock as the light rail carries riders.
enum LightRailService: String, CaseIterable, Codable, Identifiable {
    case standard, nightOwl, marketExpress, schoolSpecial, theatreTrain, scenic, freightHour

    var id: String { rawValue }

    var title: String {
        switch self {
        case .standard: return "Standard"
        case .nightOwl: return "Night Owl"
        case .marketExpress: return "Market Express"
        case .schoolSpecial: return "School Special"
        case .theatreTrain: return "Theatre Train"
        case .scenic: return "Scenic Service"
        case .freightHour: return "Freight Hour"
        }
    }

    var effect: String {
        switch self {
        case .standard: return "An even service all day."
        case .nightOwl: return "Twice the riders out at night, but quieter mornings."
        case .marketExpress: return "Twice the riders heading to food stops."
        case .schoolSpecial: return "Mornings: twice the riders crossing to culture stops."
        case .theatreTrain: return "Evenings: twice the riders crossing to culture stops, and they wait longer."
        case .scenic: return "Slower, but twice the tourists from the quays, and they pay half again."
        case .freightHour: return "Carries building supplies: landmarks cost 20% less, but light rail carries 4 fewer riders."
        }
    }

    var symbol: String {
        switch self {
        case .standard: return "tram.fill"
        case .nightOwl: return "moon.stars.fill"
        case .marketExpress: return "basket.fill"
        case .schoolSpecial: return "backpack.fill"
        case .theatreTrain: return "theatermasks.fill"
        case .scenic: return "binoculars.fill"
        case .freightHour: return "shippingbox.fill"
        }
    }

    /// Light rail riders needed to unlock this service.
    var ridersNeeded: Int {
        switch self {
        case .standard: return 0
        case .nightOwl: return 25
        case .marketExpress: return 60
        case .schoolSpecial: return 100
        case .theatreTrain: return 150
        case .scenic: return 200
        case .freightHour: return 260
        }
    }
}
