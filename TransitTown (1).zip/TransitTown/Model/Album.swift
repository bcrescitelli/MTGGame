import Foundation

/// The Town Album: every shop that has moved in gets a page that fills up as the town uses
/// it: visitors, takings, its regulars, and comment cards people leave.
struct ShopRecord: Codable {
    var openedDay = 1
    var visits = 0
    var earned = 0
    var todayVisits = 0
    var bestDayVisits = 0
    /// Named townsfolk and how often each has come by.
    var regulars: [String: Int] = [:]
    var comments: [CommentCard] = []
    var lastCommentDay = 0
    /// Visits on each of the last seven finished days, oldest first.
    var week: [Int] = []
    /// Visits by time of day: morning, midday, evening, night.
    var byPhase: [Int] = [0, 0, 0, 0]
    /// Where visitors set out from: landmark id → how many.
    var origins: [Int: Int] = [:]

    init(openedDay: Int = 1) { self.openedDay = openedDay }

    // Older saves don't have every field yet, so each one is optional when reading.
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        openedDay = try c.decodeIfPresent(Int.self, forKey: .openedDay) ?? 1
        visits = try c.decodeIfPresent(Int.self, forKey: .visits) ?? 0
        earned = try c.decodeIfPresent(Int.self, forKey: .earned) ?? 0
        todayVisits = try c.decodeIfPresent(Int.self, forKey: .todayVisits) ?? 0
        bestDayVisits = try c.decodeIfPresent(Int.self, forKey: .bestDayVisits) ?? 0
        regulars = try c.decodeIfPresent([String: Int].self, forKey: .regulars) ?? [:]
        comments = try c.decodeIfPresent([CommentCard].self, forKey: .comments) ?? []
        lastCommentDay = try c.decodeIfPresent(Int.self, forKey: .lastCommentDay) ?? 0
        week = try c.decodeIfPresent([Int].self, forKey: .week) ?? []
        byPhase = try c.decodeIfPresent([Int].self, forKey: .byPhase) ?? [0, 0, 0, 0]
        origins = try c.decodeIfPresent([Int: Int].self, forKey: .origins) ?? [:]
    }
}

struct CommentCard: Codable, Identifiable {
    let id: Int
    let author: String
    let text: String
    let day: Int
    let hearts: Int
}

/// The town's people. Names and little details combine into a couple of thousand distinct folk.
enum Townsfolk {
    static let names = [
        "Mabel", "Otto", "Rosa", "Theo", "Ivy", "Arthur", "Nell", "Felix", "June", "Bertie", "Clara", "Hugo",
        "Winnie", "Percy", "Elsie", "Albert", "Dot", "Cyril", "Hattie", "Ned", "Florence", "Sid", "Maud", "Leo",
        "Agnes", "Barnaby", "Peggy", "Rufus", "Iris", "Walter", "Edie", "Monty", "Lottie", "Frank", "Daisy", "Ike",
        "Violet", "Stan", "Greta", "Wilf", "Poppy", "Eamon", "Tilly", "Gus", "Marigold", "Alfie", "Beatrix", "Cosmo",
        "Hazel", "Ottilie", "Rex", "Sunny", "Pearl", "Ambrose", "Kit", "Lavinia", "Basil", "Opal", "Duncan", "Fern",
    ]
    static let details = [
        "who knits on the 8:15", "the retired conductor", "who always sits by the window", "with the yellow umbrella",
        "who hums show tunes", "and her three corgis", "the night-shift baker", "who collects tram tickets",
        "the crossword champion", "on his first day in town", "who feeds the pigeons", "with the enormous hat",
        "the lighthouse keeper's niece", "who never misses a Tuesday", "who reads on every ride", "and his accordion",
        "the newest neighbor", "from the flat above the bakery", "who waves at every train", "the town's best whistler",
        "who brings her own teacup", "the schoolteacher", "who's writing a novel", "with the tiny dog in a bag",
        "the retired sea captain", "who sketches strangers", "on the way to a first date", "the barber",
        "who swears the trains talk", "and her grandmother", "the night owl", "who knows everyone's name",
        "with paint on his sleeves", "the postman", "who's learning to juggle", "with a bag of oranges",
        "who's always five minutes early", "the town gossip", "who sings in the choir", "the gardener",
    ]
    /// A few animal regulars, because every good town has them.
    static let animals = ["Biscuit the dog", "Marmalade the cat", "Pickles the parrot", "Waffles the dachshund",
                          "Sir Whiskers", "Pudding the beagle"]

    static func random() -> String {
        if Int.random(in: 0..<30) == 0, let pet = animals.randomElement() { return pet }
        return "\(names.randomElement() ?? "Mabel"), \(details.randomElement() ?? "the regular")"
    }
}

extension GameState {

    /// Someone arrived at a landmark: count them, their fare, maybe a regular, maybe a comment.
    func recordVisit(at stationID: Int, from originID: Int, fare: Int) {
        guard let landmark = landmark(id: stationID), landmark.kind.info.category != .canal else { return }
        var record = shopRecords[stationID] ?? ShopRecord(openedDay: day)
        record.visits += 1
        let phaseIndex: Int
        switch currentDayPhase {
        case .morning: phaseIndex = 0
        case .midday: phaseIndex = 1
        case .evening: phaseIndex = 2
        case .night: phaseIndex = 3
        }
        if record.byPhase.count < 4 { record.byPhase = [0, 0, 0, 0] }
        record.byPhase[phaseIndex] += 1
        if originID != stationID { record.origins[originID, default: 0] += 1 }
        record.todayVisits += 1
        record.earned += fare
        record.bestDayVisits = max(record.bestDayVisits, record.todayVisits)

        // Now and then, someone we can name. Familiar faces come back more often than new ones.
        let locals = residentProgress.compactMap { id, progress -> String? in
            guard progress > 0, residentHome[id] == stationID, let resident = Cast.resident(id) else { return nil }
            return "\(resident.name), \(resident.role)"
        }
        if !locals.isEmpty, Double.random(in: 0..<1) < 0.12, let local = locals.randomElement() {
            record.regulars[local, default: 0] += 1
        } else if Double.random(in: 0..<1) < 0.2 {
            let known = Array(record.regulars.keys)
            let who = (!known.isEmpty && Double.random(in: 0..<1) < 0.6) ? (known.randomElement() ?? Townsfolk.random()) : Townsfolk.random()
            record.regulars[who, default: 0] += 1
            if record.regulars.count > 24, let quietest = record.regulars.min(by: { $0.value < $1.value })?.key {
                record.regulars[quietest] = nil
            }
        }
        // At most one comment card a day per place.
        // A comment never repeats at the same place, and nobody signs two cards in a row there.
        if record.lastCommentDay != day, Double.random(in: 0..<1) < 0.08,
           let text = commentText(for: landmark.kind, excluding: Set(record.comments.map(\.text))) {
            let lastAuthor = record.comments.first?.author
            let author = record.regulars.keys.filter { $0 != lastAuthor }.randomElement() ?? Townsfolk.random()
            nextCommentID += 1
            record.comments.insert(CommentCard(id: nextCommentID, author: author, text: text, day: day,
                                               hearts: Int.random(in: 0..<10) < 8 ? 5 : 4), at: 0)
            if record.comments.count > 20 { record.comments.removeLast() }
            record.lastCommentDay = day
        }
        shopRecords[stationID] = record
    }

    /// Each morning, today's count starts fresh.
    func startShopDay() {
        for id in shopRecords.keys {
            guard var record = shopRecords[id] else { continue }
            record.week.append(record.todayVisits)
            if record.week.count > 7 { record.week.removeFirst(record.week.count - 7) }
            record.todayVisits = 0
            shopRecords[id] = record
        }
    }

    /// The places visitors most often come from, busiest first.
    func topOrigins(of stationID: Int, limit: Int = 3) -> [(name: String, visits: Int)] {
        (shopRecords[stationID]?.origins ?? [:])
            .sorted { $0.value > $1.value }
            .prefix(limit)
            .compactMap { pair in landmark(id: pair.key).map { ($0.kind.info.name, pair.value) } }
    }

    /// Totals across the whole album.
    var albumTotals: (visitors: Int, regulars: Int, cards: Int) {
        shopRecords.values.reduce((0, 0, 0)) { total, record in
            (total.0 + record.visits, total.1 + record.regulars.values.filter { $0 >= 3 }.count, total.2 + record.comments.count)
        }
    }

    /// The regulars who come most, with how often.
    func regulars(of stationID: Int, limit: Int = 6) -> [(name: String, visits: Int)] {
        (shopRecords[stationID]?.regulars ?? [:]).sorted { $0.value > $1.value }.prefix(limit).map { ($0.key, $0.value) }
    }

    private func commentText(for kind: LandmarkKind, excluding used: Set<String>) -> String? {
        let name = kind.info.name
        let byCategory: [LandmarkCategory: [String]] = [
            .food: ["Worth every stop on the line. Back tomorrow.", "Smelled it from the platform and followed my nose.",
                    "Best thing I've eaten all week. Possibly all year.", "Friendly faces and a warm welcome.",
                    "I came for a snack and stayed for lunch. And tea.", "They remembered my order. Second visit ever.",
                    "Generous portions. I needed the walk home.", "Ate on the bench outside and watched the trains. Perfect."],
            .culture: ["Lost a whole afternoon here, happily.", "My grandson wants to come every day now.",
                       "A little bit of magic, two stops from home.", "I didn't expect to cry, but I did. In a good way.",
                       "Learned something new and argued about it all the way home.", "Came alone, left with three new friends.",
                       "The staff clearly love it here. So do I.", "Better than anything on the telly."],
            .nature: ["The quietest, greenest spot in town.", "Sat an hour and watched the trains go by.",
                      "Brought a book and forgot to read it.", "The birds were in very good voice today.",
                      "Fed the ducks. The ducks were rude. Still lovely.", "Came for ten minutes. Stayed for two hours.",
                      "Smells like cut grass and good decisions.", "My dog has declared this his favorite place."],
            .civic: ["Kind people who really helped. Thank you.", "Everything I needed, sorted in ten minutes.",
                     "Much easier now the train stops right outside.", "Patient, cheerful, and they had biscuits.",
                     "In and out before my tea went cold.", "They explained everything twice, kindly."],
            .spiritual: ["Peaceful. Exactly what I needed today.", "Came for the quiet, stayed for the stories.",
                         "A little eerie, a lot of fun.", "I lit a candle for my nan. She'd have loved the train.",
                         "Calm enough to hear yourself think.", "The bell made the whole platform stop and smile."],
            .hub: ["Trains on time and a cheerful porter.", "The busiest, friendliest platform in town.",
                   "I love the clock. I love the whole station.", "Met my sister off the 9:10. Lovely hug, lovely station.",
                   "The departure board is my favorite thing to read.", "Even the waiting is pleasant here."],
        ]
        let general = ["The \(name) makes this town feel like home.", "Tell your friends about the \(name). I already have.",
                       "Can't believe I'd never been to the \(name) before.", "I'd ride across town for the \(name). I just did."]
        let pool = ((byCategory[kind.info.category] ?? []) + general).filter { !used.contains($0) }
        return pool.randomElement()
    }
}
