import Foundation

/// Everything needed to pick a city back up. Riders in transit aren't saved: the
/// platforms and trains start empty when you return, and fill again within moments.
struct SaveGame: Codable {
    /// Version 2 is the 2×2 city. Earlier saves can't be laid out on it, so they're set aside.
    static let version = 6

    var version = SaveGame.version
    var savedAt = Date()

    // Town
    var townName: String
    var townSeed: UInt64
    var districtCols: Int
    var rows: Int
    var currentDistrict: District
    var focusedDistrict: District
    var termNumber: Int
    var isEndless: Bool
    var phase: GamePhase

    // Network
    var landmarks: [Landmark]
    var lines: [TransitLine]
    var trainsPerLine: [Int: Int]
    var lightRailUpgrades: Set<LightRailUpgrade>
    var lightRailRiders: Int
    var nextID: Int
    var nextEventID: Int

    // Progress
    var fares: Int
    var goals: [TermGoal]
    var unlocked: Set<LandmarkKind>
    var approvedCards: [CouncilCard]
    var heritageGrantAvailable: Bool
    var landmarkGrantAvailable: Bool
    var bonusLines: [District: Int]
    var districtBestRevived: [District: Double]
    var completedPairs: Set<String>
    var usedGazetteKeys: Set<String>
    var tipsShown: Set<String>
    var stats: TermStats

    // The day
    var day: Int
    var dayClock: Double
    var satisfaction: Double
    var bestRating: Double
    var vitalityGrid: [Double]
    var stationHealth: [Int: Double]
    var report: DayReport
    var featuredToday: LandmarkCategory?
    var featuredTomorrow: LandmarkCategory?
    var weatherToday: Weather
    var weatherTomorrow: Weather
    var dayCard: CouncilCard?
    var pendingDayCard: CouncilCard?
    var todayEvents: [TownEvent]
    var tomorrowEvents: [TownEvent]

    // The mayor's desk
    var letters: [Letter]
    var stationUpgrades: [Int: Set<StationUpgrade>]
    var lightRailService: LightRailService
    var freeTrainAvailable: Bool
    var recentCouncilCards: [CouncilCard]
    var seenDecisions: [String]
    var nextLetterID: Int
    var nextTripID: Int
    var decorItems: [Decor]
    var nextDecorID: Int
    var tickets: Int
    var decorUnlocked: Bool?
    var decorAnnounced: Bool?
    var shopRecords: [Int: ShopRecord]?
    var nextCommentID: Int?
    var residentProgress: [String: Int]?
    var residentHome: [String: Int]?
    var hotlineUnlocked: Bool?
    var milestonesShown: [Int]?
    var unlockedDecor: [String]?
    var lostItemsUsed: [String]?
    var tipJars: [Int: Int]?
    var adsUnlocked: Bool?
    var buildsStarted: Int?
    var openedLines: Int?
    var adsDate: String?
    var adsWatched: Int?
    var streakDays: Int?
    var lastPlayDay: String?
    var lastActive: Date?
    var earningRate: Double?
    var trainUpgrades: [String: TrainUpgrade]?
    var averageDayFares: Double?
}

/// Reads and writes the one saved city.
enum SaveStore {
    private static var fileURL: URL? {
        guard let folder = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else { return nil }
        return folder.appendingPathComponent("city.json")
    }

    static var exists: Bool {
        guard let url = fileURL else { return false }
        return FileManager.default.fileExists(atPath: url.path)
    }

    static func save(_ game: SaveGame) {
        guard let url = fileURL else { return }
        do {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            let data = try JSONEncoder().encode(game)
            try data.write(to: url, options: .atomic)
        } catch {
            print("Couldn't save the city: \(error.localizedDescription)")
        }
    }

    static func load() -> SaveGame? {
        guard let url = fileURL, let data = try? Data(contentsOf: url) else { return nil }
        do {
            let game = try JSONDecoder().decode(SaveGame.self, from: data)
            return game.version == SaveGame.version ? game : nil
        } catch {
            print("Couldn't read the saved city: \(error.localizedDescription)")
            return nil
        }
    }

    static func delete() {
        guard let url = fileURL else { return }
        try? FileManager.default.removeItem(at: url)
    }

    /// "Willow Bend, Harborside, Day 3" for the title screen.
    static func summary() -> (town: String, detail: String)? {
        guard let game = load() else { return nil }
        let day = "Day \(game.day)"
        return (game.townName, day)
    }
}
