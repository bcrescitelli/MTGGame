import Foundation

extension GameState {

    // MARK: City layout
    // The city is a 2×2 grid of districts, with canals crossing between them.
    // `districtCols` × `rows` is the size of one district. Each district opens in its term.

    var worldCols: Int { districtCols * 2 + GameState.gapCols }
    var worldRows: Int { rows * 2 + GameState.gapCols }

    /// Total grid columns, used for indexing the revival grid.
    var cols: Int { worldCols }

    /// One big town (every new city, and any city that never opened a second district).
    var isSingleMap: Bool { currentDistrict == .oldTown }

    func columns(of district: District) -> Range<Int> {
        if isSingleMap && district == .oldTown { return 0..<worldCols }
        let start = district.blockCol * (districtCols + GameState.gapCols)
        return start..<(start + districtCols)
    }

    func rowRange(of district: District) -> Range<Int> {
        if isSingleMap && district == .oldTown { return 0..<worldRows }
        let start = district.blockRow * (rows + GameState.gapCols)
        return start..<(start + rows)
    }

    /// A wide river winding across the upper part of town, two squares wide. Nothing is built on
    /// it; lines cross it like bridges. Shaped only by the map's size, so it never moves.
    var riverCells: Set<GridPoint> {
        if let cached = riverCache { return cached }
        guard isSingleMap, worldCols > 0, worldRows > 0 else { return [] }
        let occupied = Set(landmarks.filter { $0.kind != .tunnelPortal }.map(\.cell))
        let base = Int(Double(worldRows) * 0.78)
        var cells = Set<GridPoint>()
        var previous: Int?
        for col in -8..<(worldCols + 8) {
            let row = base + Int((sin(Double(col) / 5.0) * 2.2).rounded())
            let from = min(previous ?? row, row), to = max(previous ?? row, row)
            for r in from...to { cells.insert(GridPoint(col: col, row: r)); cells.insert(GridPoint(col: col, row: r + 1)) }
            previous = row
        }
        // Anything already built stays put; the river simply flows around it.
        let river = cells.subtracting(occupied)
        riverCache = river
        return river
    }

    func district(at cell: GridPoint) -> District? {
        District.allCases.first { columns(of: $0).contains(cell.col) && rowRange(of: $0).contains(cell.row) }
    }

    func isOpened(_ district: District) -> Bool {
        district.rawValue <= currentDistrict.rawValue
    }

    var openedDistricts: [District] {
        District.allCases.filter { isOpened($0) }
    }

    func hub(of district: District) -> Landmark? {
        landmarks.first { $0.kind == district.hub }
    }

    /// A district counts as settled once it's mostly revived and a newer district has opened.
    /// Settled districts are calmer: fewer riders set out, and they wait twice as long.
    func isSettled(_ district: District) -> Bool {
        district != currentDistrict && (districtRevived[district] ?? 0) >= 0.6
    }

    // MARK: Opening districts

    /// Called by the scene once the grid size is known. Lays out Old Town.
    func prepareTown(cols: Int, rows: Int) {
        riverCache = nil
        guard !isTownReady, cols > 0, rows > 0 else { return }
        districtCols = cols
        self.rows = rows
        isTownReady = true
        vitalityGrid = Array(repeating: 0.05, count: worldCols * worldRows)
        layoutDistrict(currentDistrict)

        report = DayReport()
        report.ratingStart = townRating
        refreshHUD()
        changed()
    }

    /// Places a district's hub, starter landmarks, and boarded-up heritage site.
    func layoutDistrict(_ district: District) {
        var rng = SeededGenerator(seed: townSeed &+ UInt64(district.rawValue + 1) &* 7919)
        let hubCell = hubPosition(for: district, using: &rng)
        addLandmark(district.hub, at: hubCell, open: true)

        for (index, kind) in LandmarkKind.preplaced(in: district).enumerated() {
            let side = index % 2 == 0 ? -1 : 1
            let candidate = clamped(GridPoint(col: hubCell.col + side * Int.random(in: 3...4, using: &rng),
                                              row: hubCell.row + (side < 0 ? 1 : -1) * Int.random(in: 1...2, using: &rng)),
                                    to: district)
            if isBuildable(candidate, in: district) {
                addLandmark(kind, at: candidate, open: true)
            } else if let cell = freeCell(in: district, awayFromOthersBy: 2, using: &rng) {
                addLandmark(kind, at: cell, open: true)
            }
        }

        for kind in LandmarkKind.heritage(in: district) {
            if let cell = freeCell(in: district, awayFromOthersBy: 2, using: &rng) {
                addLandmark(kind, at: cell, open: false)
            }
        }

        // The canals are crossed by tunnels now; there are no quays.
    }

    private func quayCell(_ kind: LandmarkKind) -> GridPoint {
        func hubCell(_ district: District) -> GridPoint {
            hub(of: district)?.cell ?? GridPoint(col: columns(of: district).lowerBound + districtCols / 2,
                                                  row: rowRange(of: district).lowerBound + rows / 2)
        }
        func between(_ a: Int, _ b: Int, in range: Range<Int>) -> Int {
            min(max((a + b) / 2, range.lowerBound), range.upperBound - 1)
        }
        switch kind {
        case .northQuay:
            let a = hubCell(.oldTown), b = hubCell(.harborside)
            return GridPoint(col: districtCols, row: between(a.row, b.row, in: rowRange(of: .oldTown)))
        case .southQuay:
            let a = hubCell(.hillQuarter), b = hubCell(.lanternRow)
            return GridPoint(col: districtCols, row: between(a.row, b.row, in: rowRange(of: .hillQuarter)))
        case .westQuay:
            let a = hubCell(.oldTown), b = hubCell(.hillQuarter)
            return GridPoint(col: between(a.col, b.col, in: columns(of: .oldTown)), row: rows)
        default:
            let a = hubCell(.harborside), b = hubCell(.lanternRow)
            return GridPoint(col: between(a.col, b.col, in: columns(of: .harborside)), row: rows)
        }
    }

    /// Old Town's station sits in the middle, for the tutorial. Each later district's station
    /// starts farther out, toward its outer corner, so linking the city takes more track
    /// (and more money) every term.
    private func hubPosition(for district: District, using rng: inout SeededGenerator) -> GridPoint {
        let cols = columns(of: district)
        let rowsHere = rowRange(of: district)
        let jitter = Int.random(in: -1...1, using: &rng)
        switch district {
        case .oldTown:
            return GridPoint(col: cols.lowerBound + districtCols / 2, row: rowsHere.lowerBound + rows / 2)
        case .harborside:
            return GridPoint(col: cols.upperBound - 3, row: rowsHere.lowerBound + rows / 2 + jitter)
        case .hillQuarter:
            return GridPoint(col: cols.lowerBound + 2 + max(0, jitter), row: rowsHere.lowerBound + 1)
        case .lanternRow:
            return GridPoint(col: cols.upperBound - 3 - max(0, jitter), row: rowsHere.lowerBound + 1)
        }
    }

    private func clamped(_ cell: GridPoint, to district: District) -> GridPoint {
        let range = columns(of: district)
        let rowsHere = rowRange(of: district)
        return GridPoint(col: min(max(cell.col, range.lowerBound + 1), range.upperBound - 2),
                         row: min(max(cell.row, rowsHere.lowerBound), rowsHere.upperBound - 1))
    }

    /// A random buildable cell in a district, at least `distance` cells from every landmark,
    /// kept off the district's outer columns so names never run off the edge.
    private func freeCell(in district: District, awayFromOthersBy distance: Int,
                          using rng: inout SeededGenerator) -> GridPoint? {
        let range = columns(of: district)
        let colRange = districtCols > 4 ? (range.lowerBound + 1)..<(range.upperBound - 1) : range
        for attempt in 0..<300 {
            let cell = GridPoint(col: Int.random(in: colRange, using: &rng),
                                 row: Int.random(in: rowRange(of: district), using: &rng))
            let required = attempt < 200 ? distance : 2
            let clear = landmarks.allSatisfy { max(abs($0.cell.col - cell.col), abs($0.cell.row - cell.row)) >= required }
            if clear { return cell }
        }
        return nil
    }

    @discardableResult
    func addLandmark(_ kind: LandmarkKind, at cell: GridPoint, open: Bool) -> Int {
        let id = makeID()
        landmarks.append(Landmark(id: id, kind: kind, cell: cell, isOpen: open))
        clearDecor(around: cell)
        return id
    }

    // MARK: Space around landmarks

    /// Each landmark keeps the eight squares around it clear, so the town never gets crammed.
    func isBuildable(_ cell: GridPoint, in district: District, ignoring id: Int? = nil) -> Bool {
        guard columns(of: district).contains(cell.col), rowRange(of: district).contains(cell.row) else { return false }
        guard !riverCells.contains(cell) else { return false }
        return !landmarks.contains { landmark in
            landmark.id != id && max(abs(landmark.cell.col - cell.col), abs(landmark.cell.row - cell.row)) <= 1
        }
    }

    /// Why a cell can't take a landmark, for the message shown to the player.
    func reasonNotBuildable(_ cell: GridPoint, for kind: LandmarkKind, ignoring id: Int? = nil) -> String {
        let district = kind.info.district
        guard columns(of: district).contains(cell.col), rowRange(of: district).contains(cell.row) else {
            return "Pick a marked square for the \(kind.info.name)"
        }
        return "Too close to another landmark. Leave a square of space around each one."
    }

    // MARK: Building

    func canAfford(_ cost: Int) -> Bool { fares >= cost }

    /// What building this landmark costs right now (free if the council grant is unused).
    func buildCost(_ kind: LandmarkKind) -> Int {
        // The opening grant is for the Pocket Park; a later Builders' Voucher covers anything.
        let parkPending = !landmarks.contains { $0.kind == .park }
        let isFree = landmarkGrantAvailable && (!parkPending || kind == .park)
        // A particular shop costs the same as a permit for its kind (plus tickets, when built).
        return isFree ? 0 : permitCost(kind.info.category, in: kind.info.district)
    }

    /// True if this landmark can be built right now.
    func canBuild(_ kind: LandmarkKind) -> Bool {
        let info = kind.info
        return isOpened(info.district) && !info.isHeritage && info.category != .hub
            && unlocked.contains(kind) && !isBuilt(kind) && canAfford(buildCost(kind))
    }

    func beginPlacing(_ kind: LandmarkKind) {
        guard canBuild(kind) else { return }
        placingIsPermit = false
        placingKind = kind
        isBookOpen = false
        selectedLineID = nil
        armedColorIndex = nil
        if tutorial == .openAlbum {
            tutorial = .placeLandmark
        } else {
            show("Tap a marked square")
        }
        changed()
    }

    func cancelPlacing() {
        guard placingKind != nil else { return }
        placingKind = nil
        if tutorial == .placeLandmark { tutorial = .openAlbum }
        changed()
    }

    @discardableResult
    func build(_ kind: LandmarkKind, at cell: GridPoint) -> Bool {
        // A transit hub can go in any open neighborhood, and there can be many.
        if placingHub && kind == .transitHub {
            return buildHub(at: cell)
        }
        // A permit's shop is a surprise, so it doesn't need to be unlocked: only unclaimed.
        let permitOK = placingIsPermit && isOpened(kind.info.district) && !isBuilt(kind)
        guard permitOK || canBuild(kind) else {
            placingKind = nil
            changed()
            return false
        }
        guard isBuildable(cell, in: kind.info.district) else {
            show(reasonNotBuildable(cell, for: kind))
            return false
        }
        let free = !placingIsPermit && buildCost(kind) == 0
        let isPermit = placingIsPermit
        guard free || isPermit else {
            show("New shops arrive by permit: pick a kind of lot in Blueprints")
            placingKind = nil
            return false
        }
        let duration = isPermit ? nextBuildSeconds : 0
        if isPermit {
            let price = permitCost(kind.info.category, in: kind.info.district)
            guard canAfford(price) else {
                show("This permit costs $\(price)")
                return false
            }
            fares -= price
            buildsStarted += 1
        }
        landmarkGrantAvailable = false
        placingIsPermit = false
        placingKind = nil
        // The first build opens at once; after that, each goes up as a building site, taking
        // longer the more the town has.
        let instant = free || duration <= 0
        let id = addLandmark(kind, at: cell, open: instant)
        if !instant, let index = landmarks.firstIndex(where: { $0.id == id }) {
            landmarks[index].constructionRemaining = duration
            landmarks[index].constructionTotal = duration
            landmarks[index].constructionEnds = Date().addingTimeInterval(duration)
            // The first build that takes a while: offer to say when it's ready.
            Notifications.requestPermissionOnce()
            show(isPermit ? "Permit approved! A new shop is on its way." : "The \(kind.info.name) is under construction")
            changed()
            return true
        }
        stationHealth[id] = 0
        report.landmarksBuilt.append(kind)
        stats.landmarksBuilt += 1
        if tutorial == .placeLandmark {
            tutorial = .connectLandmark
            tutorialLandmarkID = id
        } else {
            show("The \(kind.info.name) is open!")
            showTip("move", symbol: "hand.tap.fill", title: "Moving landmarks",
                    text: "Hold any landmark for a moment, then drag it somewhere new.")
        }
        changed()
        return true
    }

    @discardableResult
    func moveLandmark(_ id: Int, to cell: GridPoint) -> Bool {
        defer {
            // Onboarding: moved something, so the phone line opens and Pip rings to welcome.
            if tutorial == .moveLandmark, landmark(id: id)?.cell == cell {
                tutorial = .answerCall
                if !hotlineUnlocked {
                    hotlineUnlocked = true
                    announce("Pip here, at the station. Folk keep stopping me on the platform with ideas for the trains, so we've set up a Town Hotline, straight to you. Expect a ring now and then. Pick up when you can.",
                             urgent: true)
                }
                changed()
            }
        }
        guard let index = landmarks.firstIndex(where: { $0.id == id }) else { return false }
        guard isBuildable(cell, in: landmarks[index].kind.info.district, ignoring: id) else { return false }
        landmarks[index].cell = cell
        clearDecor(around: cell)
        networkChanged()
        changed()
        return true
    }

    // MARK: Heritage

    func restorationCost(_ kind: LandmarkKind) -> Int {
        Int((Double(heritageGrantAvailable ? kind.info.cost / 2 : kind.info.cost) * restorationMultiplier).rounded())
    }

    func restoreRequirement(_ landmarkID: Int) -> ConditionProgress? {
        guard let site = landmark(id: landmarkID) else { return nil }
        return progress(for: site.kind.info.unlock, landmarkID: landmarkID, district: site.kind.info.district)
    }

    func canRestore(_ landmarkID: Int) -> Bool {
        guard let site = landmark(id: landmarkID), !site.isOpen,
              let requirement = restoreRequirement(landmarkID) else { return false }
        return requirement.isMet && canAfford(restorationCost(site.kind))
    }

    @discardableResult
    func restore(_ landmarkID: Int) -> Bool {
        guard canRestore(landmarkID), let index = landmarks.firstIndex(where: { $0.id == landmarkID }) else { return false }
        let kind = landmarks[index].kind
        fares -= restorationCost(kind)
        heritageGrantAvailable = false
        landmarks[index].isOpen = true
        stationHealth[landmarkID] = 0.6
        stats.heritageRestored += 1
        report.restored.append(kind)
        reviveBurst(around: landmarks[index].cell, radius: 3.2, amount: 0.45)
        events.append(.restored(landmarkID: landmarkID))
        isBookOpen = false
        networkChanged()
        show("The \(kind.info.name) is restored!")
        changed()
        return true
    }

    // MARK: Blueprints

    func openBook(district: District? = nil) {
        bookDistrict = district ?? focusedDistrict
        isBookOpen = true
        placingKind = nil
    }

    func closeBook() {
        isBookOpen = false
        unseenBlueprints.removeAll()
    }
}
