import Foundation

/// The four parts of a day. Each landmark draws riders differently in each.
enum DayPhase: Int, CaseIterable {
    case morning, midday, evening, night

    static func at(progress: Double) -> DayPhase {
        switch progress {
        case ..<0.30: return .morning
        case ..<0.56: return .midday
        case ..<0.84: return .evening
        default: return .night
        }
    }

    var name: String {
        switch self {
        case .morning: return "Morning"
        case .midday: return "Midday"
        case .evening: return "Evening"
        case .night: return "Night"
        }
    }

    var symbol: String {
        switch self {
        case .morning: return "sunrise.fill"
        case .midday: return "sun.max.fill"
        case .evening: return "sunset.fill"
        case .night: return "moon.stars.fill"
        }
    }

    /// How many riders set out, relative to midday.
    var intensity: Double {
        switch self {
        case .morning: return 1.15
        case .midday: return 1.0
        case .evening: return 1.1
        case .night: return 0.6
        }
    }
}

/// Which screen of the game loop is active.
enum GamePhase: String, Codable {
    case appointment, playing, gazette, council, termReview
}

enum GameSpeed: Int, CaseIterable {
    case paused, normal, fast

    var multiplier: Double {
        switch self {
        case .paused: return 0
        case .normal: return 1
        case .fast: return 2.5
        }
    }
}

/// Values the HUD shows, refreshed a few times a second rather than every frame.
struct HUDSnapshot: Equatable {
    var day = 1
    var phase: DayPhase = .morning
    var dayProgress: Double = 0
    var rating: Double = 1.5
    var revived: Double = 0
    var ridersToday = 0
    var waiting = 0
    var featured: LandmarkCategory?
    var dayCardTitle: String?
    var weather: Weather = .fair
    /// Problems that need the mayor: worn or broken track, crowded stations.
    var issueCount = 0
    /// The district whose revival the HUD shows (the one on screen).
    var district: District = .oldTown
}
