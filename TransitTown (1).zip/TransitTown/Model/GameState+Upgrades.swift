import Foundation

/// Optional upgrades for individual trains, paid for with money: speed (three levels) and
/// capacity (two levels, each an extra car's worth of seats). Upgrades belong to a train's slot
/// on its line (first train, second train...), so they survive the scene redrawing trains.
struct TrainUpgrade: Codable, Equatable {
    var speed = 0
    var capacity = 0
}

extension GameState {
    static let maxSpeedLevel = 3
    static let maxCapacityLevel = 2
    static let speedCosts = [150, 300, 500]
    static let capacityCosts = [200, 400]
    static let seatsPerCar = 3

    func upgrade(lineID: Int, slot: Int) -> TrainUpgrade {
        trainUpgrades["\(lineID)-\(slot)"] ?? TrainUpgrade()
    }

    func speedFactor(lineID: Int, slot: Int) -> Double {
        1 + 0.12 * Double(upgrade(lineID: lineID, slot: slot).speed)
    }

    /// Extra seats on a specific train (the scene tells us which slot each train fills).
    func extraSeats(trainID: Int) -> Int {
        guard let place = trainSlots[trainID] else { return 0 }
        return upgrade(lineID: place.lineID, slot: place.slot).capacity * GameState.seatsPerCar
    }

    func nextSpeedCost(lineID: Int, slot: Int) -> Int? {
        let level = upgrade(lineID: lineID, slot: slot).speed
        return level < GameState.maxSpeedLevel ? GameState.speedCosts[level] : nil
    }

    func nextCapacityCost(lineID: Int, slot: Int) -> Int? {
        let level = upgrade(lineID: lineID, slot: slot).capacity
        return level < GameState.maxCapacityLevel ? GameState.capacityCosts[level] : nil
    }

    func buySpeed(lineID: Int, slot: Int) {
        guard let cost = nextSpeedCost(lineID: lineID, slot: slot), canAfford(cost) else { return }
        fares -= cost
        trainUpgrades["\(lineID)-\(slot)", default: TrainUpgrade()].speed += 1
        changed()
    }

    func buyCapacity(lineID: Int, slot: Int) {
        guard let cost = nextCapacityCost(lineID: lineID, slot: slot), canAfford(cost) else { return }
        fares -= cost
        trainUpgrades["\(lineID)-\(slot)", default: TrainUpgrade()].capacity += 1
        changed()
    }
}
