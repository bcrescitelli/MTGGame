import Foundation

extension GameState {

    // MARK: Disruptions in effect
    // Events close stations, track, or whole lines for part of the day. Trains turn back
    // before closed track, roll through closed stations, and stop where they are in a
    // power cut. Riders re-plan around all of it.

    private var activeEvents: [TownEvent] {
        todayEvents.filter { $0.isActive(at: dayClock) }
    }

    func isStationClosed(_ id: Int) -> Bool {
        activeEvents.contains { event in
            (event.kind == .parade || event.kind == .streetMarket || event.kind == .storm)
                && event.stationIDs.contains(id)
        }
    }

    /// Whether trains can run this stretch right now.
    func isTrackOpen(lineID: Int, _ a: Int, _ b: Int) -> Bool {
        let key = TrackKey(lineID: lineID, a, b)
        return !activeEvents.contains { ($0.kind == .roadworks || $0.kind == .rockfall) && $0.track == key }
    }

    /// False while a power cut has stopped a line, or while the Night Owl light rail is resting.
    func isLinePowered(_ lineID: Int) -> Bool {
        if lightRailService == .nightOwl, dayClock < 0.4, line(id: lineID)?.isLightRail == true { return false }
        return !activeEvents.contains { $0.kind == .powerCut && $0.lineID == lineID }
    }

    var festivalDistrictToday: District? {
        activeEvents.first { $0.kind == .festival }?.district
    }

    var streetMarketDistrictToday: District? {
        guard let event = activeEvents.first(where: { $0.kind == .streetMarket }),
              let id = event.stationIDs.first else { return nil }
        return landmark(id: id)?.kind.info.district
    }

    /// Called every tick: when a disruption starts or ends, the network changes shape.
    func updateDisruptions() {
        let signature = activeEvents.map { "\($0.id)" }.joined(separator: ",")
        guard signature != activeEventSignature else { return }
        let before = Set(activeEventSignature.split(separator: ",").map(String.init))
        activeEventSignature = signature
        for event in activeEvents where !before.contains("\(event.id)") {
            show("\(event.title): \(describe(event, includeTiming: false))")
        }
        networkChanged()
        changed()
    }

    // MARK: Scheduling

    /// Tomorrow's events. Disruptions get likelier as the term goes on. Never on day one.
    func scheduleEvents(forDay nextDay: Int) -> [TownEvent] {
        guard nextDay >= 2 else { return [] }
        var scheduled: [TownEvent] = []
        // Rare while the town is small (about 1 day in 8), rising slowly to about 1 day in 3.
        let places = openLandmarks.filter { $0.kind.info.category != .canal }.count
        let chance = places < 5 ? 0.12 : min(0.34, 0.15 + 0.01 * Double(nextDay - 2))
        if Double.random(in: 0..<1) < chance, let event = makeDisruption(day: nextDay) {
            scheduled.append(event)
        }
        if nextDay >= 14, places >= 8, Double.random(in: 0..<1) < 0.12, let event = makeDisruption(day: nextDay),
           event.kind != scheduled.first?.kind {
            scheduled.append(event)
        }

        let linked = connectedDistricts(to: currentDistrict) + [currentDistrict]
        if linked.count >= 2, Double.random(in: 0..<1) < 0.3, let district = linked.randomElement() {
            scheduled.append(TownEvent(id: makeEventID(), kind: .festival, day: nextDay,
                                       start: 0.3, end: 0.9, district: district))
        }
        // The Disruption Plan shortens every closure by a quarter.
        if hasCard(.disruptionPlan) {
            for index in scheduled.indices where scheduled[index].kind != .festival {
                scheduled[index].end = scheduled[index].start + (scheduled[index].end - scheduled[index].start) * 0.75
            }
        }
        return scheduled
    }

    private func makeDisruption(day: Int) -> TownEvent? {
        let stations = openLandmarks.filter { landmark in
            landmark.kind.info.category != .hub && builtLines.contains { $0.stops.contains(landmark.id) }
        }
        let subway = builtLines.filter { !$0.isLightRail }
        let stretches: [TrackKey] = subway.flatMap { line in
            (1..<line.stops.count).map { TrackKey(lineID: line.id, line.stops[$0 - 1], line.stops[$0]) }
        }
        guard !stations.isEmpty || !stretches.isEmpty else { return nil }

        var kinds: [TownEvent.Kind] = []
        if !stations.isEmpty { kinds += [.parade, .streetMarket, .storm] }
        if !stretches.isEmpty { kinds += [.roadworks, .rockfall] }
        if subway.count >= 2 { kinds.append(.powerCut) }
        guard let kind = kinds.randomElement() else { return nil }

        switch kind {
        case .parade:
            guard let station = stations.randomElement() else { return nil }
            let start = Double.random(in: 0.25...0.45)
            return TownEvent(id: makeEventID(), kind: .parade, day: day, start: start, end: start + 0.3,
                             stationIDs: [station.id])
        case .streetMarket:
            guard let station = stations.randomElement() else { return nil }
            return TownEvent(id: makeEventID(), kind: .streetMarket, day: day, start: 0, end: 0.55,
                             stationIDs: [station.id])
        case .storm:
            // Harborside takes the worst of the weather when it's open.
            let coast = stations.filter { $0.kind.info.district == .harborside }
            let pool = coast.count >= 2 ? coast : stations
            let flooded = Array(pool.shuffled().prefix(2)).map(\.id)
            return TownEvent(id: makeEventID(), kind: .storm, day: day, start: 0.45, end: 0.8,
                             stationIDs: flooded)
        case .roadworks:
            guard let stretch = stretches.randomElement() else { return nil }
            return TownEvent(id: makeEventID(), kind: .roadworks, day: day, start: 0, end: 1, track: stretch)
        case .rockfall:
            let hills = stretches.filter { landmark(id: $0.a)?.kind.info.district == .hillQuarter }
            guard let stretch = (hills.isEmpty ? stretches : hills).randomElement() else { return nil }
            let start = Double.random(in: 0.2...0.5)
            return TownEvent(id: makeEventID(), kind: .rockfall, day: day, start: start, end: 0.8, track: stretch)
        case .powerCut:
            guard let line = subway.randomElement() else { return nil }
            let start = Double.random(in: 0.35...0.6)
            return TownEvent(id: makeEventID(), kind: .powerCut, day: day, start: start, end: start + 0.2,
                             lineID: line.id)
        case .festival:
            return nil
        }
    }

    private func makeEventID() -> Int {
        defer { nextEventID += 1 }
        return nextEventID
    }

    /// A one-line description of an event, for the Gazette, toasts, and the attention list.
    func describe(_ event: TownEvent, includeTiming: Bool = true) -> String {
        let when = includeTiming ? ", \(event.timing)" : ""
        let closedNames = event.stationIDs.compactMap { landmark(id: $0)?.kind.info.name }
        let stations = closedNames.isEmpty ? "a station" : closedNames.joined(separator: " and ")
        switch event.kind {
        case .parade:
            return "\(stations) closed for a parade\(when)"
        case .streetMarket:
            return "\(stations) closed for a street market\(when). Food stops nearby are busy"
        case .storm:
            return "\(stations) flooded and closed\(when)"
        case .roadworks:
            let place = event.track.map { "The \(lineName($0.lineID)) between \(stationNames($0))" } ?? "One line"
            return "\(place) closed for roadworks\(when)"
        case .rockfall:
            let place = event.track.map { "The \(lineName($0.lineID)) between \(stationNames($0))" } ?? "One line"
            return "\(place) blocked by rocks\(when)"
        case .powerCut:
            return "No power on the \(event.lineID.map { lineName($0) } ?? "line")\(when). Its trains stop where they are"
        case .festival:
            let district = event.district ?? currentDistrict
            return "Riders from every linked district head to \(district.name)\(when)"
        }
    }

    // MARK: Attention

    /// Everything worth knowing about right now, most urgent first.
    func attentionIssues() -> [AttentionIssue] {
        var issues: [AttentionIssue] = []
        for event in todayEvents where dayClock < event.end {
            let active = event.isActive(at: dayClock)
            let firstStation = event.stationIDs.first ?? event.track?.a
                ?? event.lineID.flatMap { line(id: $0)?.stops.first }
                ?? event.district.flatMap { hub(of: $0)?.id }
            let district = firstStation.flatMap { landmark(id: $0)?.kind.info.district } ?? currentDistrict
            let kind: AttentionIssue.Kind = event.kind == .festival ? .festival : (active ? .disruption : .upcoming)
            let title = active ? "\(event.title) now" : "\(event.title) at \(TownEvent.timeName(event.start))"
            issues.append(AttentionIssue(id: "event-\(event.id)", kind: kind, title: title,
                                         detail: describe(event), symbol: event.symbol, district: district,
                                         track: event.track, stationID: firstStation))
        }
        for (stationID, queue) in waiting where queue.count >= 8 {
            guard let station = landmark(id: stationID) else { continue }
            issues.append(AttentionIssue(id: "crowd-\(stationID)", kind: .crowded,
                                         title: "Crowded platform",
                                         detail: "\(Format.count(queue.count, "rider")) waiting at the \(station.kind.info.name). Add a train or another line.",
                                         symbol: "person.3.fill", district: station.kind.info.district,
                                         track: nil, stationID: stationID))
        }
        for trip in activeTrips {
            guard let from = landmark(id: trip.origin), let to = landmark(id: trip.destination) else { continue }
            let progress = trip.kind == .inspector ? "Waiting at the \(from.kind.info.name)"
                : "\(trip.delivered) of \(trip.total) arrived"
            issues.append(AttentionIssue(id: "trip-\(trip.id)", kind: .trip, title: trip.kind.title,
                                         detail: "\(from.kind.info.name) to the \(to.kind.info.name). \(progress).",
                                         symbol: trip.kind.symbol, district: from.kind.info.district,
                                         track: nil, stationID: trip.delivered + trip.gaveUp < trip.total ? trip.origin : trip.destination))
        }
        let order: [AttentionIssue.Kind] = [.disruption, .trip, .crowded, .upcoming, .festival]
        return issues.sorted { (order.firstIndex(of: $0.kind) ?? 9) < (order.firstIndex(of: $1.kind) ?? 9) }
    }

    /// Glides the camera to an issue and marks it with a ring.
    func focus(on issue: AttentionIssue) {
        cameraFocusLandmarkID = issue.stationID ?? issue.track?.a
        highlightIssueID = issue.id
    }

    // MARK: Light rail upgrades

    func canBuy(_ upgrade: LightRailUpgrade) -> Bool {
        lightRail != nil && !lightRailUpgrades.contains(upgrade)
            && lightRailRiders >= upgrade.ridersNeeded && canAfford(upgrade.cost)
    }

    func buy(_ upgrade: LightRailUpgrade) {
        guard canBuy(upgrade) else { return }
        fares -= upgrade.cost
        lightRailUpgrades.insert(upgrade)
        networkChanged()
        show("Light rail: \(upgrade.title)")
        changed()
    }

    // MARK: Names

    func lineName(_ lineID: Int) -> String {
        line(id: lineID)?.name ?? "line"
    }

    func stationNames(_ key: TrackKey) -> String {
        let a = landmark(id: key.a)?.kind.info.name ?? "?"
        let b = landmark(id: key.b)?.kind.info.name ?? "?"
        return "\(a) and \(b)"
    }
}


// MARK: Repair crews

extension GameState {

    /// What it costs to send a crew to clear a closure (nil: festivals aren't something to fix).
    func crewCost(_ event: TownEvent) -> Int? {
        switch event.kind {
        case .festival: return nil
        case .parade, .streetMarket: return 35
        case .roadworks: return 50
        case .powerCut: return 55
        case .rockfall: return 60
        case .storm: return 70
        }
    }

    /// The event behind an attention issue, if it's one a crew can clear.
    func crewableEvent(for issue: AttentionIssue) -> TownEvent? {
        guard issue.id.hasPrefix("event-"), let id = Int(issue.id.dropFirst(6)),
              let event = todayEvents.first(where: { $0.id == id }), crewCost(event) != nil else { return nil }
        return event
    }

    /// Clear a closure now (or call off one that hasn't started), paying with money or a ticket.
    func sendCrew(_ eventID: Int, withTicket: Bool) {
        guard let index = todayEvents.firstIndex(where: { $0.id == eventID }),
              let cost = crewCost(todayEvents[index]) else { return }
        if withTicket {
            guard tickets >= 1 else { show("A crew costs a Golden Ticket"); return }
            tickets -= 1
        } else {
            guard canAfford(cost) else { show("A crew costs $\(cost)"); return }
            fares -= cost
        }
        if todayEvents[index].isActive(at: dayClock) {
            todayEvents[index].end = dayClock
        } else {
            // Not started yet: the crew heads it off, and it's gone from the list.
            todayEvents.remove(at: index)
        }
        networkChanged()
        changed()
    }
}
