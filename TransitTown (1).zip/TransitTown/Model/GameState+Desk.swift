import Foundation

extension GameState {

    // MARK: Letters to the Mayor
    // A letter or two arrives most mornings. Each asks for something specific by a due date.
    // Some pull in opposite directions; the mayor can't please everyone.

    var openLetters: [Letter] { letters.filter { $0.status == .open } }

    /// Called each morning from day 2.
    func deliverMorningLetters() {
        // Replaced by the Town Hotline: residents now call instead of writing.
        return
    }

    private func legacyMorningLetters() {
        guard day >= 2, openLetters.count < 3, Double.random(in: 0..<1) < 0.8 else { return }
        let candidates = openLandmarks.filter { isOpened($0.kind.info.district) && $0.kind.info.category != .hub }
        guard candidates.count >= 2 else { return }

        // Now and then, two neighbors disagree about the same station.
        if Double.random(in: 0..<1) < 0.25,
           let station = candidates.filter({ subwayLinesServing($0.id).count == 1 }).randomElement() {
            let name = station.kind.info.name
            let busy = makeLetter(goal: .lines(station.id, 2), dueIn: 3, reward: 70,
                                  body: "The \(name) is the only stop I can get to, and the trains are always full by the time they reach me. A second line would make all the difference.")
            var quiet = makeLetter(goal: .atMost(station.id, 1), dueIn: 3, reward: 60,
                                   body: "Since the trains came back, the \(name) has been nothing but rumbling and whistles. Please, no more lines. One is plenty for a quiet street.")
            quiet.conflictsWith = busy.id
            var first = busy
            first.conflictsWith = quiet.id
            letters.append(contentsOf: [first, quiet])
            unreadLetters += 2
            show("Two letters about the \(name). They don't agree.")
            return
        }

        let shuffled = candidates.shuffled()
        let a = shuffled[0], b = shuffled[1]
        let roll = Int.random(in: 0..<4)
        let letter: Letter
        switch roll {
        case 0 where !builtLines.contains(where: { $0.stops.contains(a.id) && $0.stops.contains(b.id) }):
            letter = makeLetter(goal: .connect(a.id, b.id), dueIn: 3, reward: 80,
                                body: connectBody(a.kind.info.name, b.kind.info.name))
        case 1 where subwayLinesServing(a.id).isEmpty:
            letter = makeLetter(goal: .serve(a.id), dueIn: 2, reward: 60,
                                body: serveBody(a.kind.info.name))
        default:
            let count = Int.random(in: 10...18)
            letter = makeLetter(goal: .carryTo(a.id, count), dueIn: 2, reward: 50 + count * 3,
                                body: carryBody(a.kind.info.name, count))
        }
        letters.append(letter)
        unreadLetters += 1
        show("A letter for the mayor")
    }

    private func makeLetter(goal: LetterGoal, dueIn: Int, reward: Int, body: String) -> Letter {
        defer { nextLetterID += 1 }
        let paid = hasCard(.communityRadio) ? reward * 3 / 2 : reward
        return Letter(id: nextLetterID, sender: Residents.names.randomElement() ?? "A resident",
                      role: Residents.roles.randomElement() ?? "resident", body: body, goal: goal,
                      receivedDay: day, dueDay: day + dueIn, reward: paid)
    }

    private func connectBody(_ a: String, _ b: String) -> String {
        [
            "I work at the \(b) and live by the \(a). Getting between them takes my whole lunch hour. Could one line stop at both?",
            "My sister is at the \(a) and I'm at the \(b), and we haven't had tea in a month. One line between us would fix that.",
            "Every Thursday I carry a pie from the \(a) to the \(b). It's getting heavy. A train would be lovely.",
            "The \(a) and the \(b) belong together, like bread and butter. Please put them on the same line.",
        ].randomElement() ?? ""
    }

    private func serveBody(_ name: String) -> String {
        [
            "Nobody can reach the \(name) by train. It seems a shame, with everything coming back to life.",
            "I've walked to the \(name) every day for thirty years. My knees would like a train.",
            "The \(name) is lovely and nobody knows it's there. A station would change that.",
        ].randomElement() ?? ""
    }

    private func carryBody(_ name: String, _ count: Int) -> String {
        [
            "We're holding a fundraiser at the \(name). If you could get \(count) people there in the next couple of days, we'd be over the moon.",
            "The \(name) is having its anniversary. We've baked for \(count) guests and would hate to eat it all ourselves.",
            "I've bet my neighbor that \(count) people will visit the \(name) this week. Please don't let me lose.",
        ].randomElement() ?? ""
    }

    /// Checked every second: letters whose wish has come true are answered right away.
    /// Letters asking to keep things quiet are judged on their due date.
    func checkLetters() {
        for index in letters.indices where letters[index].status == .open {
            if case .atMost = letters[index].goal { continue }
            if isMet(letters[index]) { answer(index) }
        }
    }

    /// At the end of each day, settle letters that are due.
    func settleDueLetters() {
        for index in letters.indices where letters[index].status == .open && letters[index].dueDay <= day {
            if isMet(letters[index]) {
                answer(index)
            } else {
                letters[index].status = .missed
                satisfaction = max(0, satisfaction - 0.02)
                report.lettersMissed += 1
            }
        }
        // Keep the desk tidy: only the last few settled letters stay around.
        let settled = letters.filter { $0.status != .open }
        if settled.count > 6 {
            let drop = Set(settled.prefix(settled.count - 6).map(\.id))
            letters.removeAll { drop.contains($0.id) }
        }
    }

    func isMet(_ letter: Letter) -> Bool {
        switch letter.goal {
        case let .connect(a, b): return builtLines.contains { $0.stops.contains(a) && $0.stops.contains(b) }
        case let .serve(a): return !subwayLinesServing(a).isEmpty
        case let .lines(a, n): return subwayLinesServing(a).count >= n
        case let .atMost(a, n): return subwayLinesServing(a).count <= n
        case let .carryTo(_, n): return letter.progress >= n
        case .find: return letter.progress >= 2
        case let .decorNear(a): return decorBeside(a)
        case let .trains(n): return totalTrains >= n
        case let .hubs(n): return openHubs >= n
        case let .serveBoth(a, b): return !subwayLinesServing(a).isEmpty && !subwayLinesServing(b).isEmpty
        }
    }

    func letterProgressText(_ letter: Letter) -> String {
        func name(_ id: Int) -> String { landmark(id: id)?.kind.info.name ?? "a landmark" }
        switch letter.goal {
        case let .connect(a, b): return "Put the \(name(a)) and the \(name(b)) on one line"
        case let .serve(a): return "Put the \(name(a)) on a line"
        case let .lines(a, n): return "\(Format.count(n, "line")) at the \(name(a)) (now \(subwayLinesServing(a).count))"
        case let .atMost(a, n): return "No more than \(Format.count(n, "line")) at the \(name(a)) on day \(letter.dueDay)"
        case let .carryTo(a, n): return "Carry \(Format.count(n, "rider")) to the \(name(a)): \(min(letter.progress, n)) so far"
        case let .find(a):
            switch letter.progress {
            case 0: return "It's somewhere on the map, small. Look closely and tap it when you spot it"
            case 1: return "Found! Now tap the \(name(a)) to give it back"
            default: return "Returned"
            }
        case let .decorNear(a): return decorBeside(a) ? "Done!" : "Place any decoration right beside the \(name(a))"
        case let .trains(n): return "\(min(totalTrains, n)) of \(n) trains running"
        case let .hubs(n): return "\(min(openHubs, n)) of \(n) transit hubs open"
        case let .serveBoth(a, b):
            let served = [a, b].filter { !subwayLinesServing($0).isEmpty }.count
            return "\(served) of 2 served: the \(name(a)) and the \(name(b))"
        }
    }

    private func answer(_ index: Int) {
        letters[index].status = .answered
        fares += letters[index].reward
        satisfaction += (1 - satisfaction) * 0.04
        report.lettersAnswered += 1
        earnTickets(1, reason: "thanks from \(letters[index].sender)")
        if letters[index].residentID != nil {
            residentRequestDone(letters[index])
        } else if let lostID = letters[index].lostItemID, let lost = LostAndFound.item(lostID), let thanks = letters[index].thanks {
            announce(thanks + " (They've sent $\(letters[index].reward) and a Golden Ticket.)", from: lost.sender, role: lost.role, pitch: lost.pitch)
            newsCooldown = min(newsCooldown, 8)
        } else {
            announce("It's me again! It worked a treat, Mayor. I've sent $\(letters[index].reward) and a Golden Ticket, with thanks.",
                     from: letters[index].sender, role: letters[index].role, pitch: 0.95)
            newsCooldown = min(newsCooldown, 8)
        }
        hotlineTimer = Double.random(in: 30...60)
        // A conflicting letter can no longer be satisfied the same day; it stays open until its due date.
    }

    /// A rider reached a landmark: count it toward any `carryTo` letters.
    func countLetterDelivery(to stationID: Int) {
        for index in letters.indices where letters[index].status == .open {
            if case let .carryTo(target, _) = letters[index].goal, target == stationID {
                letters[index].progress += 1
            }
        }
    }

    // MARK: Groups traveling together

    /// Called each morning: maybe a group will turn up today.
    func scheduleTrip() {
        tripClock = day >= 2 && Double.random(in: 0..<1) < 0.33 ? Double.random(in: 0.15...0.55) : nil
    }

    func updateTrips() {
        if let clock = tripClock, dayClock >= clock {
            tripClock = nil
            startTrip()
        }
    }

    private func startTrip() {
        let open = openLandmarks.filter { isOpened($0.kind.info.district) && !isStationClosed($0.id) }
        let served = open.filter { landmark in builtLines.contains { $0.stops.contains(landmark.id) } }
        guard served.count >= 3 else { return }

        let kind = SpecialTrip.Kind.allCases.randomElement() ?? .schoolTrip
        let hubs = served.filter { $0.kind.info.category == .hub || $0.kind.info.category == .canal }
        let culture = served.filter { $0.kind.info.category == .culture || $0.kind.info.isHeritage }
        let nature = served.filter { $0.kind.info.category == .nature }
        var origin: Landmark?
        var destination: Landmark?
        switch kind {
        case .schoolTrip:
            origin = served.first { $0.kind == .school } ?? served.randomElement()
            destination = culture.filter { $0.id != origin?.id }.randomElement()
        case .weddingParty:
            origin = served.filter { $0.kind.info.category == .food || $0.kind.info.category == .civic }.randomElement()
            destination = nature.filter { $0.id != origin?.id }.randomElement()
        case .inspector:
            origin = hubs.randomElement()
            destination = served.filter { $0.id != origin?.id && $0.kind.info.category != .hub }.randomElement()
        case .tourGroup:
            origin = hubs.randomElement()
            destination = served.filter { $0.kind.info.isHeritage && $0.isOpen }.randomElement()
                ?? culture.filter { $0.id != origin?.id }.randomElement()
        }
        guard let origin, let destination, origin.id != destination.id else { return }

        let trip = SpecialTrip(id: nextTripID, kind: kind, origin: origin.id, destination: destination.id, total: kind.size)
        nextTripID += 1
        trips.append(trip)
        for _ in 0..<kind.size {
            var rider = Rider(id: nextRiderID, origin: origin.id, destination: destination.id,
                              patience: kind == .inspector ? 45 : 75 * todayPatienceMultiplier,
                              isVisitor: kind == .tourGroup, isCrossDistrict: false)
            rider.tripID = trip.id
            nextRiderID += 1
            updateRoute(&rider, at: origin.id)
            waiting[origin.id, default: []].append(rider)
        }
        let title = kind == .inspector ? "The Transport Inspector is waiting" : "\(kind.title): \(kind.size) waiting"
        announce("Pip here, at the station. \(title) at the \(origin.kind.info.name), bound for the \(destination.kind.info.name). Get them there together and they'll make it worth your while.",
                 urgent: true, tripID: trip.id)
    }

    /// A trip rider arrived or gave up.
    func tripRider(_ tripID: Int, delivered: Bool) {
        guard let index = trips.firstIndex(where: { $0.id == tripID }), !trips[index].isResolved else { return }
        if delivered { trips[index].delivered += 1 } else { trips[index].gaveUp += 1 }
        guard trips[index].remaining == 0 else { return }
        trips[index].isResolved = true
        let trip = trips[index]
        if trip.succeeded {
            fares += trip.kind.reward
            earnTickets(1, reason: "the \(trip.kind.title.lowercased()) made it")
            satisfaction += (1 - satisfaction) * (trip.kind == .inspector ? 0.12 : 0.06)
            report.tripsCompleted += 1
            show("\(trip.kind.title) made it! +$\(trip.kind.reward)")
            events.append(.stamp(text: trip.kind == .inspector ? "INSPECTED" : "ARRIVED", stationID: trip.destination))
        } else {
            // No penalty: this is a town, not a test. They'll try the trains again another day.
            report.tripsFailed += 1
        }
    }

    var activeTrips: [SpecialTrip] { trips.filter { !$0.isResolved } }

    // MARK: Snap decisions

    /// Called each morning: today's decision will appear at a random point.
    func scheduleDecision() {
        // Mid-day decision pop-ups are retired: nothing interrupts play any more.
        decisionClock = nil
    }

    func updateDecisions() {
        guard pendingDecision == nil, let clock = decisionClock, dayClock >= clock else { return }
        decisionClock = nil
        let busiest = openLandmarks
            .filter { landmark in builtLines.contains { $0.stops.contains(landmark.id) } }
            .max { waitingCount(at: $0.id) < waitingCount(at: $1.id) }
        guard let station = busiest else { return }
        var deck = DecisionDeck.all(station: "the \(station.kind.info.name)").filter { !seenDecisions.contains($0.id) }
        if deck.isEmpty {
            seenDecisions.removeAll()
            deck = DecisionDeck.all(station: "the \(station.kind.info.name)")
        }
        guard var decision = deck.randomElement() else { return }
        decision.stationID = station.id
        seenDecisions.append(decision.id)
        pendingDecision = decision
    }

    func choose(_ choice: DecisionChoice) {
        guard let decision = pendingDecision else { return }
        for effect in choice.effects {
            switch effect {
            case let .fares(amount):
                fares = max(0, fares + amount)
            case let .rating(amount):
                satisfaction = min(1, max(0, satisfaction + amount))
            case let .riders(multiplier):
                todayRiderMultiplier *= multiplier
            case let .patience(multiplier):
                todayPatienceMultiplier *= multiplier
            case let .boost(category, multiplier):
                todayCategoryBoost[category, default: 1] *= multiplier
            case let .closeStation(until):
                if let id = decision.stationID {
                    todayEvents.append(TownEvent(id: nextEventID, kind: .parade, day: day, start: dayClock,
                                                 end: min(1, dayClock + until), stationIDs: [id]))
                    nextEventID += 1
                }
            case .reviveStation:
                if let id = decision.stationID, let cell = landmark(id: id)?.cell {
                    reviveBurst(around: cell, radius: 2.4, amount: 0.3)
                }
            }
        }
        report.decisions.append(choice.outcome)
        pendingDecision = nil
        show(choice.outcome)
        refreshHUD()
        changed()
    }
}
