import Foundation

/// The guided first morning, plus the light rail step when a new district opens.
/// Each step waits for the player to do the thing it describes.
enum TutorialStep: Int, CaseIterable {
    case drawLine, firstTrip, earnBlueprint, openAlbum, placeLandmark, connectLandmark
    case connectDistricts
    case moveLandmark, answerCall, addTrain

    /// Steps of the first morning are numbered; the light rail step stands alone.
    var isFirstMorning: Bool { self != .connectDistricts }
    var number: Int { rawValue + 1 }
    static let firstMorningTotal = 6

    var title: String {
        switch self {
        case .drawLine: return "Lay your first line"
        case .firstTrip: return "Your first rider"
        case .earnBlueprint: return "Keep them moving"
        case .openAlbum: return "A landmark is ready"
        case .placeLandmark: return "Find it a home"
        case .connectLandmark: return "Connect it"
        case .connectDistricts: return "Light rail"
        case .moveLandmark: return "Make yourself at home"
        case .answerCall: return "Someone's calling"
        case .addTrain: return "Another train"
        }
    }

    var text: String {
        switch self {
        case .drawLine: return "Open the menu at the bottom left and tap the red pen. Then drag from Central Station to the Corner Bakery."
        case .firstTrip: return "Bubbles show who's waiting and where to. Watch one ride."
        case .earnBlueprint: return "Carry 15 riders to unlock your first landmark."
        case .openAlbum: return "Tap Blueprints at the top and build the Pocket Park. It's on the house."
        case .placeLandmark: return "Tap an empty square. Next to the Bakery makes a Breakfast Run."
        case .connectLandmark: return "Tap the red pen again, then drag the end of your line onto the Pocket Park."
        case .connectDistricts: return "Drag from Central Station to the new hub to lay light rail."
        case .moveLandmark: return "Press and hold the Pocket Park, then drag it to a new spot. You can rearrange anything you build."
        case .answerCall: return "The town has a phone line to the mayor now. When it rings, tap the phone to answer."
        case .addTrain: return "Busy line? Tap it on the map, then tap + TRAIN. More trains, shorter waits."
        }
    }

    static let ridersForFirstBlueprint = 15
}

/// A one-time tip shown the first time something happens.
struct CoachTip: Equatable, Identifiable {
    let id: String
    let symbol: String
    let title: String
    let text: String
}
