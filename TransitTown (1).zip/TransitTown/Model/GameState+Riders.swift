import Foundation

extension GameState {

    // MARK: Main tick

    /// Advances the simulation. `dt` is already scaled by game speed (0 when paused).
    func tick(dt: Double) {
        guard isSimulating, dt > 0, pendingDecision == nil else { return }

        dayClock += dt / GameState.dayLength
        spawn(dt: dt)
        ageWaitingRiders(dt: dt)
        updateActivity(dt: dt)
        updateDisruptions()
        updateTrips()
        updateConstruction(dt: dt)
        updateHotline(dt: dt)
        updateSpotlight(dt: dt)
        if coachTip != nil, let stillTrue = coachTipCheck, !stillTrue() {
            coachTip = nil
            coachTipCheck = nil
        }
        checkAdsUnlock()

        revivalAccumulator += dt
        if revivalAccumulator >= 0.25 {
            updateRevival(dt: revivalAccumulator)
            revivalAccumulator = 0
        }
        progressAccumulator += dt
        if progressAccumulator >= 1 {
            updateEarningRate(faresThisSecond: max(0, stats.totalFares - lastFaresTotal))
            lastFaresTotal = stats.totalFares
            autosaveClock += progressAccumulator
            if autosaveClock >= 20 {
                autosaveClock = 0
                lastActive = Date()   // a crash never counts as time away
                autosave()   // reopening resumes mid-day, not at dawn
            }
            growFruit(dt: progressAccumulator)
            checkProgress()
            progressAccumulator = 0
        }
        hudAccumulator += dt
        if hudAccumulator >= 0.2 {
            refreshHUD()
            hudAccumulator = 0
        }
        if dayClock >= 1 {
            // The Gazette and the council come once a week; other days roll over quietly.
            if day % 7 == 0 { endDay() } else { rollDayQuietly() }
        }
    }

    /// Smoothly tracks how lively the town is: riders arriving and riders waiting both count.
    private func updateActivity(dt: Double) {
        deliveryPulse *= exp(-dt / 20)
        let waitingTotal = Double(waiting.values.reduce(0) { $0 + $1.count })
        let target = 0.5 * min(1, waitingTotal / 12) + 0.5 * min(1, deliveryPulse / 6)
        activity += (target - activity) * min(1, dt * 0.3)
    }

    // MARK: Spawning

    /// Riders set out a little more often each day of the term, so the week builds.
    private var dailyRamp: Double { 1 + 0.12 * Double(max(0, day - 1)) }

    /// Landmarks riders can use today: open, and not closed for an event.
    private var usableLandmarks: [Landmark] {
        openLandmarks.filter { !isStationClosed($0.id) }
    }

    private func spawn(dt: Double) {
        let open = usableLandmarks
        guard open.count >= 2 else { return }
        let phase = currentDayPhase
        let life = 0.6 + 0.8 * averageVitality
        // Settled districts count for half: they're calm and mostly run themselves.
        let weightedCount = open.reduce(0.0) { $0 + (isSettled($1.kind.info.district) ? 0.5 : 1) }
        let size = min(1.7, 0.7 + 0.06 * weightedCount)
        var rate = 0.4 * life * size * phase.intensity * dailyRamp * weatherToday.riderMultiplier
            * riderRateModifier(phase)
        if phase == .night && dayCard == .festivalOfLights { rate *= 2 }
        if festivalDistrictToday != nil { rate *= 1.15 }

        spawnAccumulator += dt * rate
        while spawnAccumulator >= 1 {
            spawnAccumulator -= 1
            spawnRider(phase: phase, open: open)
        }
    }

    private func spawnRider(phase: DayPhase, open: [Landmark]) {
        let originWeights = open.map { landmark -> Double in
            var base: Double
            switch landmark.kind.info.category {
            case .hub: base = 1.8 * visitorMultiplier
            case .canal: base = 0   // tunnel openings aren't stations
            default: base = 0.5 + 1.4 * vitality(at: landmark.cell)
            }
            if phase == .night && hasUpgrade(.lamps, at: landmark.id) { base *= 1.4 }
            return base * (isSettled(landmark.kind.info.district) ? 0.6 : 1)
        }
        guard let origin = pickWeighted(open, weights: originWeights) else { return }
        let home = origin.kind.info.district

        // Tourists from a canal quay head into any district the light rail reaches.
        if origin.kind.info.category == .canal {
            let reachable = Set(connectedDistricts(to: home) + [home])
            let sights = open.filter { reachable.contains($0.kind.info.district) && $0.kind.info.category != .hub
                && $0.kind.info.category != .canal }
            let weights = sights.map { destinationWeight($0, phase: phase) }
            if let destination = pickWeighted(sights, weights: weights) {
                addRider(from: origin, to: destination, crossDistrict: true)
            }
            return
        }

        // Some riders head to another district when light rail connects it; a citywide
        // festival pulls far more of them toward one district.
        let linked = connectedDistricts(to: home)
        var crossChance = 0.22
        if phase == .night && lightRailUpgrades.contains(.nightService) { crossChance *= 1.8 }
        if phase == .night && lightRailService == .nightOwl { crossChance *= 2 }
        var awayDistricts = linked
        if let festival = festivalDistrictToday, linked.contains(festival) {
            crossChance = 0.55
            awayDistricts = [festival]
        }
        let crossesOver = !linked.isEmpty && Double.random(in: 0..<1) < crossChance
        var candidates = open.filter { $0.id != origin.id && $0.kind.info.district == home && $0.kind.info.category != .canal }
        if crossesOver {
            let away = open.filter { awayDistricts.contains($0.kind.info.district) && $0.kind.info.category != .hub
                && $0.kind.info.category != .canal }
            if !away.isEmpty { candidates = away }
        }
        let destinationWeights = candidates.map { destination -> Double in
            var weight = destinationWeight(destination, phase: phase)
            if isPairTrip(from: origin.id, to: destination.id) { weight *= 1.6 }
            if crossesOver { weight *= serviceWeight(for: destination, phase: phase) }
            return weight
        }
        guard let destination = pickWeighted(candidates, weights: destinationWeights) else { return }
        addRider(from: origin, to: destination, crossDistrict: destination.kind.info.district != home)
    }

    /// The tutorial's first riders, so the first line is never empty.
    func spawnGuidedRiders(from originID: Int, to destinationID: Int) {
        guard let origin = landmark(id: originID), let destination = landmark(id: destinationID) else { return }
        addRider(from: origin, to: destination, crossDistrict: false)
        addRider(from: origin, to: destination, crossDistrict: false)
        addRider(from: destination, to: origin, crossDistrict: false)
    }

    private func addRider(from origin: Landmark, to destination: Landmark, crossDistrict: Bool) {
        guard waitingCount(at: origin.id) < maxWaiting(at: origin.id) else {
            satisfaction = max(0, satisfaction - 0.01)
            report.overcrowded += 1
            return
        }
        var patience = patience(near: origin)
        if crossDistrict { patience *= 1.6 }
        if crossDistrict && lightRailService == .theatreTrain && (currentDayPhase == .evening || currentDayPhase == .night) {
            patience *= 1.5
        }
        var rider = Rider(id: nextRiderID,
                          origin: origin.id,
                          destination: destination.id,
                          patience: patience,
                          isVisitor: origin.kind.info.category == .hub,
                          isCrossDistrict: crossDistrict)
        nextRiderID += 1
        updateRoute(&rider, at: origin.id)
        waiting[origin.id, default: []].append(rider)
    }

    private func destinationWeight(_ landmark: Landmark, phase: DayPhase) -> Double {
        let info = landmark.kind.info
        var weight = info.demand.weight(phase)
        if featuredToday == info.category { weight *= 1.4 }
        if dayCard == .marketDay && info.category == .food { weight *= 1.8 }
        if info.category == .nature { weight *= weatherToday.natureDemandMultiplier }
        if info.category == .food, streetMarketDistrictToday == info.district { weight *= 1.4 }
        weight *= categoryBoost(info.category)
        weight *= adMultiplier(for: landmark.id)
        return weight
    }

    var visitorMultiplier: Double {
        var multiplier = 1.0
        if hasCard(.tourismPosters) { multiplier *= 1.5 }
        if hasCard(.welcomeSigns) { multiplier *= 1.25 }
        if dayCard == .tourDay { multiplier *= 2 }
        if openLandmarks.contains(where: { $0.kind.info.perk == .visitors }) { multiplier *= 1.4 }
        return multiplier
    }

    private func patience(near origin: Landmark) -> Double {
        var value = 60.0 * weatherPatience * patienceModifier(at: origin.id)
        if isSettled(origin.kind.info.district) { value *= 2 }
        if hasCard(.benches) { value *= 1.3 }
        let calming = openLandmarks.contains { other in
            other.kind.info.perk == .patience &&
                max(abs(other.cell.col - origin.cell.col), abs(other.cell.row - origin.cell.row)) <= 2
        }
        if calming { value *= 1.3 }
        return value
    }

    private func pickWeighted<T>(_ items: [T], weights: [Double]) -> T? {
        let total = weights.reduce(0, +)
        guard total > 0, !items.isEmpty else { return nil }
        var roll = Double.random(in: 0..<total)
        for (item, weight) in zip(items, weights) {
            if roll < weight { return item }
            roll -= weight
        }
        return items.last
    }

    // MARK: Landmark pairs

    /// True if two landmarks are natural partners and share a line.
    func isPairTrip(from a: Int, to b: Int) -> Bool {
        guard let first = landmark(id: a)?.kind, let second = landmark(id: b)?.kind else { return false }
        guard first.info.pair == second || second.info.pair == first else { return false }
        return builtLines.contains { $0.stops.contains(a) && $0.stops.contains(b) }
    }

    // MARK: Waiting

    private func ageWaitingRiders(dt: Double) {
        for (stationID, queue) in waiting {
            var kept: [Rider] = []
            kept.reserveCapacity(queue.count)
            for var rider in queue {
                rider.waited += dt
                if rider.waited > rider.patience {
                    giveUp(at: stationID)
                    if let tripID = rider.tripID { tripRider(tripID, delivered: false) }
                } else {
                    kept.append(rider)
                    if rider.waited > report.longestWait {
                        report.longestWait = rider.waited
                        report.longestWaitStation = stationID
                    }
                }
            }
            waiting[stationID] = kept
        }
    }

    private func giveUp(at stationID: Int) {
        satisfaction += (0 - satisfaction) * 0.07
        stationHealth[stationID] = max(0, (stationHealth[stationID] ?? 0) - 0.08)
        report.gaveUp += 1
        report.gaveUpAt[stationID, default: 0] += 1
        stats.gaveUp += 1
        events.append(.gaveUp(stationID: stationID))
    }

    /// The most urgent rider at a station, as a fraction of their patience (0...1).
    func urgency(at stationID: Int) -> Double {
        guard let queue = waiting[stationID], !queue.isEmpty else { return 0 }
        return queue.map { min(1, $0.waited / $0.patience) }.max() ?? 0
    }

    // MARK: Trains

    /// Called by the scene when a train stops. The stretch it just ran wears a little; riders
    /// get off; then waiting riders decide whether this train is their fastest way onward.
    func trainArrived(trainID: Int, lineID: Int, at stationID: Int, from previousID: Int?) -> TrainExchange {
        var exchange = TrainExchange()
        trainLine[trainID] = lineID
        let arrivingLoad = onboard[trainID]?.count ?? 0
        guard !isStationClosed(stationID) else {
            exchange.load = arrivingLoad
            return exchange
        }

        var aboard: [Rider] = []
        for var rider in onboard[trainID] ?? [] {
            if rider.destination == stationID {
                exchange.fares += deliver(rider, at: stationID)
                exchange.delivered += 1
            } else if rider.alightAt == nil || rider.alightAt == stationID {
                rider.waited *= transferRelief(at: stationID)
                rider.alightAt = nil
                rider.transfers += 1
                rider.isTransferring = true
                updateRoute(&rider, at: stationID)
                waiting[stationID, default: []].append(rider)
                exchange.transferred += 1
            } else {
                aboard.append(rider)
            }
        }
        if exchange.transferred > 0 {
            report.transfers += exchange.transferred
            stats.transfers += exchange.transferred
            showTip("transfer", symbol: "arrow.triangle.swap", title: "Changing trains",
                    text: "Riders change trains at transit hubs. Every change adds $1 to their fare.")
        }

        var free = capacity(forLine: lineID) + extraSeats(trainID: trainID) - aboard.count
        if free > 0, let queue = waiting[stationID], !queue.isEmpty {
            var remaining: [Rider] = []
            for rider in queue.sorted(by: { $0.waited > $1.waited }) {
                if free > 0, let stop = boardingStop(for: rider, lineID: lineID, at: stationID) {
                    var boarding = rider
                    boarding.alightAt = stop
                    boarding.isTransferring = false
                    aboard.append(boarding)
                    free -= 1
                    exchange.boarded += 1
                } else {
                    remaining.append(rider)
                }
            }
            waiting[stationID] = remaining
        }
        if line(id: lineID)?.isLightRail == true {
            lightRailRiders += exchange.boarded
        }

        onboard[trainID] = aboard
        exchange.load = aboard.count
        return exchange
    }

    /// Riders on a removed train go back to the platform they were heading for.
    func trainRemoved(trainID: Int) {
        let riders = onboard[trainID] ?? []
        onboard[trainID] = nil
        trainLine[trainID] = nil
        for var rider in riders {
            let station = rider.alightAt.flatMap { landmark(id: $0)?.id } ?? rider.origin
            guard landmark(id: station) != nil else { continue }
            rider.alightAt = nil
            updateRoute(&rider, at: station)
            waiting[station, default: []].append(rider)
        }
    }

    func onboardCount(trainID: Int) -> Int {
        onboard[trainID]?.count ?? 0
    }

    private func deliver(_ rider: Rider, at stationID: Int) -> Int {
        let fare = fare(for: rider, at: stationID)
        fares += fare
        report.fares += fare
        stats.totalFares += fare
        stats.ridersServed += 1
        report.riders += 1
        recordVisit(at: stationID, from: rider.origin, fare: fare)
        addTip(at: stationID)
        if rider.spotlight != nil { spotlightArrived(rider) }
        checkCollection(at: stationID)
        deliveryPulse += 1
        countLetterDelivery(to: stationID)
        if let tripID = rider.tripID { tripRider(tripID, delivered: true) }
        if rider.isCrossDistrict {
            stats.crossDistrictRiders += 1
            report.crossDistrictRiders += 1
        }
        if currentDayPhase == .night {
            stats.nightRiders += 1
            report.nightRiders += 1
        }
        let gain = 0.014 * (dayCard == .freeFareDay ? 2 : 1) * (hasCard(.civicPride) ? 1.15 : 1)
        satisfaction += (1 - satisfaction) * gain
        recentTraffic[stationID, default: 0] += 1
        recentTraffic[rider.origin, default: 0] += 1
        report.traffic[stationID, default: 0] += 1
        report.traffic[rider.origin, default: 0] += 1
        if tutorial == .firstTrip {
            tutorial = .earnBlueprint
        }
        return fare
    }

    private func fare(for rider: Rider, at stationID: Int) -> Int {
        if dayCard == .freeFareDay { return 0 }
        var fare = 3 + (hasCard(.transferTickets) ? 0 : rider.transfers) + fareBonus
        if rider.isVisitor { fare += 1 }
        if isPairTrip(from: rider.origin, to: stationID) { fare += 1 }
        if dayCard == .marketDay, landmark(id: stationID)?.kind.info.category == .food { fare += 1 }
        if dayCard == .festivalOfLights, currentDayPhase == .night { fare *= 2 }
        if rider.isCrossDistrict { fare *= 2 }
        if lightRailService == .scenic, landmark(id: rider.origin)?.kind.info.category == .canal { fare = fare * 3 / 2 }
        return fare
    }

    // MARK: Route planning

    /// Seconds for a train to run between two stations, including the stop.
    private func legSeconds(_ a: GridPoint, _ b: GridPoint, speedFactor: Double) -> Double {
        let dc = abs(a.col - b.col), dr = abs(a.row - b.row)
        let diagonal = min(dc, dr), straight = max(dc, dr) - diagonal
        let points = (Double(straight) + Double(diagonal) * 1.414) * GameState.cellPoints
        return points / (GameState.trainSpeed * trainSpeedMultiplier * speedFactor) + GameState.dwellSeconds
    }

    /// Seconds from a line's first stop to each of its stops.
    private func stopTimes(for line: TransitLine) -> [Double] {
        let cells = line.stops.compactMap { landmark(id: $0)?.cell }
        guard cells.count == line.stops.count, !cells.isEmpty else { return [] }
        let factor = speedFactor(forLine: line.id)
        var times: [Double] = [0]
        for index in 1..<max(cells.count, 1) {
            times.append(times[index - 1] + legSeconds(cells[index - 1], cells[index], speedFactor: factor))
        }
        return times
    }

    /// The stretches of a line that trains can still run end to end: a closed stretch
    /// splits the line in two, and trains turn back on either side of it.
    func runs(of line: TransitLine) -> [ClosedRange<Int>] {
        guard line.stops.count >= 2 else { return [] }
        var result: [ClosedRange<Int>] = []
        var start = 0
        for index in 1..<line.stops.count where !isTrackOpen(lineID: line.id, line.stops[index - 1], line.stops[index]) {
            result.append(start...(index - 1))
            start = index
        }
        result.append(start...(line.stops.count - 1))
        return result
    }

    /// Expected seconds to reach `destination` from every connected station: waiting for a
    /// train (about half the time between trains), riding, and changing lines along the way.
    /// Closed track and closed stations are routed around.
    func travelMap(to destination: Int) -> [Int: Double] {
        if let cached = travelCache[destination] { return cached }

        var routes: [(stops: [Int], times: [Double], wait: Double)] = []
        for line in builtLines where isLinePowered(line.id) {
            let times = stopTimes(for: line)
            guard times.count == line.stops.count, let total = times.last else { continue }
            let roundTrip = 2 * total + 2 * GameState.dwellSeconds
            let wait = roundTrip / Double(max(1, trainCount(for: line.id))) / 2
            for run in runs(of: line) where run.count >= 2 {
                routes.append((stops: Array(line.stops[run]), times: Array(times[run]), wait: wait))
            }
        }

        var cost: [Int: Double] = [destination: 0]
        var settled: Set<Int> = []
        while let next = cost.filter({ !settled.contains($0.key) }).min(by: { $0.value < $1.value }) {
            settled.insert(next.key)
            // Riders only change lines at a hub: from anywhere else, the only way on is the
            // line that runs straight to the destination.
            guard next.key == destination || isTransferPoint(next.key) else { continue }
            for route in routes {
                guard let here = route.stops.firstIndex(of: next.key) else { continue }
                for (index, stop) in route.stops.enumerated() where index != here && !settled.contains(stop) {
                    guard !isStationClosed(stop) else { continue }
                    let candidate = next.value + abs(route.times[index] - route.times[here]) + route.wait
                    if candidate < (cost[stop] ?? .infinity) {
                        cost[stop] = candidate
                    }
                }
            }
        }
        travelCache[destination] = cost
        return cost
    }

    /// Where a rider at `stationID` should get off if they board this train, or nil if they
    /// should let it go. They board when it's about as fast as their best plan, or any
    /// train that gets them closer once their patience is running low.
    private func boardingStop(for rider: Rider, lineID: Int, at stationID: Int) -> Int? {
        guard isLinePowered(lineID), let route = self.line(id: lineID), route.stops.count >= 2,
              let here = route.stops.firstIndex(of: stationID),
              let run = runs(of: route).first(where: { $0.contains(here) }) else { return nil }
        let travel = travelMap(to: rider.destination)
        guard let current = travel[stationID] else { return nil }
        let times = stopTimes(for: route)
        guard times.count == route.stops.count else { return nil }

        var bestStop: Int?
        var bestTotal = Double.infinity
        for index in run where index != here {
            let stop = route.stops[index]
            guard !isStationClosed(stop), let remaining = travel[stop], remaining < current else { continue }
            // Get off early only to change lines at a hub (or at the destination itself).
            guard stop == rider.destination || isTransferPoint(stop) else { continue }
            let total = abs(times[index] - times[here]) + remaining
            if total < bestTotal {
                bestTotal = total
                bestStop = stop
            }
        }
        guard let stop = bestStop else { return nil }
        let isUrgent = rider.waited / rider.patience > 0.6
        return (bestTotal <= current + 8 || isUrgent) ? stop : nil
    }

    func updateRoute(_ rider: inout Rider, at stationID: Int) {
        rider.hasRoute = travelMap(to: rider.destination)[stationID] != nil
    }

    /// Re-plans everyone after the network changes shape.
    func networkChanged() {
        travelCache.removeAll()
        // Two lines sharing a station that isn't a hub: riders can't change there.
        if let shared = landmarks.first(where: { $0.kind.info.category != .hub && $0.kind != .tunnelPortal
            && subwayLinesServing($0.id).count >= 2 }) {
            let sharedID = shared.id
            showTip("hub-needed", symbol: "arrow.triangle.swap", title: "Riders can't change lines here",
                    text: "Only transit hubs let riders change lines. Build a hub in Blueprints where your lines cross.",
                    stillTrue: { [weak self] in (self?.subwayLinesServing(sharedID).count ?? 0) >= 2 })
        }
        for (stationID, queue) in waiting {
            waiting[stationID] = queue.map { rider in
                var updated = rider
                updateRoute(&updated, at: stationID)
                return updated
            }
        }
        let built = builtLines
        for (trainID, riders) in onboard {
            guard let lineID = trainLine[trainID], let route = built.first(where: { $0.id == lineID }) else { continue }
            onboard[trainID] = riders.map { rider in
                var updated = rider
                if let stop = updated.alightAt, !route.stops.contains(stop) {
                    updated.alightAt = nil // get off at the next stop and re-plan there
                }
                return updated
            }
        }
    }

    /// Waiting riders with no route yet, grouped by trip. Drawn as wish lines on the map.
    func unservedWishes() -> [(origin: Int, destination: Int, count: Int)] {
        var counts: [Int: [Int: Int]] = [:]
        for (stationID, queue) in waiting {
            for rider in queue where !rider.hasRoute {
                counts[stationID, default: [:]][rider.destination, default: 0] += 1
            }
        }
        var result: [(origin: Int, destination: Int, count: Int)] = []
        for (origin, destinations) in counts {
            for (destination, count) in destinations {
                result.append((origin: origin, destination: destination, count: count))
            }
        }
        return result.sorted { ($0.origin, $0.destination) < ($1.origin, $1.destination) }
    }
}
