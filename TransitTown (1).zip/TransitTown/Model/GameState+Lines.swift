import Foundation

extension GameState {

    // MARK: Line availability
    // Each district has its own pens (Red, Blue, Green, Gold), and earns them on its own:
    // Old Town starts with two, every later district with one. More open up as that
    // district revives. Subway lines stay inside their district; only light rail crosses.

    /// How many lines a district can run right now.
    func lineSlots(in district: District) -> Int {
        // Lines are citywide: the town's opened lines can go anywhere.
        min(Palette.lineCount, openedLines)
    }

    /// The revival a district needed to earn its nth line (for messages).
    func lineThreshold(for slots: Int, in district: District) -> Double {
        let steps: [Double] = district == .oldTown ? [0.30, 0.55] : [0.20, 0.40, 0.60]
        let base = (district == .oldTown ? 2 : 1) + (bonusLines[district] ?? 0)
        let index = max(0, min(steps.count - 1, slots - base - 1))
        return steps[index]
    }

    func hasFreeLine(in district: District) -> Bool {
        (0..<lineSlots(in: district)).contains { line(colorIndex: $0, in: district) == nil }
    }

    func isLineUnlocked(colorIndex: Int, in district: District) -> Bool {
        colorIndex < lineSlots(in: district)
    }

    /// What it takes to open a line color in a district, for the menu.
    func lineUnlockHint(colorIndex: Int, in district: District) -> String {
        let index = colorIndex - 2
        guard index >= 0, index < GameState.lineMilestones.count else { return "the town grows" }
        return "the town is \(Int(GameState.lineMilestones[index] * 100))% revived"
    }

    func lineLockedMessage(in district: District) -> String {
        lineSlots(in: district) < Palette.lineCount
            ? "Every open line is in use. Revive more of the town to earn another."
            : "All \(Palette.lineCount) lines are in use"
    }

    // MARK: Pens

    /// Picks up an unbuilt line's pen: the next line drawn from a station uses this color.
    func armColor(_ colorIndex: Int) {
        guard isLineUnlocked(colorIndex: colorIndex, in: focusedDistrict),
              line(colorIndex: colorIndex, in: focusedDistrict) == nil else { return }
        armedColorIndex = armedColorIndex == colorIndex ? nil : colorIndex
        selectedLineID = nil
        placingKind = nil
        if armedColorIndex != nil {
            show("Drag from any station to start the \(Palette.lineNames[colorIndex])")
        }
        changed()
    }

    // MARK: Subway lines

    /// Starts a new line at a landmark, in its district, in the armed color if one was picked up.
    func startLine(at landmarkID: Int) -> Int? {
        guard let start = landmark(id: landmarkID), !isStationFull(landmarkID) else { return nil }
        let district = start.kind.info.district
        let free = (0..<lineSlots(in: district)).filter { line(colorIndex: $0, in: district) == nil }
        let preferred = armedColorIndex.flatMap { free.contains($0) ? $0 : nil }
        guard let colorIndex = preferred ?? free.first else { return nil }
        armedColorIndex = nil
        let id = makeID()
        lines.append(TransitLine(id: id, colorIndex: colorIndex, district: district, stops: [landmarkID]))
        trainsPerLine[id] = 1
        selectedLineID = id
        changed()
        return id
    }

    /// True if a landmark can join this line: subway lines stay in their district,
    /// and the light rail only stops at hubs.
    func canJoin(_ landmarkID: Int, line: TransitLine) -> Bool {
        guard let target = landmark(id: landmarkID) else { return false }
        // A building site can't take a track until the shop has opened.
        if target.isUnderConstruction { return false }
        if line.isLightRail { return false }
        // Tunnel openings join only as part of digging (or a finished tunnel, shared by lines).
        if target.kind == .tunnelPortal {
            if let step = tunnelStep, case let .connectIn(lineID, entrance, _) = step {
                return lineID == line.id && landmarkID == entrance
            }
            return target.tunnelComplete == true
        }
        return target.kind.info.category != .canal
    }

    @discardableResult
    func addStop(_ landmarkID: Int, to lineID: Int, atTail: Bool) -> Bool {
        guard let index = lines.firstIndex(where: { $0.id == lineID }),
              !lines[index].stops.contains(landmarkID),
              canJoin(landmarkID, line: lines[index]),
              landmark(id: landmarkID)?.kind == .tunnelPortal || !isStationFull(landmarkID, ignoring: lineID) else { return false }
        // Finishing a tunnel (out of its exit to a landmark) is when it's paid for.
        if case let .connectOut(stepLine, _, exit) = tunnelStep, stepLine == lineID,
           (atTail ? lines[index].stops.last : lines[index].stops.first) == exit,
           landmark(id: landmarkID)?.kind != .tunnelPortal, !canAfford(GameState.tunnelCost) {
            show("Finishing the tunnel costs $\(GameState.tunnelCost)")
            return false
        }
        // Water between neighborhoods needs a tunnel.
        if let end = atTail ? lines[index].stops.last : lines[index].stops.first, crossesWater(end, landmarkID) {
            show("There's water in the way. Buy a tunnel to cross it.")
            return false
        }
        // A shared tunnel takes two trains at most.
        if atTail {
            lines[index].stops.append(landmarkID)
        } else {
            lines[index].stops.insert(landmarkID, at: 0)
        }
        // Into a tunnel: the line comes straight out of its other end.
        if let portal = landmark(id: landmarkID), portal.kind == .tunnelPortal, let other = portal.portalPair,
           !lines[index].stops.contains(other) {
            if atTail { lines[index].stops.append(other) } else { lines[index].stops.insert(other, at: 0) }
            if case let .connectIn(stepLine, entrance, exit) = tunnelStep, stepLine == lineID {
                tunnelStep = .connectOut(lineID: lineID, entrance: entrance, exit: exit)
            }
        } else {
            completeTunnelIfReady(lineID: lineID)
        }
        let stops = lines[index].stops
        if stops.count == 2, !report.linesOpened.contains(lineID) {
            report.linesOpened.append(lineID)
            if tutorial == .drawLine {
                tutorial = .firstTrip
                spawnGuidedRiders(from: stops[0], to: stops[1])
            }
        }
        if lines[index].isLightRail {
            report.lightRailOpened = true
        }
        networkChanged()
        changed()
        return true
    }

    func removeEndStop(of lineID: Int, atTail: Bool) {
        guard let index = lines.firstIndex(where: { $0.id == lineID }), lines[index].stops.count > 1 else { return }
        if atTail {
            lines[index].stops.removeLast()
        } else {
            lines[index].stops.removeFirst()
        }
        networkChanged()
        changed()
    }

    @discardableResult
    func insertStop(_ landmarkID: Int, into lineID: Int, at position: Int) -> Bool {
        guard let index = lines.firstIndex(where: { $0.id == lineID }),
              !lines[index].stops.contains(landmarkID),
              canJoin(landmarkID, line: lines[index]),
              lines[index].isLightRail || !isStationFull(landmarkID, ignoring: lineID) else { return false }
        // A quay added mid-route only costs the detour, which is small; charge a flat fee.
        if lines[index].isLightRail {
            guard canAfford(40) else {
                show("A light rail stop costs $40")
                return false
            }
            fares -= 40
        }
        lines[index].stops.insert(landmarkID, at: min(max(position, 0), lines[index].stops.count))
        networkChanged()
        changed()
        return true
    }

    func deleteLine(_ id: Int) {
        lines.removeAll { $0.id == id }
        trainsPerLine[id] = nil
        if selectedLineID == id { selectedLineID = nil }
        networkChanged()
        changed()
    }

    func setSelectedLine(_ id: Int?) {
        guard selectedLineID != id else { return }
        // Putting the line down before the tunnel reaches a landmark fills it back in, free.
        if let step = tunnelStep, step.lineID != id { cancelTunnel() }
        selectedLineID = id
        if id != nil { armedColorIndex = nil }
        changed()
    }

    func toggleLineSelection(_ id: Int) {
        selectedLineID = (selectedLineID == id) ? nil : id
        placingKind = nil
        armedColorIndex = nil
        changed()
    }

    // MARK: Light rail

    /// Connects two district hubs by light rail: starts the light rail, or extends it from
    /// whichever end one of the hubs is on. Returns the light rail's id, or nil if it can't.
    @discardableResult
    /// Light rail is priced by distance: hubs farther apart cost more to link.
    func lightRailCost(_ a: Int, _ b: Int) -> Int {
        guard let first = landmark(id: a)?.cell, let second = landmark(id: b)?.cell else { return 0 }
        return 8 * max(abs(first.col - second.col), abs(first.row - second.row))
    }

    /// Pays for a stretch of light rail, or explains what it costs.
    private func payForLightRail(_ a: Int, _ b: Int) -> Bool {
        let cost = lightRailCost(a, b)
        guard canAfford(cost) else {
            show("That stretch of light rail costs $\(cost)")
            return false
        }
        fares -= cost
        show("Light rail laid: $\(cost)")
        return true
    }

    func connectHubs(_ a: Int, _ b: Int) -> Int? {
        guard a != b,
              let first = landmark(id: a), let second = landmark(id: b),
              first.kind.info.category == .hub, second.kind.info.category == .hub else { return nil }
        if let rail = lightRail, rail.stops.contains(a) && rail.stops.contains(b) { return rail.id }
        guard payForLightRail(a, b) else { return nil }

        guard let rail = lightRail, let index = lines.firstIndex(where: { $0.id == rail.id }) else {
            let id = makeID()
            lines.append(TransitLine(id: id, colorIndex: TransitLine.lightRailIndex,
                                     district: first.kind.info.district, stops: [a, b]))
            trainsPerLine[id] = 1
            report.lightRailOpened = true
            selectedLineID = id
            networkChanged()
            changed()
            return id
        }

        let stops = lines[index].stops
        if stops.contains(a) && stops.contains(b) { return rail.id }
        if stops.last == a && !stops.contains(b) {
            lines[index].stops.append(b)
        } else if stops.first == a && !stops.contains(b) {
            lines[index].stops.insert(b, at: 0)
        } else if stops.last == b && !stops.contains(a) {
            lines[index].stops.append(a)
        } else if stops.first == b && !stops.contains(a) {
            lines[index].stops.insert(a, at: 0)
        } else {
            show("Extend the light rail from one of its ends")
            return nil
        }
        report.lightRailOpened = true
        networkChanged()
        changed()
        return rail.id
    }

    /// Districts linked to this one by light rail.
    /// Neighborhoods joined to this one by the network (lines through tunnels).
    func connectedDistricts(to district: District) -> [District] {
        var reached: Set<District> = [district]
        var changedSet = true
        while changedSet {
            changedSet = false
            for line in builtLines {
                let here = Set(line.stops.compactMap { self.district(ofStop: $0) })
                if !here.isDisjoint(with: reached) && !here.isSubset(of: reached) {
                    reached.formUnion(here)
                    changedSet = true
                }
            }
        }
        reached.remove(district)
        return Array(reached)
    }

    // MARK: Trains

    func trainCount(for lineID: Int) -> Int {
        trainsPerLine[lineID] ?? 1
    }

    var nextTrainCost: Int {
        if freeTrainAvailable { return 0 }
        return max(20, 60 + 30 * stats.trainsBought - (hasCard(.rollingStockDeal) ? 20 : 0))
    }

    func canAddTrain(to lineID: Int) -> Bool {
        line(id: lineID) != nil && trainCount(for: lineID) < GameState.maxTrainsPerLine && canAfford(nextTrainCost)
            && !tunnelBlocksTrain(on: lineID)
    }

    func addTrain(to lineID: Int) {
        guard let route = self.line(id: lineID) else { return }
        guard !tunnelBlocksTrain(on: lineID) else {
            show("Only two trains fit through a tunnel")
            return
        }
        guard trainCount(for: lineID) < GameState.maxTrainsPerLine else {
            show("The \(route.name) already has \(GameState.maxTrainsPerLine) trains")
            return
        }
        guard canAfford(nextTrainCost) else {
            show("A new train costs $\(nextTrainCost)")
            return
        }
        fares -= nextTrainCost
        if freeTrainAvailable {
            freeTrainAvailable = false
        } else {
            stats.trainsBought += 1
        }
        trainsPerLine[lineID] = trainCount(for: lineID) + 1
        networkChanged() // shorter waits change the best routes
        show("New train on the \(route.name)")
        changed()
        if tutorial == .addTrain && trainCount(for: lineID) >= 2 { finishTutorial(skipped: false) }
    }

    /// Riders a train can carry. Light rail trains are longer, and longer still with the upgrade.
    func capacity(forLine lineID: Int) -> Int {
        let isRail = line(id: lineID)?.isLightRail == true
        var base = isRail ? (lightRailUpgrades.contains(.longerCars) ? 18 : 12) : GameState.baseCapacity
        if isRail && lightRailService == .freightHour { base -= 4 }
        if !isRail && hasCard(.quietCarriages) { base -= 1 }
        return base + (hasCard(.longerTrains) ? 2 : 0)
    }

    /// The light rail is the slow, steady workhorse: three-quarters of subway speed,
    /// or full speed once Express Service is bought.
    func speedFactor(forLine lineID: Int) -> Double {
        guard line(id: lineID)?.isLightRail == true else { return 1 }
        let wind = hasCard(.weatherWatch) ? 1 - (1 - weatherToday.lightRailSpeedMultiplier) / 2 : weatherToday.lightRailSpeedMultiplier
        let scenic = lightRailService == .scenic ? 0.6 : 1
        return (lightRailUpgrades.contains(.expressService) ? 1 : 0.75) * wind * scenic
    }

    var trainSpeedMultiplier: Double {
        var multiplier = weatherToday.trainSpeedMultiplier
        if hasCard(.expressTimetable) { multiplier *= 1.15 }
        if openLandmarks.contains(where: { $0.kind.info.perk == .trainSpeed }) { multiplier *= 1.15 }
        return multiplier
    }
}
