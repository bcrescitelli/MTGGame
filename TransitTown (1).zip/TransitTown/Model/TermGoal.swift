import Foundation

/// One of the three goals for a term. Each met goal earns a ribbon at the term review.
enum TermGoal: Equatable, Codable {
    /// The town rating when the term ends, not the best it ever reached.
    case ratingAtEnd(Double)
    case riders(Int)
    case heritage(District)
    case revived(District, Double)
    case crossDistrictRiders(Int)
    case landmarks(District, Int)

    /// Each term opens a district, and its goals are built around it.
    static func goals(forTerm term: Int, district: District) -> [TermGoal] {
        switch district {
        case .oldTown: return [.ratingAtEnd(3.5), .riders(300), .landmarks(.oldTown, 10)]
        case .harborside: return [.ratingAtEnd(3.6), .crossDistrictRiders(50), .heritage(.harborside)]
        case .hillQuarter: return [.ratingAtEnd(3.8), .revived(.hillQuarter, 0.5), .heritage(.hillQuarter)]
        case .lanternRow: return [.ratingAtEnd(4.0), .riders(520), .heritage(.lanternRow)]
        }
    }

    var symbol: String {
        switch self {
        case .ratingAtEnd: return "star.fill"
        case .riders: return "person.2.fill"
        case .heritage: return "building.columns.fill"
        case .revived: return "paintbrush.fill"
        case .crossDistrictRiders: return "tram.fill"
        case .landmarks: return "map.fill"
        }
    }

    static func gradeTitle(ribbons: Int) -> String {
        switch ribbons {
        case 3: return "A Town Reborn"
        case 2: return "A Town on the Rise"
        case 1: return "A Town Waking Up"
        default: return "Quiet Beginnings"
        }
    }

    static func gradeLine(ribbons: Int, town: String) -> String {
        switch ribbons {
        case 3: return "\(town) hums from first train to last. People who left are moving back."
        case 2: return "\(town) is brighter than anyone remembers, and neighbors are meeting on the platforms."
        case 1: return "The trains are running and people have noticed. The town is finding its feet."
        default: return "The trains are back, and that's how every good town starts. There's no hurry."
        }
    }
}
