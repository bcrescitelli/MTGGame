import UIKit

/// The city grows one district per term. Each has its own hub, look, landmarks,
/// heritage site, and busiest time of day.
enum District: Int, CaseIterable, Identifiable, Codable {
    // The city is a 2×2 grid of districts with canals crossing between them:
    //   Old Town (northwest)    | Harborside (northeast, on the coast)
    //   ------------------------+-------------------------------------
    //   Hill Quarter (southwest) | Lantern Row (southeast)

    /// 0 for the western districts, 1 for the eastern ones.
    var blockCol: Int {
        switch self {
        case .oldTown, .hillQuarter: return 0
        case .harborside, .lanternRow: return 1
        }
    }

    /// 1 for the northern districts, 0 for the southern ones (rows count up from the bottom).
    var blockRow: Int {
        switch self {
        case .oldTown, .harborside: return 1
        case .hillQuarter, .lanternRow: return 0
        }
    }

    case oldTown, harborside, hillQuarter, lanternRow

    var id: Int { rawValue }

    /// The term in which this district opens.
    var term: Int { rawValue + 1 }

    var name: String {
        switch self {
        case .oldTown: return "Old Town"
        case .harborside: return "Harborside"
        case .hillQuarter: return "Hill Quarter"
        case .lanternRow: return "Lantern Row"
        }
    }

    var rhythm: String {
        switch self {
        case .oldTown: return "Busiest in the mornings"
        case .harborside: return "Busiest at dawn and dusk"
        case .hillQuarter: return "Busiest around midday"
        case .lanternRow: return "Busiest in the evening and after dark"
        }
    }

    var look: String {
        switch self {
        case .oldTown: return "Warm brick and terracotta rooftops"
        case .harborside: return "Slate blue, whitewash, and striped awnings"
        case .hillQuarter: return "Sage gardens and stone terraces"
        case .lanternRow: return "Deep plum facades under hanging lanterns"
        }
    }

    var hub: LandmarkKind {
        switch self {
        case .oldTown: return .central
        case .harborside: return .harborStation
        case .hillQuarter: return .hilltopStation
        case .lanternRow: return .lanternStation
        }
    }

    var accent: UIColor {
        switch self {
        case .oldTown: return UIColor(hex: 0xC8714E)
        case .harborside: return UIColor(hex: 0x5D7FA3)
        case .hillQuarter: return UIColor(hex: 0x7E9A6C)
        case .lanternRow: return UIColor(hex: 0x7A4E8C)
        }
    }

    /// Colors a block returns to as it revives, and how the district's blocks are mixed.
    var homeColors: [UInt32] {
        switch self {
        case .oldTown: return [0xEDC6A3, 0xE7B6A0, 0xEFD6A2, 0xE3B49A]
        case .harborside: return [0xC9D6E3, 0xE4E8EC, 0xB9CCDD, 0xD8E1E8]
        case .hillQuarter: return [0xD5DEC3, 0xE3DCC8, 0xCBD8BE, 0xE6E0D2]
        case .lanternRow: return [0xD9C3DE, 0xE6C4CF, 0xCDB6D6, 0xE8D3C4]
        }
    }

    var shopColors: [UInt32] {
        switch self {
        case .oldTown: return [0xF0CF95, 0xE9B88E]
        case .harborside: return [0xF2D7A6, 0xE9C2B0]
        case .hillQuarter: return [0xEAD9B0, 0xDCCFAE]
        case .lanternRow: return [0xF0C98F, 0xE8B3A0]
        }
    }

    var parkColor: UInt32 {
        switch self {
        case .oldTown: return 0xC3D9A0
        case .harborside: return 0xC8DCC0
        case .hillQuarter: return 0xB8D49A
        case .lanternRow: return 0xC9D7A8
        }
    }

    var plazaColor: UInt32 {
        switch self {
        case .oldTown: return 0xF1E7CF
        case .harborside: return 0xE8EEF2
        case .hillQuarter: return 0xECE6D6
        case .lanternRow: return 0xEFE2D8
        }
    }

    /// Percent of blocks that are parks, plazas, and shops (the rest are homes).
    var blockMix: (park: Int, plaza: Int, shops: Int) {
        switch self {
        case .oldTown: return (10, 6, 28)
        case .harborside: return (6, 16, 26)
        case .hillQuarter: return (22, 6, 18)
        case .lanternRow: return (6, 8, 40)
        }
    }

    var next: District? { District(rawValue: rawValue + 1) }
    var previous: District? { District(rawValue: rawValue - 1) }

    var symbol: String {
        switch self {
        case .oldTown: return "building.2.fill"
        case .harborside: return "water.waves"
        case .hillQuarter: return "mountain.2.fill"
        case .lanternRow: return "moon.stars.fill"
        }
    }
}
