import Foundation

/// Decorations the mayor can buy and set down around town.
enum DecorKind: String, Codable, CaseIterable, Identifiable {
    case tree, bench, lamp, planter, mailbox
    // Unlocked by comment-card collections.
    case cafeTable, littleLibrary, birdBath, noticeBoard, wishingWell, stationClock, statue
    // Unlocked by a particular landmark's comment cards.
    case pumpkins, picnicBlanket, breadCart, coffeeCart, bookBench, hopscotch, flowerBarrow, rockingHorse, sundial, catTree, lobsterPots, fishFountain, anchor, barrelStack, giantCone, duckPond, telescope, popcornCart, crystalBall, candleLantern

    static let everyday: [DecorKind] = [.tree, .bench, .lamp, .planter, .mailbox]
    var isThemed: Bool { !DecorKind.everyday.contains(self) }

    var id: String { rawValue }

    var title: String {
        switch self {
        case .tree: return "Tree"
        case .bench: return "Bench"
        case .lamp: return "Lamp Post"
        case .planter: return "Flower Planter"
        case .mailbox: return "Post Box"
        case .cafeTable: return "Café Table"
        case .littleLibrary: return "Little Library"
        case .birdBath: return "Bird Bath"
        case .noticeBoard: return "Notice Board"
        case .wishingWell: return "Wishing Well"
        case .stationClock: return "Station Clock"
        case .statue: return "Statue"
        case .pumpkins: return "Pumpkins"
        case .picnicBlanket: return "Picnic Blanket"
        case .breadCart: return "Bread Cart"
        case .coffeeCart: return "Coffee Cart"
        case .bookBench: return "Book Bench"
        case .hopscotch: return "Hopscotch"
        case .flowerBarrow: return "Flower Barrow"
        case .rockingHorse: return "Rocking Horse"
        case .sundial: return "Sundial"
        case .catTree: return "Cat Tree"
        case .lobsterPots: return "Lobster Pots"
        case .fishFountain: return "Fish Fountain"
        case .anchor: return "Anchor"
        case .barrelStack: return "Barrel Stack"
        case .giantCone: return "Giant Cone"
        case .duckPond: return "Duck Pond"
        case .telescope: return "Telescope"
        case .popcornCart: return "Popcorn Cart"
        case .crystalBall: return "Crystal Ball"
        case .candleLantern: return "Candle Lantern"
        }
    }

    var cost: Int {
        switch self {
        case .tree: return 15
        case .bench: return 20
        case .planter: return 25
        case .lamp: return 30
        case .mailbox: return 35
        case .cafeTable, .birdBath: return 40
        case .littleLibrary, .noticeBoard: return 45
        case .wishingWell, .stationClock: return 50
        case .statue: return 60
        case .pumpkins: return 35
        case .picnicBlanket: return 40
        case .breadCart: return 45
        case .coffeeCart: return 45
        case .bookBench: return 40
        case .hopscotch: return 30
        case .flowerBarrow: return 40
        case .rockingHorse: return 45
        case .sundial: return 50
        case .catTree: return 40
        case .lobsterPots: return 40
        case .fishFountain: return 60
        case .anchor: return 50
        case .barrelStack: return 35
        case .giantCone: return 50
        case .duckPond: return 60
        case .telescope: return 55
        case .popcornCart: return 45
        case .crystalBall: return 50
        case .candleLantern: return 45
        }
    }
}

enum Fruit: Int, Codable, CaseIterable {
    case apple, orange, lemon, plum

    var name: String {
        switch self {
        case .apple: return "apples"
        case .orange: return "oranges"
        case .lemon: return "lemons"
        case .plum: return "plums"
        }
    }
}

/// A placed decoration. Decorations sit on a finer grid than landmarks: `spot` counts in half
/// squares, so they can stand in the middle of a square or on the streets between squares.
/// Older saves only have `cell`, which maps to the middle of that square.
struct Decor: Codable, Identifiable {
    let id: Int
    let kind: DecorKind
    var cell: GridPoint
    var spot: GridPoint?
    var fruit: Fruit = .apple
    var ripe = 0

    /// Position in half squares: the middle of square (c, r) is (2c + 1, 2r + 1).
    var position: GridPoint { spot ?? GridPoint(col: cell.col * 2 + 1, row: cell.row * 2 + 1) }
}

extension GameState {

    static let maxFruit = 3
    /// Riders carried before the City Planning Office opens decorating.
    static let decorUnlockRiders = 60

    var isDecorating: Bool { placingDecor != nil || removingDecor }

    /// The square a half-square spot belongs to.
    func cell(ofSpot spot: GridPoint) -> GridPoint {
        GridPoint(col: Int(floor(Double(spot.col) / 2)), row: Int(floor(Double(spot.row) / 2)))
    }

    /// The decoration on a square's middle (older code paths).
    func decor(at cell: GridPoint) -> Decor? {
        decor(near: GridPoint(col: cell.col * 2 + 1, row: cell.row * 2 + 1), within: 0)
    }

    /// The nearest decoration to a spot, within a distance in half squares.
    func decor(near spot: GridPoint, within reach: Int = 1) -> Decor? {
        decorItems
            .map { ($0, max(abs($0.position.col - spot.col), abs($0.position.row - spot.row))) }
            .filter { $0.1 <= reach }
            .min { $0.1 < $1.1 }?.0
    }

    /// Decorations can go anywhere in an open district except on a landmark's lot or on
    /// another decoration. They never affect tracks.
    func canPlace(atSpot spot: GridPoint) -> Bool {
        let cell = cell(ofSpot: spot)
        guard let district = district(at: cell), isOpened(district) else { return false }
        let onLot = landmarks.contains { landmark in
            max(abs(landmark.cell.col * 2 + 1 - spot.col), abs(landmark.cell.row * 2 + 1 - spot.row)) <= 2
        }
        return !onLot && decor(near: spot, within: 0) == nil && !riverCells.contains(cell)
    }

    @discardableResult
    func place(_ kind: DecorKind, atSpot spot: GridPoint) -> Bool {
        guard canPlace(atSpot: spot) else {
            show(decor(near: spot, within: 0) != nil ? "Something's already there"
                 : (district(at: cell(ofSpot: spot)).map(isOpened) == true ? "That's a landmark's lot" : "Decorations go on open ground in town"))
            return false
        }
        guard canAfford(kind.cost) else {
            show("A \(kind.title.lowercased()) costs $\(kind.cost)")
            return false
        }
        fares -= kind.cost
        let fruit = Fruit(rawValue: decorItems.filter { $0.kind == .tree }.count % Fruit.allCases.count) ?? .apple
        decorItems.append(Decor(id: nextDecorID, kind: kind, cell: cell(ofSpot: spot), spot: spot, fruit: fruit))
        nextDecorID += 1
        changed()
        return true
    }

    @discardableResult
    func removeDecor(near spot: GridPoint) -> Bool {
        guard let item = decor(near: spot) else {
            show("Tap a decoration to remove it")
            return false
        }
        decorItems.removeAll { $0.id == item.id }
        changed()
        return true
    }

    /// A new or moved landmark clears any decorations standing on its lot.
    func clearDecor(around cell: GridPoint) {
        let before = decorItems.count
        decorItems.removeAll { max(abs(cell.col * 2 + 1 - $0.position.col), abs(cell.row * 2 + 1 - $0.position.row)) <= 2 }
        if decorItems.count != before { changed() }
    }

    func startDecorating(_ kind: DecorKind) {
        placingDecor = kind
        removingDecor = false
        placingKind = nil
        setSelectedLine(nil)
        armedColorIndex = nil
    }

    func startRemovingDecor() {
        placingDecor = nil
        removingDecor = true
    }

    func stopDecorating() {
        placingDecor = nil
        removingDecor = false
    }

    func growFruit(dt: Double) {
        var grew = false
        for index in decorItems.indices where decorItems[index].kind == .tree && decorItems[index].ripe < GameState.maxFruit {
            if Double.random(in: 0..<1) < dt / 30 {
                decorItems[index].ripe += 1
                grew = true
            }
        }
        if grew { changed() }
    }

    func shakeTree(id: Int) -> Int {
        guard let index = decorItems.firstIndex(where: { $0.id == id && $0.kind == .tree }) else { return 0 }
        let fallen = decorItems[index].ripe
        decorItems[index].ripe = 0
        if fallen > 0 { changed() }
        return fallen
    }

    // MARK: Unlocking decorating, and the City Planning Office's call

    /// Decorating opens once the town is moving; the head of City Planning rings to say so.
    func checkDecorUnlock() {
        guard !decorUnlocked else { return }
        if stats.ridersServed >= GameState.decorUnlockRiders || termNumber > 1 || !decorItems.isEmpty {
            decorUnlocked = true
        }
    }

    func answerFeatureCall() {
        ringingFeature = false
        featureCallOpen = true
        decorAnnounced = true
    }

    /// "Show me": close the call, open the menu, and point at the decorating pen.
    func showMeDecor() {
        featureCallOpen = false
        newsCooldown = GameState.callCooldown
        hushAfterCall()
        dockOpenRequest = true
        decorSpotlight = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 8) { [weak self] in
            self?.decorSpotlight = false
        }
    }
}
