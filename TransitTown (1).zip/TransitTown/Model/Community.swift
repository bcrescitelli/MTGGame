import Foundation

// MARK: - Themed decorations from comment-card collections

/// When a place's comment cards fill its box, its regulars chip in for a decoration in its style.
enum Collections {
    /// Comment cards a place needs before its regulars chip in.
    static let cardsNeeded = 8

    /// Twenty landmarks have a decoration of their own; the rest share their category's.
    static let special: [LandmarkKind: DecorKind] = [
        .hauntedHouse: .pumpkins,
        .teaRoom: .picnicBlanket,
        .bakery: .breadCart,
        .cafe: .coffeeCart,
        .library: .bookBench,
        .school: .hopscotch,
        .flowerStall: .flowerBarrow,
        .toyShop: .rockingHorse,
        .clockTower: .sundial,
        .catCafe: .catTree,
        .fishMarket: .lobsterPots,
        .aquarium: .fishFountain,
        .chowderHouse: .anchor,
        .sailorsPub: .barrelStack,
        .iceCreamKiosk: .giantCone,
        .park: .duckPond,
        .observatory: .telescope,
        .cinema: .popcornCart,
        .fortuneTeller: .crystalBall,
        .church: .candleLantern,
    ]

    static func decor(for kind: LandmarkKind) -> DecorKind {
        if let own = special[kind] { return own }
        if kind.info.isHeritage { return .statue }
        switch kind.info.category {
        case .food: return .cafeTable
        case .culture: return .littleLibrary
        case .nature: return .birdBath
        case .civic: return .noticeBoard
        case .spiritual: return .wishingWell
        case .hub, .canal: return .stationClock
        }
    }
}

// MARK: - Lost and found

/// One-off calls: something's been lost somewhere in town, and you find it on the map.
struct LostItem {
    let id: String
    let sender: String
    let role: String
    let item: String
    let symbol: String
    let pitch: Double
    let ask: String
    let thanks: String
}

enum LostAndFound {
    static let items: [LostItem] = [
        LostItem(id: "spectacles", sender: "Mabel Hooper", role: "knits on the 8:15", item: "reading glasses", symbol: "eyeglasses", pitch: 1.2,
                 ask: "Mayor, I've lost my reading glasses, which means I can't see to find my reading glasses. I think I left them somewhere in town. Would you look for me? I'm at the {a}, if you find it.",
                 thanks: "My glasses! Now I can see that my scarf has a hole in it. Still, thank you, Mayor."),
        LostItem(id: "mouthpiece", sender: "Bertram Puddle", role: "retired tuba player", item: "tuba mouthpiece", symbol: "music.note", pitch: 0.82,
                 ask: "Bertram here. I've lost my tuba mouthpiece, somewhere in town. Without it, my tuba is just a very large ornament. Could you find it? I'm at the {a}, if you find it.",
                 thanks: "Mouthpiece found! The neighbors are less pleased than I am, but they'll get used to it again."),
        LostItem(id: "collar", sender: "Marmalade's owner", role: "the café cat's person", item: "cat collar with a bell", symbol: "bell.fill", pitch: 0.75,
                 ask: "Marmalade has lost her collar, the one with the little bell, somewhere in town. She says it wasn't her fault. Could you have a look? I'm at the {a}, if you find it.",
                 thanks: "Collar found and the bell still rings. Marmalade has forgiven you for taking so long, which she did not need to say."),
        LostItem(id: "umbrella", sender: "Ottoline Fairweather", role: "amateur meteorologist", item: "yellow umbrella", symbol: "umbrella.fill", pitch: 1.2,
                 ask: "Mayor, a catastrophe: I've lost my yellow umbrella somewhere in town, and I'm forecasting rain by teatime. Could you find it before then? I'm at the {a}, if you find it.",
                 thanks: "Umbrella recovered! It didn't rain in the end. Please don't tell the Weather Society."),
        LostItem(id: "notebook", sender: "Hamish Gale", role: "the stationmaster's nephew", item: "timing notebook", symbol: "book.closed.fill", pitch: 1.05,
                 ask: "Mayor, it's Hamish. I've lost my notebook with all my timings in it, somewhere in town. Uncle Pip doesn't know yet. Could you find it before he does? I'm at the {a}, if you find it.",
                 thanks: "Notebook found and Uncle Pip never knew. I've written down that you found it, and the exact time."),
        LostItem(id: "ring", sender: "Wendell Spry", role: "the postman", item: "small velvet box", symbol: "gift.fill", pitch: 1.25,
                 ask: "Mayor, it's Wendell, and it's urgent. I've lost a small velvet box somewhere in town. It's important. It's for Bea. Could you find it, quickly? I'm at the {a}, if you find it.",
                 thanks: "Found it! I asked her. She said yes before I'd finished the question. I'm going to sit down for a bit."),
        LostItem(id: "hat", sender: "Lady Philippa Snodgrass", role: "of the Snodgrasses", item: "second-best hat", symbol: "crown.fill", pitch: 1.1,
                 ask: "I have mislaid my second-best hat somewhere in town. My best hat is not suitable for weekdays. Would you be so good as to find it? I'm at the {a}, if you find it.",
                 thanks: "My hat. Thank you. I'm told I said thank you twice. I'll deny it."),
        LostItem(id: "teddy", sender: "Clementine Dart", role: "age nine, future train driver", item: "teddy bear called Captain", symbol: "teddybear.fill", pitch: 1.45,
                 ask: "Mayor, I lost Captain! He's my bear. He's got one eye. I think he got off a train without me. Can you find him? I'm at the {a}, if you find it.",
                 thanks: "CAPTAIN! He says he went on an adventure. He's not allowed to ride trains on his own anymore."),
        LostItem(id: "keys", sender: "Stanley Brooks", role: "drove the old town bus", item: "bus keys", symbol: "key.fill", pitch: 0.8,
                 ask: "Stanley. I've lost the keys to my old bus somewhere in town. It doesn't go anywhere now, but they're my keys. Would you find them? I'm at the {a}, if you find it.",
                 thanks: "Keys found. I sat in the old bus for a while afterwards. Then I took the train home. Don't tell anyone."),
        LostItem(id: "trowel", sender: "Fergus Oakley", role: "the town gardener", item: "favorite trowel", symbol: "leaf.fill", pitch: 0.9,
                 ask: "Fergus here. I've lost my favorite trowel somewhere in town. The other trowels are fine, but they're not her. Could you find her? I'm at the {a}, if you find it.",
                 thanks: "She's back. Thirty years we've been together, that trowel and me. Thank you, Mayor."),
        LostItem(id: "baton", sender: "Hugo Marchetti", role: "retired opera singer", item: "conductor's baton", symbol: "wand.and.stars", pitch: 0.83,
                 ask: "Hugo Marchetti. A disaster: my baton, a gift from a great maestro, is lost somewhere in town. Without it I simply wave my hands. Would you find it? I'm at the {a}, if you find it.",
                 thanks: "My baton! I conducted the entire platform in celebration. Several people joined in. Bravissimo."),
        LostItem(id: "pipe", sender: "Captain Morwenna Brine", role: "retired sea captain", item: "brass compass", symbol: "location.north.circle.fill", pitch: 0.78,
                 ask: "Brine here. I've lost my brass compass somewhere in town. A captain without a compass is just a lady with opinions. Would you find it? I'm at the {a}, if you find it.",
                 thanks: "Compass found, still pointing north. Unlike some people I could mention. Fair winds, Mayor."),
    ]

    static func item(_ id: String) -> LostItem? { items.first { $0.id == id } }
}

// MARK: - Spotlight riders

/// A resident out and about, waiting on a platform with a star over them.
struct SpotlightInfo: Identifiable, Equatable {
    let id: Int
    let residentID: String
    let originID: Int
    let destinationID: Int
}

// MARK: - Advertising

/// A campaign running at one place: extra visitors for the rest of the day.
struct AdCampaign: Codable {
    let multiplier: Double
    let day: Int
    let kindName: String
}

enum AdOption: CaseIterable, Identifiable {
    case posters, radio

    var id: Self { self }
    var title: String { self == .posters ? "Platform posters" : "A radio spot" }
    var detail: String { self == .posters ? "Posters on every platform until tonight." : "Read out on the morning show, and talked about all day." }
    var cost: Int { self == .posters ? 40 : 110 }
    var multiplier: Double { self == .posters ? 1.6 : 2.4 }
}

extension GameState {

    // MARK: Collections

    /// Comment cards at a place count toward its decoration; when full, the regulars chip in.
    func checkCollection(at stationID: Int) {
        guard let landmark = landmark(id: stationID), let record = shopRecords[stationID],
              record.comments.count >= Collections.cardsNeeded else { return }
        let decor = Collections.decor(for: landmark.kind)
        guard !unlockedDecor.contains(decor.rawValue) else { return }
        unlockedDecor.insert(decor.rawValue)
        earnTickets(1, reason: "the \(landmark.name) collection")
        let voice = landmark.shopkeeper ?? "Pip Holloway"
        announce("\(voice) here, at the \(landmark.kind.info.name). Our regulars filled the comment box, so they've all chipped in for a \(decor.title.lowercased()) for the town. You'll find it in the Decorate menu.",
                 from: voice, role: landmark.shopkeeper == nil ? "Station Master" : "at the \(landmark.kind.info.name)")
    }

    /// How far a place is toward its themed decoration.
    func collectionProgress(at stationID: Int) -> (count: Int, decor: DecorKind)? {
        guard let landmark = landmark(id: stationID) else { return nil }
        return (min(shopRecords[stationID]?.comments.count ?? 0, Collections.cardsNeeded), Collections.decor(for: landmark.kind))
    }

    // MARK: Lost and found

    /// A lost-item call, if there's one left to make and somewhere to lose it.
    func makeLostItemCall() -> Letter? {
        let places = openLandmarks.filter { isOpened($0.kind.info.district) && $0.kind.info.category != .canal }
        guard let place = places.randomElement(),
              let lost = LostAndFound.items.filter({ !lostItemsUsed.contains($0.id) }).randomElement() else { return nil }
        lostItemsUsed.insert(lost.id)
        defer { nextLetterID += 1 }
        let fill: (String) -> String = { $0.replacingOccurrences(of: "{a}", with: place.kind.info.name) }
        var letter = Letter(id: nextLetterID, sender: lost.sender, role: lost.role, body: fill(lost.ask),
                            goal: .find(place.id), receivedDay: day, dueDay: day + 2, reward: 60)
        letter.thanks = fill(lost.thanks)
        letter.lostItemID = lost.id
        letter.homeID = place.id
        return letter
    }

    /// The open lost-item request, if any: its index, the item, and how far along it is
    /// (0: still lost somewhere on the map, 1: found and being carried back).
    var lostItemTask: (index: Int, item: LostItem, placeID: Int)? {
        for (index, letter) in letters.enumerated() where letter.status == .open {
            if case let .find(placeID) = letter.goal, letter.progress < 2,
               let id = letter.lostItemID, let item = LostAndFound.item(id) {
                return (index, item, placeID)
            }
        }
        return nil
    }

    /// The lost item waiting to be spotted on the map (not yet found).
    var lostItemOnMap: LostItem? {
        guard let task = lostItemTask, letters[task.index].progress == 0 else { return nil }
        return task.item
    }

    /// Where to bring a found item back to.
    var lostItemReturnTarget: Int? {
        guard let task = lostItemTask, letters[task.index].progress == 1 else { return nil }
        return task.placeID
    }

    /// Lost items being carried back: badge them at the place they're going.
    var lostItemsOnMap: [Int: LostItem] {
        guard let task = lostItemTask, letters[task.index].progress == 1 else { return [:] }
        return [task.placeID: task.item]
    }

    /// The mayor spotted the item and tapped it: the owner rings to ask for it back.
    func pickUpLostItem() {
        guard let task = lostItemTask, letters[task.index].progress == 0 else { return }
        letters[task.index].progress = 1
        lostItemSpot = nil
        let place = landmark(id: task.placeID)?.kind.info.name ?? "their place"
        showTip("found-\(task.item.id)", symbol: task.item.symbol, title: "Found it!",
                text: "Bring the \(task.item.item) to the \(place): tap it there to hand it back.")
        changed()
    }

    /// Hand the item back at the owner's place.
    func returnLostItem() {
        guard let task = lostItemTask, letters[task.index].progress == 1 else { return }
        letters[task.index].progress = 2
        returnPrompt = nil
        checkLetters()
        changed()
    }

    // MARK: Spotlight riders

    /// Now and then, a resident turns up on a platform with somewhere to be.
    func updateSpotlight(dt: Double) {
        guard hotlineUnlocked, phase == .playing else { return }
        spotlightTimer -= dt
        guard spotlightTimer <= 0 else { return }
        spotlightTimer = Double.random(in: 80...140)
        let alreadyOut = waiting.values.flatMap { $0 }.contains { $0.spotlight != nil }
        guard !alreadyOut else { return }
        let served = openLandmarks.filter { !subwayLinesServing($0.id).isEmpty && $0.kind.info.category != .canal }
        guard served.count >= 2 else { return }
        let introduced = Cast.residents.filter { (residentProgress[$0.id] ?? 0) > 0 }
        guard let resident = (introduced.isEmpty ? Cast.residents : introduced).randomElement() else { return }
        for _ in 0..<6 {
            guard let origin = served.randomElement(),
                  let destination = served.filter({ $0.id != origin.id && $0.kind.info.district == origin.kind.info.district }).randomElement()
            else { continue }
            var rider = Rider(id: nextRiderID, origin: origin.id, destination: destination.id,
                              patience: 400, isVisitor: false)
            rider.spotlight = resident.id
            nextRiderID += 1
            updateRoute(&rider, at: origin.id)
            guard rider.hasRoute else { continue }
            waiting[origin.id, default: []].append(rider)
            return
        }
    }

    /// The spotlight rider waiting at a place, if any.
    func spotlight(at stationID: Int) -> SpotlightInfo? {
        guard let rider = waiting[stationID]?.first(where: { $0.spotlight != nil }), let id = rider.spotlight else { return nil }
        return SpotlightInfo(id: rider.id, residentID: id, originID: rider.origin, destinationID: rider.destination)
    }

    /// A spotlight rider made it: a wave, a small tip, and a familiar face in the visitor book.
    func spotlightArrived(_ rider: Rider) {
        guard let id = rider.spotlight, let resident = Cast.resident(id) else { return }
        fares += 10
        let who = "\(resident.name), \(resident.role)"
        if Int.random(in: 0..<3) == 0 {
            earnTickets(1, reason: "\(resident.name.split(separator: " ").first.map(String.init) ?? resident.name) enjoyed the ride")
        }
        var record = shopRecords[rider.destination] ?? ShopRecord(openedDay: day)
        record.regulars[who, default: 0] += 1
        shopRecords[rider.destination] = record
        let first = resident.name.split(separator: " ").first.map(String.init) ?? resident.name
        events.append(.note(text: "♥ \(first) made it", stationID: rider.destination))
        if spotlightCard?.id == rider.id { spotlightCard = nil }
    }

    // MARK: Tip jars

    static let tipJarReady = 6

    /// Riders who enjoyed the trip sometimes leave a little in the station's jar.
    func addTip(at stationID: Int) {
        guard Double.random(in: 0..<1) < 0.25 else { return }
        tipJars[stationID] = min(40, (tipJars[stationID] ?? 0) + Int.random(in: 1...3))
    }

    /// Empty a full jar into the treasury. Returns what was in it.
    @discardableResult
    func collectTips(at stationID: Int) -> Int {
        let amount = tipJars[stationID] ?? 0
        guard amount >= GameState.tipJarReady else { return 0 }
        tipJars[stationID] = 0
        fares += amount
        events.append(.stamp(text: "TIPS +$\(amount)", stationID: stationID))
        changed()
        return amount
    }

    // MARK: Advertising

    static let adRiders = 450

    /// Frenchie LaRue rings once the town is busy enough to be worth advertising in.
    func checkAdsUnlock() {
        guard !adsUnlocked, hotlineUnlocked else { return }
        let pinned = openLandmarks.filter { $0.kind.info.category != .canal }.count
        guard (albumTotals.visitors >= GameState.adRiders && pinned >= 8) || termNumber > 2 else { return }
        adsUnlocked = true
        announce("Frenchie LaRue, of LaRue and Partners, darling! Your little town is the talk of the coast, so let's make it the talk of the town. You can now advertise any shop: tap it, see how many extra visitors we forecast, pay, and voilà. Kisses!",
                 from: "Frenchie LaRue", role: "head of LaRue and Partners", pitch: 1.15, urgent: true)
    }

    /// The campaign running today at a place, if any.
    func activeCampaign(at stationID: Int) -> AdCampaign? {
        guard let campaign = adCampaigns[stationID], campaign.day == day else { return nil }
        return campaign
    }

    /// Extra visitors a campaign would bring for the rest of today: a low and high estimate.
    func adForecast(_ option: AdOption, at stationID: Int) -> (low: Int, high: Int) {
        let record = shopRecords[stationID]
        let week = record?.week ?? []
        let average = week.isEmpty ? 0 : Double(week.reduce(0, +)) / Double(week.count)
        let pace = (record.map { Double($0.todayVisits) } ?? 0) / max(0.15, dayClock)
        let perDay = max(6, average, pace)
        let extra = perDay * max(0.1, 1 - dayClock) * (option.multiplier - 1)
        return (max(1, Int((extra * 0.75).rounded())), max(2, Int((extra * 1.25).rounded())))
    }

    func buyAd(_ option: AdOption, at stationID: Int) -> Bool {
        guard activeCampaign(at: stationID) == nil else { return false }
        guard canAfford(option.cost) else {
            show("\(option.title) costs $\(option.cost)")
            return false
        }
        fares -= option.cost
        adCampaigns[stationID] = AdCampaign(multiplier: option.multiplier, day: day, kindName: option.title)
        changed()
        return true
    }

    /// How much more often riders choose a place because of an advert today.
    func adMultiplier(for stationID: Int) -> Double {
        activeCampaign(at: stationID)?.multiplier ?? 1
    }
}
