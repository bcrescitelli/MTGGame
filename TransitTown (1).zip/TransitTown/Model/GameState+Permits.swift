import Foundation

/// Permits, construction, shopkeepers, and Golden Tickets.
///
/// Buying a permit picks a *kind* of shop (food, culture...). The lot goes up as scaffolding,
/// and when it's finished someone moves in: the actual shop is a surprise, drawn from the
/// blueprints that kind of lot could become. Inviting a particular shop costs Golden Tickets.
extension GameState {

    static let constructionSeconds: Double = 90
    static let inviteTicketCost = 2
    static let rushTicketCost = 1

    /// What a permit costs: rises with each district, and varies a little by kind.
    func permitCost(_ category: LandmarkCategory, in district: District) -> Int {
        if isOnboardingBuild || landmarkGrantAvailable { return 0 }
        let base = [300.0, 420.0, 590.0, 820.0][min(district.rawValue, 3)]
        let factor: Double
        switch category {
        case .nature: factor = 1.0
        case .food: factor = 1.15
        case .culture: factor = 1.3
        case .civic: factor = 1.45
        case .spiritual: factor = 1.6
        case .hub, .canal: factor = 1.0
        }
        return Int((base * factor * landmarkCostMultiplier / 5).rounded()) * 5
    }

    /// Shops a permit of this kind could turn into, in this district. Every one is a surprise.
    /// The very first build of a new town: the Pocket Park, free and instant.
    var isOnboardingBuild: Bool { !landmarks.contains { $0.kind == .park } }

    /// How long the next build takes, in real seconds: the first is instant, then 45 seconds,
    /// 2 minutes, and growing to about 3 hours by the fifteenth (where it stays).
    var nextBuildSeconds: Double {
        let n = buildsStarted + 1
        switch n {
        case ...1: return 0
        case 2: return 45
        case 3: return 120
        default: return min(10_800, 120 * pow(1.455, Double(n - 3)))
        }
    }

    /// Golden Tickets to finish a build now: one per half hour left, at least one.
    func rushTickets(for landmark: Landmark) -> Int {
        max(1, Int(ceil((landmark.constructionRemaining ?? 0) / 1800)))
    }

    func permitCandidates(_ category: LandmarkCategory, in district: District) -> [LandmarkKind] {
        // The first build is always the Pocket Park.
        if isOnboardingBuild { return category == .nature && district == .oldTown ? [.park] : [] }
        return LandmarkKind.landmarks(in: district).filter { kind in
            kind.info.category == category && !landmarks.contains { $0.kind == kind }
        }
    }

    /// Kinds of lot open up as the town grows. Later terms start with all of them.
    func isPermitOpen(_ category: LandmarkCategory) -> Bool {
        if isOnboardingBuild { return category == .nature }
        if termNumber > 1 { return true }
        switch category {
        case .food, .nature: return true
        case .culture: return stats.ridersServed >= 40
        case .civic: return day >= 3
        case .spiritual: return averageVitality >= 0.25
        case .hub, .canal: return false
        }
    }

    /// What it takes to open a kind of lot, for the locked permit.
    func permitLockHint(_ category: LandmarkCategory) -> String {
        if isOnboardingBuild { return "Opens after your first landmark" }
        switch category {
        case .culture: return "Opens at 40 riders (\(min(stats.ridersServed, 40)) so far)"
        case .civic: return "Opens on day 3"
        case .spiritual: return "Opens at 25% revived"
        default: return ""
        }
    }

    func canBuyPermit(_ category: LandmarkCategory, in district: District) -> Bool {
        isPermitOpen(category) && !permitCandidates(category, in: district).isEmpty
            && canAfford(permitCost(category, in: district))
    }

    /// Buy a permit: a surprise shop of this kind is chosen now and revealed when it opens.
    func beginPermit(_ category: LandmarkCategory, in district: District) {
        guard isPermitOpen(category) else {
            show(permitLockHint(category))
            return
        }
        guard let kind = permitCandidates(category, in: district).randomElement() else {
            show("No \(category.name.lowercased()) shops are ready to move in yet")
            return
        }
        guard landmarkGrantAvailable || canAfford(permitCost(category, in: district)) else {
            show("A \(category.name.lowercased()) permit costs $\(permitCost(category, in: district))")
            return
        }
        placingKind = kind
        placingIsPermit = true
        isBookOpen = false
        selectedLineID = nil
        armedColorIndex = nil
        changed()   // redraw the map so the placement markers appear
    }

    /// Building runs on the real clock (it carries on while the app is closed); when it's
    /// done, the shopkeeper moves in.
    func updateConstruction(dt: Double) {
        let now = Date()
        for index in landmarks.indices {
            guard let remaining = landmarks[index].constructionRemaining else { continue }
            let next = landmarks[index].constructionEnds.map { $0.timeIntervalSince(now) } ?? (remaining - dt)
            if next <= 0 {
                openShop(at: index)
            } else {
                let before = landmarks[index].constructionProgress
                landmarks[index].constructionRemaining = next
                // The scaffolding goes up partway through; redraw once when it does.
                if before < 0.3 && landmarks[index].constructionProgress >= 0.3 { changed() }
            }
        }
    }

    private func openShop(at index: Int) {
        let name = Residents.names.randomElement() ?? "A newcomer"
        landmarks[index].constructionRemaining = nil
        landmarks[index].isOpen = true
        landmarks[index].shopkeeper = name
        let landmark = landmarks[index]
        shopRecords[landmark.id] = ShopRecord(openedDay: day)
        stationHealth[landmark.id] = 0
        report.landmarksBuilt.append(landmark.kind)
        stats.landmarksBuilt += 1
        events.append(.stamp(text: landmark.kind == .transitHub ? "HUB OPEN" : "GRAND OPENING", stationID: landmark.id))
        if landmark.kind == .transitHub { landmarks[index].shopkeeper = nil }
        queueReveal(landmark.id)
        networkChanged()
        changed()
    }

    /// A shop counts as discovered once someone has moved in and opened it.
    func hasMovedIn(_ kind: LandmarkKind) -> Bool {
        landmarks.contains { $0.kind == kind && $0.isOpen }
    }

    /// Close the grand-opening postcard; the town carries on.
    func pinPostcard() {
        revealedLandmarkID = nil
    }

    /// Spend a Golden Ticket to finish building right away.
    func rushConstruction(_ id: Int) {
        guard let index = landmarks.firstIndex(where: { $0.id == id }), landmarks[index].isUnderConstruction else { return }
        let cost = rushTickets(for: landmarks[index])
        guard tickets >= cost else {
            show("Finishing now takes \(cost == 1 ? "a Golden Ticket" : "\(cost) Golden Tickets")")
            return
        }
        tickets -= cost
        openShop(at: index)
    }

    /// Golden Tickets earned, with a little fanfare.
    func earnTickets(_ count: Int, reason: String) {
        guard count > 0 else { return }
        tickets += count
        ticketNote = "+\(count) Golden Ticket\(count == 1 ? "" : "s"): \(reason)"
        ticketNoteID += 1
        let id = ticketNoteID
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.2) { [weak self] in
            if self?.ticketNoteID == id { self?.ticketNote = nil }
        }
    }
}
