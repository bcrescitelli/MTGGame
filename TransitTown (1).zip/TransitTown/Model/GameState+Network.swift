import Foundation

/// The citywide network: eight lines you earn and then pay to open, tunnels to cross water, and
/// transit hubs, the only places riders can change trains.
extension GameState {

    // MARK: Lines

    /// Lines the town has earned the right to open: two to start, then one per milestone.
    var lineRights: Int {
        let town = districtBestRevived[.oldTown] ?? 0
        var rights = 2 + GameState.lineMilestones.filter { town >= $0 }.count
        rights += bonusLines.values.reduce(0, +)
        return min(Palette.lineCount, rights)
    }

    /// What it costs to open a line color: money and Golden Tickets.
    func lineOpeningCost(_ colorIndex: Int) -> (money: Int, tickets: Int) {
        let table: [(Int, Int)] = [(0, 0), (0, 0), (400, 2), (700, 4), (1000, 6), (1400, 8), (1900, 10), (2500, 12)]
        return table[min(max(colorIndex, 0), table.count - 1)]
    }

    /// The next line can be opened now (it's been earned, and it's the next in order).
    func canOpenLine(_ colorIndex: Int) -> Bool {
        colorIndex == openedLines && colorIndex < lineRights
    }

    func openLine(_ colorIndex: Int) {
        guard canOpenLine(colorIndex) else { return }
        let cost = lineOpeningCost(colorIndex)
        guard canAfford(cost.money), tickets >= cost.tickets else {
            show("Opening the \(Palette.lineNames[colorIndex]) takes $\(cost.money) and \(cost.tickets) Golden Tickets")
            return
        }
        fares -= cost.money
        tickets -= cost.tickets
        openedLines += 1
        openLinePrompt = nil
        changed()
    }

    /// Cities saved before the citywide network: light rail and quays go, unfinished tunnels are
    /// filled in, and every line already in use stays open.
    func migrateToCitywideNetwork(openedLines saved: Int?) {
        let retired = Set(landmarks.filter {
            [.northQuay, .westQuay, .eastQuay, .southQuay].contains($0.kind)
                || ($0.kind == .tunnelPortal && $0.tunnelComplete != true)
        }.map(\.id))
        lines.removeAll { $0.isLightRail }
        for index in lines.indices { lines[index].stops.removeAll { retired.contains($0) } }
        lines.removeAll { $0.stops.isEmpty }
        landmarks.removeAll { retired.contains($0.id) }
        // Two lines of the same color in different districts can't both stay: keep the longer.
        var kept: [Int: TransitLine] = [:]
        for line in lines {
            if let other = kept[line.colorIndex], other.stops.count >= line.stops.count { continue }
            kept[line.colorIndex] = line
        }
        let keptIDs = Set(kept.values.map(\.id))
        lines.removeAll { !keptIDs.contains($0.id) }
        let used = (lines.map(\.colorIndex).max() ?? 1) + 1
        openedLines = max(saved ?? 2, used, 2)
        travelCache.removeAll()
    }

    /// Revival the town needs to earn lines three to eight.
    static let lineMilestones: [Double] = [0.08, 0.14, 0.20, 0.26, 0.32, 0.38]

    // MARK: Water and districts

    /// The neighborhood a stop stands in (a tunnel opening belongs to wherever it was dug).
    func district(ofStop id: Int) -> District? {
        guard let stop = landmark(id: id) else { return nil }
        return stop.kind == .tunnelPortal ? district(at: stop.cell) : stop.kind.info.district
    }

    /// Two neighboring stops on a line need dry land between them, or a tunnel.
    func crossesWater(_ a: Int, _ b: Int) -> Bool {
        // One big town: the streams are decoration, and nothing blocks a line.
        false
    }

    // MARK: Transfers

    /// Riders can only change lines at a hub (and, of course, get off at their destination).
    func isTransferPoint(_ id: Int) -> Bool {
        landmark(id: id)?.kind.info.category == .hub
    }

    /// Building hubs: each costs more than the last.
    var hubsBuilt: Int { landmarks.filter { $0.kind == .transitHub }.count }
    var nextHubCost: Int { Int((500 * pow(1.5, Double(hubsBuilt))).rounded() / 10) * 10 }
    static let hubBuildSeconds: Double = 90

    func beginHub() {
        guard canAfford(nextHubCost) else {
            show("A transit hub costs $\(nextHubCost)")
            return
        }
        placingIsPermit = false
        placingHub = true
        placingKind = .transitHub
        isBookOpen = false
        selectedLineID = nil
        armedColorIndex = nil
        changed()
    }

    func buildHub(at cell: GridPoint) -> Bool {
        guard let area = self.district(at: cell), isOpened(area), isBuildable(cell, in: area) else {
            show("Pick a marked square in an open neighborhood")
            return false
        }
        let cost = nextHubCost
        guard canAfford(cost) else {
            show("A transit hub costs $\(cost)")
            return false
        }
        fares -= cost
        placingHub = false
        placingKind = nil
        let id = addLandmark(.transitHub, at: cell, open: false)
        if let index = landmarks.firstIndex(where: { $0.id == id }) {
            landmarks[index].constructionRemaining = GameState.hubBuildSeconds
            landmarks[index].constructionTotal = GameState.hubBuildSeconds
            landmarks[index].constructionEnds = Date().addingTimeInterval(GameState.hubBuildSeconds)
        }
        showTip("hub-built", symbol: "arrow.triangle.swap", title: "A transit hub",
                text: "When it's finished, run two or more lines through it. Riders can only change lines at a hub.")
        changed()
        return true
    }

    func nameHub(_ id: Int, _ name: String) {
        guard let index = landmarks.firstIndex(where: { $0.id == id }) else { return }
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        landmarks[index].customName = trimmed.isEmpty ? nil : String(trimmed.prefix(24))
        hubNamingID = nil
        changed()
    }

    // MARK: Tunnels

    /// Steps 2 and 3: the next tap on the grid digs a tunnel opening.
    var isDiggingTunnel: Bool {
        switch tunnelStep {
        case .entrance, .exit: return true
        default: return false
        }
    }

    static let tunnelCost = 300
    static let tunnelTrainLimit = 2

    /// Step 1: buy a tunnel for the selected line (nothing is charged until it's finished).
    func beginTunnel(for lineID: Int) {
        guard tunnelStep == nil else { return }
        guard canAfford(GameState.tunnelCost) else {
            show("A tunnel costs $\(GameState.tunnelCost)")
            return
        }
        tunnelStep = .entrance(lineID: lineID)
        changed()
    }

    /// Steps 2 and 3: dig the entrance, then the exit, on open ground.
    func digTunnel(at cell: GridPoint) {
        guard let step = tunnelStep, let area = self.district(at: cell), isOpened(area),
              landmark(at: cell) == nil, decor(at: cell) == nil else {
            show("Dig on open ground in an open neighborhood")
            return
        }
        switch step {
        case let .entrance(lineID):
            let id = addLandmark(.tunnelPortal, at: cell, open: true)
            tunnelStep = .exit(lineID: lineID, entrance: id)
        case let .exit(lineID, entrance):
            guard let first = landmark(id: entrance), first.cell != cell else { return }
            let id = addLandmark(.tunnelPortal, at: cell, open: true)
            pairPortals(entrance, id)
            tunnelStep = .connectIn(lineID: lineID, entrance: entrance, exit: id)
        default:
            return
        }
        changed()
    }

    private func pairPortals(_ a: Int, _ b: Int) {
        if let i = landmarks.firstIndex(where: { $0.id == a }) { landmarks[i].portalPair = b }
        if let j = landmarks.firstIndex(where: { $0.id == b }) { landmarks[j].portalPair = a }
    }

    /// The other opening of a tunnel.
    func otherPortal(of id: Int) -> Int? { landmark(id: id)?.portalPair }

    /// Step 5 done: the line came out of the tunnel to a landmark. Now it's paid for.
    func completeTunnelIfReady(lineID: Int) {
        guard case let .connectOut(stepLine, entrance, exit) = tunnelStep, stepLine == lineID,
              let line = line(id: lineID),
              let exitIndex = line.stops.firstIndex(of: exit), let entranceIndex = line.stops.firstIndex(of: entrance) else { return }
        let beyond = exitIndex > entranceIndex ? exitIndex + 1 : exitIndex - 1
        guard beyond >= 0, beyond < line.stops.count, let next = landmark(id: line.stops[beyond]),
              next.kind != .tunnelPortal else { return }
        fares -= GameState.tunnelCost
        for id in [entrance, exit] {
            if let index = landmarks.firstIndex(where: { $0.id == id }) { landmarks[index].tunnelComplete = true }
        }
        tunnelStep = nil
        networkChanged()
        changed()
    }

    /// Anything short of step 5: the tunnel is filled back in and nothing is charged.
    func cancelTunnel() {
        guard let step = tunnelStep else { return }
        var portals: [Int] = []
        switch step {
        case .entrance: break
        case let .exit(_, entrance): portals = [entrance]
        case let .connectIn(_, entrance, exit), let .connectOut(_, entrance, exit): portals = [entrance, exit]
        }
        for index in lines.indices { lines[index].stops.removeAll { portals.contains($0) } }
        landmarks.removeAll { portals.contains($0.id) }
        tunnelStep = nil
        networkChanged()
        changed()
    }

    /// Trains running through a tunnel, across every line that shares it.
    func trainsThroughTunnel(_ portalID: Int) -> Int {
        guard let other = otherPortal(of: portalID) else { return 0 }
        return lines.filter { $0.stops.contains(portalID) && $0.stops.contains(other) }
            .reduce(0) { $0 + trainCount(for: $1.id) }
    }

    /// The tunnels a line runs through (one portal id from each).
    func tunnels(on line: TransitLine) -> [Int] {
        line.stops.filter { id in
            guard let stop = landmark(id: id), stop.kind == .tunnelPortal, let other = stop.portalPair else { return false }
            return id < other && line.stops.contains(other)
        }
    }

    /// True if another train on this line would push a shared tunnel past two trains.
    func tunnelBlocksTrain(on lineID: Int) -> Bool {
        // A tunnel is just part of its line: it takes as many trains as the line does.
        false
    }
}

/// Where the mayor is in digging a tunnel.
enum TunnelStep: Equatable {
    /// Bought: tap the grid for the entrance.
    case entrance(lineID: Int)
    /// Entrance dug: tap the grid for the exit.
    case exit(lineID: Int, entrance: Int)
    /// Both dug: drag the line into the entrance.
    case connectIn(lineID: Int, entrance: Int, exit: Int)
    /// Through the tunnel: drag the line out to a landmark.
    case connectOut(lineID: Int, entrance: Int, exit: Int)

    var lineID: Int {
        switch self {
        case let .entrance(id), let .exit(id, _), let .connectIn(id, _, _), let .connectOut(id, _, _): return id
        }
    }
}
