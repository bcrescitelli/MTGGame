import UIKit

/// A line: an ordered list of landmark ids it stops at.
/// Subway lines stay inside one district; the light rail runs between district hubs.
struct TransitLine: Identifiable, Codable {
    static let lightRailIndex = 99

    let id: Int
    let colorIndex: Int
    let district: District
    var stops: [Int]

    var isLightRail: Bool { colorIndex == TransitLine.lightRailIndex }
    var color: UIColor { isLightRail ? Palette.lightRail : Palette.lines[colorIndex] }
    var name: String { isLightRail ? "Light Rail" : Palette.lineNames[colorIndex] }
}
