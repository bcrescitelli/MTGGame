import Foundation

extension GameState {

    func makeSave() -> SaveGame {
        SaveGame(townName: townName, townSeed: townSeed, districtCols: districtCols, rows: rows,
                 currentDistrict: currentDistrict, focusedDistrict: focusedDistrict,
                 termNumber: termNumber, isEndless: isEndless, phase: phase,
                 landmarks: landmarks, lines: lines, trainsPerLine: trainsPerLine,
                 lightRailUpgrades: lightRailUpgrades,
                 lightRailRiders: lightRailRiders, nextID: nextID, nextEventID: nextEventID,
                 fares: fares, goals: goals, unlocked: unlocked, approvedCards: approvedCards,
                 heritageGrantAvailable: heritageGrantAvailable, landmarkGrantAvailable: landmarkGrantAvailable,
                 bonusLines: bonusLines, districtBestRevived: districtBestRevived,
                 completedPairs: completedPairs, usedGazetteKeys: usedGazetteKeys, tipsShown: tipsShown,
                 stats: stats, day: day, dayClock: dayClock, satisfaction: satisfaction, bestRating: bestRating,
                 vitalityGrid: vitalityGrid, stationHealth: stationHealth, report: report,
                 featuredToday: featuredToday, featuredTomorrow: featuredTomorrow,
                 weatherToday: weatherToday, weatherTomorrow: weatherTomorrow,
                 dayCard: dayCard, pendingDayCard: pendingDayCard,
                 todayEvents: todayEvents, tomorrowEvents: tomorrowEvents,
                 letters: letters, stationUpgrades: stationUpgrades, lightRailService: lightRailService,
                 freeTrainAvailable: freeTrainAvailable, recentCouncilCards: recentCouncilCards,
                 seenDecisions: seenDecisions, nextLetterID: nextLetterID, nextTripID: nextTripID,
                 decorItems: decorItems, nextDecorID: nextDecorID, tickets: tickets,
                 decorUnlocked: decorUnlocked, decorAnnounced: decorAnnounced,
                 shopRecords: shopRecords, nextCommentID: nextCommentID,
                 residentProgress: residentProgress, residentHome: residentHome,
                 hotlineUnlocked: hotlineUnlocked, milestonesShown: Array(milestonesShown),
                 unlockedDecor: Array(unlockedDecor), lostItemsUsed: Array(lostItemsUsed),
                 tipJars: tipJars, adsUnlocked: adsUnlocked, buildsStarted: buildsStarted,
                 openedLines: openedLines, adsDate: adsDate, adsWatched: adsWatched, streakDays: streakDays,
                 lastPlayDay: lastPlayDay, lastActive: lastActive, earningRate: earningRate,
                 trainUpgrades: trainUpgrades, averageDayFares: averageDayFares)
    }

    /// Saves the city. Only once a town exists, and never mid-tutorial-setup.
    func autosave() {
        guard isTownReady, districtCols > 0 else { return }
        SaveStore.save(makeSave())
    }

    /// Restores a saved city. The scene then lays out the grid at the saved size.
    func restore(from save: SaveGame) {
        townName = save.townName
        townSeed = save.townSeed
        districtCols = save.districtCols
        rows = save.rows
        currentDistrict = save.currentDistrict
        focusedDistrict = save.focusedDistrict
        bookDistrict = save.focusedDistrict
        termNumber = save.termNumber
        isEndless = save.isEndless

        landmarks = save.landmarks
        lines = save.lines
        trainsPerLine = save.trainsPerLine
        lightRailUpgrades = save.lightRailUpgrades
        lightRailRiders = save.lightRailRiders
        nextID = save.nextID
        nextEventID = save.nextEventID

        fares = save.fares
        goals = save.goals
        unlocked = save.unlocked
        approvedCards = save.approvedCards
        heritageGrantAvailable = save.heritageGrantAvailable
        landmarkGrantAvailable = save.landmarkGrantAvailable
        bonusLines = save.bonusLines
        districtBestRevived = save.districtBestRevived
        completedPairs = save.completedPairs
        usedGazetteKeys = save.usedGazetteKeys
        tipsShown = save.tipsShown
        stats = save.stats

        day = save.day
        dayClock = save.dayClock
        satisfaction = save.satisfaction
        bestRating = save.bestRating
        vitalityGrid = save.vitalityGrid
        stationHealth = save.stationHealth
        report = save.report
        featuredToday = save.featuredToday
        featuredTomorrow = save.featuredTomorrow
        weatherToday = save.weatherToday
        weatherTomorrow = save.weatherTomorrow
        dayCard = save.dayCard
        pendingDayCard = save.pendingDayCard
        todayEvents = save.todayEvents
        tomorrowEvents = save.tomorrowEvents
        letters = save.letters
        stationUpgrades = save.stationUpgrades
        lightRailService = save.lightRailService
        freeTrainAvailable = save.freeTrainAvailable
        recentCouncilCards = save.recentCouncilCards
        seenDecisions = save.seenDecisions
        nextLetterID = save.nextLetterID
        nextTripID = save.nextTripID
        decorItems = save.decorItems
        nextDecorID = save.nextDecorID
        tickets = save.tickets
        decorUnlocked = save.decorUnlocked ?? !save.decorItems.isEmpty
        decorAnnounced = save.decorAnnounced ?? decorUnlocked
        shopRecords = save.shopRecords ?? [:]
        nextCommentID = save.nextCommentID ?? 0
        residentProgress = save.residentProgress ?? [:]
        residentHome = save.residentHome ?? [:]
        // Cities saved before the hotline was locked already have it.
        hotlineUnlocked = save.hotlineUnlocked ?? true
        milestonesShown = Set(save.milestonesShown ?? [])
        isEndless = true   // there are no term deadlines any more
        unlockedDecor = Set(save.unlockedDecor ?? [])
        lostItemsUsed = Set(save.lostItemsUsed ?? [])
        tipJars = save.tipJars ?? [:]
        adsUnlocked = save.adsUnlocked ?? false
        buildsStarted = save.buildsStarted ?? landmarks.filter { $0.shopkeeper != nil || $0.isUnderConstruction }.count
        migrateToCitywideNetwork(openedLines: save.openedLines)
        adsDate = save.adsDate ?? ""
        adsWatched = save.adsWatched ?? 0
        streakDays = save.streakDays ?? 0
        lastPlayDay = save.lastPlayDay ?? ""
        lastActive = save.lastActive
        earningRate = save.earningRate ?? 0
        trainUpgrades = save.trainUpgrades ?? [:]
        averageDayFares = save.averageDayFares ?? 0
        dayFaresStart = stats.totalFares
        // The revival share isn't saved: work it out now so the top bar is right at once.
        updateRevival(dt: 0)
        refreshHUD()
        // What the town earned while away shows first thing, before any other pop-up.
        cameBack()
        lastFaresTotal = stats.totalFares

        for district in District.allCases where districtBestRevived[district] != nil {
            announcedLineSlots[district] = lineSlots(in: district)
        }
        isTownReady = vitalityGrid.count == worldCols * worldRows && districtCols > 0
        tutorial = nil
        completedPairs = save.completedPairs

        // Pick up where the city left off. A Gazette in progress goes straight to the council.
        switch save.phase {
        case .gazette, .council:
            phase = .playing
            finishGazette()
        case .appointment, .termReview, .playing:
            phase = save.phase
        }
        refreshHUD()
    }
}
