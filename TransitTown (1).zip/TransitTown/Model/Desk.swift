import Foundation

// MARK: Letters to the Mayor

/// What a resident is asking for.
enum LetterGoal: Codable, Equatable {
    /// Put both landmarks on one line.
    case connect(Int, Int)
    /// Put this landmark on any line.
    case serve(Int)
    /// Have this many lines stop here.
    case lines(Int, Int)
    /// Keep this station to at most this many lines (checked on the due date).
    case atMost(Int, Int)
    /// Find something lost near this place (tap it on the map).
    case find(Int)
    /// Place a decoration right beside this landmark.
    case decorNear(Int)
    /// Have at least this many trains running in town.
    case trains(Int)
    /// Have at least this many transit hubs open.
    case hubs(Int)
    /// Give both places a train stop.
    case serveBoth(Int, Int)
    /// Carry this many riders to the landmark.
    case carryTo(Int, Int)
}

struct Letter: Codable, Identifiable {
    enum Status: String, Codable { case open, answered, missed }

    let id: Int
    let sender: String
    let role: String
    let body: String
    let goal: LetterGoal
    let receivedDay: Int
    let dueDay: Int
    let reward: Int
    var status: Status = .open
    /// Riders carried toward a `carryTo` goal since the letter arrived.
    var progress = 0
    /// Letters that pull in opposite directions point at each other.
    var conflictsWith: Int?
    /// A request from one of the town's residents: who, their follow-up, and the place it's about.
    var residentID: String?
    var thanks: String?
    var homeID: Int?
    /// The comment card the resident leaves once it's done.
    var cardText: String?
    /// For lost-and-found calls: which item is lost.
    var lostItemID: String?
}

/// The people who write in. Names and roles are mixed and matched.
enum Residents {
    static let names = [
        "Mrs. Penny Hollis", "Mr. Arthur Quill", "Dot Merriweather", "Sam Okafor", "Lena Brandt",
        "Mr. Teddy Vane", "Rosa Delgado", "Mrs. Ivy Pembroke", "Gus Hartley", "Nell Ashby",
        "Mr. Felix Moreau", "Hattie Burke", "Oscar Lund", "Mrs. Maud Kettering", "Jun Park",
        "Wilf Greaves", "Clara Bell", "Mr. Percy Dunn",
    ]
    static let roles = [
        "retired schoolteacher", "baker's apprentice", "night nurse", "piano tuner", "shop owner",
        "grandmother of four", "student", "postman", "bus driver, retired", "florist",
        "librarian", "dog walker", "watchmaker", "harbor pilot", "street sweeper",
    ]
}

// MARK: Groups traveling together

/// A group that shows up all at once and needs to get somewhere together.
struct SpecialTrip: Codable, Identifiable {
    enum Kind: String, Codable, CaseIterable {
        case schoolTrip, weddingParty, inspector, tourGroup

        var title: String {
            switch self {
            case .schoolTrip: return "School trip"
            case .weddingParty: return "Wedding party"
            case .inspector: return "The Transport Inspector"
            case .tourGroup: return "Tour group"
            }
        }

        var symbol: String {
            switch self {
            case .schoolTrip: return "backpack.fill"
            case .weddingParty: return "gift.fill"
            case .inspector: return "magnifyingglass"
            case .tourGroup: return "camera.fill"
            }
        }

        var size: Int {
            switch self {
            case .schoolTrip: return 12
            case .weddingParty: return 8
            case .inspector: return 1
            case .tourGroup: return 10
            }
        }

        var reward: Int {
            switch self {
            case .schoolTrip: return 60
            case .weddingParty: return 80
            case .inspector: return 100
            case .tourGroup: return 90
            }
        }
    }

    let id: Int
    let kind: Kind
    let origin: Int
    let destination: Int
    let total: Int
    var delivered = 0
    var gaveUp = 0
    var isResolved = false

    var remaining: Int { total - delivered - gaveUp }
    /// Most of the group has to make it: three in four, or the inspector himself.
    var succeeded: Bool { kind == .inspector ? delivered == 1 : Double(delivered) >= Double(total) * 0.75 }
}

// MARK: Snap decisions

/// What a choice does. Targets are resolved when the decision appears.
enum DecisionEffect: Codable, Equatable {
    case fares(Int)
    case rating(Double)
    case riders(Double)
    case patience(Double)
    case boost(LandmarkCategory, Double)
    /// Close the decision's station until the given fraction of the day.
    case closeStation(until: Double)
    case reviveStation
}

struct DecisionChoice: Codable, Equatable {
    let label: String
    let outcome: String
    let effects: [DecisionEffect]
}

/// A quick choice that pops up mid-day. The day pauses until the mayor picks one.
struct SnapDecision: Codable, Identifiable, Equatable {
    let id: String
    let title: String
    let body: String
    let symbol: String
    var stationID: Int?
    let first: DecisionChoice
    let second: DecisionChoice
}

enum DecisionDeck {
    /// Every decision, with `{station}` standing for a busy station chosen when it appears.
    static func all(station: String) -> [SnapDecision] {
        [
            SnapDecision(id: "busker", title: "A busker at \(station)",
                         body: "A fiddler wants to play on the platform at \(station) all afternoon.",
                         symbol: "music.note",
                         first: DecisionChoice(label: "Let him play", outcome: "Toes are tapping. Riders wait more happily.",
                                               effects: [.patience(1.25), .rating(0.03)]),
                         second: DecisionChoice(label: "Not today", outcome: "The platform stays clear and quiet.",
                                                effects: [])),
            SnapDecision(id: "film", title: "A film crew",
                         body: "A film crew wants to shoot a scene at \(station). They'll pay, but the station closes for a while.",
                         symbol: "film.fill",
                         first: DecisionChoice(label: "Roll camera ($120)", outcome: "Lights, camera, closed station.",
                                               effects: [.fares(120), .closeStation(until: 0.15)]),
                         second: DecisionChoice(label: "Turn them away", outcome: "The trains keep running. The director sulks.",
                                                effects: [])),
            SnapDecision(id: "lostdog", title: "A dog on the line",
                         body: "A very good dog has wandered onto the tracks near \(station). Stop the trains to fetch him?",
                         symbol: "pawprint.fill",
                         first: DecisionChoice(label: "Stop and fetch him", outcome: "He's safe, and the whole town heard about it.",
                                               effects: [.closeStation(until: 0.08), .rating(0.05)]),
                         second: DecisionChoice(label: "Call his owner", outcome: "His owner arrives eventually. Riders were kept waiting.",
                                                effects: [.patience(0.9)])),
            SnapDecision(id: "bakesale", title: "A bake sale",
                         body: "The school wants to hold a bake sale on the platform at \(station).",
                         symbol: "birthday.cake.fill",
                         first: DecisionChoice(label: "Of course", outcome: "Everyone's carrying a slice of something.",
                                               effects: [.boost(.food, 1.3), .rating(0.02)]),
                         second: DecisionChoice(label: "Health and safety says no", outcome: "Rules are rules.",
                                                effects: [])),
            SnapDecision(id: "sponsor", title: "A sponsor calls",
                         body: "A soap company will pay to paint its name on every train today.",
                         symbol: "megaphone.fill",
                         first: DecisionChoice(label: "Take the money ($90)", outcome: "The trains are very clean and slightly embarrassing.",
                                               effects: [.fares(90), .rating(-0.03)]),
                         second: DecisionChoice(label: "Keep them plain", outcome: "The town appreciates your taste.",
                                                effects: [.rating(0.02)])),
            SnapDecision(id: "heatwave", title: "Hot afternoon",
                         body: "It's sweltering. Hand out free water at the busiest platforms?",
                         symbol: "drop.fill",
                         first: DecisionChoice(label: "Hand it out ($40)", outcome: "Grateful riders, damp collars.",
                                               effects: [.fares(-40), .patience(1.3)]),
                         second: DecisionChoice(label: "They'll manage", outcome: "Some of them did.",
                                                effects: [.patience(0.85)])),
            SnapDecision(id: "choir", title: "A choir at \(station)",
                         body: "The town choir wants to rehearse in the ticket hall at \(station).",
                         symbol: "music.mic",
                         first: DecisionChoice(label: "Let them sing", outcome: "Harmony in the ticket hall. People linger.",
                                               effects: [.boost(.culture, 1.4), .reviveStation]),
                         second: DecisionChoice(label: "Find them a church", outcome: "They found one. It has worse acoustics.",
                                                effects: [])),
            SnapDecision(id: "leaves", title: "Leaves on the line",
                         body: "Wet leaves are making the trains slip. Run them slowly for safety, or push on?",
                         symbol: "leaf.fill",
                         first: DecisionChoice(label: "Slow and safe", outcome: "A little late, but nobody minds a careful driver.",
                                               effects: [.riders(0.9), .rating(0.02)]),
                         second: DecisionChoice(label: "Push on", outcome: "On time, mostly. A few nervous faces.",
                                                effects: [.patience(0.85)])),
            SnapDecision(id: "flowers", title: "Flower boxes",
                         body: "The garden club offers to plant flower boxes around \(station).",
                         symbol: "camera.macro",
                         first: DecisionChoice(label: "Yes, please ($30)", outcome: "Petunias everywhere. The street perks up.",
                                               effects: [.fares(-30), .reviveStation]),
                         second: DecisionChoice(label: "Maybe next week", outcome: "The garden club will ask again. They always do.",
                                                effects: [])),
            SnapDecision(id: "strike", title: "Drivers want a break",
                         body: "The drivers ask for a long lunch. Fair enough, but the trains will thin out for a while.",
                         symbol: "cup.and.saucer.fill",
                         first: DecisionChoice(label: "Give them the break", outcome: "Rested drivers, shorter tempers on the platform.",
                                               effects: [.patience(0.85), .rating(0.03)]),
                         second: DecisionChoice(label: "Pay overtime ($60)", outcome: "The trains keep running. So does the payroll.",
                                                effects: [.fares(-60)])),
            SnapDecision(id: "tourists", title: "A coach breaks down",
                         body: "A coach of tourists is stranded at the edge of town. Send a train to fetch them?",
                         symbol: "bus.fill",
                         first: DecisionChoice(label: "Fetch them", outcome: "Forty tourists, all very grateful and hungry.",
                                               effects: [.riders(1.2), .boost(.food, 1.3)]),
                         second: DecisionChoice(label: "Let them walk", outcome: "They'll find their own way. Probably.",
                                                effects: [])),
            SnapDecision(id: "mural", title: "Graffiti or art?",
                         body: "Someone painted a mural overnight on the wall at \(station). It's actually quite good.",
                         symbol: "paintpalette.fill",
                         first: DecisionChoice(label: "Keep it", outcome: "People are coming to look at it.",
                                               effects: [.reviveStation, .boost(.culture, 1.2)]),
                         second: DecisionChoice(label: "Paint over it ($20)", outcome: "A very clean wall.",
                                                effects: [.fares(-20)])),
            SnapDecision(id: "lostproperty", title: "Lost property",
                         body: "The lost property office is overflowing. Hold a sale?",
                         symbol: "umbrella.fill",
                         first: DecisionChoice(label: "Hold a sale (+$50)", outcome: "Three hundred umbrellas found new homes.",
                                               effects: [.fares(50)]),
                         second: DecisionChoice(label: "Keep looking for owners", outcome: "One owner found. Two hundred and ninety-nine to go.",
                                                effects: [.rating(0.02)])),
            SnapDecision(id: "rush", title: "The big match",
                         body: "There's a match on tonight. Run extra trains at full tilt, or keep the usual timetable?",
                         symbol: "sportscourt.fill",
                         first: DecisionChoice(label: "Extra trains ($50)", outcome: "Packed and cheering, all the way home.",
                                               effects: [.fares(-50), .riders(1.3), .patience(1.1)]),
                         second: DecisionChoice(label: "Usual timetable", outcome: "Crowded platforms, but the timetable held.",
                                                effects: [.riders(1.2), .patience(0.85)])),
            SnapDecision(id: "wedding", title: "A wedding photo",
                         body: "A couple wants their wedding photos on the platform at \(station).",
                         symbol: "camera.fill",
                         first: DecisionChoice(label: "Congratulations!", outcome: "Confetti on the tracks. Worth it.",
                                               effects: [.rating(0.04), .patience(0.95)]),
                         second: DecisionChoice(label: "Suggest the park", outcome: "The park was lovely. Nobody blocked a door.",
                                                effects: [.boost(.nature, 1.3)])),
            SnapDecision(id: "pigeons", title: "Pigeons",
                         body: "Pigeons have moved into the roof at \(station). Evict them?",
                         symbol: "bird.fill",
                         first: DecisionChoice(label: "Call the pigeon man ($30)", outcome: "The roof is pigeon-free. For now.",
                                               effects: [.fares(-30), .rating(0.02)]),
                         second: DecisionChoice(label: "Live and let live", outcome: "Some riders feed them. Some riders don't stand there.",
                                                effects: [.patience(0.95)])),
        ]
    }
}
