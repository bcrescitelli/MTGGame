import Foundation

/// Golden Tickets and the moments around them: daily streaks, rewarded ads, what the town earned
/// while you were away, express trains for stuck groups, and keeping pop-ups from piling up.
struct AwayRecap: Identifiable, Equatable {
    let id = UUID()
    let seconds: TimeInterval
    let money: Int
    let streakDay: Int
    let streakTicket: Bool
}

extension GameState {

    // MARK: Rewarded ads (a placeholder until a real ad network is connected)

    static let adsPerDay = 15

    var adsLeftToday: Int {
        adsDate == GameState.todayKey ? max(0, GameState.adsPerDay - adsWatched) : GameState.adsPerDay
    }

    /// Start a rewarded ad. The placeholder plays for a few seconds, then pays a ticket.
    func watchAdForTicket() {
        guard adsLeftToday > 0, !isAdPlaying else { return }
        isAdPlaying = true
    }

    func finishAd() {
        isAdPlaying = false
        if adsDate != GameState.todayKey { adsDate = GameState.todayKey; adsWatched = 0 }
        adsWatched += 1
        earnTickets(1, reason: "thanks for watching")
        changed()
        autosave()
    }

    static var todayKey: String {
        let parts = Calendar.current.dateComponents([.year, .month, .day], from: Date())
        return "\(parts.year ?? 0)-\(parts.month ?? 0)-\(parts.day ?? 0)"
    }

    // MARK: Daily streak

    /// Playing on consecutive real days: a ticket on the 3rd, 5th, and 7th day in a row.
    /// Returns true if today's visit earned one.
    @discardableResult
    func updateStreak() -> Bool {
        let today = GameState.todayKey
        guard lastPlayDay != today else { return false }
        let yesterday: String = {
            let date = Calendar.current.date(byAdding: .day, value: -1, to: Date()) ?? Date()
            let parts = Calendar.current.dateComponents([.year, .month, .day], from: date)
            return "\(parts.year ?? 0)-\(parts.month ?? 0)-\(parts.day ?? 0)"
        }()
        streakDays = lastPlayDay == yesterday ? streakDays + 1 : 1
        lastPlayDay = today
        if [3, 5, 7].contains(streakDays) {
            earnTickets(1, reason: "\(streakDays) days in a row")
            return true
        }
        if streakDays > 7 { streakDays = 1 }
        return false
    }

    // MARK: While you were away

    static let awayCap: TimeInterval = 8 * 3600

    /// The app is going to the background: remember when, and how the town was earning.
    func wentAway() {
        lastActive = Date()
        autosave()
        Notifications.schedule(for: self)
    }

    /// Back again: half the town's usual earnings for the time away (up to eight hours),
    /// shown on a recap card before anything else.
    func cameBack() {
        Notifications.clearPending()
        let streakTicket = updateStreak()
        guard let then = lastActive else { lastActive = Date(); return }
        lastActive = Date()
        let away = Date().timeIntervalSince(then)
        guard away > 120 || streakTicket else { return }
        let counted = min(away, GameState.awayCap)
        // About half a typical day's fares for every hour away. Older saves have no daily figure
        // yet, so estimate one from the recent pace.
        let perDay = averageDayFares > 0 ? averageDayFares : earningRate * GameState.dayLength
        let money = Int((perDay * 0.5 * counted / 3600).rounded())
        guard money > 0 || streakTicket else { return }
        fares += money
        awayRecap = AwayRecap(seconds: away, money: money, streakDay: streakDays, streakTicket: streakTicket)
        changed()
    }

    /// At the end of each day: remember what a typical day brings in.
    func recordDayFares() {
        let today = Double(max(0, stats.totalFares - dayFaresStart))
        averageDayFares = averageDayFares == 0 ? today : averageDayFares * 0.7 + today * 0.3
        dayFaresStart = stats.totalFares
    }

    /// Fares per second, smoothed (kept for older saves).
    func updateEarningRate(faresThisSecond: Int) {
        earningRate = earningRate * 0.98 + Double(faresThisSecond) * 0.02
    }

    // MARK: One thing at a time

    /// A finished landmark (or hub) waits its turn: never during a call, never within a few
    /// seconds of hanging up, never on top of the away recap.
    func queueReveal(_ id: Int) {
        if !pendingReveals.contains(id) { pendingReveals.append(id) }
    }

    func updateReveals() {
        guard !pendingReveals.isEmpty, revealedLandmarkID == nil, hubNamingID == nil, awayRecap == nil,
              !isPhoneBusy, Date() >= phoneQuietUntil, phase == .playing else { return }
        let id = pendingReveals.removeFirst()
        guard let landmark = landmark(id: id) else { return }
        if landmark.kind == .transitHub { hubNamingID = id } else { revealedLandmarkID = id }
    }

    /// A short hush after any call ends, before anything else pops up.
    func hushAfterCall() {
        phoneQuietUntil = Date().addingTimeInterval(4)
    }

    // MARK: A clear warning

    /// For things the mayor really needs to notice (a full station): a big, short-lived card.
    func flashAlert(_ text: String) {
        alertNote = text
        alertNoteID += 1
        let id = alertNoteID
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.6) { [weak self] in
            if self?.alertNoteID == id { self?.alertNote = nil }
        }
    }

    // MARK: Express trains for groups

    /// An express for a waiting group: about 70% of what the trip pays, so helping still wins.
    func expressCost(for tripID: Int) -> Int? {
        guard let trip = trips.first(where: { $0.id == tripID && !$0.isResolved }) else { return nil }
        return Int((Double(trip.kind.reward) * 0.7 / 5).rounded()) * 5
    }

    func sendExpress(tripID: Int) {
        guard let cost = expressCost(for: tripID), let trip = trips.first(where: { $0.id == tripID }) else { return }
        guard canAfford(cost) else {
            show("An express train costs $\(cost)")
            return
        }
        fares -= cost
        for key in waiting.keys { waiting[key]?.removeAll { $0.tripID == tripID } }
        for key in onboard.keys { onboard[key]?.removeAll { $0.tripID == tripID } }
        let remaining = trip.remaining
        for _ in 0..<remaining { tripRider(tripID, delivered: true) }
        events.append(.note(text: "Express train arrived", stationID: trip.destination))
        networkChanged()
        changed()
    }
}
