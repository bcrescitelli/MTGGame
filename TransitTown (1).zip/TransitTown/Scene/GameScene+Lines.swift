import SpriteKit
import UIKit

extension GameScene {

    // MARK: Drawing

    /// Routes all lines, spreads shared track into lanes, and draws them with their terminals.
    func drawLines() {
        guard let state else { return }
        linesLayer.removeAllChildren()
        lineShapes.removeAll()
        terminals.removeAll()

        let inputs = state.lines.sorted { $0.id < $1.id }.map { line in
            LaneLayout.Input(lineID: line.id,
                             colorIndex: line.colorIndex,
                             stopCells: line.stops.compactMap { stationCell(of: $0) })
        }
        let stations = Set(state.landmarks.compactMap { stationCell(of: $0.id) })
        routed = LaneLayout.layout(inputs, stations: stations, center: { self.center(of: $0) })
        paths = routed.mapValues { LinePath(points: $0.points, stopIndices: $0.stopIndices) }

        let selectedID = state.selectedLineID
        for (index, line) in state.lines.enumerated() {
            guard let route = routed[line.id], let path = paths[line.id], route.points.count >= 2 else { continue }
            // Small steps keep every line inside the lines layer, however many there are,
            // so tracks always sit beneath landmarks.
            let z = CGFloat(index) * 0.3
            let isSelected = selectedID == line.id
            let isDimmed = selectedID != nil && !isSelected
            let color = isDimmed ? line.color.mixed(with: Palette.paper, amount: 0.45) : line.color
            // Underground stretches (between a tunnel's two openings) aren't drawn.
            let hidden = tunnelRanges(for: line, path: path)
            tunnelSpans[line.id] = hidden
            let visible: CGPath
            if hidden.isEmpty {
                visible = TransitGeometry.roundedPath(through: visiblePoints(for: line.id, path: path))
            } else {
                let combined = CGMutablePath()
                var cursor: CGFloat = 0
                for span in hidden + [path.total...path.total] {
                    let piece = path.points(from: cursor, to: span.lowerBound)
                    if piece.count >= 2 { combined.addPath(TransitGeometry.roundedPath(through: piece)) }
                    cursor = span.upperBound
                }
                visible = combined
            }

            if line.isLightRail {
                // Light rail: a wider teal band with a paper center stripe, like a double track.
                let band = SKShapeNode(path: visible)
                band.strokeColor = color
                band.lineWidth = lineWidth + 3
                band.lineCap = .round
                band.lineJoin = .round
                band.zPosition = z + 6
                linesLayer.addChild(band)
                let stripe = SKShapeNode(path: visible)
                stripe.strokeColor = Palette.card
                stripe.lineWidth = 2
                stripe.lineCap = .round
                stripe.lineJoin = .round
                stripe.zPosition = z + 6.1
                linesLayer.addChild(stripe)
                lineShapes[line.id] = band
            } else {
                // A thin paper edge keeps neighboring lanes and crossings distinct.
                let edge = SKShapeNode(path: visible)
                edge.strokeColor = Palette.card
                edge.lineWidth = lineWidth + 2
                edge.lineCap = .round
                edge.lineJoin = .round
                edge.zPosition = z
                linesLayer.addChild(edge)
                let shape = SKShapeNode(path: visible)
                shape.strokeColor = color
                shape.lineWidth = lineWidth
                shape.lineCap = .round
                shape.lineJoin = .round
                // Colors all sit above every line's pale edge (edges stay at z), so lines running
                // side by side never paint over each other and look half as thick.
                shape.zPosition = z + 6
                linesLayer.addChild(shape)
                lineShapes[line.id] = shape
            }

            drawClosures(for: line, path: path, z: z + 6.2)

            let reveal = reveals[line.id]
            let p = route.points
            addTerminal(for: line, atTail: false, end: p[0], from: p[1], color: color,
                        isSelected: isSelected, isHidden: reveal?.fromHead == true, z: z + 6.25)
            addTerminal(for: line, atTail: true, end: p[p.count - 1], from: p[p.count - 2], color: color,
                        isSelected: isSelected, isHidden: reveal.map { !$0.fromHead } ?? false, z: z + 6.25)
        }
    }

    /// The end of a line past its last station: a short stub ending in a round cap,
    /// which grows into a pulsing drag knob when the line is selected.
    private func addTerminal(for line: TransitLine, atTail: Bool, end: CGPoint, from: CGPoint, color: UIColor,
                             isSelected: Bool, isHidden: Bool, z: CGFloat) {
        let direction = from.vector(to: end).normalized
        let stubStart = end + direction * (cellSize * 0.3)
        let tip = end + direction * (cellSize * 0.62)
        terminals.append(LineHandle(lineID: line.id, atTail: atTail, point: tip))
        guard !isHidden else { return }

        let path = CGMutablePath()
        path.move(to: stubStart)
        path.addLine(to: tip)
        let stub = SKShapeNode(path: path)
        stub.strokeColor = color
        stub.lineWidth = lineWidth
        stub.lineCap = .round
        stub.zPosition = z
        linesLayer.addChild(stub)

        if !isSelected {
            let cap = SKShapeNode(circleOfRadius: 5.5)
            cap.position = tip
            cap.fillColor = color
            cap.strokeColor = .clear
            cap.zPosition = z + 0.5
            let hole = SKShapeNode(circleOfRadius: 2)
            hole.fillColor = Palette.card
            hole.strokeColor = .clear
            hole.zPosition = 1
            cap.addChild(hole)
            linesLayer.addChild(cap)
        } else {
            let knob = SKShapeNode(circleOfRadius: 9)
            knob.position = tip
            knob.fillColor = color
            knob.strokeColor = Palette.card
            knob.lineWidth = 2.5
            knob.zPosition = z + 0.02
            let dot = SKShapeNode(circleOfRadius: 3)
            dot.fillColor = Palette.card
            dot.strokeColor = .clear
            dot.zPosition = 1
            knob.addChild(dot)
            knob.run(.repeatForever(.sequence([.scale(to: 1.15, duration: 0.5), .scale(to: 1.0, duration: 0.5)])))
            linesLayer.addChild(knob)
        }
    }

    /// Closed stretches (worn out, under repair, or roadworks) are drawn as broken track:
    /// paper-colored gaps cut through the line.
    private func drawClosures(for line: TransitLine, path: LinePath, z: CGFloat) {
        guard let state, line.stops.count == path.stopDistances.count else { return }
        for index in 1..<line.stops.count where !state.isTrackOpen(lineID: line.id, line.stops[index - 1], line.stops[index]) {
            let piece = TransitGeometry.subpath(path.points, from: path.stopDistances[index - 1] + cellSize * 0.4,
                                                to: path.stopDistances[index] - cellSize * 0.4)
            guard piece.count >= 2 else { continue }
            let gaps = SKShapeNode(path: TransitGeometry.roundedPath(through: piece).copy(dashingWithPhase: 0, lengths: [5, 7]))
            gaps.strokeColor = Palette.paper
            gaps.lineWidth = lineWidth + 3
            gaps.lineCap = .butt
            gaps.zPosition = z
            linesLayer.addChild(gaps)
        }
    }

    // MARK: Ink-in animation

    /// Starts drawing a line's new section progressively from where it used to end.
    func startReveal(lineID: Int, fromHead: Bool, previousLength: CGFloat) {
        // The light rail's two-part stroke appears whole rather than inking in.
        guard state?.line(id: lineID)?.isLightRail != true else { return }
        reveals[lineID] = LineReveal(shown: previousLength, fromHead: fromHead)
        drawLines()
    }

    func updateReveals(dt: CGFloat) {
        guard !reveals.isEmpty else { return }
        var finished = false
        for (id, current) in reveals {
            guard let path = paths[id] else {
                reveals[id] = nil
                continue
            }
            var reveal = current
            reveal.shown += revealSpeed * dt
            if reveal.shown >= path.total {
                reveals[id] = nil
                finished = true
            } else {
                reveals[id] = reveal
                lineShapes[id]?.path = TransitGeometry.roundedPath(through: visiblePoints(for: id, path: path))
            }
        }
        if finished {
            drawLines()
        }
    }

    private func visiblePoints(for lineID: Int, path: LinePath) -> [CGPoint] {
        guard let reveal = reveals[lineID] else { return path.points }
        let shown = min(max(reveal.shown, 0), path.total)
        if reveal.fromHead {
            return TransitGeometry.subpath(path.points, from: path.total - shown, to: path.total)
        }
        return TransitGeometry.subpath(path.points, from: 0, to: shown)
    }

    // MARK: Previews

    func showPreview(_ points: [CGPoint], color: UIColor, dashed: Bool = false) {
        let base = TransitGeometry.roundedPath(through: points)
        previewNode.path = dashed ? base.copy(dashingWithPhase: 0, lengths: [10, 8]) : base
        previewNode.strokeColor = color.withAlphaComponent(0.55)
    }

    func hidePreview() {
        previewNode.path = nil
    }

    /// Green outline where a dragged landmark can drop, red where the cell is taken.
    func showGhost(for id: Int, at p: CGPoint) {
        guard let cell = gridPoint(at: p) else {
            hideGhost()
            return
        }
        let district = state?.landmark(id: id)?.kind.info.district ?? .oldTown
        let occupied = !(state?.isBuildable(cell, in: district, ignoring: id) ?? false)
        let c = center(of: cell)
        let side = cellSize * 0.9
        let rect = CGRect(x: c.x - side / 2, y: c.y - side / 2, width: side, height: side)
        ghostNode.path = CGPath(roundedRect: rect, cornerWidth: 12, cornerHeight: 12, transform: nil)
        let color = occupied ? Palette.bad : Palette.good
        ghostNode.strokeColor = color
        ghostNode.fillColor = color.withAlphaComponent(0.14)
    }

    func hideGhost() {
        ghostNode.path = nil
    }
}


extension GameScene {

    /// The stretches of a line that run underground: between the two openings of a tunnel.
    func tunnelRanges(for line: TransitLine, path: LinePath) -> [ClosedRange<CGFloat>] {
        guard let state, path.stopDistances.count == line.stops.count else { return [] }
        var spans: [ClosedRange<CGFloat>] = []
        for index in 0..<max(0, line.stops.count - 1) {
            guard let a = state.landmark(id: line.stops[index]), a.kind == .tunnelPortal,
                  a.portalPair == line.stops[index + 1] else { continue }
            let from = path.stopDistances[index], to = path.stopDistances[index + 1]
            spans.append(min(from, to)...max(from, to))
        }
        return spans.sorted { $0.lowerBound < $1.lowerBound }
    }

    /// How visible a train car is at a distance along its line: fading out as it heads down into
    /// a tunnel, gone underground, and fading back in as it climbs out.
    func undergroundAlpha(lineID: Int, at distance: CGFloat) -> CGFloat {
        guard let spans = tunnelSpans[lineID] else { return 1 }
        for span in spans where span.contains(distance) {
            let depth = min(distance - span.lowerBound, span.upperBound - distance)
            return max(0, 1 - depth / (cellSize * 0.45))
        }
        return 1
    }
}
