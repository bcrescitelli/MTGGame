import SpriteKit
import UIKit

extension GameScene {

    /// Pins on the map for anything that needs the mayor (worn or broken track, crowds,
    /// crews at work, events), plus arrows at the screen edge for pins that are off-screen.
    func updateAttention() {
        guard let state else { return }
        let issues = state.attentionIssues()
        var live = Set<String>()

        for issue in issues {
            guard let point = attentionPoint(for: issue) else { continue }
            live.insert(issue.id)
            let signature = "\(issue.kind)"
            if let existing = attentionNodes[issue.id], attentionSignatures[issue.id] == signature {
                existing.position = point
                continue
            }
            attentionNodes[issue.id]?.removeFromParent()
            let pin = makePin(for: issue)
            pin.position = point
            attentionLayer.addChild(pin)
            attentionNodes[issue.id] = pin
            attentionSignatures[issue.id] = signature
            attentionPoints[issue.id] = point
        }
        for (id, node) in attentionNodes where !live.contains(id) {
            node.removeFromParent()
            attentionNodes[id] = nil
            attentionSignatures[id] = nil
            attentionPoints[id] = nil
        }
        for issue in issues {
            if let point = attentionPoint(for: issue) { attentionPoints[issue.id] = point }
        }

        updateEdgeArrows(for: issues.filter(\.needsAction))
        updateClosureTapes()
        showHighlightRing()
    }

    /// Where an issue's pin goes: the middle of its stretch of track, or beside its station.
    func attentionPoint(for issue: AttentionIssue) -> CGPoint? {
        if let key = issue.track, let line = state?.line(id: key.lineID), let path = paths[key.lineID],
           line.stops.count == path.stopDistances.count,
           let i = line.stops.firstIndex(of: key.a), let j = line.stops.firstIndex(of: key.b) {
            let middle = (path.stopDistances[i] + path.stopDistances[j]) / 2
            return path.sample(at: middle).point
        }
        if let stationID = issue.stationID, let point = displayPosition(ofLandmark: stationID) {
            return CGPoint(x: point.x - cellSize * 0.5, y: point.y + cellSize * 0.42)
        }
        return nil
    }

    /// The issue whose pin is under a point, if any.
    func attentionHit(at p: CGPoint) -> String? {
        attentionPoints.first { TransitGeometry.distance($0.value, p) < 20 }?.key
    }

    private func makePin(for issue: AttentionIssue) -> SKNode {
        let node = SKNode()
        node.zPosition = 5
        let fill: UIColor
        switch issue.kind {
        case .disruption: fill = Palette.bad
        case .crowded, .upcoming: fill = Palette.warning
        case .festival: fill = Palette.card
        case .trip: fill = Palette.gold
        }
        let disc = SKShapeNode(circleOfRadius: 12)
        disc.fillColor = fill
        disc.strokeColor = Palette.ink
        disc.lineWidth = 2
        node.addChild(disc)

        let iconColor = issue.kind == .disruption ? Palette.card : Palette.ink
        let icon = icons.sprite(symbol: issue.symbol, color: iconColor, pointSize: 11,
                                variant: "pin-\(issue.kind == .disruption)")
        icon.zPosition = 1
        node.addChild(icon)

        if issue.needsAction {
            node.run(.repeatForever(.sequence([.scale(to: 1.12, duration: 0.5), .scale(to: 1.0, duration: 0.5)])))
        }
        return node
    }

    /// After "Show me": a ring that pulses around the problem so it can't be missed,
    /// even if the camera was already looking at that district.
    func showHighlightRing() {
        guard let state, let id = state.highlightIssueID else { return }
        state.highlightIssueID = nil
        guard let point = attentionPoints[id] else { return }
        attentionLayer.childNode(withName: "highlight")?.removeFromParent()

        let ring = SKShapeNode(circleOfRadius: 26)
        ring.name = "highlight"
        ring.strokeColor = Palette.ink
        ring.lineWidth = 3
        ring.fillColor = .clear
        ring.position = point
        ring.zPosition = 4
        attentionLayer.addChild(ring)
        let pulse = SKAction.sequence([
            .group([.scale(to: 1.5, duration: 0.6), .fadeAlpha(to: 0.2, duration: 0.6)]),
            .group([.scale(to: 1.0, duration: 0.0), .fadeAlpha(to: 1, duration: 0.0)]),
        ])
        ring.run(.sequence([.repeat(pulse, count: 6), .removeFromParent()]))
    }

    /// Small arrows at the screen edge toward problems that are off-screen, like in another district.
    private func updateEdgeArrows(for issues: [AttentionIssue]) {
        edgeArrows.removeAllChildren()
        let scale = cameraNode.xScale
        let halfWidth = size.width * scale / 2
        let halfHeight = size.height * scale / 2
        let visible = CGRect(x: cameraNode.position.x - halfWidth, y: cameraNode.position.y - halfHeight,
                             width: halfWidth * 2, height: halfHeight * 2)
        for issue in issues {
            guard let point = attentionPoints[issue.id], !visible.insetBy(dx: 20, dy: 20).contains(point) else { continue }
            // Direction from the screen center, in screen space.
            let dx = (point.x - cameraNode.position.x) / scale
            let dy = (point.y - cameraNode.position.y) / scale
            let edgeX = size.width / 2 - 70
            let edgeY = size.height / 2 - 90
            let t = min(edgeX / max(abs(dx), 0.001), edgeY / max(abs(dy), 0.001))
            let position = CGPoint(x: dx * t, y: dy * t)

            let arrow = SKNode()
            arrow.position = position
            let disc = SKShapeNode(circleOfRadius: 14)
            disc.fillColor = issue.kind == .disruption ? Palette.bad : Palette.warning
            disc.strokeColor = Palette.ink
            disc.lineWidth = 2
            arrow.addChild(disc)
            let chevron = icons.sprite(symbol: "arrowtriangle.right.fill", color: Palette.ink, pointSize: 10, variant: "edge")
            chevron.zRotation = atan2(dy, dx)
            chevron.zPosition = 1
            arrow.addChild(chevron)
            edgeArrows.addChild(arrow)
        }
    }

    /// Striped tape across stations closed for a parade or market.
    private func updateClosureTapes() {
        guard let state else { return }
        for landmark in state.landmarks {
            let closed = state.isStationClosed(landmark.id)
            let node = landmarkNodes[landmark.id]
            let existing = node?.childNode(withName: "closed-tape")
            if closed, existing == nil, let node {
                let tape = SKNode()
                tape.name = "closed-tape"
                tape.zPosition = 8
                tape.zRotation = -0.35
                let band = SKShapeNode(rect: CGRect(x: -cellSize * 0.55, y: -5, width: cellSize * 1.1, height: 10), cornerRadius: 2)
                band.fillColor = Palette.warning
                band.strokeColor = Palette.ink
                band.lineWidth = 1.2
                tape.addChild(band)
                let label = SKLabelNode()
                label.attributedText = NSAttributedString(string: "CLOSED", attributes: [
                    .font: AppFont.uiFont(AppFont.boldName, size: 9),
                    .foregroundColor: Palette.ink,
                    .kern: 1,
                ])
                label.verticalAlignmentMode = .center
                label.zPosition = 1
                tape.addChild(label)
                node.addChild(tape)
            } else if !closed {
                existing?.removeFromParent()
            }
        }
    }
}
