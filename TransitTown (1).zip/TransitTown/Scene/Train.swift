import SpriteKit
import UIKit

/// A two-car train running back and forth along a line.
/// Windows are dark glass when empty and light up, one per rider, as people board.
final class Train {
    /// Distance between the two cars' centers. Light rail cars are longer.
    let carGap: CGFloat

    let id: Int
    let lineID: Int
    /// Which train this is on its line (0 = first), for its upgrades.
    var slot = 0
    /// Distance of the lead car along the line's path.
    var distance: CGFloat = 0
    /// +1 toward the tail, -1 toward the head.
    var direction: CGFloat = 1
    /// The stop the train is at, or last left. Movement is always toward the neighboring stop.
    var stopIndex = 0
    /// Seconds left to wait at the current stop.
    var dwell: CGFloat = 0.6
    /// Where the train last stopped, for easing out of stations.
    var lastStop: CGFloat = 0
    /// True while waiting at a stop, until it picks a direction and leaves.
    var isDeparting = true

    let lead: SKNode
    let trailer: SKNode
    /// Lives in the scene's glow layer so it shows at night.
    let headlight: SKSpriteNode
    private var windows: [SKShapeNode] = []
    private var bodyColor: UIColor
    private var shownLoad = -1

    init(id: Int, lineID: Int, color: UIColor, isLightRail: Bool = false, glowTexture: SKTexture) {
        self.id = id
        self.lineID = lineID
        carGap = isLightRail ? 28 : 22
        bodyColor = color
        var collected: [SKShapeNode] = []
        let width: CGFloat = isLightRail ? 26 : 20
        let windowCount = isLightRail ? 4 : 3
        lead = Train.makeCar(color: color, isFront: true, width: width, windowCount: windowCount, windows: &collected)
        trailer = Train.makeCar(color: color, isFront: false, width: width, windowCount: windowCount, windows: &collected)
        windows = collected
        lead.zPosition = 1
        trailer.zPosition = 0

        headlight = SKSpriteNode(texture: glowTexture)
        headlight.size = CGSize(width: 34, height: 34)
        headlight.color = Palette.lamp
        headlight.colorBlendFactor = 1
        headlight.blendMode = .add
        headlight.alpha = 0.9
        setLoad(0, capacity: 1)
    }

    func setColor(_ color: UIColor) {
        guard color != bodyColor else { return }
        bodyColor = color
        (lead.childNode(withName: "body") as? SKShapeNode)?.fillColor = color
        (trailer.childNode(withName: "body") as? SKShapeNode)?.fillColor = color
        shownLoad = -1
    }

    /// Lights one window per rider aboard (scaled to capacity); empty windows stay dark.
    func setLoad(_ load: Int, capacity: Int) {
        guard load != shownLoad else { return }
        shownLoad = load
        let lit = capacity > 0 ? Int((Double(load) / Double(capacity) * Double(windows.count)).rounded(.up)) : 0
        let dark = bodyColor.mixed(with: Palette.ink, amount: 0.55)
        for (index, window) in windows.enumerated() {
            window.fillColor = index < lit ? Palette.card : dark
        }
    }

    func removeFromScene() {
        lead.removeFromParent()
        trailer.removeFromParent()
        headlight.removeFromParent()
    }

    /// Small bump when arriving at a stop.
    func bump() {
        let squash = SKAction.sequence([.scaleX(to: 0.9, duration: 0.06), .scaleX(to: 1, duration: 0.16)])
        lead.run(squash, withKey: "bump")
        trailer.run(squash, withKey: "bump")
    }

    private static func makeCar(color: UIColor, isFront: Bool, width: CGFloat, windowCount: Int,
                                windows: inout [SKShapeNode]) -> SKNode {
        let car = SKNode()
        let height: CGFloat = 11

        let body = SKShapeNode(rect: CGRect(x: -width / 2, y: -height / 2, width: width, height: height),
                               cornerRadius: isFront ? 4.5 : 3)
        body.name = "body"
        body.fillColor = color
        body.strokeColor = Palette.ink
        body.lineWidth = 1.5
        body.zPosition = 0
        car.addChild(body)

        let firstWindowX = -CGFloat(windowCount) * 5 / 2 + 0.7
        for i in 0..<windowCount {
            let window = SKShapeNode(rect: CGRect(x: firstWindowX + CGFloat(i) * 5, y: -2.25, width: 3.6, height: 4.5),
                                     cornerRadius: 1)
            window.strokeColor = .clear
            window.zPosition = 1
            car.addChild(window)
            windows.append(window)
        }

        if isFront {
            let lamp = SKShapeNode(circleOfRadius: 1.6)
            lamp.position = CGPoint(x: width / 2 - 2.2, y: 0)
            lamp.fillColor = Palette.lamp
            lamp.strokeColor = .clear
            lamp.zPosition = 1
            car.addChild(lamp)
        }
        return car
    }
}
