import SpriteKit
import UIKit

extension GameScene {

    // MARK: Touch phases

    func handleTouchBegan(at p: CGPoint, viewPoint: CGPoint) {
        guard let state, state.phase == .playing else {
            mode = .finished
            return
        }
        touchStart = (p, landmarkHit(at: p))
        touchTravel = 0
        selectedAtTouchStart = state.selectedLineID

        // Placing a permit or a decoration: a drag moves the map; only a clean tap places,
        // so you can scroll to the right spot first.
        if state.isDecorating || state.placingKind != nil || state.isDiggingTunnel {
            placeOnTap = p
            mode = .panning(start: viewPoint, last: viewPoint, moved: false)
            return
        }

        // A pin on the map: open the attention list on it.
        if let issueID = attentionHit(at: p) {
            state.attentionFocusID = issueID
            state.isAttentionOpen = true
            mode = .finished
            return
        }

        // The lost item, lying on the map: pick it up.
        if lostItemHit(at: p) {
            state.pickUpLostItem()
            AudioManager.shared.play(.sparkle)
            haptic(.medium)
            mode = .finished
            return
        }

        // Something to collect, find, return, or a resident waiting: always a tap on that
        // place, never the start of a track edit. Badges sit a little up and to the left, so
        // touches on them count too.
        if let id = communityTapTarget(at: p) {
            mode = .pending(landmarkID: id, start: p, time: CACurrentMediaTime(), extending: nil)
            return
        }

        // A pen is picked up: its ends are big, easy targets.
        if let selectedID = state.selectedLineID,
           let handle = terminals.first(where: { $0.lineID == selectedID && TransitGeometry.distance($0.point, p) < 46 }) {
            mode = .drawing(lineID: selectedID, atTail: handle.atTail)
            return
        }

        // On a landmark: drag to draw (or extend the picked-up line), hold to move it.
        if let id = landmarkHit(at: p) {
            var extending: LineHandle?
            if let selectedID = state.selectedLineID, let line = state.line(id: selectedID), line.stops.count >= 2,
               id == line.stops.first || id == line.stops.last {
                extending = LineHandle(lineID: selectedID, atTail: id == line.stops.last, point: p)
            }
            mode = .pending(landmarkID: id, start: p, time: CACurrentMediaTime(), extending: extending)
            return
        }

        // Lines are only edited with a pen in hand (picked from the menu): the middle of the
        // picked line can be dragged onto a landmark to add a stop. Without a pen, lines can't be
        // grabbed at all, so scrolling never edits anything.
        if let selectedID = state.selectedLineID, let hit = segmentHit(at: p), hit.lineID == selectedID {
            mode = .rerouting(lineID: hit.lineID, segment: hit.segment)
            return
        }

        // A tree: shake down any ripe fruit.
        if let item = state.decor(near: spot(at: p)), item.kind == .tree {
            let fallen = state.shakeTree(id: item.id)
            shakeTree(item, fallen: fallen)
            mode = .finished
            return
        }

        // Empty streets: pan around the city; a tap puts the pen down.
        mode = .panning(start: viewPoint, last: viewPoint, moved: false)
    }

    func handleTouchMoved(to p: CGPoint, viewPoint: CGPoint) {
        guard let state else { return }
        if let start = touchStart { touchTravel = max(touchTravel, TransitGeometry.distance(start.point, p)) }
        let now = CACurrentMediaTime()
        if let last = lastDragSample, now > last.time {
            let speed = hypot(viewPoint.x - last.point.x, viewPoint.y - last.point.y) / CGFloat(now - last.time)
            dragSpeed += (min(speed, 2000) - dragSpeed) * 0.3
        }
        lastDragSample = (viewPoint, now)

        switch mode {
        case let .pending(id, start, _, extending):
            guard TransitGeometry.distance(p, start) > dragThreshold else { return }
            if let extending {
                mode = .drawing(lineID: extending.lineID, atTail: extending.atTail)
                continueDrawing(lineID: extending.lineID, atTail: extending.atTail, to: p)
                return
            }
            guard let landmark = state.landmark(id: id) else {
                mode = .finished
                return
            }
            // No pen picked: dragging from a landmark just scrolls the map.
            guard state.armedColorIndex != nil else {
                mode = .panning(start: viewPoint, last: viewPoint, moved: true)
                return
            }
            let district = landmark.kind.info.district
            guard state.hasFreeLine(in: district) || landmark.kind.info.category == .hub else {
                state.show(state.lineLockedMessage(in: district))
                mode = .finished
                return
            }
            guard state.hasFreeLine(in: district), !state.isStationFull(id) else {
                state.flashAlert(fullMessage(for: id))
                UINotificationFeedbackGenerator().notificationOccurred(.error)
                mode = .finished
                return
            }
            guard let lineID = state.startLine(at: id) else {
                mode = .finished
                return
            }
            mode = .drawing(lineID: lineID, atTail: true)
            haptic(.light)
            continueDrawing(lineID: lineID, atTail: true, to: p)

        case let .drawing(lineID, atTail):
            continueDrawing(lineID: lineID, atTail: atTail, to: p)

        case let .linkingHubs(from):
            continueLinking(from: from, to: p)

        case let .moving(id):
            landmarkNodes[id]?.position = p
            glowNodes[id]?.position = CGPoint(x: p.x, y: p.y - cellSize * 0.35)
            showGhost(for: id, at: p)
            let target = validDropCell(for: id, at: p)
            if target != moveTarget?.cell {
                moveTarget = target.map { (id: id, cell: $0) }
                drawLines()
                syncTrains()
            }

        case let .rerouting(lineID, segment):
            continueRerouting(lineID: lineID, segment: segment, to: p)

        case let .panning(start, last, moved):
            let travelled = hypot(viewPoint.x - start.x, viewPoint.y - start.y)
            let isMoving = moved || travelled > 8
            if isMoving && canPan {
                cameraNode.removeAction(forKey: "focus")
                panCamera(byViewDelta: CGPoint(x: viewPoint.x - last.x, y: viewPoint.y - last.y))
            }
            mode = .panning(start: start, last: viewPoint, moved: isMoving)

        case .idle, .finished:
            break
        }
    }

    func handleTouchEnded(at p: CGPoint, cancelled: Bool) {
        defer {
            activeTouch = nil
            touchStart = nil
            placeOnTap = nil
            lastDragSample = nil
            dragSpeed = 0
            mode = .idle
            rejectedLandmarkID = nil
            hidePreview()
            updateGridVisibility()
        }
        guard let state else { return }

        switch mode {
        case let .pending(id, _, _, _):
            if !cancelled {
                tapped(landmarkID: id)
            }

        case let .drawing(lineID, _):
            // A line needs at least two stops to exist.
            if let line = state.line(id: lineID), line.stops.count < 2 {
                state.deleteLine(lineID)
            }
            // Touched and let go without dragging: a tap. On a landmark, open it; anywhere else,
            // put the line down.
            if !cancelled, touchTravel < dragThreshold {
                if let id = touchStart?.landmarkID {
                    tapped(landmarkID: id)
                } else if selectedAtTouchStart == lineID {
                    state.setSelectedLine(nil)
                    state.armedColorIndex = nil
                }
            }

        case let .moving(id):
            mode = .idle
            let original = state.landmark(id: id)?.cell
            let drop = cancelled ? nil : validDropCell(for: id, at: p)
            moveTarget = nil
            hideGhost()
            if let finalCell = drop ?? original {
                settle(id, to: center(of: finalCell))
            }
            if let drop, drop != original {
                state.moveLandmark(id, to: drop)
                haptic(.light)
                AudioManager.shared.play(.place)
                AudioManager.shared.playPlaceLandmark()
                ripple(at: center(of: drop))
            } else {
                if !cancelled, gridPoint(at: p) != original {
                    state.show("Landmarks need a square of space around them")
                }
                redraw()
            }

        case let .panning(_, _, moved):
            if let target = placeOnTap {
                if !moved && !cancelled { placeTapped(at: target) }
            } else if !moved && !cancelled {
                state.setSelectedLine(nil)
                if state.armedColorIndex != nil {
                    state.armedColorIndex = nil
                }
            }

        case let .rerouting(lineID, _):
            // Tapping the selected line's body again (no drag) puts it down; tapping another
            // line just selects that one.
            if !cancelled, touchTravel < dragThreshold, selectedAtTouchStart == lineID {
                state.setSelectedLine(nil)
                state.armedColorIndex = nil
            }

        case .linkingHubs, .idle, .finished:
            break
        }
    }

    /// A quick tap on a landmark: derelict sites open their blueprint page; open ones show their status.
    private func tapped(landmarkID id: Int) {
        guard let state, let landmark = state.landmark(id: id) else { return }
        if landmark.isUnderConstruction {
            state.inspectedStationID = id
            return
        }
        if !landmark.isOpen {
            state.openBook(district: landmark.kind.info.district)
            return
        }
        if state.lostItemReturnTarget == id {
            AudioManager.shared.play(.tick)
            state.returnPrompt = id
            return
        }
        if state.collectTips(at: id) > 0 {
            AudioManager.shared.play(.chunk)
            haptic(.light)
            return
        }
        if let spotlight = state.spotlight(at: id) {
            AudioManager.shared.play(.tick)
            state.spotlightCard = spotlight
            return
        }
        AudioManager.shared.play(.whoosh, volume: 0.6)
        state.albumLandmarkID = id
        state.isAlbumOpen = true
    }

    /// Long press on a landmark: pick it up.
    func beginMove(_ id: Int) {
        if state?.landmark(id: id)?.kind.info.category == .canal {
            state?.show("Quays stay on the water")
            mode = .finished
            return
        }
        if state?.landmark(id: id)?.kind.info.category == .hub {
            state?.show("Stations stay where they are")
            mode = .finished
            return
        }
        mode = .moving(landmarkID: id)
        moveTarget = nil
        haptic(.medium)
        AudioManager.shared.play(.pop)
        if let node = landmarkNodes[id] {
            node.removeAction(forKey: "settle")
            node.zPosition = 20
            node.run(.scale(to: 1.15, duration: 0.1))
        }
        updateGridVisibility()
    }

    // MARK: Gestures

    /// Dragging a line's end: entering a new landmark adds it, entering the previous stop removes the last one.
    /// A brand-new line that reaches another district's hub turns into light rail.
    private func continueDrawing(lineID: Int, atTail: Bool, to p: CGPoint) {
        guard let state, let line = state.line(id: lineID),
              let endID = atTail ? line.stops.last : line.stops.first else {
            mode = .finished
            return
        }

        let hitID = landmarkHit(at: p, tolerance: 0.42)
        if hitID != rejectedLandmarkID { rejectedLandmarkID = nil }

        if let hitID, hitID != endID, hitID != rejectedLandmarkID, let target = state.landmark(id: hitID) {
            let previousID: Int? = line.stops.count > 1
                ? (atTail ? line.stops[line.stops.count - 2] : line.stops[1])
                : nil
            let crossesDistricts = !line.isLightRail && target.kind.info.district != line.district

            if hitID == previousID {
                state.removeEndStop(of: lineID, atTail: atTail)
                haptic(.light)
                AudioManager.shared.play(.tick)
            } else if crossesDistricts {
                // From a hub, a fresh line becomes light rail to the other district's hub.
                if line.stops.count == 1, target.kind.info.category == .hub,
                   state.landmark(id: endID)?.kind.info.category == .hub {
                    state.deleteLine(lineID)
                    linkHubs(endID, hitID)
                    mode = .finished
                    hidePreview()
                    return
                }
                rejectedLandmarkID = hitID
                state.show("That stop can't join this line.")
                haptic(.rigid)
            } else if !line.stops.contains(hitID) {
                let previousLength = paths[lineID]?.total ?? 0
                if state.addStop(hitID, to: lineID, atTail: atTail) {
                    haptic(.light)
                    AudioManager.shared.play(.ping, volume: 0.7)
                    // Into the tunnel: this drag ends here. The line now waits at the exit, and
                    // the next drag brings it out to a landmark.
                    if case .connectOut = state.tunnelStep, state.landmark(id: hitID)?.kind == .tunnelPortal {
                        AudioManager.shared.play(.whoosh, volume: 0.6)
                        mode = .finished
                        return
                    }
                    startReveal(lineID: lineID, fromHead: !atTail, previousLength: previousLength)
                    if let point = position(ofLandmark: hitID) {
                        ripple(at: point, color: line.color)
                    }
                } else {
                    rejectedLandmarkID = hitID
                    let isQuay = target.kind.info.category == .canal
                    let railCanStop = target.kind.info.category == .hub || isQuay
                    if !(line.isLightRail && railCanStop) {
                        // (If the light rail could stop there, it couldn't be paid for; that was already said.)
                        state.show(line.isLightRail ? "The light rail stops at district hubs and canal quays"
                                   : (isQuay ? "Quays are light rail stops" : fullMessage(for: hitID)))
                    }
                    haptic(.rigid)
                }
            }
        }

        guard let updated = state.line(id: lineID),
              let newEndID = atTail ? updated.stops.last : updated.stops.first,
              let endPoint = position(ofLandmark: newEndID) else { return }
        showPreview(TransitGeometry.octilinear(from: endPoint, to: p), color: updated.color)
    }

    /// Dragging from a full hub: only light rail can start here.
    private func continueLinking(from hubID: Int, to p: CGPoint) {
        guard let state, let start = position(ofLandmark: hubID) else {
            mode = .finished
            return
        }
        if let hitID = landmarkHit(at: p, tolerance: 0.42), hitID != hubID,
           let target = state.landmark(id: hitID), target.kind.info.category == .hub {
            linkHubs(hubID, hitID)
            hidePreview()
            mode = .finished
            return
        }
        showPreview(TransitGeometry.octilinear(from: start, to: p), color: Palette.lightRail)
    }

    private func linkHubs(_ a: Int, _ b: Int) {
        guard let state else { return }
        if state.connectHubs(a, b) != nil {
            haptic(.medium)
            if let point = position(ofLandmark: b) {
                ripple(at: point, color: Palette.lightRail)
            }
        }
    }

    /// Dragging the middle of a line: bends it toward the finger and inserts the first new landmark it touches.
    private func continueRerouting(lineID: Int, segment: Int, to p: CGPoint) {
        guard let state, let line = state.line(id: lineID), segment + 1 < line.stops.count,
              let a = position(ofLandmark: line.stops[segment]),
              let b = position(ofLandmark: line.stops[segment + 1]) else {
            hidePreview()
            mode = .finished
            return
        }

        if let hitID = landmarkHit(at: p, tolerance: 0.42), !line.stops.contains(hitID) {
            hidePreview()
            mode = .finished
            if state.insertStop(hitID, into: lineID, at: segment + 1) {
                haptic(.light)
                if let point = position(ofLandmark: hitID) {
                    ripple(at: point, color: line.color)
                }
            } else {
                let sameDistrict = state.canJoin(hitID, line: line)
                UINotificationFeedbackGenerator().notificationOccurred(.error)
                state.flashAlert(sameDistrict ? fullMessage(for: hitID)
                           : "That stop can't join this line.")
                haptic(.rigid)
            }
            return
        }

        let bend = TransitGeometry.octilinear(from: a, to: p)
            + Array(TransitGeometry.octilinear(from: p, to: b).dropFirst())
        showPreview(bend, color: line.color, dashed: true)
    }

    /// The stop-to-stop segment of a line closest to a point, if within reach.
    private func segmentHit(at p: CGPoint) -> (lineID: Int, segment: Int)? {
        guard let state else { return nil }
        var best: (lineID: Int, segment: Int, gap: CGFloat)?

        for line in state.lines where line.stops.count >= 2 {
            guard let route = routed[line.id], route.points.count >= 2 else { continue }
            let reach: CGFloat = line.id == state.selectedLineID ? 24 : 16
            for i in 1..<route.points.count {
                let gap = TransitGeometry.distance(from: p, toSegment: route.points[i - 1], route.points[i])
                guard gap < reach, gap < (best?.gap ?? .greatestFiniteMagnitude) else { continue }
                let stopBefore = route.stopIndices.lastIndex(where: { $0 <= i - 1 }) ?? 0
                let segment = min(stopBefore, line.stops.count - 2)
                best = (lineID: line.id, segment: segment, gap: gap)
            }
        }

        guard let best else { return nil }
        return (lineID: best.lineID, segment: best.segment)
    }

    /// The cell a dragged landmark can drop into: in its own district, with space around it.
    private func validDropCell(for id: Int, at p: CGPoint) -> GridPoint? {
        guard let state, let cell = gridPoint(at: p), let landmark = state.landmark(id: id) else { return nil }
        return state.isBuildable(cell, in: landmark.kind.info.district, ignoring: id) ? cell : nil
    }

    private func fullMessage(for landmarkID: Int) -> String {
        let name = state?.landmark(id: landmarkID)?.kind.info.name ?? "This station"
        let limit = state?.maxLines(at: landmarkID) ?? GameState.maxLinesPerStation
        return "\(name) already has \(limit) lines"
    }

    private func haptic(_ style: UIImpactFeedbackGenerator.FeedbackStyle) {
        UIImpactFeedbackGenerator(style: style).impactOccurred()
    }
}

extension GameScene {
    /// The stretch sound plays while track is being drawn, extended, bent, or laid between hubs.
    func updateDrawingSound(dt: CGFloat) {
        let drawing: Bool
        switch mode {
        case .drawing, .rerouting, .linkingHubs: drawing = true
        default: drawing = false
        }
        // Let the speed settle back when the finger pauses.
        if drawing, let last = lastDragSample, CACurrentMediaTime() - last.time > 0.08 {
            dragSpeed *= max(0, 1 - dt * 6)
        }
        AudioManager.shared.setDrawing(drawing, speed: Double(dragSpeed))
    }
}


extension GameScene {

    /// A clean tap while placing: set down the decoration or the permit there.
    func placeTapped(at p: CGPoint) {
        guard let state else { return }
        if state.isDiggingTunnel {
            if let cell = gridPoint(at: p) {
                state.digTunnel(at: cell)
                AudioManager.shared.play(.place)
                haptic(.medium)
            }
            return
        }
        if state.isDecorating {
            // Decorations snap to half squares, so they can stand on the streets too.
            let target = spot(at: p)
            if state.removingDecor {
                if state.removeDecor(near: target) {
                    haptic(.light)
                    AudioManager.shared.play(.pop)
                }
            } else if let kind = state.placingDecor, state.place(kind, atSpot: target) {
                haptic(.medium)
                AudioManager.shared.play(.place)
                if kind == .tree || kind == .planter { AudioManager.shared.play(.rustle, volume: 0.6) }
            }
            return
        }
        if let kind = state.placingKind {
            if let cell = gridPoint(at: p), state.build(kind, at: cell) {
                haptic(.medium)
                AudioManager.shared.playPlaceLandmark()
            } else if gridPoint(at: p) == nil {
                state.show("Tap a marked square, or cancel at the top")
            }
        }
    }
}


extension GameScene {

    /// The landmark whose badge (or the landmark itself, if it has something waiting) is under
    /// the touch, if any.
    func communityTapTarget(at p: CGPoint) -> Int? {
        guard let state else { return nil }
        for (id, node) in communityBadges where TransitGeometry.distance(node.position, p) < 30 {
            return id
        }
        if let id = landmarkHit(at: p, tolerance: 0.5) {
            let hasSomething = (state.tipJars[id] ?? 0) >= GameState.tipJarReady
                || state.spotlight(at: id) != nil || state.lostItemReturnTarget == id
            if hasSomething { return id }
        }
        return nil
    }
}
