import SpriteKit
import UIKit

extension GameScene {

    /// Trees and benches on their squares. Trees sway a little and show their ripe fruit.
    func drawDecor() {
        guard let state else { return }
        let live = Set(state.decorItems.map(\.id))
        for (id, node) in decorNodes where !live.contains(id) {
            node.removeFromParent()
            decorNodes[id] = nil
            decorGlows[id]?.removeFromParent()
            decorGlows[id] = nil
        }
        for item in state.decorItems {
            let spotCenter = spotPoint(item.position)
            let base = CGPoint(x: spotCenter.x, y: spotCenter.y - cellSize * 0.25)
            let node: SKNode
            if let existing = decorNodes[item.id] {
                node = existing
            } else {
                switch item.kind {
                case .tree: node = makeTree()
                case .bench: node = makeBench()
                case .lamp: node = makeLamp()
                case .planter: node = makePlanter()
                case .mailbox: node = makeMailbox()
                default: node = makeThemed(item.kind)
                }
                decorLayer.addChild(node)
                decorNodes[item.id] = node
                if state.isDecorating {
                    // Just placed: pop up, with a puff of leaves for trees.
                    node.setScale(0.2)
                    node.run(.sequence([.scale(to: 1.12, duration: 0.14), .scale(to: 0.96, duration: 0.08), .scale(to: 1, duration: 0.08)]))
                    if item.kind == .tree { leafPuff(at: spotPoint(item.position)) }
                }
            }
            node.position = base
            node.zPosition = -base.y * 0.01   // sorts with buildings: lower on screen is in front
            if item.kind == .lamp {
                // At night the lamp lights the pavement around it (the glow layer fades in after dark).
                if decorGlows[item.id] == nil {
                    let sprite = SKSpriteNode(texture: glowTexture)
                    sprite.size = CGSize(width: cellSize * 1.9, height: cellSize * 1.1)
                    sprite.color = Palette.lamp
                    sprite.colorBlendFactor = 1
                    sprite.blendMode = .add
                    sprite.alpha = 0.5
                    glowLayer.addChild(sprite)
                    decorGlows[item.id] = sprite
                }
                decorGlows[item.id]?.position = CGPoint(x: base.x, y: base.y + cellSize * 0.1)
            }
            if item.kind == .tree { showFruit(on: node, item: item) }
        }
    }

    private var treeSize: CGFloat { cellSize * 1.05 }

    private func makeTree() -> SKNode {
        let root = SKNode()
        let sprite = SKSpriteNode(texture: MarkerFactory.tree(size: treeSize), size: CGSize(width: treeSize, height: treeSize))
        sprite.anchorPoint = CGPoint(x: 0.5, y: 0.08)   // the trunk's foot sits 92% down the drawing
        sprite.name = "tree"
        root.addChild(sprite)
        let tilt = CGFloat.random(in: 0.03...0.045)
        let period = Double.random(in: 1.8...2.4)
        sprite.zRotation = -tilt
        sprite.run(.repeatForever(.sequence([
            .rotate(toAngle: tilt, duration: period, shortestUnitArc: true),
            .rotate(toAngle: -tilt, duration: period, shortestUnitArc: true),
        ])))
        return root
    }

    private func makeBench() -> SKNode {
        let root = SKNode()
        let size = cellSize * 0.85
        let sprite = SKSpriteNode(texture: MarkerFactory.bench(size: size), size: CGSize(width: size, height: size))
        sprite.anchorPoint = CGPoint(x: 0.5, y: 0.16)   // the legs end 84% down the drawing
        root.addChild(sprite)
        return root
    }

    /// A themed decoration from a comment-card collection.
    private func makeThemed(_ kind: DecorKind) -> SKNode {
        let root = SKNode()
        let size = cellSize * (kind == .statue || kind == .cafeTable ? 1.0 : 0.92)
        let sprite = SKSpriteNode(texture: MarkerFactory.cachedArt("decor-\(kind.rawValue)") ?? MarkerFactory.mailbox(size: size),
                                  size: CGSize(width: size, height: size))
        sprite.anchorPoint = CGPoint(x: 0.5, y: 0.12)   // each themed drawing's foot sits about 88% down
        root.addChild(sprite)
        return root
    }

    private func makeMailbox() -> SKNode {
        let root = SKNode()
        let size = cellSize * 0.9
        let sprite = SKSpriteNode(texture: MarkerFactory.mailbox(size: size), size: CGSize(width: size, height: size))
        sprite.anchorPoint = CGPoint(x: 0.5, y: 0.1)   // the base sits 90% down the drawing
        root.addChild(sprite)
        return root
    }

    /// The middle of a half-square spot (the middle of square (c, r) is spot (2c + 1, 2r + 1)).
    func spotPoint(_ spot: GridPoint) -> CGPoint {
        let origin = center(of: GridPoint(col: 0, row: 0))
        let right = center(of: GridPoint(col: 1, row: 0))
        let down = center(of: GridPoint(col: 0, row: 1))
        let fx = CGFloat(spot.col - 1) / 2, fy = CGFloat(spot.row - 1) / 2
        return CGPoint(x: origin.x + fx * (right.x - origin.x) + fy * (down.x - origin.x),
                       y: origin.y + fx * (right.y - origin.y) + fy * (down.y - origin.y))
    }

    /// The half-square spot nearest a point on the map.
    func spot(at point: CGPoint) -> GridPoint {
        let origin = center(of: GridPoint(col: 0, row: 0))
        let stepX = center(of: GridPoint(col: 1, row: 0)).x - origin.x
        let stepY = center(of: GridPoint(col: 0, row: 1)).y - origin.y
        let fx = (point.x - origin.x) / stepX, fy = (point.y - origin.y) / stepY
        return GridPoint(col: Int((fx * 2 + 1).rounded()), row: Int((fy * 2 + 1).rounded()))
    }

    private func makePlanter() -> SKNode {
        let root = SKNode()
        let size = cellSize * 0.95
        let sprite = SKSpriteNode(texture: MarkerFactory.planter(size: size), size: CGSize(width: size, height: size))
        sprite.anchorPoint = CGPoint(x: 0.5, y: 0.12)   // the box's foot sits 88% down the drawing
        root.addChild(sprite)
        return root
    }

    private func makeLamp() -> SKNode {
        let root = SKNode()
        let size = cellSize * 1.0
        let sprite = SKSpriteNode(texture: MarkerFactory.lamp(size: size), size: CGSize(width: size, height: size))
        sprite.anchorPoint = CGPoint(x: 0.5, y: 0.12)
        root.addChild(sprite)
        return root
    }

    /// Spots on the canopy where fruit hangs, in the tree drawing's 100 × 100 space.
    private static let fruitSpots = [CGPoint(x: 34, y: 42), CGPoint(x: 64, y: 36), CGPoint(x: 52, y: 56)]

    private func fruitPosition(_ index: Int) -> CGPoint {
        let spot = GameScene.fruitSpots[index % GameScene.fruitSpots.count]
        // The tree sprite's anchor is (0.5, 0.08); image y runs downward.
        return CGPoint(x: (spot.x / 100 - 0.5) * treeSize, y: (1 - spot.y / 100 - 0.08) * treeSize)
    }

    private func fruitColor(_ fruit: Fruit) -> UIColor {
        switch fruit {
        case .apple: return UIColor(hex: 0xD9533B)
        case .orange: return UIColor(hex: 0xE8833A)
        case .lemon: return UIColor(hex: 0xF2C94C)
        case .plum: return UIColor(hex: 0x7A4FB0)
        }
    }

    private func makeFruit(_ fruit: Fruit) -> SKNode {
        let berry = SKShapeNode(circleOfRadius: treeSize * 0.055)
        berry.fillColor = fruitColor(fruit)
        berry.strokeColor = fruitColor(fruit).mixed(with: Palette.ink, amount: 0.35)
        berry.lineWidth = 1
        let shine = SKShapeNode(circleOfRadius: treeSize * 0.016)
        shine.fillColor = UIColor.white.withAlphaComponent(0.6)
        shine.strokeColor = .clear
        shine.position = CGPoint(x: -treeSize * 0.018, y: treeSize * 0.018)
        berry.addChild(shine)
        return berry
    }

    private func showFruit(on node: SKNode, item: Decor) {
        guard let tree = node.childNode(withName: "tree") else { return }
        let existing = tree.children.filter { $0.name == "fruit" }
        guard existing.count != item.ripe else { return }
        existing.forEach { $0.removeFromParent() }
        for index in 0..<item.ripe {
            let berry = makeFruit(item.fruit)
            berry.name = "fruit"
            berry.position = fruitPosition(index)
            berry.zPosition = 1
            tree.addChild(berry)
            if index == item.ripe - 1 && existing.count < item.ripe {
                berry.setScale(0.1)
                berry.run(.scale(to: 1, duration: 0.3))
            }
        }
    }

    /// A tap on a tree: it wiggles, and any ripe fruit tumbles down and rolls away.
    func shakeTree(_ item: Decor, fallen: Int) {
        let fruit = item.fruit
        guard let node = decorNodes[item.id] else { return }
        AudioManager.shared.play(.rustle)
        node.removeAction(forKey: "wiggle")
        node.run(.sequence([
            .scaleX(to: 1.1, y: 0.92, duration: 0.08),
            .scaleX(to: 0.95, y: 1.06, duration: 0.1),
            .scale(to: 1, duration: 0.1),
        ]), withKey: "wiggle")
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
        guard fallen > 0 else {
            leafPuff(at: spotPoint(item.position))
            return
        }
        for index in 0..<fallen {
            let berry = makeFruit(fruit)
            let start = CGPoint(x: node.position.x + fruitPosition(index).x, y: node.position.y + fruitPosition(index).y)
            berry.position = start
            berry.zPosition = 3
            effectsLayer.addChild(berry)
            let ground = node.position.y + CGFloat.random(in: -6...2)
            let roll = CGFloat([-1, 1].randomElement() ?? 1) * CGFloat.random(in: 8...18)
            let fall = SKAction.moveTo(y: ground, duration: 0.32)
            fall.timingMode = .easeIn
            let bounce = SKAction.sequence([.moveBy(x: roll * 0.4, y: 6, duration: 0.12), .moveBy(x: roll * 0.6, y: -6, duration: 0.14)])
            berry.run(.sequence([
                .wait(forDuration: Double(index) * 0.06),
                fall, bounce,
                .wait(forDuration: 0.6),
                .fadeOut(withDuration: 0.4),
                .removeFromParent(),
            ]))
        }
        let name = fruit.name
        state?.show(fallen == 1 ? "One ripe \(String(name.dropLast()))" : "\(fallen) ripe \(name)")
    }

    private func leafPuff(at point: CGPoint) {
        for index in 0..<6 {
            let leaf = SKShapeNode(ellipseOf: CGSize(width: 6, height: 3.5))
            leaf.fillColor = index % 2 == 0 ? UIColor(hex: 0x7FAE69) : UIColor(hex: 0x9CC686)
            leaf.strokeColor = .clear
            leaf.position = CGPoint(x: point.x, y: point.y + cellSize * 0.2)
            leaf.zPosition = 2
            effectsLayer.addChild(leaf)
            let angle = CGFloat(index) / 6 * .pi * 2 + CGFloat.random(in: -0.3...0.3)
            let distance = CGFloat.random(in: 16...26)
            let drift = SKAction.moveBy(x: cos(angle) * distance, y: sin(angle) * distance - 6, duration: 0.6)
            drift.timingMode = .easeOut
            leaf.run(.sequence([
                .group([drift, .rotate(byAngle: .pi * 1.5, duration: 0.6), .fadeOut(withDuration: 0.6)]),
                .removeFromParent(),
            ]))
        }
    }
}
