import SpriteKit
import UIKit

extension GameScene {

    /// Reacts to things the simulation reports: riders giving up, restorations.
    func handleSimEvents() {
        guard let state else { return }
        for event in state.drainEvents() {
            switch event {
            case .gaveUp(let stationID):
                if let point = displayPosition(ofLandmark: stationID) {
                    showPopup("−1", at: point, color: Palette.inkSoft, rise: 14)
                }
            case let .note(text, stationID):
                if let point = position(ofLandmark: stationID) {
                    showPopup(text, at: CGPoint(x: point.x, y: point.y + cellSize * 0.9), color: UIColor(hex: 0xC8553F))
                }
            case let .stamp(text, stationID):
                if let point = displayPosition(ofLandmark: stationID) {
                    showStamp(text, at: point, color: text == "ARRIVED" ? Palette.good : Palette.stampRed)
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                }
            case .restored(let landmarkID):
                if let point = position(ofLandmark: landmarkID) {
                    confetti(at: point)
                    ripple(at: point, color: Palette.gold)
                    ripple(at: point, color: Palette.gold, delay: 0.15)
                    UINotificationFeedbackGenerator().notificationOccurred(.success)
                }
            }
        }
    }

    /// A small label that rises and fades above a station.
    /// An inked rubber stamp that thumps down and fades, matching the stamped landmarks.
    func showStamp(_ text: String, at point: CGPoint, color: UIColor = Palette.stampRed) {
        let stamp = SKSpriteNode(texture: MarkerFactory.rubberStamp(text, color: color))
        stamp.position = CGPoint(x: point.x + 18, y: point.y + 26)
        stamp.zRotation = CGFloat.random(in: -0.24 ... -0.08)
        stamp.setScale(1.8)
        stamp.alpha = 0
        stamp.zPosition = 3
        popupLayer.addChild(stamp)
        let thump = SKAction.group([.scale(to: 1, duration: 0.12), .fadeAlpha(to: 0.92, duration: 0.08)])
        thump.timingMode = .easeIn
        stamp.run(.sequence([thump, .wait(forDuration: 1.0), .fadeOut(withDuration: 0.4), .removeFromParent()]))
    }

    func showPopup(_ text: String, at point: CGPoint, color: UIColor, rise: CGFloat = 26) {
        let node = SKNode()
        let label = SKLabelNode()
        label.attributedText = NSAttributedString(string: text, attributes: [
            .font: AppFont.uiFont(AppFont.boldName, size: 13),
            .foregroundColor: color,
            .kern: 0.4,
        ])
        label.verticalAlignmentMode = .center
        label.horizontalAlignmentMode = .center
        label.zPosition = 1
        let width = label.frame.width + 12
        let pill = SKShapeNode(rect: CGRect(x: -width / 2, y: -8, width: width, height: 16), cornerRadius: 8)
        pill.fillColor = Palette.card
        pill.strokeColor = color.withAlphaComponent(0.6)
        pill.lineWidth = 1
        pill.zPosition = 0
        node.addChild(pill)
        node.addChild(label)

        node.position = CGPoint(x: point.x + 14, y: point.y + 10)
        node.alpha = 0
        node.setScale(0.6)
        popupLayer.addChild(node)

        let up = SKAction.moveBy(x: 0, y: rise, duration: 0.9)
        up.timingMode = .easeOut
        node.run(.sequence([
            .group([.fadeIn(withDuration: 0.12), .scale(to: 1, duration: 0.18), up]),
            .fadeOut(withDuration: 0.3),
            .removeFromParent(),
        ]))
    }

    /// Expanding ring used for drops and new stops.
    func ripple(at point: CGPoint, color: UIColor = Palette.ink, delay: TimeInterval = 0) {
        let ring = SKShapeNode(circleOfRadius: cellSize * 0.4)
        ring.position = point
        ring.strokeColor = color
        ring.lineWidth = 2.5
        ring.fillColor = .clear
        ring.alpha = 0
        effectsLayer.addChild(ring)
        let expand = SKAction.scale(to: 1.9, duration: 0.45)
        expand.timingMode = .easeOut
        ring.run(.sequence([
            .wait(forDuration: delay),
            .fadeAlpha(to: 0.7, duration: 0.02),
            .group([expand, .fadeOut(withDuration: 0.45)]),
            .removeFromParent(),
        ]))
    }

    /// Paper confetti in the four line colors, for ribbon-cuttings.
    func confetti(at point: CGPoint) {
        let colors = Palette.lines + [Palette.gold]
        for i in 0..<40 {
            let piece = SKSpriteNode(color: colors[i % colors.count], size: CGSize(width: 6, height: 3.5))
            piece.position = point
            piece.zRotation = CGFloat.random(in: 0...(2 * .pi))
            popupLayer.addChild(piece)

            let angle = CGFloat.random(in: 0...(2 * .pi))
            let distance = CGFloat.random(in: 40...110)
            let burst = SKAction.moveBy(x: cos(angle) * distance, y: sin(angle) * distance + 30, duration: 0.55)
            burst.timingMode = .easeOut
            let fall = SKAction.moveBy(x: cos(angle) * 12, y: -60, duration: 0.9)
            fall.timingMode = .easeIn
            piece.run(.sequence([
                .group([burst, .rotate(byAngle: CGFloat.random(in: -6...6), duration: 0.55)]),
                .group([fall, .rotate(byAngle: CGFloat.random(in: -4...4), duration: 0.9), .fadeOut(withDuration: 0.9)]),
                .removeFromParent(),
            ]))
        }
    }
}
