import UIKit

/// The day's light, applied as a multiply tint over the map. Keyed to day progress
/// (0 when the first train runs, 1 when the last one does). Full daylight through midday,
/// then a slow, even fade into a soft blue night. No warm sunset band.
enum DayCycle {
    private struct Key {
        let phase: CGFloat
        let r: CGFloat
        let g: CGFloat
        let b: CGFloat
        let night: CGFloat
    }

    private static let keys: [Key] = [
        Key(phase: 0.00, r: 0.94, g: 0.95, b: 0.98, night: 0.15), // first light
        Key(phase: 0.06, r: 1.00, g: 1.00, b: 1.00, night: 0.0),
        Key(phase: 0.52, r: 1.00, g: 1.00, b: 1.00, night: 0.0),
        Key(phase: 0.84, r: 0.74, g: 0.78, b: 0.92, night: 1.0), // night
        Key(phase: 1.00, r: 0.72, g: 0.76, b: 0.91, night: 1.0),
    ]

    /// Returns the tint color and how "night" it is (0...1).
    static func sample(_ progress: CGFloat) -> (tint: UIColor, night: CGFloat) {
        let p = min(max(progress, 0), 1)
        var i = 1
        while i < keys.count - 1 && keys[i].phase < p { i += 1 }
        let a = keys[i - 1], b = keys[i]
        let span = b.phase - a.phase
        let t = span > 0 ? min(1, max(0, (p - a.phase) / span)) : 0
        let s = t * t * (3 - 2 * t)
        func mix(_ x: CGFloat, _ y: CGFloat) -> CGFloat { x + (y - x) * s }
        let tint = UIColor(red: mix(a.r, b.r), green: mix(a.g, b.g), blue: mix(a.b, b.b), alpha: 1)
        return (tint, mix(a.night, b.night))
    }
}
