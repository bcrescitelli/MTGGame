import SpriteKit
import UIKit

/// What the current touch is doing.
enum DragMode {
    case idle
    /// Finger is down on a landmark; becomes `.drawing` on drag or `.moving` on hold.
    /// `extending` is set when the landmark is an end of the line whose pen is picked up:
    /// a drag then extends that line instead of starting a new one.
    case pending(landmarkID: Int, start: CGPoint, time: TimeInterval, extending: LineHandle?)
    case drawing(lineID: Int, atTail: Bool)
    case moving(landmarkID: Int)
    case rerouting(lineID: Int, segment: Int)
    /// Dragging from a hub toward another district's hub to lay light rail.
    case linkingHubs(from: Int)
    /// One finger on empty streets: pans the map when zoomed in; a tap clears the selection.
    case panning(start: CGPoint, last: CGPoint, moved: Bool)
    /// Touch already handled; ignore the rest of it.
    case finished
}

/// The end of a line past its terminal station. Dragging it extends or shortens the line.
struct LineHandle {
    let lineID: Int
    let atTail: Bool
    let point: CGPoint
}

/// A line segment being "inked in" after a stop is added.
struct LineReveal {
    /// Length currently visible, measured from the end that didn't change.
    var shown: CGFloat
    /// True when the line grew at its head (first stop) rather than its tail.
    let fromHead: Bool
}

enum BlockKind {
    case homes, shops, park, plaza
}

/// One city block between four grid cells. Faded and grey until the cells around it revive.
final class CityBlock {
    let kind: BlockKind
    let cells: [GridPoint]
    let base: SKSpriteNode
    let details: SKNode
    let lights: SKNode
    /// Taller buildings and extra greenery that appear once a block is thriving.
    /// Built only when the block first gets there, to keep the city light.
    let growth: SKNode
    var growthRect: CGRect = .zero
    var growthSeed: UInt64 = 1
    var hasGrown = false
    let faded: UIColor
    let revived: UIColor
    var shownVitality: CGFloat = -1

    init(kind: BlockKind, cells: [GridPoint], base: SKSpriteNode, details: SKNode, lights: SKNode,
         growth: SKNode = SKNode(), faded: UIColor, revived: UIColor) {
        self.kind = kind
        self.cells = cells
        self.base = base
        self.details = details
        self.growth = growth
        self.lights = lights
        self.faded = faded
        self.revived = revived
    }
}
