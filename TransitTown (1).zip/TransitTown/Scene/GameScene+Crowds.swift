import SpriteKit
import UIKit

/// Little paper people gathered outside stations (residents in the spotlight, groups waiting to
/// travel together), and lost items lying somewhere on the map.
extension GameScene {

    private static let shirts: [UInt32] = [0xD2694F, 0x6F93B5, 0x7FAE69, 0xA597D6, 0xE0A21B, 0xC98A9B, 0x5FA7A0, 0xE8833A]
    private static let skins: [UInt32] = [0xF1D3B3, 0xD9A87E, 0xB07A52, 0x7A5236]

    func updateCrowds() {
        guard let state else { return }
        var live = Set<Int>()
        for landmark in state.landmarks where landmark.isOpen {
            let queue = state.waiting[landmark.id] ?? []
            let spotlight = queue.contains { $0.spotlight != nil }
            let group = min(6, queue.filter { $0.tripID != nil }.count)
            guard spotlight || group > 0 else { continue }
            live.insert(landmark.id)
            let signature = "\(spotlight)|\(group)"
            if crowdSignatures[landmark.id] != signature {
                crowdNodes[landmark.id]?.removeFromParent()
                let node = SKNode()
                var placed = 0
                if spotlight {
                    let person = makePerson(seed: landmark.id &* 7, star: true)
                    person.position = CGPoint(x: -cellSize * 0.62, y: -cellSize * 0.18)
                    node.addChild(person)
                    placed += 1
                }
                for index in 0..<group {
                    let person = makePerson(seed: landmark.id &* 31 &+ index, star: false)
                    // A loose huddle in front of the station, back row a little higher.
                    let column = CGFloat((placed + index) % 4), row = CGFloat((placed + index) / 4)
                    person.position = CGPoint(x: cellSize * (-0.45 + column * 0.2), y: -cellSize * (0.3 - row * 0.12))
                    person.zPosition = -row
                    node.addChild(person)
                }
                node.zPosition = 4
                ridersLayer.addChild(node)
                crowdNodes[landmark.id] = node
                crowdSignatures[landmark.id] = signature
            }
            crowdNodes[landmark.id]?.position = center(of: landmark.cell)
        }
        for (id, node) in crowdNodes where !live.contains(id) {
            node.removeFromParent()
            crowdNodes[id] = nil
            crowdSignatures[id] = nil
        }
    }

    /// A small paper person, sized to the buildings around them, swaying very slightly.
    private func makePerson(seed: Int, star: Bool) -> SKNode {
        let shirt = UIColor(hex: GameScene.shirts[abs(seed) % GameScene.shirts.count])
        let skin = UIColor(hex: GameScene.skins[abs(seed / 3) % GameScene.skins.count])
        let height = cellSize * 0.34
        let node = SKNode()
        let sprite = SKSpriteNode(texture: MarkerFactory.person(shirt: shirt, skin: skin),
                                  size: CGSize(width: height * 0.5, height: height))
        sprite.anchorPoint = CGPoint(x: 0.5, y: 0.05)
        node.addChild(sprite)
        if star {
            let glint = icons.sprite(symbol: "star.fill", color: UIColor(hex: 0xE0A21B), pointSize: 8, variant: "spotlight")
            glint.position = CGPoint(x: 0, y: height + 6)
            glint.run(.repeatForever(.sequence([.fadeAlpha(to: 0.55, duration: 0.9), .fadeAlpha(to: 1, duration: 0.9)])))
            node.addChild(glint)
        }
        let sway = Double(abs(seed) % 5) * 0.12
        sprite.run(.repeatForever(.sequence([.rotate(toAngle: 0.04, duration: 1.1 + sway), .rotate(toAngle: -0.04, duration: 1.1 + sway)])))
        return node
    }

    // MARK: Tunnel helper

    /// While connecting a tunnel, a pulsing ring and arrow mark where to drag next: the entrance
    /// (step 4), then the exit (step 5).
    func updateTunnelHelper() {
        guard let state else { return }
        var target: Int?
        var symbol = "arrow.down.circle.fill"
        switch state.tunnelStep {
        case let .connectIn(_, entrance, _): target = entrance
        case let .connectOut(_, _, exit): target = exit; symbol = "arrow.up.forward.circle.fill"
        default: target = nil
        }
        guard let id = target, let portal = state.landmark(id: id) else {
            tunnelHelper?.removeFromParent()
            tunnelHelper = nil
            return
        }
        let key = "\(id)|\(symbol)"
        if tunnelHelper?.name != key {
            tunnelHelper?.removeFromParent()
            let node = SKNode()
            node.name = key
            let ring = SKShapeNode(circleOfRadius: cellSize * 0.55)
            ring.strokeColor = UIColor(hex: 0xE0A21B)
            ring.lineWidth = 3
            ring.fillColor = .clear
            ring.run(.repeatForever(.sequence([.group([.scale(to: 1.25, duration: 0.7), .fadeAlpha(to: 0.3, duration: 0.7)]),
                                               .group([.scale(to: 1, duration: 0.01), .fadeAlpha(to: 1, duration: 0.01)])])))
            node.addChild(ring)
            let arrow = icons.sprite(symbol: symbol, color: UIColor(hex: 0xE0A21B), pointSize: 20, variant: "tunnel")
            arrow.position = CGPoint(x: 0, y: cellSize * 0.95)
            arrow.run(.repeatForever(.sequence([.moveBy(x: 0, y: 5, duration: 0.45), .moveBy(x: 0, y: -5, duration: 0.45)])))
            node.addChild(arrow)
            node.zPosition = 9
            ridersLayer.addChild(node)
            tunnelHelper = node
        }
        tunnelHelper?.position = center(of: portal.cell)
    }

    // MARK: Lost items

    /// Draw the lost item where it's lying, choosing a visible spot when the call first comes in.
    func updateLostItem() {
        guard let state else { return }
        guard let item = state.lostItemOnMap else {
            lostItemNode?.removeFromParent()
            lostItemNode = nil
            lostItemKey = nil
            return
        }
        if state.lostItemSpot == nil { state.lostItemSpot = visibleOpenSpot() }
        guard let spot = state.lostItemSpot else { return }
        let key = "\(item.id)|\(spot.col)|\(spot.row)"
        guard lostItemKey != key else { return }
        lostItemNode?.removeFromParent()
        let node = SKNode()
        let shadow = SKShapeNode(ellipseOf: CGSize(width: 16, height: 5))
        shadow.fillColor = UIColor.black.withAlphaComponent(0.18)
        shadow.strokeColor = .clear
        shadow.position = CGPoint(x: 0, y: -6)
        node.addChild(shadow)
        let icon = icons.sprite(symbol: item.symbol, color: UIColor(hex: 0x5B5866), pointSize: 11, variant: "lost")
        node.addChild(icon)
        // A faint glint now and then, so it can be spotted without shouting.
        let glint = icons.sprite(symbol: "sparkle", color: UIColor(hex: 0xF2CF7A), pointSize: 7, variant: "glint")
        glint.position = CGPoint(x: 8, y: 8)
        glint.alpha = 0
        glint.run(.repeatForever(.sequence([.wait(forDuration: 2.4), .fadeIn(withDuration: 0.25), .fadeOut(withDuration: 0.5)])))
        node.addChild(glint)
        node.position = spotPoint(spot)
        node.zPosition = 8
        ridersLayer.addChild(node)
        lostItemNode = node
        lostItemKey = key
    }

    /// A free spot in an open district, inside what's on screen (clear of the top bar and the
    /// menus), never on a landmark's lot or a decoration.
    private func visibleOpenSpot() -> GridPoint? {
        guard let state else { return nil }
        let scale = cameraNode.xScale
        let width = size.width * scale, height = size.height * scale
        let center = cameraNode.position
        let rect = CGRect(x: center.x - width * 0.38, y: center.y - height * 0.28, width: width * 0.76, height: height * 0.5)
        for _ in 0..<80 {
            let point = CGPoint(x: CGFloat.random(in: rect.minX...rect.maxX), y: CGFloat.random(in: rect.minY...rect.maxY))
            let candidate = spot(at: point)
            if state.canPlace(atSpot: candidate) { return candidate }
        }
        return nil
    }

    /// True if the touch lands on the lost item.
    func lostItemHit(at p: CGPoint) -> Bool {
        guard let node = lostItemNode else { return false }
        return TransitGeometry.distance(node.position, p) < 22
    }
}
