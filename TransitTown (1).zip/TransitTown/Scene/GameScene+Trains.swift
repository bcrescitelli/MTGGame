import SpriteKit

extension GameScene {

    /// Matches the trains on each line to the game state, and keeps existing trains
    /// in place when a line changes shape.
    func syncTrains() {
        guard let state else { return }

        for (lineID, list) in trains where paths[lineID] == nil {
            for train in list {
                removeTrain(train)
            }
            trains[lineID] = nil
        }

        for line in state.lines {
            guard let path = paths[line.id] else { continue }
            var list = trains[line.id] ?? []
            let wanted = state.trainCount(for: line.id)

            while list.count > wanted {
                removeTrain(list.removeLast())
            }
            for (slot, train) in list.enumerated() {
                train.slot = slot
                state.trainSlots[train.id] = (line.id, slot)
                train.distance = path.closestDistance(to: train.lead.position)
                resyncStop(train, on: path)
                train.setColor(line.color)
            }
            while list.count < wanted {
                let train = Train(id: nextTrainID, lineID: line.id, color: line.color,
                                  isLightRail: line.isLightRail, glowTexture: glowTexture)
                nextTrainID += 1
                // Space extra trains out along the line, heading opposite ways.
                let index = list.count
                train.slot = index
                state.trainSlots[train.id] = (line.id, index)
                let stops = path.stopDistances
                if index > 0, !stops.isEmpty {
                    let stopIndex = min(stops.count - 1, stops.count * index / max(wanted, 1))
                    train.stopIndex = stopIndex
                    train.distance = stops[stopIndex]
                    train.lastStop = train.distance
                    train.direction = index % 2 == 0 ? 1 : -1
                    if stopIndex == 0 { train.direction = 1 }
                    if stopIndex == stops.count - 1 { train.direction = -1 }
                }
                trainsLayer.addChild(train.trailer)
                trainsLayer.addChild(train.lead)
                glowLayer.addChild(train.headlight)
                place(train, on: path)
                list.append(train)
            }
            trains[line.id] = list
        }
    }

    /// After a line changes shape: which stop is the train at or just past, given its direction.
    private func resyncStop(_ train: Train, on path: LinePath) {
        let stops = path.stopDistances
        guard stops.count >= 2 else { return }
        if train.direction > 0 {
            train.stopIndex = stops.lastIndex(where: { $0 <= train.distance + 0.5 }) ?? 0
            if train.stopIndex >= stops.count - 1 {
                train.stopIndex = stops.count - 1
                train.direction = -1
            }
        } else {
            train.stopIndex = stops.firstIndex(where: { $0 >= train.distance - 0.5 }) ?? (stops.count - 1)
            if train.stopIndex <= 0 {
                train.stopIndex = 0
                train.direction = 1
            }
        }
        train.lastStop = stops[train.stopIndex]
    }

    private func removeTrain(_ train: Train) {
        train.removeFromScene()
        state?.trainRemoved(trainID: train.id)
    }

    func updateTrains(dt: CGFloat) {
        guard let state else { return }
        for (lineID, list) in trains {
            guard let path = paths[lineID] else { continue }
            let capacity = state.capacity(forLine: lineID)
            for train in list {
                if dt > 0 {
                    advance(train, on: path, dt: dt)
                }
                place(train, on: path)
                train.setLoad(state.onboardCount(trainID: train.id), capacity: capacity + state.extraSeats(trainID: train.id))
            }
        }
    }

    /// Moves toward the neighboring stop, easing out of and into stations.
    /// The target is tracked by index, so no stop is ever skipped. Trains turn back
    /// rather than run onto closed track, and slow down on worn track.
    private func advance(_ train: Train, on path: LinePath, dt: CGFloat) {
        if train.dwell > 0 {
            train.dwell -= dt
            return
        }
        let stops = path.stopDistances
        guard stops.count >= 2, let state, let line = state.line(id: train.lineID),
              line.stops.count == stops.count else { return }

        // Power cut: every train on the line stops where it is until the power's back.
        guard state.isLinePowered(line.id) else { return }

        // Closed track ahead mid-stretch: turn back toward the stop just left.
        if !train.isDeparting {
            let ahead = train.stopIndex + (train.direction > 0 ? 1 : -1)
            if ahead >= 0, ahead < stops.count, !canRun(line, from: train.stopIndex, to: ahead) {
                train.stopIndex = ahead
                turnAround(train)
            }
        }

        if train.isDeparting {
            let ahead = train.stopIndex + (train.direction > 0 ? 1 : -1)
            if !canRun(line, from: train.stopIndex, to: ahead) {
                let behind = train.stopIndex - (train.direction > 0 ? 1 : -1)
                guard canRun(line, from: train.stopIndex, to: behind) else {
                    train.dwell = 0.5 // closed on both sides: wait for the crew
                    return
                }
                turnAround(train)
            }
            train.isDeparting = false
        }

        var targetIndex = train.stopIndex + (train.direction > 0 ? 1 : -1)
        if targetIndex < 0 || targetIndex >= stops.count {
            train.direction = -train.direction
            targetIndex = train.stopIndex + (train.direction > 0 ? 1 : -1)
        }
        targetIndex = min(max(targetIndex, 0), stops.count - 1)
        let target = stops[targetIndex]

        let fromLast = abs(train.distance - train.lastStop)
        let toNext = abs(target - train.distance)
        let ease = min(max(min(fromLast, toNext) / 26, 0.25), 1)
        let multiplier = state.trainSpeedMultiplier * state.speedFactor(forLine: train.lineID)
        let underground: CGFloat = undergroundAlpha(lineID: train.lineID, at: train.distance) < 1 ? 1.5 : 1
        let upgraded = CGFloat(state.speedFactor(lineID: train.lineID, slot: train.slot))
        let speed = trainSpeed * CGFloat(multiplier) * underground * upgraded
        let step = speed * ease * dt

        if toNext <= step {
            arrive(train, at: targetIndex, on: path)
        } else {
            train.distance += (target > train.distance ? 1 : -1) * step
        }
    }

    /// Stops the train: riders get off and on, then it waits a moment.
    /// At either end of the line it reverses by swapping which car leads, so nothing jumps.
    private func arrive(_ train: Train, at index: Int, on path: LinePath) {
        let stops = path.stopDistances
        let previousIndex = train.stopIndex
        train.stopIndex = index
        train.distance = stops[index]
        train.lastStop = stops[index]
        train.dwell = dwellTime
        train.isDeparting = true
        train.bump()

        if let state, let line = state.line(id: train.lineID), index < line.stops.count,
           state.landmark(id: line.stops[index])?.kind == .tunnelPortal {
            // A tunnel opening isn't a station: roll straight through.
            train.dwell = 0
            return
        }
        if let state, let line = state.line(id: train.lineID), index < line.stops.count {
            let stationID = line.stops[index]
            let previousID = previousIndex != index && previousIndex < line.stops.count ? line.stops[previousIndex] : nil
            if state.isStationClosed(stationID) {
                train.dwell = 0.15 // closed for an event: roll straight through
            }
            let exchange = state.trainArrived(trainID: train.id, lineID: train.lineID, at: stationID, from: previousID)
            train.setLoad(exchange.load, capacity: state.capacity(forLine: train.lineID) + state.extraSeats(trainID: train.id))
            if exchange.delivered > 0, let point = position(ofLandmark: stationID) {
                if exchange.fares > 0 {
                    showPopup("+$\(exchange.fares)", at: point, color: Palette.ink)
                } else {
                    showStamp("FREE RIDE", at: point)
                }
                // Arriving riders walk off into the neighborhood.
                spawnWalkers(from: stationID, count: min(exchange.delivered, 3))
            }
        }

        // Turn back at the end of the line, or before closed track.
        let ahead = index + (train.direction > 0 ? 1 : -1)
        let blocked = state.flatMap { state in
            state.line(id: train.lineID).map { !canRun($0, from: index, to: ahead) }
        } ?? (ahead < 0 || ahead >= stops.count)
        if blocked {
            turnAround(train)
        }
    }

    /// Reverses by swapping which car leads, so nothing jumps on screen.
    private func turnAround(_ train: Train) {
        train.distance -= train.direction * train.carGap
        train.direction = -train.direction
    }

    /// Whether a train can run from one stop to the next: the stop exists and the track is open.
    private func canRun(_ line: TransitLine, from index: Int, to next: Int) -> Bool {
        guard let state, next >= 0, next < line.stops.count, index >= 0, index < line.stops.count else { return false }
        return state.isTrackOpen(lineID: line.id, line.stops[index], line.stops[next])
    }

    private func place(_ train: Train, on path: LinePath) {
        let front = path.sample(at: train.distance)
        let back = path.sample(at: train.distance - train.direction * train.carGap)
        let flip: CGFloat = train.direction < 0 ? .pi : 0

        train.lead.position = front.point
        train.lead.zRotation = front.angle + flip
        train.trailer.position = back.point
        train.trailer.zRotation = back.angle + flip
        // Down into a tunnel and out the other end.
        train.lead.alpha = undergroundAlpha(lineID: train.lineID, at: train.distance)
        train.trailer.alpha = undergroundAlpha(lineID: train.lineID, at: train.distance - train.direction * train.carGap)
        train.headlight.alpha = train.lead.alpha

        let heading = front.angle + flip
        train.headlight.position = CGPoint(x: front.point.x + cos(heading) * 14,
                                           y: front.point.y + sin(heading) * 14)
    }
}
