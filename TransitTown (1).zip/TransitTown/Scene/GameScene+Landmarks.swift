import SpriteKit
import UIKit

extension GameScene {

    // MARK: Sync

    /// Adds, removes, rebuilds, and repositions landmark nodes to match the game state.
    func drawLandmarks() {
        guard let state else { return }
        defer {
            // Lower on screen means closer: sort buildings (and decor, in the same layer) by y.
            for node in landmarkNodes.values where node.zPosition < 15 {
                node.zPosition = -node.position.y * 0.01
            }
            for landmark in state.landmarks {
                if let node = landmarkNodes[landmark.id] { updateColor(of: node, for: landmark) }
            }
        }
        let liveIDs = Set(state.landmarks.map(\.id))

        for (id, node) in landmarkNodes where !liveIDs.contains(id) {
            node.removeFromParent()
            landmarkNodes[id] = nil
            landmarkOpenState[id] = nil
            landmarkStage[id] = nil
            landmarkColored[id] = nil
            windowGlows[id] = nil
            glowNodes[id]?.removeFromParent()
            glowNodes[id] = nil
            restoreBadges[id]?.removeFromParent()
            restoreBadges[id] = nil
        }

        var newCount = 0
        for landmark in state.landmarks {
            let target = center(of: landmark.cell)

            // A derelict site that was just restored gets a fresh node.
            let stage = landmark.isOpen ? 2 : (landmark.isUnderConstruction ? (landmark.constructionProgress < 0.3 ? 0 : 1) : 3)
            let stageChanged = landmarkStage[landmark.id] != nil && landmarkStage[landmark.id] != stage
            landmarkStage[landmark.id] = stage
            let renamed = landmarkNameShown[landmark.id] != nil && landmarkNameShown[landmark.id] != landmark.name
            landmarkNameShown[landmark.id] = landmark.name
            if let node = landmarkNodes[landmark.id], landmarkOpenState[landmark.id] != landmark.isOpen || stageChanged || renamed {
                node.removeFromParent()
                landmarkNodes[landmark.id] = nil
                restoreBadges[landmark.id]?.removeFromParent()
                restoreBadges[landmark.id] = nil
            }

            if let node = landmarkNodes[landmark.id] {
                if case let .moving(id) = mode, id == landmark.id { continue }
                if node.action(forKey: "settle") == nil {
                    node.position = target
                    node.alpha = 1
                    node.setScale(1)
                }
                glowNodes[landmark.id]?.position = CGPoint(x: target.x, y: target.y - cellSize * 0.35)
                continue
            }

            let node = makeLandmarkNode(landmark)
            node.position = target
            landmarksLayer.addChild(node)
            landmarkNodes[landmark.id] = node
            let wasKnown = landmarkOpenState[landmark.id] != nil
            landmarkOpenState[landmark.id] = landmark.isOpen

            if glowNodes[landmark.id] == nil {
                let glow = SKSpriteNode(texture: glowTexture)
                glow.size = CGSize(width: cellSize * 2.6, height: cellSize * 1.3)
                glow.color = Palette.lamp
                glow.colorBlendFactor = 1
                glow.blendMode = .add
                glowLayer.addChild(glow)
                glowNodes[landmark.id] = glow
            }
            glowNodes[landmark.id]?.position = CGPoint(x: target.x, y: target.y - cellSize * 0.35)
            glowNodes[landmark.id]?.alpha = landmark.isOpen ? 0.42 : 0

            if wasKnown {
                celebrateRestoration(node)
            } else {
                animateDrop(node, delay: TimeInterval(newCount) * 0.09)
                newCount += 1
            }
        }
    }

    /// Animates a landmark back into its cell after a drag.
    func settle(_ id: Int, to point: CGPoint) {
        guard let node = landmarkNodes[id] else { return }
        node.removeAction(forKey: "settle")
        node.zPosition = 0
        let move = SKAction.move(to: point, duration: 0.14)
        move.timingMode = .easeOut
        node.run(.group([move, .scale(to: 1, duration: 0.14), .fadeIn(withDuration: 0.14)]), withKey: "settle")
        glowNodes[id]?.position = point
    }

    /// Shows a pulsing hammer on derelict sites that can be restored right now.
    func updateRestoreBadges() {
        guard let state else { return }
        for landmark in state.landmarks where landmark.kind.info.isHeritage {
            let ready = !landmark.isOpen && state.canRestore(landmark.id)
            if ready, restoreBadges[landmark.id] == nil, let node = landmarkNodes[landmark.id] {
                let badge = makeRestoreBadge()
                badge.position = CGPoint(x: cellSize * 0.36, y: cellSize * 0.36)
                node.addChild(badge)
                restoreBadges[landmark.id] = badge
            } else if !ready, let badge = restoreBadges[landmark.id] {
                badge.removeFromParent()
                restoreBadges[landmark.id] = nil
            }
        }
    }

    // MARK: Building nodes

    /// A landmark is its paper building, standing on its own paper base (part of the art).
    /// Tracks run behind it; buildings and decor are sorted by how low they sit on screen.
    /// While it's being built it shows the permit lot, then scaffolding. At night its windows
    /// light up, and a few landmarks have a small idle animation.
    private func makeLandmarkNode(_ landmark: Landmark) -> SKNode {
        let root = SKNode()
        let kind = landmark.kind
        let width = cellSize * (kind == .tunnelPortal ? 1.25 : (kind.info.category == .hub ? 2.2 : 1.9))
        let height = width * 200 / 240
        let anchor = CGPoint(x: 0.525, y: 0.16)
        let building = landmark.isUnderConstruction
        let artName = building ? (landmark.constructionProgress < 0.3 ? "stamp-lot" : "stamp-construction") : landmark.artName

        if let texture = MarkerFactory.cachedArt(artName) {
            let sprite = SKSpriteNode(texture: texture, size: CGSize(width: width, height: height))
            sprite.anchorPoint = anchor
            sprite.alpha = landmark.isOpen || building ? 1 : 0.42
            sprite.name = "marker"
            root.addChild(sprite)
        }
        // Open shops wait in black and white until a line reaches them (stations and quays don't).
        if landmark.isOpen, kind.info.category != .hub, kind.info.category != .canal,
           let grey = MarkerFactory.greyArt(landmark.artName) {
            let sprite = SKSpriteNode(texture: grey, size: CGSize(width: width, height: height))
            sprite.anchorPoint = anchor
            sprite.zPosition = 0.5
            sprite.name = "grey"
            sprite.alpha = landmarkColored[landmark.id] == true ? 0 : 1
            root.addChild(sprite)
        }
        if landmark.isOpen, let glowTexture = MarkerFactory.cachedArt("glow-\(kind.rawValue)") {
            let glow = SKSpriteNode(texture: glowTexture, size: CGSize(width: width, height: height))
            glow.anchorPoint = anchor
            glow.alpha = 0
            glow.zPosition = 1
            root.addChild(glow)
            windowGlows[landmark.id] = glow
        } else {
            windowGlows[landmark.id] = nil
        }

        if kind != .tunnelPortal {
            let tag = makeNameTag(building ? (kind == .transitHub ? "Hub, opening soon" : "Opening soon") : landmark.name,
                                  faded: !landmark.isOpen && !building)
            tag.position = CGPoint(x: 0, y: -cellSize * 0.4)
            tag.zPosition = 20
            root.addChild(tag)
        }
        return root
    }

    /// Black and white until a line arrives; then the color washes back in, with sparkles.
    private func updateColor(of node: SKNode, for landmark: Landmark) {
        guard let state, let grey = node.childNode(withName: "grey") else { return }
        let connected = state.lines.contains { $0.stops.count > 1 && $0.stops.contains(landmark.id) }
        let was = landmarkColored[landmark.id]
        landmarkColored[landmark.id] = connected
        guard let was else {
            grey.alpha = connected ? 0 : 1
            return
        }
        if !was && connected {
            grey.removeAllActions()
            grey.run(.fadeOut(withDuration: 1.5))
            colorSparkle(at: node.position)
            AudioManager.shared.play(.sparkle)
        } else if was && !connected {
            grey.removeAllActions()
            grey.run(.fadeIn(withDuration: 0.6))
        }
    }

    private func colorSparkle(at point: CGPoint) {
        let burst = SKEmitterNode()
        burst.particleTexture = atmosphere.dot
        burst.particleBirthRate = 60
        burst.numParticlesToEmit = 22
        burst.particleLifetime = 1.1
        burst.particlePositionRange = CGVector(dx: cellSize * 1.2, dy: cellSize * 0.8)
        burst.emissionAngleRange = .pi * 2
        burst.particleSpeed = 26
        burst.particleSpeedRange = 14
        burst.particleScale = 0.5
        burst.particleScaleRange = 0.3
        burst.particleAlphaSpeed = -0.9
        burst.particleColor = UIColor(hex: 0xF2CF7A)
        burst.particleColorBlendFactor = 1
        burst.position = CGPoint(x: point.x, y: point.y + cellSize * 0.5)
        effectsLayer.addChild(burst)
        burst.run(.sequence([.wait(forDuration: 1.6), .removeFromParent()]))
    }

    /// Where a point in the 240 × 200 drawing lands on the node.
    private func artPoint(_ x: CGFloat, _ y: CGFloat, width: CGFloat, height: CGFloat, anchor: CGPoint) -> CGPoint {
        CGPoint(x: (x / 240 - anchor.x) * width, y: (1 - y / 200 - anchor.y) * height)
    }

    /// Small looping touches: chimney smoke, the lighthouse beam.
    private func addIdleAnimation(to root: SKNode, kind: LandmarkKind, width: CGFloat, height: CGFloat, anchor: CGPoint) {
        // Positions are in the drawing's 240 × 200 space. The bakery's art already includes its smoke.
        let chimneys: [LandmarkKind: CGPoint] = [.chowderHouse: CGPoint(x: 152, y: 58)]
        if let chimney = chimneys[kind] {
            let smoke = SKEmitterNode()
            smoke.particleTexture = atmosphere.dot
            smoke.particleBirthRate = 1.3
            smoke.particleLifetime = 2.6
            smoke.emissionAngle = .pi / 2 - 0.35
            smoke.emissionAngleRange = 0.3
            smoke.particleSpeed = 10
            smoke.particleSpeedRange = 3
            smoke.particleScale = 0.55
            smoke.particleScaleSpeed = 0.35
            smoke.particleAlpha = 0.75
            smoke.particleAlphaSpeed = -0.28
            smoke.particleColor = UIColor(hex: 0xFBF6EC)
            smoke.particleColorBlendFactor = 1
            smoke.position = artPoint(chimney.x, chimney.y, width: width, height: height, anchor: anchor)
            smoke.zPosition = 2
            smoke.advanceSimulationTime(2.6)
            root.addChild(smoke)
        }
        if kind == .lighthouse {
            let lamp = artPoint(138, 33, width: width, height: height, anchor: anchor)
            let path = CGMutablePath()
            path.move(to: .zero)
            path.addLine(to: CGPoint(x: width * 0.55, y: height * 0.12))
            path.addLine(to: CGPoint(x: width * 0.55, y: -height * 0.1))
            path.closeSubpath()
            let beam = SKShapeNode(path: path)
            beam.fillColor = UIColor(hex: 0xFFE7A8).withAlphaComponent(0.4)
            beam.strokeColor = .clear
            beam.position = lamp
            beam.zPosition = 2
            beam.run(.repeatForever(.sequence([.scaleX(to: -1, duration: 2.2), .scaleX(to: 1, duration: 2.2)])))
            root.addChild(beam)
        }
    }

    /// A small paper strip with the landmark's name in serif, like a label on a model village.
    private func makeNameTag(_ text: String, faded: Bool) -> SKNode {
        let node = SKNode()
        let label = SKLabelNode()
        label.attributedText = NSAttributedString(string: text, attributes: [
            .font: UIFont(name: AppFont.body, size: 10.5) ?? UIFont.systemFont(ofSize: 10.5),
            .foregroundColor: faded ? Palette.inkSoft : Palette.ink,
        ])
        label.verticalAlignmentMode = .center
        label.horizontalAlignmentMode = .center
        label.zPosition = 1
        let width = label.frame.width + 12
        // Flat paper with a darker sheet peeking beneath, like the panels.
        let under = SKShapeNode(rect: CGRect(x: -width / 2 + 1, y: -9.5, width: width, height: 16), cornerRadius: 4)
        under.fillColor = UIColor(hex: 0xD3C4A6).withAlphaComponent(faded ? 0.6 : 1)
        under.strokeColor = .clear
        node.addChild(under)
        let strip = SKShapeNode(rect: CGRect(x: -width / 2, y: -8, width: width, height: 16), cornerRadius: 4)
        strip.fillColor = Palette.card.withAlphaComponent(faded ? 0.75 : 0.97)
        strip.strokeColor = .clear
        node.addChild(strip)
        node.addChild(label)
        return node
    }

    /// A paper stamp: card with a category color band, icon, ink outline, and a flat print shadow.
    private func buildStamp(into node: SKNode, kind: LandmarkKind) {
        let side = cellSize * 0.76
        let radius: CGFloat = 8
        let band: CGFloat = 9
        let rect = CGRect(x: -side / 2, y: -side / 2, width: side, height: side)

        addShape(SKShapeNode(rect: rect.offsetBy(dx: 2, dy: -3), cornerRadius: radius),
                 to: node, fill: Palette.ink.withAlphaComponent(0.18), z: 0)
        addShape(SKShapeNode(rect: rect, cornerRadius: radius), to: node, fill: Palette.card, z: 1)
        addShape(SKShapeNode(path: topBandPath(rect: rect, band: band, radius: radius)),
                 to: node, fill: kind.info.category.color, z: 2)

        let icon = icons.sprite(symbol: kind.info.symbol, color: Palette.ink, pointSize: 15, variant: "stamp")
        icon.position = CGPoint(x: 0, y: -band / 2 + 0.5)
        icon.zPosition = 3
        node.addChild(icon)

        let outline = SKShapeNode(rect: rect, cornerRadius: radius)
        outline.fillColor = .clear
        outline.strokeColor = Palette.ink
        outline.lineWidth = 2.5
        outline.zPosition = 4
        node.addChild(outline)
    }

    /// A boarded-up heritage site: grey, tilted, with planks across it.
    private func buildDerelict(into node: SKNode, kind: LandmarkKind) {
        let side = cellSize * 0.76
        let radius: CGFloat = 8
        let rect = CGRect(x: -side / 2, y: -side / 2, width: side, height: side)
        let body = SKNode()
        body.zRotation = -0.06
        node.addChild(body)

        addShape(SKShapeNode(rect: rect.offsetBy(dx: 2, dy: -3), cornerRadius: radius),
                 to: body, fill: Palette.ink.withAlphaComponent(0.12), z: 0)
        addShape(SKShapeNode(rect: rect, cornerRadius: radius), to: body, fill: UIColor(hex: 0xCFC8BC), z: 1)
        addShape(SKShapeNode(path: topBandPath(rect: rect, band: 9, radius: radius)),
                 to: body, fill: UIColor(hex: 0xA59E92), z: 2)

        let icon = icons.sprite(symbol: kind.info.symbol, color: Palette.inkSoft, pointSize: 15, variant: "derelict")
        icon.position = CGPoint(x: 0, y: -4)
        icon.alpha = 0.7
        icon.zPosition = 3
        body.addChild(icon)

        let outline = SKShapeNode(rect: rect, cornerRadius: radius)
        outline.fillColor = .clear
        outline.strokeColor = Palette.inkSoft
        outline.lineWidth = 2
        outline.zPosition = 4
        body.addChild(outline)

        for (angle, offset) in [(CGFloat(0.32), CGFloat(5)), (CGFloat(-0.28), CGFloat(-7))] {
            let plank = SKShapeNode(rect: CGRect(x: -side * 0.58, y: -3, width: side * 1.16, height: 6), cornerRadius: 1.5)
            plank.fillColor = UIColor(hex: 0xA07C5A)
            plank.strokeColor = UIColor(hex: 0x6E5238)
            plank.lineWidth = 1
            plank.position = CGPoint(x: 0, y: offset)
            plank.zRotation = angle
            plank.zPosition = 5
            body.addChild(plank)
        }
    }

    /// Central Station: an ink roundel with a paper ring.
    private func buildHub(into node: SKNode, kind: LandmarkKind) {
        let radius = cellSize * 0.42
        let shadow = SKShapeNode(circleOfRadius: radius)
        shadow.position = CGPoint(x: 2, y: -3)
        addShape(shadow, to: node, fill: Palette.ink.withAlphaComponent(0.18), z: 0)
        addShape(SKShapeNode(circleOfRadius: radius), to: node, fill: Palette.ink, z: 1)

        let ring = SKShapeNode(circleOfRadius: radius - 4.5)
        ring.fillColor = .clear
        ring.strokeColor = Palette.card
        ring.lineWidth = 1.5
        ring.zPosition = 2
        node.addChild(ring)

        let icon = icons.sprite(symbol: kind.info.symbol, color: Palette.card, pointSize: 15, variant: "hub")
        icon.zPosition = 3
        node.addChild(icon)
    }

    private func addShape(_ shape: SKShapeNode, to node: SKNode, fill: UIColor, z: CGFloat) {
        shape.fillColor = fill
        shape.strokeColor = .clear
        shape.zPosition = z
        node.addChild(shape)
    }

    /// Station name in condensed caps on a paper pill, like a printed map label.
    /// The pill's thin outline carries the district's color, so each district reads as its own place.
    private func makeLabel(_ text: String, faded: Bool, accent: UIColor) -> SKNode {
        let node = SKNode()
        node.zPosition = 6

        let label = SKLabelNode()
        label.attributedText = NSAttributedString(string: text, attributes: [
            .font: AppFont.uiFont(AppFont.boldName, size: 11),
            .foregroundColor: faded ? Palette.inkSoft : Palette.ink,
            .kern: 0.8,
        ])
        label.verticalAlignmentMode = .center
        label.horizontalAlignmentMode = .center
        label.zPosition = 1

        let width = label.frame.width + 10
        let height: CGFloat = 15
        let pill = SKShapeNode(rect: CGRect(x: -width / 2, y: -height / 2, width: width, height: height),
                               cornerRadius: height / 2)
        pill.fillColor = Palette.paper.withAlphaComponent(0.94)
        pill.strokeColor = accent.withAlphaComponent(faded ? 0.3 : 0.75)
        pill.lineWidth = 1.2
        pill.zPosition = 0

        node.addChild(pill)
        node.addChild(label)
        return node
    }

    private func makeRestoreBadge() -> SKNode {
        let badge = SKNode()
        badge.zPosition = 10
        let disc = SKShapeNode(circleOfRadius: 9)
        disc.fillColor = Palette.gold
        disc.strokeColor = Palette.ink
        disc.lineWidth = 1.5
        disc.zPosition = 0
        badge.addChild(disc)
        let icon = icons.sprite(symbol: "hammer.fill", color: Palette.ink, pointSize: 9, variant: "badge")
        icon.zPosition = 1
        badge.addChild(icon)
        badge.run(.repeatForever(.sequence([
            .scale(to: 1.18, duration: 0.45),
            .scale(to: 1.0, duration: 0.45),
        ])))
        return badge
    }

    /// The top band of a rounded card (rounded top corners, square bottom).
    private func topBandPath(rect: CGRect, band: CGFloat, radius: CGFloat) -> CGPath {
        let path = CGMutablePath()
        let top = rect.maxY, bottom = rect.maxY - band
        let left = rect.minX, right = rect.maxX
        path.move(to: CGPoint(x: left, y: bottom))
        path.addLine(to: CGPoint(x: left, y: top - radius))
        path.addArc(tangent1End: CGPoint(x: left, y: top), tangent2End: CGPoint(x: left + radius, y: top), radius: radius)
        path.addLine(to: CGPoint(x: right - radius, y: top))
        path.addArc(tangent1End: CGPoint(x: right, y: top), tangent2End: CGPoint(x: right, y: top - radius), radius: radius)
        path.addLine(to: CGPoint(x: right, y: bottom))
        path.closeSubpath()
        return path
    }

    // MARK: Animations

    /// Drops a new landmark in with a bounce, then a ripple.
    private func animateDrop(_ node: SKNode, delay: TimeInterval) {
        let final = node.position
        node.alpha = 0
        node.setScale(0.6)
        node.position = CGPoint(x: final.x, y: final.y + 16)

        let move = SKAction.move(to: final, duration: 0.2)
        move.timingMode = .easeIn
        let bounce = SKAction.sequence([
            .scale(to: 1.14, duration: 0.16),
            .scale(to: 0.95, duration: 0.08),
            .scale(to: 1, duration: 0.08),
        ])
        node.run(.sequence([.wait(forDuration: delay), .group([.fadeIn(withDuration: 0.12), move, bounce])]),
                 withKey: "settle")
        ripple(at: final, delay: delay + 0.18)
    }

    /// The restored building pops in from a squash.
    private func celebrateRestoration(_ node: SKNode) {
        node.setScale(0.4)
        node.run(.sequence([
            .scale(to: 1.25, duration: 0.18),
            .scale(to: 0.94, duration: 0.1),
            .scale(to: 1, duration: 0.1),
        ]), withKey: "settle")
    }
}
