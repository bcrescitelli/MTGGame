import SpriteKit
import UIKit

/// Renders SF Symbols into SpriteKit textures once and reuses them.
final class IconCache {
    private var entries: [String: (texture: SKTexture, size: CGSize)] = [:]

    func sprite(symbol: String, color: UIColor, pointSize: CGFloat, variant: String) -> SKSpriteNode {
        let key = "\(symbol)|\(variant)|\(pointSize)"
        if entries[key] == nil {
            let config = UIImage.SymbolConfiguration(pointSize: pointSize, weight: .bold)
            let base = UIImage(systemName: symbol, withConfiguration: config)
                ?? UIImage(systemName: "questionmark", withConfiguration: config)
                ?? UIImage()
            let tinted = base.withTintColor(color, renderingMode: .alwaysOriginal)
            let image = UIGraphicsImageRenderer(size: tinted.size).image { _ in
                tinted.draw(at: .zero)
            }
            entries[key] = (texture: SKTexture(image: image), size: image.size)
        }
        guard let entry = entries[key] else { return SKSpriteNode() }
        return SKSpriteNode(texture: entry.texture, size: entry.size)
    }
}
