import SpriteKit
import UIKit

/// Generates the map's shared textures in code.
enum TextureFactory {

    /// Transparent overlay with paper grain and a soft vignette, laid over the city blocks
    /// so the whole map reads as one printed sheet.
    static func paperOverlay(size: CGSize) -> SKTexture {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 2
        format.opaque = false
        let image = UIGraphicsImageRenderer(size: size, format: format).image { context in
            let cg = context.cgContext
            drawGrain(in: cg, size: size)
            drawVignette(in: cg, size: size)
        }
        return SKTexture(image: image)
    }

    /// White rounded square for 9-slice tinted sprites (city blocks).
    static func roundedSquare(side: CGFloat = 24, radius: CGFloat = 6) -> SKTexture {
        let size = CGSize(width: side, height: side)
        let image = UIGraphicsImageRenderer(size: size).image { _ in
            UIColor.white.setFill()
            UIBezierPath(roundedRect: CGRect(origin: .zero, size: size), cornerRadius: radius).fill()
        }
        return SKTexture(image: image)
    }

    /// White circle for tinted sprites (trees, lamps).
    static func circle(diameter: CGFloat = 16) -> SKTexture {
        let size = CGSize(width: diameter, height: diameter)
        let image = UIGraphicsImageRenderer(size: size).image { _ in
            UIColor.white.setFill()
            UIBezierPath(ovalIn: CGRect(origin: .zero, size: size)).fill()
        }
        return SKTexture(image: image)
    }

    /// Soft white radial glow, tinted by the sprite's color.
    static func glow(diameter: CGFloat = 64) -> SKTexture {
        let size = CGSize(width: diameter, height: diameter)
        let image = UIGraphicsImageRenderer(size: size).image { context in
            let colors = [UIColor.white.cgColor, UIColor.white.withAlphaComponent(0).cgColor] as CFArray
            guard let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) else { return }
            let c = CGPoint(x: diameter / 2, y: diameter / 2)
            context.cgContext.drawRadialGradient(gradient, startCenter: c, startRadius: 0,
                                                 endCenter: c, endRadius: diameter / 2, options: [])
        }
        return SKTexture(image: image)
    }

    // MARK: Private

    private static func drawGrain(in cg: CGContext, size: CGSize) {
        guard size.width > 1, size.height > 1 else { return }
        var rng = SeededGenerator(seed: 7)
        let count = Int(size.width * size.height / 6)
        let dark = Palette.ink.withAlphaComponent(0.06).cgColor
        let light = UIColor.white.withAlphaComponent(0.22).cgColor
        for i in 0..<count {
            let x = CGFloat.random(in: 0..<size.width, using: &rng)
            let y = CGFloat.random(in: 0..<size.height, using: &rng)
            cg.setFillColor(i % 3 == 0 ? light : dark)
            cg.fill(CGRect(x: x, y: y, width: 0.8, height: 0.8))
        }
    }

    private static func drawVignette(in cg: CGContext, size: CGSize) {
        let colors = [Palette.ink.withAlphaComponent(0).cgColor, Palette.ink.withAlphaComponent(0.12).cgColor] as CFArray
        guard let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0.55, 1]) else { return }
        let center = CGPoint(x: size.width / 2, y: size.height / 2)
        let radius = hypot(size.width, size.height) / 2
        cg.drawRadialGradient(gradient, startCenter: center, startRadius: 0,
                              endCenter: center, endRadius: radius, options: [.drawsAfterEndLocation])
    }
}
