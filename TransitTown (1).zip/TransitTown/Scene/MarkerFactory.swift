import SpriteKit
import UIKit
import CoreImage

/// Draws the round "passport stamp" markers that stand for landmarks on the map, the
/// distressed rubber stamps for game moments, and the decor trees. Everything is drawn once
/// and cached as a texture.
enum MarkerFactory {
    enum State: String {
        case open
        /// Not built yet, or a boarded-up heritage site: grey rim, faded drawing.
        case blueprint
    }

    private static var cache: [String: SKTexture] = [:]

    // MARK: Landmark markers

    static func marker(for kind: LandmarkKind, state: State, diameter: CGFloat) -> SKTexture {
        let key = "marker|\(kind.rawValue)|\(state.rawValue)|\(Int(diameter))"
        if let texture = cache[key] { return texture }
        let texture = SKTexture(image: markerImage(for: kind, state: state, diameter: diameter))
        cache[key] = texture
        return texture
    }

    /// A rubber-stamp impression in one ink: double ring, name around the top, a line drawing
    /// in the middle, speckled where the ink didn't take. Drawn in a 100 × 100 space.
    static func markerImage(for kind: LandmarkKind, state: State, diameter: CGFloat) -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 3
        return UIGraphicsImageRenderer(size: CGSize(width: diameter, height: diameter), format: format).image { context in
            let cg = context.cgContext
            cg.scaleBy(x: diameter / 100, y: diameter / 100)
            let open = state == .open
            let ink = open ? kind.inkColor : UIColor(hex: 0xA39A88)

            // The paper the stamp is pressed onto, lifted just off the map.
            cg.setFillColor(Palette.ink.withAlphaComponent(0.12).cgColor)
            cg.fillEllipse(in: CGRect(x: 4, y: 6, width: 92, height: 92))
            cg.setFillColor(Palette.card.withAlphaComponent(open ? 0.96 : 0.85).cgColor)
            cg.fillEllipse(in: CGRect(x: 3, y: 3, width: 94, height: 94))

            // Everything inked goes in one layer, so the speckles only bite the ink.
            cg.beginTransparencyLayer(auxiliaryInfo: nil)
            cg.setStrokeColor(ink.cgColor)
            cg.setLineWidth(3.4)
            if !open { cg.setLineDash(phase: 0, lengths: [5, 3.5]) }
            cg.strokeEllipse(in: CGRect(x: 6, y: 6, width: 88, height: 88))
            cg.setLineDash(phase: 0, lengths: [])
            cg.setLineWidth(1.5)
            cg.strokeEllipse(in: CGRect(x: 17.5, y: 17.5, width: 65, height: 65))

            let artRect = CGRect(x: 26, y: 29, width: 48, height: 40)
            if let line = UIImage(named: "line-\(kind.rawValue)") {
                line.withTintColor(ink, renderingMode: .alwaysOriginal).draw(in: artRect)
            } else if let symbol = UIImage(systemName: kind.info.symbol,
                                           withConfiguration: UIImage.SymbolConfiguration(pointSize: 22, weight: .bold)) {
                symbol.withTintColor(ink, renderingMode: .alwaysOriginal).draw(in: artRect.insetBy(dx: 8, dy: 4))
            }
            drawArcText(kind.markerName, in: cg, center: CGPoint(x: 50, y: 50), radius: 38.6, color: ink)
            if kind.info.isHeritage {
                drawStar(in: cg, center: CGPoint(x: 50, y: 88.6), radius: 3.6, color: ink)
            } else {
                cg.setFillColor(ink.cgColor)
                for dx in [-5.5, 0, 5.5] {
                    cg.fillEllipse(in: CGRect(x: 50 + dx - 1.4, y: 87.2, width: 2.8, height: 2.8))
                }
            }
            // Speckles, seeded by the landmark so each stamp always looks the same.
            var generator = SeededGenerator(seed: UInt64(kind.rawValue.unicodeScalars.reduce(5) { $0 &* 31 &+ Int($1.value) } & 0xFFFFFF) + 1)
            cg.setBlendMode(.clear)
            for _ in 0..<520 {
                let x = CGFloat.random(in: 0...100, using: &generator)
                let y = CGFloat.random(in: 0...100, using: &generator)
                let r = CGFloat.random(in: 0.3...1.0, using: &generator)
                cg.fillEllipse(in: CGRect(x: x, y: y, width: r, height: r))
            }
            cg.setBlendMode(.normal)
            cg.endTransparencyLayer()
        }
    }

    /// Lays text along the top of a circle, centered, reading left to right.
    private static func drawArcText(_ text: String, in cg: CGContext, center: CGPoint, radius: CGFloat, color: UIColor) {
        let characters = text.map { String($0) }
        let longest: CGFloat = 11
        let size: CGFloat = max(7.6, 10.6 - max(0, CGFloat(characters.count) - longest) * 0.45)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: AppFont.uiFont(AppFont.boldName, size: size),
            .foregroundColor: color,
        ]
        let tracking: CGFloat = size * 0.16
        let widths = characters.map { ($0 as NSString).size(withAttributes: attributes).width + tracking }
        let total = widths.reduce(0, +) - tracking
        var angle = -CGFloat.pi / 2 - total / radius / 2
        for (character, width) in zip(characters, widths) {
            let mid = angle + (width - tracking) / 2 / radius
            cg.saveGState()
            cg.translateBy(x: center.x + radius * cos(mid), y: center.y + radius * sin(mid))
            cg.rotate(by: mid + .pi / 2)
            let glyph = (character as NSString)
            let glyphSize = glyph.size(withAttributes: attributes)
            glyph.draw(at: CGPoint(x: -glyphSize.width / 2, y: -glyphSize.height / 2), withAttributes: attributes)
            cg.restoreGState()
            angle += width / radius
        }
    }

    private static func drawStar(in cg: CGContext, center: CGPoint, radius: CGFloat, color: UIColor) {
        let path = CGMutablePath()
        for index in 0..<10 {
            let r = index % 2 == 0 ? radius : radius * 0.45
            let angle = -CGFloat.pi / 2 + CGFloat(index) * .pi / 5
            let point = CGPoint(x: center.x + r * cos(angle), y: center.y + r * sin(angle))
            index == 0 ? path.move(to: point) : path.addLine(to: point)
        }
        path.closeSubpath()
        cg.addPath(path)
        cg.setFillColor(color.cgColor)
        cg.fillPath()
    }

    // MARK: Rubber stamps

    /// An inked rubber stamp ("ARRIVED", "FREE RIDE"...): double border, with the speckled
    /// gaps a real stamp leaves.
    static func rubberStamp(_ text: String, color: UIColor) -> SKTexture {
        let key = "stamp|\(text)|\(color.hashValue)"
        if let texture = cache[key] { return texture }
        let font = AppFont.uiFont(AppFont.boldName, size: 13)
        let attributes: [NSAttributedString.Key: Any] = [.font: font, .foregroundColor: color, .kern: 2.2]
        let textSize = (text as NSString).size(withAttributes: attributes)
        let size = CGSize(width: textSize.width + 26, height: textSize.height + 16)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 3
        let image = UIGraphicsImageRenderer(size: size, format: format).image { context in
            let cg = context.cgContext
            cg.setStrokeColor(color.cgColor)
            cg.setLineWidth(2.4)
            cg.addPath(UIBezierPath(roundedRect: CGRect(origin: .zero, size: size).insetBy(dx: 1.5, dy: 1.5), cornerRadius: 4).cgPath)
            cg.strokePath()
            cg.setLineWidth(0.9)
            cg.addPath(UIBezierPath(roundedRect: CGRect(origin: .zero, size: size).insetBy(dx: 5, dy: 5), cornerRadius: 2).cgPath)
            cg.strokePath()
            (text as NSString).draw(at: CGPoint(x: (size.width - textSize.width) / 2 + 1, y: (size.height - textSize.height) / 2),
                                    withAttributes: attributes)
            // Speckles where the ink didn't take, seeded by the text so a stamp always looks the same.
            var seed = UInt64(abs(text.hashValue % 100_000) + 7)
            var generator = SeededGenerator(seed: seed)
            cg.setBlendMode(.clear)
            for _ in 0..<Int(size.width * size.height / 18) {
                let x = CGFloat.random(in: 0...size.width, using: &generator)
                let y = CGFloat.random(in: 0...size.height, using: &generator)
                let r = CGFloat.random(in: 0.3...1.1, using: &generator)
                cg.fillEllipse(in: CGRect(x: x, y: y, width: r, height: r))
            }
            seed &+= 1
        }
        let texture = SKTexture(image: image)
        cache[key] = texture
        return texture
    }

    // MARK: Decor
    // Decor is drawn flat and soft, like the map's parks, so it settles into the town
    // instead of sitting on top of it: no ink outlines, a soft shadow, muted greens.

    private static let ciContext = CIContext()

    /// A black-and-white copy of a piece of art, for landmarks waiting for their first line.
    static func greyArt(_ name: String) -> SKTexture? {
        if let texture = cache["grey|\(name)"] { return texture }
        guard let image = UIImage(named: name), let input = CIImage(image: image),
              let filter = CIFilter(name: "CIColorControls") else { return nil }
        filter.setValue(input, forKey: kCIInputImageKey)
        filter.setValue(0, forKey: kCIInputSaturationKey)
        filter.setValue(1.05, forKey: kCIInputContrastKey)
        filter.setValue(0.03, forKey: kCIInputBrightnessKey)
        guard let output = filter.outputImage,
              let cgImage = ciContext.createCGImage(output, from: input.extent) else { return nil }
        let texture = SKTexture(image: UIImage(cgImage: cgImage, scale: image.scale, orientation: .up))
        cache["grey|\(name)"] = texture
        return texture
    }

    /// Any piece of art from the asset catalog, cached as a texture.
    static func cachedArt(_ name: String) -> SKTexture? {
        if let texture = cache["art|\(name)"] { return texture }
        guard let image = UIImage(named: name) else { return nil }
        let texture = SKTexture(image: image)
        cache["art|\(name)"] = texture
        return texture
    }

    /// A landmark's building, cached so redraws don't rebuild textures.
    static func building(_ kind: LandmarkKind) -> SKTexture? {
        if let texture = cache["building|\(kind.rawValue)"] { return texture }
        guard let art = kind.artImage else { return nil }
        let texture = SKTexture(image: art)
        cache["building|\(kind.rawValue)"] = texture
        return texture
    }

    /// A small paper person: shoes, trousers, a shirt in their color, a head, and a little hair.
    static func person(shirt: UIColor, skin: UIColor) -> SKTexture {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        shirt.getRed(&r, green: &g, blue: &b, alpha: &a)
        var sr: CGFloat = 0, sg: CGFloat = 0, sb: CGFloat = 0
        skin.getRed(&sr, green: &sg, blue: &sb, alpha: &a)
        let key = String(format: "person|%.2f%.2f%.2f|%.2f%.2f%.2f", r, g, b, sr, sg, sb)
        return cached(key) {
            let format = UIGraphicsImageRendererFormat()
            format.scale = 3
            let image = UIGraphicsImageRenderer(size: CGSize(width: 14, height: 28), format: format).image { context in
                let cg = context.cgContext
                cg.setFillColor(UIColor.black.withAlphaComponent(0.18).cgColor)
                cg.fillEllipse(in: CGRect(x: 2, y: 25.5, width: 10, height: 2.5))
                cg.setFillColor(UIColor(hex: 0x45424F).cgColor)
                cg.fill(CGRect(x: 4.2, y: 17, width: 2.4, height: 9))
                cg.fill(CGRect(x: 7.4, y: 17, width: 2.4, height: 9))
                cg.setFillColor(shirt.cgColor)
                cg.addPath(UIBezierPath(roundedRect: CGRect(x: 3, y: 9, width: 8, height: 10), cornerRadius: 3).cgPath)
                cg.fillPath()
                cg.setFillColor(shirt.withAlphaComponent(0.75).cgColor)
                cg.fill(CGRect(x: 8.6, y: 10, width: 2.2, height: 8))
                cg.setFillColor(skin.cgColor)
                cg.fillEllipse(in: CGRect(x: 3.6, y: 2, width: 6.8, height: 6.8))
                cg.setFillColor(UIColor(hex: 0x4A3A30).withAlphaComponent(0.85).cgColor)
                cg.addPath(UIBezierPath(arcCenter: CGPoint(x: 7, y: 5.2), radius: 3.5, startAngle: .pi, endAngle: 0, clockwise: true).cgPath)
                cg.fillPath()
            }
            return SKTexture(image: image)
        }
    }

    /// A soft oval shadow for something standing on the map.
    static func groundShadow() -> SKTexture {
        cached("ground-shadow") {
            let format = UIGraphicsImageRendererFormat()
            format.scale = 2
            let image = UIGraphicsImageRenderer(size: CGSize(width: 120, height: 40), format: format).image { context in
                softShadow(context.cgContext, rect: CGRect(x: 0, y: 0, width: 120, height: 40), alpha: 0.3)
            }
            return SKTexture(image: image)
        }
    }

    // Decor art comes from the asset catalog (flat paper cut-outs); the drawn versions below
    // are fallbacks if an asset is missing.

    static func tree(size: CGFloat) -> SKTexture {
        cached("tree|\(Int(size))") { SKTexture(image: decorImage(.tree, size: size)) }
    }

    static func bench(size: CGFloat) -> SKTexture {
        cached("bench|\(Int(size))") { SKTexture(image: decorImage(.bench, size: size)) }
    }

    static func mailbox(size: CGFloat) -> SKTexture {
        cached("mailbox|\(Int(size))") { SKTexture(image: decorImage(.mailbox, size: size)) }
    }

    static func planter(size: CGFloat) -> SKTexture {
        cached("planter|\(Int(size))") { SKTexture(image: decorImage(.planter, size: size)) }
    }

    static func lamp(size: CGFloat) -> SKTexture {
        cached("lamp|\(Int(size))") { SKTexture(image: decorImage(.lamp, size: size)) }
    }

    /// The picture for a decoration, for the map and for the decorating bar.
    static func decorImage(_ kind: DecorKind, size: CGFloat) -> UIImage {
        if let art = UIImage(named: "decor-\(kind.rawValue)") { return art }
        switch kind {
        case .tree: return treeImage(size: size)
        default: return benchImage(size: size)
        }
    }

    private static func cached(_ key: String, make: () -> SKTexture) -> SKTexture {
        if let texture = cache[key] { return texture }
        let texture = make()
        cache[key] = texture
        return texture
    }

    private static func softShadow(_ cg: CGContext, rect: CGRect, alpha: CGFloat) {
        let colors = [Palette.ink.withAlphaComponent(alpha).cgColor, Palette.ink.withAlphaComponent(0).cgColor] as CFArray
        guard let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) else { return }
        cg.saveGState()
        cg.translateBy(x: rect.midX, y: rect.midY)
        cg.scaleBy(x: 1, y: rect.height / rect.width)
        cg.drawRadialGradient(gradient, startCenter: .zero, startRadius: 0, endCenter: .zero, endRadius: rect.width / 2, options: [])
        cg.restoreGState()
    }

    /// A round, leafy tree in a 100 × 100 space; its base sits near the bottom.
    static func treeImage(size: CGFloat) -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 3
        return UIGraphicsImageRenderer(size: CGSize(width: size, height: size), format: format).image { context in
            let cg = context.cgContext
            cg.scaleBy(x: size / 100, y: size / 100)
            softShadow(cg, rect: CGRect(x: 22, y: 80, width: 60, height: 14), alpha: 0.22)

            let trunk = UIBezierPath(roundedRect: CGRect(x: 45, y: 58, width: 10, height: 30), cornerRadius: 3)
            cg.setFillColor(UIColor(hex: 0x9B7350).cgColor)
            cg.addPath(trunk.cgPath); cg.fillPath()
            cg.setStrokeColor(UIColor(hex: 0x6E4F35).cgColor); cg.setLineWidth(1.3)
            cg.addPath(trunk.cgPath); cg.strokePath()

            let blobs = [CGRect(x: 16, y: 28, width: 38, height: 38), CGRect(x: 46, y: 28, width: 38, height: 38),
                         CGRect(x: 29, y: 10, width: 42, height: 42), CGRect(x: 25, y: 36, width: 50, height: 30)]
            let canopy = CGMutablePath()
            blobs.forEach { canopy.addEllipse(in: $0) }
            // A soft darker edge instead of an ink outline.
            cg.addPath(canopy)
            cg.setStrokeColor(UIColor(hex: 0x5C8A4B).cgColor); cg.setLineWidth(2.4)
            cg.strokePath()
            cg.setFillColor(UIColor(hex: 0x7FAE69).cgColor)
            blobs.forEach { cg.fillEllipse(in: $0) }
            // Shade on the lower right, light on the upper left.
            cg.saveGState()
            cg.addPath(canopy); cg.clip()
            cg.setFillColor(UIColor(hex: 0x6C9C59).cgColor)
            cg.fillEllipse(in: CGRect(x: 48, y: 44, width: 40, height: 28))
            cg.fillEllipse(in: CGRect(x: 22, y: 54, width: 50, height: 16))
            cg.setFillColor(UIColor(hex: 0x9CC686).cgColor)
            cg.fillEllipse(in: CGRect(x: 32, y: 15, width: 18, height: 11))
            cg.fillEllipse(in: CGRect(x: 19, y: 34, width: 11, height: 8))
            cg.restoreGState()
        }
    }

    /// A slatted park bench, seen from the front, in a 100 × 100 space.
    static func benchImage(size: CGFloat) -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 3
        return UIGraphicsImageRenderer(size: CGSize(width: size, height: size), format: format).image { context in
            let cg = context.cgContext
            cg.scaleBy(x: size / 100, y: size / 100)
            softShadow(cg, rect: CGRect(x: 12, y: 70, width: 76, height: 14), alpha: 0.2)
            let iron = UIColor(hex: 0x4A4650).cgColor
            cg.setFillColor(iron)
            for x in [22.0, 73.0] {
                cg.addPath(UIBezierPath(roundedRect: CGRect(x: x, y: 34, width: 5, height: 42), cornerRadius: 2).cgPath)
                cg.fillPath()
            }
            let wood = UIColor(hex: 0xC4946A).cgColor
            let edge = UIColor(hex: 0x8A6440).cgColor
            for rect in [CGRect(x: 16, y: 30, width: 68, height: 7), CGRect(x: 16, y: 40, width: 68, height: 7),
                         CGRect(x: 12, y: 54, width: 76, height: 8)] {
                let slat = UIBezierPath(roundedRect: rect, cornerRadius: 2).cgPath
                cg.setFillColor(wood); cg.addPath(slat); cg.fillPath()
                cg.setStrokeColor(edge); cg.setLineWidth(1.2); cg.addPath(slat); cg.strokePath()
            }
            // Armrests.
            cg.setStrokeColor(iron); cg.setLineWidth(3); cg.setLineCap(.round)
            cg.move(to: CGPoint(x: 18, y: 54)); cg.addQuadLine(to: CGPoint(x: 14, y: 46), control: CGPoint(x: 12, y: 52)); cg.strokePath()
            cg.move(to: CGPoint(x: 82, y: 54)); cg.addQuadLine(to: CGPoint(x: 86, y: 46), control: CGPoint(x: 88, y: 52)); cg.strokePath()
        }
    }
}

private extension CGContext {
    func addQuadLine(to point: CGPoint, control: CGPoint) {
        addQuadCurve(to: point, control: control)
    }
}
