import SpriteKit
import UIKit

/// Renders the town and turns touches into changes on `GameState`.
///
/// Split across files:
/// - GameScene.swift             state, setup, coordinates, frame loop
/// - GameScene+Camera.swift      pinch to zoom, panning, keeping the view on the map
/// - GameScene+City.swift        city blocks and their revival, placement grid, daylight
/// - GameScene+Landmarks.swift   landmark stamps, derelict sites, labels, animations
/// - GameScene+Lines.swift       lines, lanes, line ends, ink-in, previews
/// - GameScene+Trains.swift      trains, stops, loading
/// - GameScene+Riders.swift      waiting bubbles and wish lines
/// - GameScene+Effects.swift     fare pop-ups, ripples, confetti
/// - GameScene+Tutorial.swift    the animated guide hand
/// - GameScene+Input.swift       touch gestures
final class GameScene: SKScene {
    weak var state: GameState?

    // MARK: Grid
    let cellSize: CGFloat = 48
    /// Space kept clear around the grid at normal zoom: the HUD on top, the dock below,
    /// and the rounded screen corners and camera housing on both sides.
    let topInset: CGFloat = 62
    let bottomInset: CGFloat = 78
    let leadingInset: CGFloat = 62
    let trailingInset: CGFloat = 62
    /// Size of one district, in grid cells. The city is a 2×2 grid of districts with canals between.
    var districtCols = 0
    var rows = 0
    var origin = CGPoint.zero
    var isSetUp = false
    var renderedTownVersion = -1
    var renderedCityVersion = -1
    var placementKey = ""

    var worldCols: Int { districtCols * 2 + GameState.gapCols }
    var worldRows: Int { rows * 2 + GameState.gapCols }

    // MARK: Camera
    let cameraNode = SKCameraNode()
    /// Smallest scale = most zoomed in.
    let minCameraScale: CGFloat = 0.45
    var pinchStartScale: CGFloat = 1
    var pinchAnchor = CGPoint.zero

    // MARK: Layers (bottom to top)
    let cityLayer = SKNode()
    let paperOverlay = SKSpriteNode()
    let gridLayer = SKNode()
    let wishLayer = SKNode()
    let ghostLayer = SKNode()
    let linesLayer = SKNode()
    let previewLayer = SKNode()
    let trainsLayer = SKNode()
    let effectsLayer = SKNode()
    let landmarksLayer = SKNode()
    let ridersLayer = SKNode()
    let tutorialLayer = SKNode()
    let attentionLayer = SKNode()
    /// People walking the streets, between the tracks and the trains.
    let pedestrianLayer = SKNode()
    /// Trees and other decor.
    let decorLayer = SKNode()
    var decorNodes: [Int: SKNode] = [:]
    var decorGlows: [Int: SKSpriteNode] = [:]
    var windowGlows: [Int: SKSpriteNode] = [:]
    var landmarkStage: [Int: Int] = [:]
    var landmarkColored: [Int: Bool] = [:]
    var landmarkNameShown: [Int: String] = [:]
    var communityBadges: [Int: SKNode] = [:]
    var communitySignatures: [Int: String] = [:]
    var crowdNodes: [Int: SKNode] = [:]
    /// Each line's underground stretches, for hiding trains in tunnels.
    var tunnelSpans: [Int: [ClosedRange<CGFloat>]] = [:]
    var tunnelHelper: SKNode?
    var crowdSignatures: [Int: String] = [:]
    var lostItemNode: SKNode?
    var lostItemKey: String?
    /// Rain, fog, wind, and sun, carried by the camera so they cover the screen.
    let weatherNode = SKNode()
    let atmosphere = AtmosphereTextures()
    /// Weather that sits over the streets but under the lines and landmarks: fog banks, rain shade.
    let groundWeatherNode = SKNode()
    var weatherKey = ""
    var atmosphereTimer: CGFloat = 0
    /// Finger speed while drawing, for the stretch sound. Smoothed, in screen points per second.
    var dragSpeed: CGFloat = 0
    var lastDragSample: (point: CGPoint, time: TimeInterval)?
    /// Arrows at the screen edge, carried by the camera so they stay put while the map moves.
    let edgeArrows = SKNode()
    let tintNode = SKSpriteNode(color: .white, size: CGSize(width: 1, height: 1))
    let glowLayer = SKNode()
    let popupLayer = SKNode()
    let previewNode = SKShapeNode()
    let ghostNode = SKShapeNode()

    // MARK: Shared textures
    lazy var glowTexture: SKTexture = TextureFactory.glow()
    lazy var roundedTexture: SKTexture = TextureFactory.roundedSquare()
    lazy var circleTexture: SKTexture = TextureFactory.circle()
    let icons = IconCache()

    // MARK: Render state
    var blocks: [CityBlock] = []
    var landmarkNodes: [Int: SKNode] = [:]
    var landmarkOpenState: [Int: Bool] = [:]
    var restoreBadges: [Int: SKNode] = [:]
    var glowNodes: [Int: SKSpriteNode] = [:]
    var routed: [Int: RoutedLine] = [:]
    var paths: [Int: LinePath] = [:]
    var lineShapes: [Int: SKShapeNode] = [:]
    var terminals: [LineHandle] = []
    var reveals: [Int: LineReveal] = [:]
    var queueNodes: [Int: SKNode] = [:]
    var queueSignatures: [Int: String] = [:]
    let wishShape = SKShapeNode()
    var wishBasePath: CGPath?
    var wishSignature = ""
    var wishPhase: CGFloat = 0
    var tutorialKey = ""
    var attentionNodes: [String: SKNode] = [:]
    var attentionSignatures: [String: String] = [:]
    var attentionPoints: [String: CGPoint] = [:]

    // MARK: Style
    let lineWidth: CGFloat = 6
    let revealSpeed: CGFloat = 700

    // MARK: Trains
    var trains: [Int: [Train]] = [:]
    var nextTrainID = 1
    let trainSpeed: CGFloat = 70
    let dwellTime: CGFloat = 0.7

    // MARK: Time
    var lastUpdate: TimeInterval = 0
    var nightFactor: CGFloat = 0
    var slowTimer: CGFloat = 0
    var riderTimer: CGFloat = 0

    // MARK: Input
    var mode: DragMode = .idle
    var activeTouch: UITouch?
    /// Where the current touch began, and the landmark under it, so a touch that never moves
    /// counts as a tap even when it started on a line's end.
    var touchStart: (point: CGPoint, landmarkID: Int?)?
    var touchTravel: CGFloat = 0
    /// The line that was selected when the touch began: tapping it again puts it down.
    var selectedAtTouchStart: Int?
    /// While placing: where the touch began, placed only if it ends as a tap (not a drag).
    var placeOnTap: CGPoint?
    /// Whether the camera has been placed on the town since it was laid out.
    var hasCenteredCamera = false
    /// While a landmark is being dragged: the cell it would land in. Lines preview against this cell.
    var moveTarget: (id: Int, cell: GridPoint)?
    /// A station that just refused a line (full), so the warning doesn't repeat every frame.
    var rejectedLandmarkID: Int?
    let longPressDelay: TimeInterval = 0.35
    let dragThreshold: CGFloat = 12

    override init(size: CGSize) {
        super.init(size: size)
        scaleMode = .resizeFill
        anchorPoint = .zero
        backgroundColor = Palette.paper

        let layers: [(SKNode, CGFloat)] = [
            (cityLayer, -90), (gridLayer, 0), (wishLayer, 3), (ghostLayer, 5),
            (linesLayer, 10), (previewLayer, 20), (trainsLayer, 46), (effectsLayer, 48),
            (pedestrianLayer, 25), (decorLayer, 40), (landmarksLayer, 40), (ridersLayer, 50), (attentionLayer, 55), (tutorialLayer, 60),
            (glowLayer, 8), (popupLayer, 95),
        ]
        for (layer, z) in layers {
            layer.zPosition = z
            addChild(layer)
        }

        // The camera carries the paper texture and daylight tint, so they stay fixed to the
        // screen while the town zooms and pans beneath them.
        addChild(cameraNode)
        camera = cameraNode
        paperOverlay.anchorPoint = .zero
        paperOverlay.zPosition = -50
        cameraNode.addChild(paperOverlay)
        // The daylight tint sits just above the city blocks and below the lines, so night
        // darkens the streets while tracks, trains, and landmarks stay crisp.
        tintNode.anchorPoint = .zero
        tintNode.blendMode = .multiply
        tintNode.zPosition = -40
        cameraNode.addChild(tintNode)
        edgeArrows.zPosition = 97
        cameraNode.addChild(edgeArrows)
        weatherNode.zPosition = 85
        cameraNode.addChild(weatherNode)
        groundWeatherNode.zPosition = 6
        cameraNode.addChild(groundWeatherNode)

        gridLayer.alpha = 0
        glowLayer.alpha = 0

        previewNode.lineWidth = lineWidth
        previewNode.lineCap = .round
        previewNode.lineJoin = .round
        previewLayer.addChild(previewNode)

        ghostNode.lineWidth = 2.5
        ghostLayer.addChild(ghostNode)

        wishShape.strokeColor = Palette.ink.withAlphaComponent(0.45)
        wishShape.lineWidth = 2
        wishShape.lineCap = .round
        wishLayer.addChild(wishShape)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /// Connects the scene to the game state. Called once from ContentView.
    func configure(with state: GameState) {
        self.state = state
        state.onChange = { [weak self] in self?.redraw() }
        setUpIfReady()
    }

    // MARK: Lifecycle

    override func didMove(to view: SKView) {
        installCameraGestures(in: view)
        setUpIfReady()
    }

    override func didChangeSize(_ oldSize: CGSize) {
        super.didChangeSize(oldSize)
        if isSetUp {
            layoutGrid()
            redraw()
        } else {
            setUpIfReady()
        }
    }

    override func update(_ currentTime: TimeInterval) {
        let realDt = lastUpdate == 0 ? 0 : min(CGFloat(currentTime - lastUpdate), 0.05)
        lastUpdate = currentTime
        guard isSetUp, let state else { return }

        if case let .pending(id, _, time, _) = mode, CACurrentMediaTime() - time > longPressDelay {
            beginMove(id)
        }

        let simDt = state.isSimulating ? realDt * CGFloat(state.speed.multiplier) : 0
        state.tick(dt: Double(simDt))
        handleSimEvents()

        updateDaylight()
        AudioManager.shared.update(dt: Double(realDt), activity: state.activity, isLive: state.isSimulating)
        updateReveals(dt: realDt)
        updateTrains(dt: simDt)
        updateTutorialGuide()
        updateCameraFocus()
        updateAtmosphere(dt: realDt)
        updateDrawingSound(dt: realDt)

        riderTimer += realDt
        if riderTimer >= 0.12 {
            updateRiders()
            riderTimer = 0
        }
        slowTimer += realDt
        if slowTimer >= 0.3 {
            updateCity()
            updateRestoreBadges()
            updateAttention()
            slowTimer = 0
        }
    }

    // MARK: Touch forwarding
    // UIKit overrides stay in the class body; the gesture logic lives in GameScene+Input.swift.

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard isSetUp, activeTouch == nil, let touch = touches.first else { return }
        activeTouch = touch
        handleTouchBegan(at: touch.location(in: self), viewPoint: touch.location(in: view))
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = activeTouch, touches.contains(touch) else { return }
        handleTouchMoved(to: touch.location(in: self), viewPoint: touch.location(in: view))
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = activeTouch, touches.contains(touch) else { return }
        handleTouchEnded(at: touch.location(in: self), cancelled: false)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = activeTouch, touches.contains(touch) else { return }
        handleTouchEnded(at: touch.location(in: self), cancelled: true)
    }

    // MARK: Setup

    private func setUpIfReady() {
        guard !isSetUp, let state, view != nil, size.width > 200, size.height > 150 else { return }
        if state.isTownReady {
            // A saved city keeps the grid it was built on.
            districtCols = state.districtCols
            rows = state.rows
        } else {
            // Districts are a good deal larger than the screen, so there's room for every
            // landmark, decorations, and space to spread out.
            // One big town to scroll around: about two screens wide and three tall.
            // The town is the whole grid (four of these quarters), a few screens to scroll around.
            districtCols = max(16, Int((size.width - leadingInset - trailingInset) / cellSize) + 4)
            rows = max(9, Int((size.height - topInset - bottomInset) / cellSize) + 2)
        }
        isSetUp = true
        layoutGrid()
        redraw()
    }

    /// Recomputes the grid origin and rebuilds everything that depends on it.
    private func layoutGrid() {
        let usableWidth = size.width - leadingInset - trailingInset
        let usableHeight = size.height - topInset - bottomInset
        origin = CGPoint(x: leadingInset + (usableWidth - CGFloat(districtCols) * cellSize) / 2,
                         y: bottomInset + (usableHeight - CGFloat(rows) * cellSize) / 2)
        paperOverlay.texture = TextureFactory.paperOverlay(size: size)
        paperOverlay.size = size
        paperOverlay.position = CGPoint(x: -size.width / 2, y: -size.height / 2)
        tintNode.size = size
        tintNode.position = CGPoint(x: -size.width / 2, y: -size.height / 2)
        cameraNode.position = CGPoint(x: size.width / 2, y: size.height / 2)
        cameraNode.setScale(1)
        if let state, state.isTownReady {
            cameraNode.position = districtCenter(state.focusedDistrict)
        }
        buildCity()
        placementKey = ""
    }

    // MARK: Coordinates

    func center(of cell: GridPoint) -> CGPoint {
        CGPoint(x: origin.x + (CGFloat(cell.col) + 0.5) * cellSize,
                y: origin.y + (CGFloat(cell.row) + 0.5) * cellSize)
    }

    func gridPoint(at p: CGPoint) -> GridPoint? {
        let col = Int(floor((p.x - origin.x) / cellSize))
        let row = Int(floor((p.y - origin.y) / cellSize))
        guard col >= 0, col < worldCols, row >= 0, row < worldRows else { return nil }
        return GridPoint(col: col, row: row)
    }

    /// The cell a landmark occupies for routing. While dragging, this is the cell it would drop into.
    func stationCell(of id: Int) -> GridPoint? {
        if let target = moveTarget, target.id == id { return target.cell }
        return state?.landmark(id: id)?.cell
    }

    func position(ofLandmark id: Int) -> CGPoint? {
        guard let cell = stationCell(of: id) else { return nil }
        return center(of: cell)
    }

    /// Where a landmark is drawn right now (follows the finger while dragging).
    func displayPosition(ofLandmark id: Int) -> CGPoint? {
        landmarkNodes[id]?.position ?? position(ofLandmark: id)
    }

    /// The landmark under a point, if the point is within its tile.
    func landmarkHit(at p: CGPoint, tolerance: CGFloat = 0.45) -> Int? {
        guard let cell = gridPoint(at: p), let landmark = state?.landmark(at: cell) else { return nil }
        let c = center(of: cell)
        guard abs(p.x - c.x) <= cellSize * tolerance, abs(p.y - c.y) <= cellSize * tolerance else { return nil }
        return landmark.id
    }

    var isMovingLandmark: Bool {
        if case .moving = mode { return true }
        return false
    }

    // MARK: Redraw

    func redraw() {
        guard isSetUp, let state else { return }
        if !state.isTownReady {
            state.prepareTown(cols: districtCols, rows: rows) // calls back into redraw once ready
            return
        }
        if renderedTownVersion != state.townVersion {
            resetTownVisuals()
            renderedTownVersion = state.townVersion
            // A freshly laid-out or loaded town: put the camera on it, not on an empty corner.
            if !hasCenteredCamera {
                hasCenteredCamera = true
                focus(on: state.focusedDistrict, animated: false)
            }
        }
        if renderedCityVersion != state.cityVersion {
            buildCity()
            renderedCityVersion = state.cityVersion
        }
        drawLandmarks()
        drawDecor()
        drawLines()
        syncTrains()
        updateGridVisibility()
    }

    /// Clears everything drawn for a previous town.
    private func resetTownVisuals() {
        for node in landmarkNodes.values { node.removeFromParent() }
        for node in glowNodes.values { node.removeFromParent() }
        for node in queueNodes.values { node.removeFromParent() }
        for node in restoreBadges.values { node.removeFromParent() }
        for node in decorNodes.values { node.removeFromParent() }
        decorNodes = [:]
        for node in decorGlows.values { node.removeFromParent() }
        for node in communityBadges.values { node.removeFromParent() }
        communityBadges = [:]
        communitySignatures = [:]
        for node in crowdNodes.values { node.removeFromParent() }
        crowdNodes = [:]
        crowdSignatures = [:]
        lostItemNode?.removeFromParent()
        lostItemNode = nil
        lostItemKey = nil
        decorGlows = [:]
        windowGlows = [:]
        landmarkStage = [:]
        landmarkColored = [:]
        for list in trains.values { for train in list { train.removeFromScene() } }
        landmarkNodes = [:]
        landmarkOpenState = [:]
        glowNodes = [:]
        queueNodes = [:]
        queueSignatures = [:]
        restoreBadges = [:]
        trains = [:]
        reveals = [:]
        wishSignature = ""
        wishBasePath = nil
        wishShape.path = nil
        wishLayer.children.filter { $0 !== wishShape }.forEach { $0.removeFromParent() }
        tutorialKey = ""
        tutorialLayer.removeAllChildren()
        cameraNode.position = CGPoint(x: size.width / 2, y: size.height / 2)
        cameraNode.setScale(1)
        buildCity()
    }
}
