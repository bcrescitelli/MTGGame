import SpriteKit
import UIKit

extension GameScene {

    // MARK: City blocks

    /// Lays out the city's blocks between grid cells, so streets run exactly where lines travel.
    /// The districts sit in four quadrants with canals crossing between them. Each district has
    /// its own colors and mix of homes, shops, parks, and plazas. Blocks start faded and revive
    /// with service. Open districts are drawn, plus the next one as a grey preview.
    func buildCity() {
        cityLayer.removeAllChildren()
        blocks.removeAll()
        guard let state, districtCols > 0, rows > 0, state.districtCols == districtCols else { return }

        // The whole city is always drawn: districts not yet open simply stay grey and quiet,
        // so the map never ends in bare paper.
        // Draw the town that's open (one big area in a new city; older cities keep their districts).
        let drawn = District.allCases.filter { state.isOpened($0) }
        let solo = drawn.count == 1
        let isDrawn: (Int, Int) -> Bool = { blockCol, blockRow in
            drawn.contains { $0.blockCol == blockCol && $0.blockRow == blockRow }
        }
        var minRow = Int.max, maxRow = Int.min, minCol = Int.max, maxCol = Int.min

        for district in drawn {
            var rng = SeededGenerator(seed: state.townSeed &+ 99 &+ UInt64(district.rawValue) &* 104_729)
            let cols = state.columns(of: district)
            let rowsHere = state.rowRange(of: district)
            let west = district.blockCol == 0
            let north = district.blockRow == 1
            let neighborAcross = isDrawn(1 - district.blockCol, district.blockRow)
            let neighborBelowOrAbove = isDrawn(district.blockCol, 1 - district.blockRow)

            // Outer edges get extra blocks so zooming out never shows a hard edge. Inner edges
            // always stop at the district's own canal, so one district never spills into the next.
            _ = (neighborAcross, neighborBelowOrAbove)
            let firstCol = (west || solo) ? cols.lowerBound - 6 : cols.lowerBound
            let lastCol = (west && !solo) ? cols.upperBound - 2 : cols.upperBound + 5
            let firstRow = (north && !solo) ? rowsHere.lowerBound : rowsHere.lowerBound - 5
            let lastRow = (north || solo) ? rowsHere.upperBound + 4 : rowsHere.upperBound - 2
            guard firstCol <= lastCol, firstRow <= lastRow else { continue }
            minRow = min(minRow, firstRow); maxRow = max(maxRow, lastRow)
            minCol = min(minCol, firstCol); maxCol = max(maxCol, lastCol)

            let river = state.riverCells
            for row in firstRow...lastRow {
                var col = firstCol
                while col <= lastCol {
                    // No blocks on the river, and none straddling into it.
                    if river.contains(GridPoint(col: col, row: row)) { col += 1; continue }
                    let span = Int.random(in: 0..<10, using: &rng) < 3 && col + 1 <= lastCol
                        && !river.contains(GridPoint(col: col + 1, row: row)) ? 2 : 1
                    addBlock(district: district, col: col, row: row, span: span, rng: &rng)
                    col += span
                }
            }
        }

        guard minRow <= maxRow else { return }
        // The canal cross: north–south between west and east, east–west between north and south.
        if drawn.contains(where: { $0.blockCol == 1 }) && drawn.contains(where: { $0.blockCol == 0 }) {
            addCanal(vertical: true, at: districtCols, from: minRow, to: maxRow + 1)
        }
        if drawn.contains(where: { $0.blockRow == 0 }) && drawn.contains(where: { $0.blockRow == 1 }) {
            addCanal(vertical: false, at: rows, from: minCol, to: maxCol + 1)
        }
        if solo { addRiver() }
        updateCity(force: true)
    }

    /// The river: a wide, soft-edged band of water through the cells left free for it.
    private func addRiver() {
        guard let state else { return }
        let river = state.riverCells
        guard !river.isEmpty else { return }
        // One smooth line through the middle of the river, column by column.
        let byCol = Dictionary(grouping: river, by: \.col)
        let points: [CGPoint] = byCol.keys.sorted().compactMap { col in
            guard let rows = byCol[col]?.map(\.row), let low = rows.min(), let high = rows.max() else { return nil }
            let a = center(of: GridPoint(col: col, row: low)), b = center(of: GridPoint(col: col, row: high))
            return CGPoint(x: a.x, y: (a.y + b.y) / 2)
        }
        guard points.count > 2 else { return }
        let path = CGMutablePath()
        path.move(to: points[0])
        for index in 1..<points.count - 1 {
            let mid = CGPoint(x: (points[index].x + points[index + 1].x) / 2, y: (points[index].y + points[index + 1].y) / 2)
            path.addQuadCurve(to: mid, control: points[index])
        }
        path.addLine(to: points[points.count - 1])
        for (width, color, z) in [(cellSize * 2.0, UIColor(hex: 0xC9DCC0), -0.3), (cellSize * 1.7, UIColor(hex: 0xBFD8E5), -0.2),
                                  (cellSize * 1.35, UIColor(hex: 0x9CC2D6), -0.1)] {
            let band = SKShapeNode(path: path)
            band.strokeColor = color
            band.lineWidth = width
            band.lineCap = .round
            band.lineJoin = .round
            band.zPosition = CGFloat(z)
            cityLayer.addChild(band)
        }
        // A few soft ripples along the water.
        for (index, point) in points.enumerated() where index % 4 == 2 {
            let ripple = SKShapeNode(ellipseOf: CGSize(width: cellSize * 0.5, height: cellSize * 0.12))
            ripple.strokeColor = UIColor.white.withAlphaComponent(0.55)
            ripple.lineWidth = 1.5
            ripple.fillColor = .clear
            ripple.position = CGPoint(x: point.x, y: point.y + CGFloat(index % 3 - 1) * cellSize * 0.2)
            ripple.zPosition = 0
            cityLayer.addChild(ripple)
        }
    }

    private func addBlock(district: District, col: Int, row: Int, span: Int, rng: inout SeededGenerator) {
        let street: CGFloat = 12
        let minX = origin.x + (CGFloat(col) + 0.5) * cellSize + street / 2
        let maxX = origin.x + (CGFloat(col + span) + 0.5) * cellSize - street / 2
        let minY = origin.y + (CGFloat(row) + 0.5) * cellSize + street / 2
        let maxY = origin.y + (CGFloat(row + 1) + 0.5) * cellSize - street / 2
        let rect = CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY)

        let mix = district.blockMix
        let roll = Int.random(in: 0..<100, using: &rng)
        let kind: BlockKind
        if roll < mix.park {
            kind = .park
        } else if roll < mix.park + mix.plaza {
            kind = .plaza
        } else if roll < mix.park + mix.plaza + mix.shops {
            kind = .shops
        } else {
            kind = .homes
        }

        var cells: [GridPoint] = []
        for c in col...(col + span) {
            for r in row...(row + 1) {
                let cell = GridPoint(col: min(max(c, 0), worldCols - 1), row: min(max(r, 0), worldRows - 1))
                if !cells.contains(cell) { cells.append(cell) }
            }
        }
        blocks.append(makeBlock(kind: kind, district: district, rect: rect, cells: cells, rng: &rng))
    }

    /// Water between districts, with a soft bank on each side. `at` is the first grid column
    /// (or row) of the gap; `from`/`to` is its extent along the other axis.
    private func addCanal(vertical: Bool, at start: Int, from: Int, to: Int) {
        let near = CGFloat(start) * cellSize + 6
        let far = CGFloat(start + GameState.gapCols) * cellSize - 6
        let rect: CGRect = vertical
            ? CGRect(x: origin.x + near, y: origin.y + CGFloat(from) * cellSize,
                     width: far - near, height: CGFloat(to - from) * cellSize)
            : CGRect(x: origin.x + CGFloat(from) * cellSize, y: origin.y + near,
                     width: CGFloat(to - from) * cellSize, height: far - near)

        let bank = SKSpriteNode(color: UIColor(hex: 0xCFC3A6),
                                size: vertical ? CGSize(width: rect.width + 8, height: rect.height)
                                               : CGSize(width: rect.width, height: rect.height + 8))
        bank.position = CGPoint(x: rect.midX, y: rect.midY)
        bank.zPosition = -1
        cityLayer.addChild(bank)

        let water = SKSpriteNode(color: UIColor(hex: 0xA9CFE0), size: rect.size)
        water.position = bank.position
        water.zPosition = 0
        cityLayer.addChild(water)

        // A few ripples so it reads as water at a glance.
        var rng = SeededGenerator(seed: UInt64(start) &* 31 &+ (vertical ? 5 : 11))
        var along = (vertical ? rect.minY : rect.minX) + 20
        let end = vertical ? rect.maxY : rect.maxX
        while along < end {
            let ripple = SKSpriteNode(color: UIColor.white.withAlphaComponent(0.55),
                                      size: vertical ? CGSize(width: 10, height: 1.5) : CGSize(width: 1.5, height: 10))
            ripple.position = vertical
                ? CGPoint(x: CGFloat.random(in: (rect.minX + 10)...(rect.maxX - 10), using: &rng), y: along)
                : CGPoint(x: along, y: CGFloat.random(in: (rect.minY + 10)...(rect.maxY - 10), using: &rng))
            ripple.zPosition = 1
            cityLayer.addChild(ripple)
            along += CGFloat.random(in: 26...46, using: &rng)
        }
    }

    private func makeBlock(kind: BlockKind, district: District, rect: CGRect, cells: [GridPoint],
                           rng: inout SeededGenerator) -> CityBlock {
        let container = SKNode()
        container.position = CGPoint(x: rect.midX, y: rect.midY)
        cityLayer.addChild(container)

        // Rounded base, tinted, stretched with 9-slice so the corners stay round.
        let base = SKSpriteNode(texture: roundedTexture)
        base.centerRect = CGRect(x: 0.3, y: 0.3, width: 0.4, height: 0.4)
        base.xScale = rect.width / roundedTexture.size().width
        base.yScale = rect.height / roundedTexture.size().height
        base.colorBlendFactor = 1
        base.zPosition = 0
        container.addChild(base)

        let details = SKNode()
        details.zPosition = 1
        container.addChild(details)
        let lights = SKNode()
        lights.zPosition = 2
        container.addChild(lights)

        let faded: UIColor
        let revived: UIColor
        let inner = rect.insetBy(dx: 4, dy: 4).offsetBy(dx: -rect.midX, dy: -rect.midY)

        switch kind {
        case .homes:
            faded = UIColor(hex: 0xD8D2C6)
            let palette = district.homeColors
            revived = UIColor(hex: palette[Int.random(in: 0..<palette.count, using: &rng)])
            addHouses(in: inner, roof: revived.mixed(with: Palette.ink, amount: 0.2), details: details, lights: lights, rng: &rng)
        case .shops:
            faded = UIColor(hex: 0xD5CFC3)
            let palette = district.shopColors
            revived = UIColor(hex: palette[Int.random(in: 0..<palette.count, using: &rng)])
            addShops(in: inner, base: revived, district: district, details: details, lights: lights, rng: &rng)
        case .park:
            faded = UIColor(hex: 0xD2CBB8)
            revived = UIColor(hex: district.parkColor)
            addTrees(in: inner, details: details, lights: lights, rng: &rng)
        case .plaza:
            faded = UIColor(hex: 0xDED8CC)
            revived = UIColor(hex: district.plazaColor)
            addFountain(in: inner, details: details, lights: lights)
        }

        base.color = faded
        details.alpha = 0
        lights.alpha = 0
        let growth = SKNode()
        growth.zPosition = 3
        growth.alpha = 0
        container.addChild(growth)
        let block = CityBlock(kind: kind, cells: cells, base: base, details: details, lights: lights,
                              growth: growth, faded: faded, revived: revived)
        block.growthRect = inner
        block.growthSeed = UInt64.random(in: 1...UInt64.max, using: &rng)
        return block
    }

    /// What a block grows into once it's thriving: taller buildings with lit windows on
    /// homes and shops, and more trees in parks and plazas.
    private func addGrowth(kind: BlockKind, in rect: CGRect, color: UIColor, growth: SKNode, rng: inout SeededGenerator) {
        switch kind {
        case .homes, .shops:
            let count = rect.width > 40 ? 2 : 1
            let slot = rect.width / CGFloat(count)
            for index in 0..<count {
                let width = min(slot - 6, CGFloat.random(in: 12...18, using: &rng))
                let height = min(rect.height - 4, CGFloat.random(in: 16...22, using: &rng))
                let x = rect.minX + slot * (CGFloat(index) + 0.5)
                let tower = SKShapeNode(rect: CGRect(x: x - width / 2, y: rect.minY + 2, width: width, height: height),
                                        cornerRadius: 1.5)
                tower.fillColor = color.mixed(with: Palette.ink, amount: 0.28)
                tower.strokeColor = Palette.ink.withAlphaComponent(0.35)
                tower.lineWidth = 0.8
                growth.addChild(tower)
                var y = rect.minY + 5
                while y < rect.minY + height - 2 {
                    for column in [-1, 1] {
                        let window = SKSpriteNode(color: UIColor(hex: 0xFFE7A6), size: CGSize(width: 2.2, height: 2.2))
                        window.position = CGPoint(x: x + CGFloat(column) * width * 0.22, y: y)
                        window.alpha = 0.85
                        growth.addChild(window)
                    }
                    y += 4.5
                }
            }
        case .park, .plaza:
            for _ in 0..<3 {
                let tree = SKShapeNode(circleOfRadius: CGFloat.random(in: 3...4.5, using: &rng))
                tree.fillColor = UIColor(hex: 0x6E9F5B)
                tree.strokeColor = Palette.ink.withAlphaComponent(0.3)
                tree.lineWidth = 0.6
                tree.position = CGPoint(x: CGFloat.random(in: rect.minX + 4...rect.maxX - 4, using: &rng),
                                        y: CGFloat.random(in: rect.minY + 4...rect.maxY - 4, using: &rng))
                growth.addChild(tree)
            }
        }
    }

    private func addHouses(in rect: CGRect, roof: UIColor, details: SKNode, lights: SKNode, rng: inout SeededGenerator) {
        let columns = max(1, Int(rect.width / 16))
        let cellW = rect.width / CGFloat(columns)
        let cellH = rect.height / 2
        for c in 0..<columns {
            for r in 0..<2 {
                // A few gaps read as gardens between houses.
                guard Int.random(in: 0..<10, using: &rng) < 8 else { continue }
                let size = CGSize(width: cellW - 4, height: cellH - 4)
                let center = CGPoint(x: rect.minX + (CGFloat(c) + 0.5) * cellW, y: rect.minY + (CGFloat(r) + 0.5) * cellH)
                let house = SKSpriteNode(color: roof, size: size)
                house.position = center
                details.addChild(house)
                let ridge = SKSpriteNode(color: roof.mixed(with: Palette.ink, amount: 0.25), size: CGSize(width: size.width, height: 1.5))
                ridge.position = center
                details.addChild(ridge)
                let window = SKSpriteNode(color: Palette.lamp, size: CGSize(width: 3, height: 3))
                window.position = CGPoint(x: center.x + CGFloat.random(in: -3...3, using: &rng), y: center.y - 2.5)
                lights.addChild(window)
            }
        }
    }

    private func addShops(in rect: CGRect, base: UIColor, district: District, details: SKNode, lights: SKNode,
                          rng: inout SeededGenerator) {
        let roofHeight = rect.height * 0.55
        let roof = SKSpriteNode(color: base.mixed(with: Palette.ink, amount: 0.18),
                                size: CGSize(width: rect.width - 2, height: roofHeight))
        roof.position = CGPoint(x: rect.midX, y: rect.maxY - roofHeight / 2)
        details.addChild(roof)

        let stripeCount = max(4, Int(rect.width / 6))
        let stripeWidth = (rect.width - 2) / CGFloat(stripeCount)
        let awning = district.accent.mixed(with: Palette.card, amount: CGFloat.random(in: 0.1...0.35, using: &rng))
        for i in 0..<stripeCount where i % 2 == 0 {
            let stripe = SKSpriteNode(color: awning, size: CGSize(width: stripeWidth, height: 4))
            stripe.position = CGPoint(x: rect.minX + 1 + (CGFloat(i) + 0.5) * stripeWidth, y: rect.maxY - roofHeight - 2)
            details.addChild(stripe)
        }

        let windowCount = max(2, Int(rect.width / 12))
        for i in 0..<windowCount {
            let window = SKSpriteNode(color: Palette.lamp, size: CGSize(width: 4, height: 3))
            window.position = CGPoint(x: rect.minX + (CGFloat(i) + 0.5) * rect.width / CGFloat(windowCount), y: rect.minY + 5)
            lights.addChild(window)
        }
    }

    private func addTrees(in rect: CGRect, details: SKNode, lights: SKNode, rng: inout SeededGenerator) {
        let count = Int.random(in: 3...5, using: &rng) * max(1, Int(rect.width / 30))
        for _ in 0..<count {
            let radius = CGFloat.random(in: 4...6.5, using: &rng)
            let x = CGFloat.random(in: (rect.minX + radius)...(rect.maxX - radius), using: &rng)
            let y = CGFloat.random(in: (rect.minY + radius)...(rect.maxY - radius), using: &rng)
            let shadow = SKSpriteNode(texture: circleTexture, size: CGSize(width: radius * 2, height: radius * 2))
            shadow.color = UIColor(hex: 0x7FA466)
            shadow.colorBlendFactor = 1
            shadow.position = CGPoint(x: x + 1, y: y - 1.5)
            details.addChild(shadow)
            let tree = SKSpriteNode(texture: circleTexture, size: CGSize(width: radius * 2, height: radius * 2))
            tree.color = UIColor(hex: 0x9CC27E)
            tree.colorBlendFactor = 1
            tree.position = CGPoint(x: x, y: y)
            details.addChild(tree)
        }
        let lamp = SKSpriteNode(texture: circleTexture, size: CGSize(width: 4, height: 4))
        lamp.color = Palette.lamp
        lamp.colorBlendFactor = 1
        lamp.position = CGPoint(x: rect.midX, y: rect.midY)
        lights.addChild(lamp)
    }

    private func addFountain(in rect: CGRect, details: SKNode, lights: SKNode) {
        let side = min(rect.width, rect.height)
        let rim = SKSpriteNode(texture: circleTexture, size: CGSize(width: side * 0.7, height: side * 0.7))
        rim.color = UIColor(hex: 0xD9CDB4)
        rim.colorBlendFactor = 1
        rim.position = CGPoint(x: rect.midX, y: rect.midY)
        details.addChild(rim)
        let water = SKSpriteNode(texture: circleTexture, size: CGSize(width: side * 0.5, height: side * 0.5))
        water.color = UIColor(hex: 0xA9D3E3)
        water.colorBlendFactor = 1
        water.position = rim.position
        details.addChild(water)
        for corner in [CGPoint(x: rect.minX + 3, y: rect.minY + 3), CGPoint(x: rect.maxX - 3, y: rect.maxY - 3)] {
            let lamp = SKSpriteNode(texture: circleTexture, size: CGSize(width: 4, height: 4))
            lamp.color = Palette.lamp
            lamp.colorBlendFactor = 1
            lamp.position = corner
            lights.addChild(lamp)
        }
    }

    /// Recolors blocks from the revival grid. Runs a few times a second.
    func updateCity(force: Bool = false) {
        guard let state else { return }
        for block in blocks {
            let values = block.cells.map { CGFloat(state.vitality(at: $0)) }
            let vitality = values.isEmpty ? 0 : values.reduce(0, +) / CGFloat(values.count)
            let reveal = smoothstep((vitality - 0.3) / 0.45)
            if force || abs(vitality - block.shownVitality) > 0.008 {
                block.shownVitality = vitality
                block.base.color = block.faded.mixed(with: block.revived, amount: smoothstep(vitality / 0.85))
                block.details.alpha = reveal
                let grown = smoothstep((vitality - 0.78) / 0.15)
                if grown > 0, !block.hasGrown {
                    block.hasGrown = true
                    var rng = SeededGenerator(seed: block.growthSeed)
                    addGrowth(kind: block.kind, in: block.growthRect, color: block.revived, growth: block.growth, rng: &rng)
                }
                block.growth.alpha = grown
            }
            block.lights.alpha = reveal * nightFactor
        }
        for glow in windowGlows.values { glow.alpha = nightFactor * 0.95 }
    }

    private func smoothstep(_ x: CGFloat) -> CGFloat {
        let t = min(max(x, 0), 1)
        return t * t * (3 - 2 * t)
    }

    // MARK: Placement grid

    /// While placing or moving a landmark: marks on every square it can go, in its district,
    /// leaving clear the space around other landmarks.
    func updatePlacementGrid() {
        guard let state else { return }
        var district: District?
        var ignoring: Int?
        let everywhere = state.placingHub || state.isDiggingTunnel
        if everywhere {
            district = state.focusedDistrict
        } else if let kind = state.placingKind {
            district = kind.info.district
        } else if case let .moving(id) = mode, let landmark = state.landmark(id: id) {
            district = landmark.kind.info.district
            ignoring = id
        }
        let key = "\(everywhere)|\(district?.rawValue ?? -1)|\(ignoring ?? -1)|\(state.landmarks.count)|\(state.landmarks.map { "\($0.cell.col),\($0.cell.row)" }.joined())"
        guard key != placementKey else { return }
        placementKey = key
        gridLayer.removeAllChildren()
        guard let district else { return }

        let marks = CGMutablePath()
        let arm: CGFloat = 4
        let areas = everywhere ? District.allCases.filter { state.isOpened($0) } : [district]
        for area in areas {
        for col in state.columns(of: area) {
            for row in state.rowRange(of: area) {
                let cell = GridPoint(col: col, row: row)
                guard state.isBuildable(cell, in: area, ignoring: ignoring) else { continue }
                let p = center(of: cell)
                marks.move(to: CGPoint(x: p.x - arm, y: p.y))
                marks.addLine(to: CGPoint(x: p.x + arm, y: p.y))
                marks.move(to: CGPoint(x: p.x, y: p.y - arm))
                marks.addLine(to: CGPoint(x: p.x, y: p.y + arm))
            }
        }
        }
        let node = SKShapeNode(path: marks)
        node.strokeColor = Palette.good
        node.lineWidth = 2
        node.lineCap = .round
        gridLayer.addChild(node)
    }

    func updateGridVisibility() {
        updatePlacementGrid()
        let visible = isMovingLandmark || state?.placingKind != nil
        let target: CGFloat = visible ? 1 : 0
        guard gridLayer.alpha != target else { return }
        gridLayer.run(.fadeAlpha(to: target, duration: 0.2), withKey: "fade")
    }

    // MARK: Daylight

    /// Daylight follows the day clock: dawn when the first train runs, night when the last one does.
    func updateDaylight() {
        guard let state else { return }
        let sample = DayCycle.sample(CGFloat(state.dayClock))
        tintNode.color = sample.tint
        nightFactor = sample.night
        glowLayer.alpha = sample.night
    }
}
