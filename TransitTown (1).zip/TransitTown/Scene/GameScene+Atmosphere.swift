import SpriteKit
import UIKit

/// Small textures for weather particles and walkers, drawn once.
final class AtmosphereTextures {
    lazy var dot = make(CGSize(width: 8, height: 8)) { context, rect in
        context.fillEllipse(in: rect)
    }
    /// A soft raindrop: short, rounded, fading toward its tail.
    lazy var drop = make(CGSize(width: 4, height: 11)) { context, rect in
        let colors = [UIColor.white.withAlphaComponent(0).cgColor, UIColor.white.cgColor] as CFArray
        if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
            context.addPath(UIBezierPath(roundedRect: rect, cornerRadius: rect.width / 2).cgPath)
            context.clip()
            context.drawLinearGradient(gradient, start: CGPoint(x: rect.midX, y: rect.maxY), end: CGPoint(x: rect.midX, y: rect.minY), options: [])
        }
    }

    /// A ring where a drop lands.
    lazy var ripple = make(CGSize(width: 24, height: 12)) { context, rect in
        context.setStrokeColor(UIColor.white.cgColor)
        context.setLineWidth(1.4)
        context.strokeEllipse(in: rect.insetBy(dx: 1, dy: 1))
    }

    lazy var streak = make(CGSize(width: 2, height: 16)) { context, rect in
        context.fill(rect)
    }
    lazy var leaf = make(CGSize(width: 9, height: 5)) { context, rect in
        context.fillEllipse(in: rect)
    }
    lazy var gust = make(CGSize(width: 44, height: 2)) { context, rect in
        context.fill(rect)
    }
    lazy var puff: SKTexture = {
        let size = CGSize(width: 128, height: 128)
        let image = UIGraphicsImageRenderer(size: size).image { renderer in
            let colors = [UIColor.white.cgColor, UIColor.white.withAlphaComponent(0).cgColor] as CFArray
            let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1])!
            let center = CGPoint(x: 64, y: 64)
            renderer.cgContext.drawRadialGradient(gradient, startCenter: center, startRadius: 0,
                                                  endCenter: center, endRadius: 64, options: [])
        }
        return SKTexture(image: image)
    }()

    private func make(_ size: CGSize, draw: (CGContext, CGRect) -> Void) -> SKTexture {
        let image = UIGraphicsImageRenderer(size: size).image { renderer in
            UIColor.white.setFill()
            draw(renderer.cgContext, CGRect(origin: .zero, size: size))
        }
        return SKTexture(image: image)
    }
}

extension GameScene {

    /// Called every frame: weather overlays, rain ripples, lightning, and people walking.
    func updateAtmosphere(dt: CGFloat) {
        guard let state else { return }
        let storm = state.todayEvents.contains { $0.kind == .storm && $0.isActive(at: state.dayClock) }
        let weather = storm ? Weather.rain : state.weatherToday
        let key = "\(weather.rawValue)|\(storm)|\(Int(size.width))"
        if key != weatherKey {
            weatherKey = key
            buildWeather(weather, storm: storm)
        }

        atmosphereTimer += dt
        guard atmosphereTimer >= 0.15 else { return }
        let step = atmosphereTimer
        atmosphereTimer = 0

        if weather == .rain {
            for _ in 0..<(storm ? 3 : 1) { addPuddleRipple() }
        }
        if storm, Int.random(in: 0..<60) == 0 {
            flashLightning()
        }
        spawnAmbientWalkers(step: step)
        pedestrianLayer.isPaused = state.speed == .paused
    }

    // MARK: Weather

    private func buildWeather(_ weather: Weather, storm: Bool) {
        weatherNode.removeAllChildren()
        groundWeatherNode.removeAllChildren()
        let width = size.width, height = size.height

        switch weather {
        case .rain:
            // A gentle shower: soft short drops drifting down, and small ripples on the streets.
            let rain = SKEmitterNode()
            rain.particleTexture = atmosphere.drop
            rain.particleBirthRate = storm ? 110 : 55
            rain.particleLifetime = 1.7
            rain.particlePositionRange = CGVector(dx: width * 1.3, dy: 0)
            rain.position = CGPoint(x: width * 0.08, y: height / 2 + 20)
            rain.emissionAngle = -.pi / 2 - (storm ? 0.22 : 0.12)
            rain.particleRotation = storm ? 0.22 : 0.12
            rain.particleSpeed = storm ? 290 : 220
            rain.particleSpeedRange = 40
            rain.particleAlpha = 0
            rain.particleAlphaSequence = SKKeyframeSequence(keyframeValues: [0, storm ? 0.42 : 0.32, storm ? 0.42 : 0.32, 0],
                                                            times: [0, 0.15, 0.8, 1])
            rain.particleScale = 0.85
            rain.particleScaleRange = 0.35
            rain.particleColor = UIColor(hex: 0x8DB0CF)
            rain.particleColorBlendFactor = 1
            rain.advanceSimulationTime(1.8)
            weatherNode.addChild(rain)
            let ripples = SKEmitterNode()
            ripples.particleTexture = atmosphere.ripple
            ripples.particleBirthRate = storm ? 14 : 7
            ripples.particleLifetime = 0.9
            ripples.particlePositionRange = CGVector(dx: width, dy: height)
            ripples.particleSpeed = 0
            ripples.particleScale = 0.15
            ripples.particleScaleSpeed = 0.75
            ripples.particleAlpha = 0.4
            ripples.particleAlphaSpeed = -0.44
            ripples.particleColor = UIColor(hex: 0xE6F0F6)
            ripples.particleColorBlendFactor = 1
            groundWeatherNode.addChild(ripples)
            let dim = SKSpriteNode(color: UIColor(hex: 0x5D6F82), size: CGSize(width: width * 1.2, height: height * 1.2))
            dim.alpha = storm ? 0.12 : 0.06
            groundWeatherNode.addChild(dim)

        case .fog:
            // Low banks drifting across the streets, under the lines and landmarks so the
            // network stays readable. Thin, evenly spread, and from both sides.
            for (index, fromLeft) in [true, false].enumerated() {
                let fog = SKEmitterNode()
                fog.particleTexture = atmosphere.puff
                fog.particleBirthRate = 0.7
                fog.particleLifetime = 26
                fog.particlePositionRange = CGVector(dx: width * 0.6, dy: height)
                fog.position = CGPoint(x: fromLeft ? -width * 0.3 : width * 0.3, y: 0)
                fog.emissionAngle = fromLeft ? 0 : .pi
                fog.particleSpeed = 9
                fog.particleSpeedRange = 4
                fog.particleAlpha = 0
                fog.particleAlphaSequence = SKKeyframeSequence(keyframeValues: [0, 0.32, 0.32, 0], times: [0, 0.25, 0.75, 1])
                fog.particleScale = 2.2
                fog.particleScaleRange = 0.8
                fog.particleColor = UIColor(hex: 0xF4F1EA)
                fog.particleColorBlendFactor = 1
                fog.advanceSimulationTime(26 + Double(index) * 7)
                groundWeatherNode.addChild(fog)
            }
            let haze = SKSpriteNode(color: UIColor(hex: 0xF4F1EA), size: CGSize(width: width * 1.2, height: height * 1.2))
            haze.alpha = 0.12
            groundWeatherNode.addChild(haze)

        case .windy:
            let leaves = SKEmitterNode()
            leaves.particleTexture = atmosphere.leaf
            leaves.particleBirthRate = 10
            leaves.particleLifetime = 7
            leaves.particlePositionRange = CGVector(dx: 0, dy: height)
            leaves.position = CGPoint(x: -width / 2 - 20, y: 0)
            leaves.emissionAngle = -0.1
            leaves.emissionAngleRange = 0.4
            leaves.particleSpeed = 150
            leaves.particleSpeedRange = 60
            leaves.particleRotationRange = .pi * 2
            leaves.particleRotationSpeed = 3
            leaves.particleColor = UIColor(hex: 0x8FA857)
            leaves.particleColorBlendFactor = 1
            leaves.particleColorRedRange = 0.35
            leaves.particleColorGreenRange = 0.15
            leaves.particleAlpha = 0.85
            leaves.advanceSimulationTime(7)
            weatherNode.addChild(leaves)
            let gusts = SKEmitterNode()
            gusts.particleTexture = atmosphere.gust
            gusts.particleBirthRate = 2.5
            gusts.particleLifetime = 2.2
            gusts.particlePositionRange = CGVector(dx: 0, dy: height * 0.9)
            gusts.position = CGPoint(x: -width / 2 - 40, y: 0)
            gusts.emissionAngle = 0
            gusts.particleSpeed = 420
            gusts.particleAlpha = 0
            gusts.particleAlphaSequence = SKKeyframeSequence(keyframeValues: [0, 0.35, 0],
                                                             times: [0, 0.5, 1])
            gusts.particleColor = .white
            gusts.particleColorBlendFactor = 1
            weatherNode.addChild(gusts)

        case .sunny:
            let motes = SKEmitterNode()
            motes.particleTexture = atmosphere.dot
            motes.particleBirthRate = 3
            motes.particleLifetime = 9
            motes.particlePositionRange = CGVector(dx: width, dy: height)
            motes.emissionAngle = .pi / 2
            motes.emissionAngleRange = 0.8
            motes.particleSpeed = 8
            motes.particleScale = 0.35
            motes.particleScaleRange = 0.2
            motes.particleAlpha = 0
            motes.particleAlphaSequence = SKKeyframeSequence(keyframeValues: [0, 0.45, 0], times: [0, 0.5, 1])
            motes.particleColor = Palette.gold
            motes.particleColorBlendFactor = 1
            motes.advanceSimulationTime(9)
            weatherNode.addChild(motes)
            let warmth = SKSpriteNode(color: Palette.gold, size: CGSize(width: width, height: height))
            warmth.alpha = 0.05
            warmth.zPosition = -1
            weatherNode.addChild(warmth)

        case .fair:
            break
        }
    }

    /// A ring spreading on a wet street or canal, somewhere on screen.
    private func addPuddleRipple() {
        let scale = cameraNode.xScale
        let x = cameraNode.position.x + CGFloat.random(in: -0.5...0.5) * size.width * scale
        let y = cameraNode.position.y + CGFloat.random(in: -0.5...0.5) * size.height * scale
        let ripple = SKShapeNode(circleOfRadius: 3)
        ripple.strokeColor = UIColor(hex: 0x4F7399).withAlphaComponent(0.5)
        ripple.lineWidth = 1
        ripple.fillColor = .clear
        ripple.position = CGPoint(x: x, y: y)
        ripple.zPosition = 6
        cityLayer.addChild(ripple)
        ripple.run(.sequence([.group([.scale(to: 3, duration: 0.8), .fadeOut(withDuration: 0.8)]), .removeFromParent()]))
    }

    private func flashLightning() {
        let flash = SKSpriteNode(color: .white, size: size)
        flash.alpha = 0
        flash.zPosition = 5
        weatherNode.addChild(flash)
        flash.run(.sequence([
            .fadeAlpha(to: 0.5, duration: 0.05), .fadeAlpha(to: 0.1, duration: 0.08),
            .fadeAlpha(to: 0.4, duration: 0.05), .fadeOut(withDuration: 0.4), .removeFromParent(),
        ]))
    }

    // MARK: People

    /// Walkers set out from busy stations into their neighborhoods. Livelier, more revived
    /// districts have busier streets; nights are quieter.
    private func spawnAmbientWalkers(step: CGFloat) {
        guard let state, pedestrianLayer.children.count < 80 else { return }
        let intensity = state.currentDayPhase.intensity
        for landmark in state.openLandmarks {
            let health = state.stationHealth[landmark.id] ?? 0
            guard health > 0.15 else { continue }
            let revived = state.districtRevived[landmark.kind.info.district] ?? 0
            let chancePerSecond = 0.25 * health * (0.4 + revived) * intensity
            if Double.random(in: 0..<1) < chancePerSecond * Double(step) {
                spawnWalkers(from: landmark.id, count: 1)
            }
        }
    }

    /// People walking from a station along the streets to somewhere nearby.
    func spawnWalkers(from stationID: Int, count: Int) {
        guard let state, let landmark = state.landmark(id: stationID), pedestrianLayer.children.count < 80 else { return }
        let district = landmark.kind.info.district
        let cols = state.columns(of: district)
        let rowsHere = state.rowRange(of: district)
        let colors = district.homeColors.map { UIColor(hex: $0).mixed(with: Palette.ink, amount: 0.45) } + [Palette.ink]

        for _ in 0..<count {
            let start = landmark.cell
            var dc = Int.random(in: -3...3), dr = Int.random(in: -2...2)
            if dc == 0 && dr == 0 { dc = 1 }
            let end = GridPoint(col: min(max(start.col + dc, cols.lowerBound), cols.upperBound - 1),
                                row: min(max(start.row + dr, rowsHere.lowerBound), rowsHere.upperBound - 1))
            let corner = GridPoint(col: end.col, row: start.row)
            // Walk on the sidewalk, a little to one side of the street's center.
            let side = CGPoint(x: CGFloat([-6, 6].randomElement() ?? 6), y: CGFloat([-6, 6].randomElement() ?? 6))
            let points = [start, corner, end].map { cell -> CGPoint in
                let c = center(of: cell)
                return CGPoint(x: c.x + side.x, y: c.y + side.y)
            }

            let walker = SKSpriteNode(texture: atmosphere.dot)
            walker.size = CGSize(width: 4.5, height: 4.5)
            walker.color = colors.randomElement() ?? Palette.ink
            walker.colorBlendFactor = 1
            walker.alpha = 0
            walker.position = points[0]
            walker.zPosition = CGFloat.random(in: 0...1)
            pedestrianLayer.addChild(walker)

            let speed = CGFloat.random(in: 12...20)
            var actions: [SKAction] = [.wait(forDuration: Double.random(in: 0...0.6)), .fadeAlpha(to: 0.85, duration: 0.3)]
            for index in 1..<points.count {
                let distance = TransitGeometry.distance(points[index - 1], points[index])
                guard distance > 0.5 else { continue }
                actions.append(.move(to: points[index], duration: Double(distance / speed)))
            }
            actions += [.fadeOut(withDuration: 0.6), .removeFromParent()]
            walker.run(.sequence(actions))
        }
    }
}
