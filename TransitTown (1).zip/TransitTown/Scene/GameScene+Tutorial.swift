import SpriteKit
import UIKit

extension GameScene {

    /// Draws the guide for the current tutorial step: a hand tracing the first line,
    /// or a pulsing ring around the landmark that needs connecting.
    func updateTutorialGuide() {
        guard let state else { return }
        let step = state.tutorial
        let key = "\(step?.rawValue ?? -1)|\(state.tutorialLandmarkID ?? -1)|\(state.townVersion)|\(state.currentDistrict.rawValue)"
        guard key != tutorialKey else { return }
        tutorialKey = key
        tutorialLayer.removeAllChildren()

        switch step {
        case .drawLine:
            let hub = state.landmarks.first { $0.kind.info.category == .hub }
            let target = state.landmarks.first { $0.kind == .bakery }
            if let hub, let target {
                showTracingHand(from: center(of: hub.cell), to: center(of: target.cell), color: Palette.lines[0])
            }
        case .connectLandmark:
            // The hand drags from the first line's end to the new landmark.
            if let id = state.tutorialLandmarkID, let point = position(ofLandmark: id) {
                if let line = state.builtLines.first, let end = line.stops.last, let from = position(ofLandmark: end) {
                    showTracingHand(from: from, to: point, color: line.color)
                } else {
                    showPulse(at: point)
                }
            }
        case .moveLandmark:
            // Press and hold, then drag: the hand shows the gesture on the park.
            if let park = state.landmarks.first(where: { $0.kind == .park }), let point = position(ofLandmark: park.id) {
                showTracingHand(from: point, to: CGPoint(x: point.x + cellSize * 2, y: point.y), color: Palette.ink)
            }
        case .connectDistricts:
            if let previous = state.currentDistrict.previous,
               let from = state.hub(of: previous), let to = state.hub(of: state.currentDistrict) {
                showTracingHand(from: center(of: from.cell), to: center(of: to.cell), color: Palette.lightRail)
            }
        default:
            break
        }
    }

    private func showTracingHand(from start: CGPoint, to end: CGPoint, color: UIColor) {
        let points = TransitGeometry.octilinear(from: start, to: end)
        let base = TransitGeometry.roundedPath(through: points)
        let duration = max(1.8, Double(TransitGeometry.distance(start, end) / 260))

        let ghost = SKShapeNode(path: base.copy(dashingWithPhase: 0, lengths: [8, 7]))
        ghost.strokeColor = color.withAlphaComponent(0.55)
        ghost.lineWidth = lineWidth
        ghost.lineCap = .round
        ghost.zPosition = 0
        tutorialLayer.addChild(ghost)

        let hand = icons.sprite(symbol: "hand.point.up.left.fill", color: Palette.ink, pointSize: 26, variant: "guide")
        hand.anchorPoint = CGPoint(x: 0.28, y: 0.86) // fingertip on the path
        hand.position = start
        hand.zPosition = 1
        tutorialLayer.addChild(hand)

        let trace = SKAction.follow(base, asOffset: false, orientToPath: false, duration: duration)
        trace.timingMode = .easeInEaseOut
        hand.run(.repeatForever(.sequence([
            .group([.fadeIn(withDuration: 0.2), .scale(to: 1, duration: 0.2)]),
            .wait(forDuration: 0.25),
            trace,
            .wait(forDuration: 0.3),
            .group([.fadeOut(withDuration: 0.25), .scale(to: 0.9, duration: 0.25)]),
            .move(to: start, duration: 0),
            .wait(forDuration: 0.5),
        ])))
    }

    private func showPulse(at point: CGPoint) {
        let ring = SKShapeNode(circleOfRadius: cellSize * 0.5)
        ring.position = point
        ring.strokeColor = Palette.gold
        ring.lineWidth = 3
        ring.fillColor = .clear
        tutorialLayer.addChild(ring)
        ring.run(.repeatForever(.sequence([
            .group([.scale(to: 1.25, duration: 0.6), .fadeAlpha(to: 0.3, duration: 0.6)]),
            .group([.scale(to: 1.0, duration: 0.6), .fadeAlpha(to: 1, duration: 0.6)]),
        ])))
    }
}
