import SpriteKit
import UIKit

extension GameScene {

    /// Refreshes the waiting bubbles over stations and the wish lines for trips with no route.
    func updateRiders() {
        updateQueueBubbles()
        updateWishLines()
        updateCommunityBadges()
        updateLostItem()
        updateTunnelHelper()
    }

    // MARK: Community badges

    /// Little paper badges beside a station: a lost item to find, a full tip jar, a resident
    /// waiting in the spotlight.
    private func updateCommunityBadges() {
        guard let state else { return }
        let lost = state.lostItemsOnMap
        var live = Set<Int>()
        for landmark in state.landmarks where landmark.isOpen {
            var symbols: [(String, UIColor)] = []
            if let item = lost[landmark.id] { symbols.append((item.symbol, UIColor(hex: 0x8676C2))) }
            if (state.tipJars[landmark.id] ?? 0) >= GameState.tipJarReady { symbols.append(("dollarsign.circle.fill", UIColor(hex: 0xC8901A))) }
            if state.spotlight(at: landmark.id) != nil { symbols.append(("star.fill", UIColor(hex: 0xE0A21B))) }
            guard !symbols.isEmpty else { continue }
            live.insert(landmark.id)
            let signature = symbols.map(\.0).joined(separator: "|")
            if communitySignatures[landmark.id] != signature {
                communityBadges[landmark.id]?.removeFromParent()
                let node = SKNode()
                for (index, entry) in symbols.enumerated() {
                    let badge = SKNode()
                    let back = SKShapeNode(circleOfRadius: 11)
                    back.fillColor = Palette.card
                    back.strokeColor = entry.1.withAlphaComponent(0.8)
                    back.lineWidth = 2
                    badge.addChild(back)
                    let icon = icons.sprite(symbol: entry.0, color: entry.1, pointSize: 12, variant: "badge")
                    icon.zPosition = 1
                    badge.addChild(icon)
                    badge.position = CGPoint(x: -CGFloat(index) * 26, y: 0)
                    // A gentle bob, offset per badge, so they read as something to tap.
                    badge.run(.repeatForever(.sequence([.moveBy(x: 0, y: 3, duration: 0.6 + Double(index) * 0.1),
                                                        .moveBy(x: 0, y: -3, duration: 0.6 + Double(index) * 0.1)])))
                    node.addChild(badge)
                }
                node.zPosition = 6
                ridersLayer.addChild(node)
                communityBadges[landmark.id] = node
                communitySignatures[landmark.id] = signature
            }
            let point = center(of: landmark.cell)
            communityBadges[landmark.id]?.position = CGPoint(x: point.x - cellSize * 0.7, y: point.y + cellSize * 1.05)
        }
        for (id, node) in communityBadges where !live.contains(id) {
            node.removeFromParent()
            communityBadges[id] = nil
            communitySignatures[id] = nil
        }
    }

    // MARK: Waiting bubbles

    /// Each station shows who's waiting there as small destination icons with counts.
    /// The bubble warms from paper to amber to coral as the longest wait nears giving up.
    private func updateQueueBubbles() {
        guard let state else { return }
        var live = Set<Int>()

        for landmark in state.landmarks where landmark.isOpen {
            let queue = state.waiting[landmark.id] ?? []
            let urgency = state.urgency(at: landmark.id)
            live.insert(landmark.id)
            let groups = Dictionary(grouping: queue, by: \.destination)
                .map { (destination: $0.key, count: $0.value.count) }
                .sorted { $0.count != $1.count ? $0.count > $1.count : $0.destination < $1.destination }
            let urgencyStep = Int(urgency * 4)
            let transfers = queue.filter(\.isTransferring).count
            let signature = groups.map { "\($0.destination):\($0.count)" }.joined(separator: ",") + "|\(urgencyStep)|t\(transfers)"

            if queueSignatures[landmark.id] != signature {
                queueSignatures[landmark.id] = signature
                queueNodes[landmark.id]?.removeFromParent()
                queueNodes[landmark.id] = nil
                if !groups.isEmpty {
                    let bubble = makeQueueBubble(groups: groups, transfers: transfers, urgency: urgency)
                    ridersLayer.addChild(bubble)
                    queueNodes[landmark.id] = bubble
                }
            }
            if let bubble = queueNodes[landmark.id], let point = displayPosition(ofLandmark: landmark.id) {
                bubble.position = CGPoint(x: point.x, y: point.y + cellSize * 1.22 + 4)
            }
        }

        for (id, node) in queueNodes where !live.contains(id) {
            node.removeFromParent()
            queueNodes[id] = nil
            queueSignatures[id] = nil
        }
    }

    /// Riders changing trains get their own chip with a swap arrow.
    private func makeQueueBubble(groups: [(destination: Int, count: Int)], transfers: Int, urgency: Double) -> SKNode {
        let node = SKNode()
        let shown = Array(groups.prefix(3))
        let extra = groups.dropFirst(3).reduce(0) { $0 + $1.count }
        let chipWidth: CGFloat = 25
        let width = CGFloat(shown.count) * chipWidth + (extra > 0 ? 18 : 0) + (transfers > 0 ? chipWidth : 0) + 6
        let height: CGFloat = 18

        let fill: UIColor
        if urgency < 0.5 {
            fill = Palette.card
        } else if urgency < 0.8 {
            fill = Palette.card.mixed(with: Palette.warning, amount: CGFloat((urgency - 0.5) / 0.3))
        } else {
            fill = Palette.warning.mixed(with: Palette.urgent, amount: CGFloat((urgency - 0.8) / 0.2))
        }

        let path = CGMutablePath()
        path.addRoundedRect(in: CGRect(x: -width / 2, y: -height / 2 + 3, width: width, height: height),
                            cornerWidth: 7, cornerHeight: 7)
        path.move(to: CGPoint(x: -4, y: -height / 2 + 3))
        path.addLine(to: CGPoint(x: 0, y: -height / 2 - 2))
        path.addLine(to: CGPoint(x: 4, y: -height / 2 + 3))
        let bubble = SKShapeNode(path: path)
        bubble.fillColor = fill
        bubble.strokeColor = Palette.ink
        bubble.lineWidth = 1.5
        bubble.zPosition = 0
        node.addChild(bubble)

        var x = -width / 2 + 3 + chipWidth / 2
        for group in shown {
            if let kind = state?.landmark(id: group.destination)?.kind {
                let icon = icons.sprite(symbol: kind.info.symbol, color: Palette.ink, pointSize: 8, variant: "chip")
                icon.position = CGPoint(x: x - 5, y: 3)
                icon.zPosition = 1
                node.addChild(icon)
            }
            let count = makeCount("\(group.count)")
            count.position = CGPoint(x: x + 6, y: 3)
            node.addChild(count)
            x += chipWidth
        }
        if extra > 0 {
            let more = makeCount("+\(extra)")
            more.position = CGPoint(x: x + 1, y: 3)
            node.addChild(more)
        }
        if extra > 0 { x += 18 }
        if transfers > 0 {
            let swap = icons.sprite(symbol: "arrow.triangle.swap", color: Palette.ink, pointSize: 8, variant: "chip")
            swap.position = CGPoint(x: x - 5, y: 3)
            swap.zPosition = 1
            node.addChild(swap)
            let count = makeCount("\(transfers)")
            count.position = CGPoint(x: x + 6, y: 3)
            node.addChild(count)
        }

        if urgency >= 0.8 {
            node.run(.repeatForever(.sequence([.scale(to: 1.1, duration: 0.3), .scale(to: 1.0, duration: 0.3)])))
        }
        return node
    }

    private func makeCount(_ text: String) -> SKLabelNode {
        let label = SKLabelNode()
        label.attributedText = NSAttributedString(string: text, attributes: [
            .font: AppFont.uiFont(AppFont.boldName, size: 11),
            .foregroundColor: Palette.ink,
        ])
        label.verticalAlignmentMode = .center
        label.horizontalAlignmentMode = .center
        label.zPosition = 1
        return label
    }

    // MARK: Wish lines

    /// Dotted arcs between places people want to travel between but can't yet.
    /// The dots march toward the destination so the direction of demand reads at a glance.
    private func updateWishLines() {
        guard let state else { return }
        let wishes = state.unservedWishes()
        let signature = wishes.map { "\($0.origin)>\($0.destination):\($0.count)" }.joined(separator: ",")
            + (isMovingLandmark ? "|\(moveTarget?.cell.col ?? -1),\(moveTarget?.cell.row ?? -1)" : "")

        if signature != wishSignature {
            wishSignature = signature
            wishLayer.children.filter { $0 !== wishShape }.forEach { $0.removeFromParent() }
            let path = CGMutablePath()
            for wish in wishes {
                guard let a = position(ofLandmark: wish.origin), let b = position(ofLandmark: wish.destination) else { continue }
                let control = arcControlPoint(from: a, to: b)
                let start = a + a.vector(to: control).normalized * (cellSize * 0.42)
                let end = b + b.vector(to: control).normalized * (cellSize * 0.42)
                path.move(to: start)
                path.addQuadCurve(to: end, control: control)
                path.addEllipse(in: CGRect(x: end.x - 2.5, y: end.y - 2.5, width: 5, height: 5))

                if TransitGeometry.distance(a, b) > cellSize * 3 {
                    let mid = quadPoint(start, control, end, t: 0.5)
                    let pill = makeWishCount(wish.count)
                    pill.position = mid
                    wishLayer.addChild(pill)
                }
            }
            wishBasePath = wishes.isEmpty ? nil : path
        }

        wishPhase -= 1.5
        if let base = wishBasePath {
            wishShape.path = base.copy(dashingWithPhase: wishPhase, lengths: [2, 6])
        } else {
            wishShape.path = nil
        }
    }

    private func arcControlPoint(from a: CGPoint, to b: CGPoint) -> CGPoint {
        let mid = CGPoint(x: (a.x + b.x) / 2, y: (a.y + b.y) / 2)
        let direction = a.vector(to: b)
        let normal = CGVector(dx: -direction.dy, dy: direction.dx).normalized
        return mid + normal * (direction.length * 0.18)
    }

    private func quadPoint(_ a: CGPoint, _ c: CGPoint, _ b: CGPoint, t: CGFloat) -> CGPoint {
        let u = 1 - t
        return CGPoint(x: u * u * a.x + 2 * u * t * c.x + t * t * b.x,
                       y: u * u * a.y + 2 * u * t * c.y + t * t * b.y)
    }

    private func makeWishCount(_ count: Int) -> SKNode {
        let node = SKNode()
        node.zPosition = 1
        let label = SKLabelNode()
        label.attributedText = NSAttributedString(string: "\(count) WANT TO GO", attributes: [
            .font: AppFont.uiFont(AppFont.boldName, size: 9),
            .foregroundColor: Palette.inkSoft,
            .kern: 0.5,
        ])
        label.verticalAlignmentMode = .center
        label.horizontalAlignmentMode = .center
        label.zPosition = 1
        let width = label.frame.width + 10
        let pill = SKShapeNode(rect: CGRect(x: -width / 2, y: -7, width: width, height: 14), cornerRadius: 7)
        pill.fillColor = Palette.paper.withAlphaComponent(0.92)
        pill.strokeColor = Palette.ink.withAlphaComponent(0.25)
        pill.lineWidth = 1
        pill.zPosition = 0
        node.addChild(pill)
        node.addChild(label)
        return node
    }
}

