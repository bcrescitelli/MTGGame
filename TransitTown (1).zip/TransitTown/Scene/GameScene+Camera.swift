import SpriteKit
import UIKit

/// Pinch to zoom (around the fingers), two-finger pan, and one-finger pan on empty streets.
/// The view stays over the open districts; zooming out can show the whole city at once.
extension GameScene: UIGestureRecognizerDelegate {

    func installCameraGestures(in view: SKView) {
        let alreadyInstalled = view.gestureRecognizers?.contains { $0.name == "map.pinch" } ?? false
        guard !alreadyInstalled else { return }
        view.isMultipleTouchEnabled = true

        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(handlePinch(_:)))
        pinch.name = "map.pinch"
        pinch.delegate = self
        view.addGestureRecognizer(pinch)

        let pan = UIPanGestureRecognizer(target: self, action: #selector(handleTwoFingerPan(_:)))
        pan.name = "map.pan"
        pan.minimumNumberOfTouches = 2
        pan.maximumNumberOfTouches = 2
        pan.delegate = self
        view.addGestureRecognizer(pan)
    }

    @objc func handlePinch(_ gesture: UIPinchGestureRecognizer) {
        guard let view else { return }
        let viewPoint = gesture.location(in: view)
        switch gesture.state {
        case .began:
            cameraNode.removeAction(forKey: "focus")
            pinchStartScale = cameraNode.xScale
            pinchAnchor = convertPoint(fromView: viewPoint)
        case .changed:
            let scale = min(max(pinchStartScale / max(gesture.scale, 0.01), minCameraScale), maxCameraScale)
            cameraNode.setScale(scale)
            // Keep the spot between the fingers under the fingers.
            let after = convertPoint(fromView: viewPoint)
            cameraNode.position = CGPoint(x: cameraNode.position.x + pinchAnchor.x - after.x,
                                          y: cameraNode.position.y + pinchAnchor.y - after.y)
            clampCamera()
        default:
            break
        }
    }

    @objc func handleTwoFingerPan(_ gesture: UIPanGestureRecognizer) {
        guard let view, gesture.state == .began || gesture.state == .changed else { return }
        cameraNode.removeAction(forKey: "focus")
        let translation = gesture.translation(in: view)
        panCamera(byViewDelta: translation)
        gesture.setTranslation(.zero, in: view)
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        true
    }

    // MARK: Bounds

    /// The part of the city that's open, plus a margin.
    var openWorldRect: CGRect {
        guard let state, state.districtCols > 0 else { return CGRect(origin: .zero, size: size) }
        var rect = CGRect.null
        for district in state.openedDistricts {
            rect = rect.union(districtRect(district))
        }
        guard !rect.isNull else { return CGRect(origin: .zero, size: size) }
        // Generous margins, so nothing near an edge hides under the top bar or the menus.
        let extraX: CGFloat = 70, extraTop: CGFloat = 110, extraBottom: CGFloat = 70
        return CGRect(x: rect.minX - leadingInset - extraX, y: rect.minY - bottomInset - extraBottom,
                      width: rect.width + leadingInset + trailingInset + extraX * 2,
                      height: rect.height + bottomInset + topInset + extraTop + extraBottom)
    }

    /// A district's area on the map, in scene points.
    func districtRect(_ district: District) -> CGRect {
        guard let state else { return .zero }
        let cols = state.columns(of: district)
        let rowsHere = state.rowRange(of: district)
        return CGRect(x: origin.x + CGFloat(cols.lowerBound) * cellSize,
                      y: origin.y + CGFloat(rowsHere.lowerBound) * cellSize,
                      width: CGFloat(cols.count) * cellSize,
                      height: CGFloat(rowsHere.count) * cellSize)
    }

    /// Most zoomed out: enough to see every open district.
    var maxCameraScale: CGFloat {
        let world = openWorldRect
        guard size.width > 0, size.height > 0 else { return 1 }
        return min(4, max(1.35, world.width / size.width, world.height / size.height))
    }

    /// True when there's more city than fits on screen, so one-finger panning makes sense.
    var canPan: Bool {
        let world = openWorldRect
        let scale = cameraNode.xScale
        return size.width * scale < world.width - 1 || size.height * scale < world.height - 1
    }

    /// Moves the view by a finger movement measured in screen points.
    func panCamera(byViewDelta delta: CGPoint) {
        let scale = cameraNode.xScale
        cameraNode.position = CGPoint(x: cameraNode.position.x - delta.x * scale,
                                      y: cameraNode.position.y + delta.y * scale)
        clampCamera()
    }

    /// Keeps the view over the open city. If the view is bigger than the city, it centers it.
    func clampCamera() {
        let world = openWorldRect
        let scale = min(cameraNode.xScale, maxCameraScale)
        if scale != cameraNode.xScale { cameraNode.setScale(scale) }
        let halfWidth = size.width * scale / 2
        let halfHeight = size.height * scale / 2
        var position = cameraNode.position
        position.x = halfWidth * 2 >= world.width
            ? world.midX
            : min(max(position.x, world.minX + halfWidth), world.maxX - halfWidth)
        position.y = halfHeight * 2 >= world.height
            ? world.midY
            : min(max(position.y, world.minY + halfHeight), world.maxY - halfHeight)
        cameraNode.position = position
    }

    // MARK: Districts

    /// Where the camera sits to show a district at normal zoom.
    func districtCenter(_ district: District) -> CGPoint {
        let rect = districtRect(district)
        guard rect.width > 0 else { return CGPoint(x: size.width / 2, y: size.height / 2) }
        // Nudge for the HUD and menu so the district sits centered in the visible area.
        return CGPoint(x: rect.midX + (trailingInset - leadingInset) / 2,
                       y: rect.midY + (topInset - bottomInset) / 2)
    }

    /// Glides the camera to a district at normal zoom.
    func focus(on district: District, animated: Bool = true) {
        // Center on the district's station (where the action is), kept inside the open city.
        var target = districtCenter(district)
        if let hub = state?.hub(of: district) {
            target = center(of: hub.cell)
        }
        let original = cameraNode.position
        let originalScale = cameraNode.xScale
        cameraNode.setScale(1)
        cameraNode.position = target
        clampCamera()
        target = cameraNode.position
        cameraNode.position = original
        cameraNode.setScale(originalScale)

        cameraNode.removeAction(forKey: "focus")
        guard animated else {
            cameraNode.setScale(1)
            cameraNode.position = target
            return
        }
        let move = SKAction.move(to: target, duration: 0.9)
        move.timingMode = .easeInEaseOut
        let zoom = SKAction.scale(to: 1, duration: 0.9)
        zoom.timingMode = .easeInEaseOut
        cameraNode.run(.group([move, zoom]), withKey: "focus")
    }

    /// Handles focus requests from the game and reports which district is on screen,
    /// so the menu shows that district's pens.
    func updateCameraFocus() {
        guard let state else { return }
        if let request = state.cameraFocusRequest {
            state.cameraFocusRequest = nil
            focus(on: request)
        }
        if let landmarkID = state.cameraFocusLandmarkID {
            state.cameraFocusLandmarkID = nil
            if let point = position(ofLandmark: landmarkID) {
                cameraNode.removeAction(forKey: "focus")
                // Work out where the camera may go, then glide there.
                let original = cameraNode.position
                cameraNode.position = CGPoint(x: point.x, y: point.y)
                clampCamera()
                let target = cameraNode.position
                cameraNode.position = original
                // Zoom in a little too, so the spot is easy to find.
                let move = SKAction.move(to: target, duration: 0.7)
                move.timingMode = .easeInEaseOut
                let zoom = SKAction.scale(to: min(cameraNode.xScale, 0.85), duration: 0.7)
                zoom.timingMode = .easeInEaseOut
                cameraNode.run(.group([move, zoom]), withKey: "focus")
            }
        }
        let here = cameraNode.position
        let nearest = state.openedDistricts.min {
            TransitGeometry.distance(districtCenter($0), here) < TransitGeometry.distance(districtCenter($1), here)
        }
        if let nearest, nearest != state.focusedDistrict {
            state.focusedDistrict = nearest
            if state.selectedLineID != nil, state.line(id: state.selectedLineID ?? -1)?.isLightRail != true {
                state.setSelectedLine(nil)
            }
            state.armedColorIndex = nil
        }
    }
}
