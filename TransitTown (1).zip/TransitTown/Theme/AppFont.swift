import CoreText
import SwiftUI
import UIKit

/// Bundled typefaces (all SIL Open Font License), registered at launch so no Info.plist entry is needed.
///
/// - Jost: a geometric sans in the Futura tradition, the type of mid-century travel posters and
///   transit signage. Used for the map, signs, and interface.
/// - Libre Caslon: the classic book-and-newspaper serif. Used for the Gazette, letters, and ceremonies.
/// - UnifrakturMaguntia: a blackletter for the Gazette's nameplate, like a real town paper.
enum AppFont {
    // PostScript names
    static let uiMedium = "Jost-Medium"
    static let uiSemibold = "Jost-SemiBold"
    static let uiBold = "Jost-Bold"
    static let headline = "LibreCaslonDisplay-Regular"
    static let body = "LibreCaslonText-Regular"
    static let bodyBold = "LibreCaslonText-Bold"
    static let bodyItalic = "LibreCaslonText-Italic"
    static let nameplate = "UnifrakturMaguntia"
    static let typewriter = "CourierPrime-Regular"

    /// Names used by existing call sites.
    static let boldName = uiBold
    static let semiboldName = uiSemibold

    /// Jost sets wider than a condensed face. Interface sizes throughout the app are written in
    /// "layout points"; this converts them so text stays close to its original footprint.
    static let uiScale: CGFloat = 0.88

    private static let files = [
        "Jost-Medium", "Jost-SemiBold", "Jost-Bold",
        "LibreCaslonDisplay-Regular", "LibreCaslonText-Regular", "LibreCaslonText-Bold", "LibreCaslonText-Italic",
        "UnifrakturMaguntia-Book",
        "CourierPrime-Regular",
    ]

    static func registerBundledFonts() {
        for file in files {
            guard let url = Bundle.main.url(forResource: file, withExtension: "ttf") else {
                print("Font file missing from the app target: \(file).ttf")
                continue
            }
            _ = CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
        }
    }

    /// An interface font for SpriteKit labels, sized in layout points.
    static func uiFont(_ name: String, size: CGFloat) -> UIFont {
        UIFont(name: name, size: size * uiScale) ?? UIFont.systemFont(ofSize: size * uiScale, weight: .semibold)
    }
}

extension Font {
    /// Interface text (Jost Bold), sized in layout points.
    static func mapBold(_ size: CGFloat) -> Font { .custom(AppFont.uiBold, fixedSize: size * AppFont.uiScale) }
    /// Interface text (Jost SemiBold), sized in layout points.
    static func mapSemibold(_ size: CGFloat) -> Font { .custom(AppFont.uiSemibold, fixedSize: size * AppFont.uiScale) }
    /// Headlines and titles (Libre Caslon Display).
    static func display(_ size: CGFloat) -> Font { .custom(AppFont.headline, fixedSize: size) }
    /// Italic serif for signatures and asides (Libre Caslon Text Italic).
    static func displayItalic(_ size: CGFloat) -> Font { .custom(AppFont.bodyItalic, fixedSize: size) }
    /// Typed letters (Courier Prime): Edna's letters and residents' mail.
    static func typewriter(_ size: CGFloat) -> Font { .custom(AppFont.typewriter, fixedSize: size) }
    /// Section headings in serif capitals, gently spaced.
    static func smallCaps(_ size: CGFloat) -> Font { .custom(AppFont.body, fixedSize: size) }
    /// The Gazette's blackletter nameplate.
    static func nameplate(_ size: CGFloat) -> Font { .custom(AppFont.nameplate, fixedSize: size) }
    /// Newspaper and letter body copy (Libre Caslon Text).
    static func bodySerif(_ size: CGFloat, italic: Bool = false) -> Font {
        .custom(italic ? AppFont.bodyItalic : AppFont.body, fixedSize: size)
    }
}
