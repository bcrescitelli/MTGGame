import SwiftUI
import UIKit

/// Printed-transit-map palette. Computed properties so they're safe to read from any context.
enum Palette {
    // Paper and ink
    static var paper: UIColor { UIColor(hex: 0xF2EBDD) }
    static var card: UIColor { UIColor(hex: 0xFFFBF2) }
    static var newsprint: UIColor { UIColor(hex: 0xF4EEDF) }
    static var ink: UIColor { UIColor(hex: 0x24222B) }
    static var inkSoft: UIColor { UIColor(hex: 0x6E6875) }

    // Blueprint book
    static var blueprint: UIColor { UIColor(hex: 0x1F4A72) }
    static var blueprintDeep: UIColor { UIColor(hex: 0x173A5B) }
    static var blueprintLine: UIColor { UIColor(hex: 0xA9C8E6) }

    // Feedback and light
    static var good: UIColor { UIColor(hex: 0x3E9B5F) }
    static var bad: UIColor { UIColor(hex: 0xD9534F) }
    static var lamp: UIColor { UIColor(hex: 0xFFC965) }
    static var gold: UIColor { UIColor(hex: 0xE9B44C) }
    static var stampRed: UIColor { UIColor(hex: 0xC8402F) }
    static var urgent: UIColor { UIColor(hex: 0xEE7B5F) }
    static var warning: UIColor { UIColor(hex: 0xF4C46A) }

    /// One color per transit line, in unlock order.
    static var lines: [UIColor] {
        [UIColor(hex: 0xE2483A), UIColor(hex: 0x2D63C8), UIColor(hex: 0x23946A), UIColor(hex: 0xE8A317),
         UIColor(hex: 0xE07AA3), UIColor(hex: 0x8C62C2), UIColor(hex: 0x9A6A44), UIColor(hex: 0x2F9C9A)]
    }
    static let lineNames = ["Red Line", "Blue Line", "Green Line", "Gold Line",
                            "Pink Line", "Purple Line", "Brown Line", "Teal Line"]
    /// The light rail between districts.
    static var lightRail: UIColor { UIColor(hex: 0x2F7F86) }
    static let lineCount = 8
}

extension UIColor {
    convenience init(hex: UInt32, alpha: CGFloat = 1) {
        self.init(red: CGFloat((hex >> 16) & 0xFF) / 255,
                  green: CGFloat((hex >> 8) & 0xFF) / 255,
                  blue: CGFloat(hex & 0xFF) / 255,
                  alpha: alpha)
    }

    /// Blends this color toward another. `amount` 0 keeps this color, 1 returns the other.
    func mixed(with other: UIColor, amount: CGFloat) -> UIColor {
        var r1: CGFloat = 0, g1: CGFloat = 0, b1: CGFloat = 0, a1: CGFloat = 0
        var r2: CGFloat = 0, g2: CGFloat = 0, b2: CGFloat = 0, a2: CGFloat = 0
        getRed(&r1, green: &g1, blue: &b1, alpha: &a1)
        other.getRed(&r2, green: &g2, blue: &b2, alpha: &a2)
        let t = min(max(amount, 0), 1)
        return UIColor(red: r1 + (r2 - r1) * t,
                       green: g1 + (g2 - g1) * t,
                       blue: b1 + (b2 - b1) * t,
                       alpha: a1 + (a2 - a1) * t)
    }
}

extension Color {
    static var ink: Color { Color(uiColor: Palette.ink) }
    static var inkSoft: Color { Color(uiColor: Palette.inkSoft) }
    static var paper: Color { Color(uiColor: Palette.paper) }
    static var card: Color { Color(uiColor: Palette.card) }
    static var newsprint: Color { Color(uiColor: Palette.newsprint) }
    static var bad: Color { Color(uiColor: Palette.bad) }
    static var good: Color { Color(uiColor: Palette.good) }
    static var gold: Color { Color(uiColor: Palette.gold) }
    static var stampRed: Color { Color(uiColor: Palette.stampRed) }
    static var blueprint: Color { Color(uiColor: Palette.blueprint) }
    static var blueprintDeep: Color { Color(uiColor: Palette.blueprintDeep) }
    static var blueprintLine: Color { Color(uiColor: Palette.blueprintLine) }
}
