# TransitTown — The Mayor's Term

You're the newly appointed mayor of a run-down town. Bring the trains back, and the town
comes back with them.

## The game loop

- **Each day (about 2½ minutes):** riders appear at stations wanting to reach specific
  landmarks. Draw and extend lines, add trains, and keep waits short. Unserved trips show
  as dotted wish lines. Riders who wait too long give up and walk.
- **Revival:** served stations bring color, rooftops, trees, and lit windows back to the
  streets around them. Neglected streets slowly fade to grey.
- **The Gazette:** at the end of each day, the town paper reports what happened.
- **Council session:** approve one of three proposals (permanent upgrades, one-day events,
  or instant help).
- **City Blueprints:** every landmark the town could have. Unlock them by playing well,
  then build them with fares. Restore boarded-up heritage sites for big revivals.
- **End of term (7 days):** three goals, one ribbon each. Then keep building, or take on a
  new town.

## Project structure

```
App/            Entry point; registers fonts
Audio/          AudioManager: looping theme and city ambience
Theme/          Palette, AppFont
Resources/      Fonts (Jost, Libre Caslon, UnifrakturMaguntia) and licenses
Model/
  GameState.swift              Storage, queries, messages, tips
  GameState+Town.swift         Town layout, building, moving, restoring, the album
  GameState+Lines.swift        Lines, pens, trains, line unlocks
  GameState+Riders.swift       Passengers, fastest-route planning, transfers, pairs
  GameState+Revival.swift      Neighborhood revival
  GameState+Progress.swift     Rating, unlocks, tutorial, day loop, council, terms
  District.swift               Old Town, Harborside, Hill Quarter, Lantern Row
  LandmarkKind.swift           The landmark list for every district
  Tutorial.swift               The guided first morning, light rail step, and tips
  Weather.swift                Tomorrow's weather and what it does
  Maintenance.swift            Track wear, town events, light rail upgrades, specialties
  SaveGame.swift               The saved city
  PairStatus.swift             Pair bonus tracking
  CouncilCard, TermGoal, Gazette, Rider, UnlockCondition, TownTime, ...
Geometry/       Grid routing, parallel lanes, line paths
Scene/
  GameScene.swift              Setup, coordinates, frame loop
  GameScene+Camera.swift       Pinch to zoom, panning
  GameScene+Input.swift        Gestures and pens
  GameScene+Tutorial.swift     The animated guide hand
  ...City, Landmarks, Lines, Trains, Riders, Effects
Views/
  RootView.swift               Title screen: Continue or New City
  SettingsView.swift           Sound, music, how to play, new city
  AttentionPanelView.swift     The bell: worn track, crowds, events, repairs
  ContentView.swift            Full-screen map, HUD, dock, overlays
  HUDView.swift                Town and day, theme, treasury, rating, speed
  DockView.swift               Collapsible corner menu: pens, light rail, blueprints, help, sound
  TownPanelView.swift          Districts, term goals, and pair bonuses (tap the town name)
  TutorialOverlayView.swift    Tutorial steps and tips
  BlueprintsView.swift         The city blueprints, by district
  GazetteView, CouncilView, TermReviewView, AppointmentLetterView, ...
```

## Updating the Xcode project

1. Delete all the old code folders from the project (Move to Trash).
2. Drag in the seven folders: App, Theme, Resources, Model, Geometry, Scene, Views.
   Check "Copy items if needed" and make sure your app target is ticked.
3. Product → Clean Build Folder (Shift+Cmd+K), then Run.

Fonts are registered in code at launch; no Info.plist changes needed.

## Tuning

Most balance numbers live in one place each:
- Day length, term length, line and train limits: `GameState.swift` (Rules)
- Spawn rate, patience, fares: `GameState+Riders.swift`
- Revival speed and reach: `GameState+Revival.swift`
- Rating formula, line unlock thresholds: `GameState+Progress.swift`, `GameState+Lines.swift`
- Landmark costs, unlocks, and demand: `LandmarkKind.swift`
