import AVFoundation
import Combine
import Foundation

/// Background sound for the town.
///
/// - The theme (`mind-the-gap-theme.mp3`) loops quietly the whole time.
/// - The city ambience (`city-ambiance.mp3`) comes and goes in slow waves: it fades in,
///   lingers, fades out, and rests in silence before the next wave. The busier the town
///   (riders arriving, riders waiting), the louder the waves and the shorter the silences.
///   It rests while the game is paused or between days.
@MainActor
final class AudioManager: ObservableObject {
    static let shared = AudioManager()

    @Published var isMuted: Bool {
        didSet {
            UserDefaults.standard.set(isMuted, forKey: "audio.muted")
            applyMute()
        }
    }

    /// Theme music level, 0...1, from Settings.
    @Published var musicVolume: Double {
        didSet {
            UserDefaults.standard.set(musicVolume, forKey: "audio.music")
            applyMute()
        }
    }

    /// City ambience level, 0...1, from Settings.
    @Published var cityVolume: Double {
        didSet { UserDefaults.standard.set(cityVolume, forKey: "audio.city") }
    }

    /// Sound effects level (placing landmarks, drawing track), 0...1, from Settings.
    @Published var effectsVolume: Double {
        didSet { UserDefaults.standard.set(effectsVolume, forKey: "audio.effects") }
    }

    private enum AmbienceState {
        case resting(remaining: Double)
        case rising(remaining: Double)
        case holding(remaining: Double)
        case falling(remaining: Double)
    }

    private let themeVolume: Float = 0.22
    private var theme: AVAudioPlayer?
    private var musicWatch: Timer?
    private var ambience: AVAudioPlayer?
    private var ambienceState: AmbienceState = .resting(remaining: 3)
    private var ambiencePeak: Float = 0
    private var retuneTimer: Double = 0
    private var started = false

    // Effects
    private var placeSounds: [AVAudioPlayer] = []
    private var drawLoop: AVAudioPlayer?
    private var drawLoopTarget: Float = 0
    private var isDrawing = false
    private var pendingStop: Double = 0

    private init() {
        let defaults = UserDefaults.standard
        isMuted = defaults.bool(forKey: "audio.muted")
        musicVolume = defaults.object(forKey: "audio.music") as? Double ?? 0.8
        cityVolume = defaults.object(forKey: "audio.city") as? Double ?? 0.8
        effectsVolume = defaults.object(forKey: "audio.effects") as? Double ?? 0.8
    }

    private var themeLevel: Float { isMuted ? 0 : themeVolume * Float(musicVolume) / 0.8 }

    /// Call once at launch.
    func start() {
        guard !started else { return }
        started = true

        // Ambient: mixes politely with other audio and respects the silent switch.
        let session = AVAudioSession.sharedInstance()
        // Playback (mixed with other apps) keeps the music going with the ring/silent switch on,
        // like other games and music apps. Ambient would be muted by the switch.
        try? session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)

        theme = makePlayer(named: ["mind-the-gap-theme", "mind_the_gap_theme", "mind-the-gap"])
        theme?.numberOfLoops = -1
        theme?.volume = 0
        theme?.play()
        theme?.setVolume(themeLevel, fadeDuration: 3)
        // If iOS interrupts our audio (a ring, a notification sound), bring the theme back.
        NotificationCenter.default.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] _ in
            self?.keepMusicPlaying()
        }
        musicWatch = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
            self?.keepMusicPlaying()
        }

        // Both spellings are accepted, since "ambiance" and "ambience" are easy to mix up.
        ambience = makePlayer(named: ["city-ambiance", "city-ambience", "city_ambiance", "city_ambience"])
        ambience?.numberOfLoops = -1
        ambience?.volume = 0
    }

    /// Called every frame by the scene.
    /// - Parameters:
    ///   - activity: how lively the town is right now, 0...1.
    ///   - isLive: false while paused, reading the Gazette, at the council, and so on.
    // MARK: Little sounds

    enum Effect: String {
        case tick, pop, place, ping, sparkle, whoosh, stamp, rustle, chunk
    }

    private var effectPlayers: [Effect: [AVAudioPlayer]] = [:]

    /// A short one-shot sound. Each effect keeps a few players so quick repeats overlap.
    func play(_ effect: Effect, volume: Double = 1) {
        guard !isMuted, effectsVolume > 0.01 else { return }
        let now = Date()
        if let last = lastPlayed[effect], now.timeIntervalSince(last) < 0.25 { return }
        lastPlayed[effect] = now
        if effectPlayers[effect] == nil {
            effectPlayers[effect] = (0..<3).compactMap { _ in makePlayer(named: ["sfx-\(effect.rawValue)"]) }
        }
        guard let players = effectPlayers[effect], !players.isEmpty else { return }
        let player = players.first(where: { !$0.isPlaying }) ?? players[0]
        player.currentTime = 0
        player.volume = Float(min(1, 0.45 * effectsVolume * volume))
        player.play()
    }

    // MARK: Hotline

    private var ringPlayer: AVAudioPlayer?
    private var wahPlayers: [AVAudioPlayer] = []
    private var lastPlayed: [Effect: Date] = [:]

    /// The phone rings until it's picked up or gives up.
    func startRinging() {
        guard !isMuted, effectsVolume > 0.01 else { return }
        if ringPlayer == nil { ringPlayer = makePlayer(named: ["phone-ring"]) }
        ringPlayer?.numberOfLoops = -1
        ringPlayer?.volume = Float(0.7 * effectsVolume)
        if ringPlayer?.isPlaying != true {
            ringPlayer?.currentTime = 0
            ringPlayer?.play()
        }
    }

    func stopRinging() {
        ringPlayer?.stop()
        keepMusicPlaying()
    }

    /// The theme should always be looping; if anything has stopped it, start it again softly.
    func keepMusicPlaying() {
        guard let theme, !theme.isPlaying else { return }
        try? AVAudioSession.sharedInstance().setActive(true)
        theme.volume = 0
        theme.play()
        theme.setVolume(themeLevel, fadeDuration: 1.5)
    }

    /// One muffled "wah" syllable of a caller's voice. `pitch` around 1 (higher is squeakier).
    func babble(pitch: Double) {
        guard !isMuted, effectsVolume > 0.01 else { return }
        if wahPlayers.isEmpty {
            wahPlayers = (0..<4).compactMap { _ in
                let player = makePlayer(named: ["hotline-wah"])
                player?.enableRate = true
                player?.prepareToPlay()   // rate changes only take effect if enabled before preparing
                return player
            }
        }
        guard let player = wahPlayers.first(where: { !$0.isPlaying }) ?? wahPlayers.first else { return }
        player.currentTime = 0
        let voices = [0.7, 0.92, 1.18, 1.45]
        let voice = voices.min(by: { abs($0 - pitch) < abs($1 - pitch) }) ?? 1
        player.rate = Float(voice * Double.random(in: 0.96...1.04))
        player.volume = Float(0.55 * effectsVolume)
        player.play()
    }

    // MARK: Effects

    /// A landmark set down on the map.
    func playPlaceLandmark() {
        guard !isMuted, effectsVolume > 0.01 else { return }
        if placeSounds.isEmpty {
            // A few copies so quick placements can overlap.
            placeSounds = (0..<3).compactMap { _ in makePlayer(named: ["place-landmark", "place_landmark"]) }
        }
        guard let player = placeSounds.first(where: { !$0.isPlaying }) ?? placeSounds.first else { return }
        player.currentTime = 0
        player.volume = Float(0.9 * effectsVolume)
        player.play()
    }

    /// Track being drawn or stretched. The sound loops while the finger is down, and its pitch
    /// rises a little with drag speed, so faster strokes sound like a tighter stretch.
    /// `speed` is in screen points per second.
    func setDrawing(_ drawing: Bool, speed: Double = 0) {
        guard !isMuted, effectsVolume > 0.01 else {
            drawLoop?.stop()
            isDrawing = false
            return
        }
        if drawing && drawLoop == nil {
            drawLoop = makePlayer(named: ["rotate-track", "rotate_track"])
            drawLoop?.numberOfLoops = -1
            drawLoop?.enableRate = true
            drawLoop?.prepareToPlay()
        }
        guard let loop = drawLoop else { return }
        if drawing {
            if !isDrawing {
                isDrawing = true
                loop.currentTime = 0
                loop.volume = 0
                loop.play()
            }
            let rate = 0.9 + min(speed / 900, 0.45)
            loop.rate = Float(rate)
            loop.setVolume(Float(0.75 * effectsVolume), fadeDuration: 0.08)
        } else if isDrawing {
            isDrawing = false
            loop.setVolume(0, fadeDuration: 0.15)
            drawLoopStopTime = 0.18
        }
    }

    private var drawLoopStopTime: Double {
        get { pendingStop }
        set { pendingStop = newValue }
    }

    func update(dt: Double, activity: Double, isLive: Bool) {
        if pendingStop > 0 {
            pendingStop -= dt
            if pendingStop <= 0, !isDrawing { drawLoop?.stop() }
        }
        guard let ambience, dt > 0 else { return }
        let level = min(max(activity, 0), 1)
        let allowed = isLive && !isMuted && cityVolume > 0.01

        switch ambienceState {
        case .resting(let remaining):
            // Busier towns rest for less time between waves.
            let left = remaining - dt * (0.6 + 1.8 * level)
            if left <= 0 && allowed {
                beginWave(ambience, level: level)
            } else {
                ambienceState = .resting(remaining: max(0, left))
            }

        case .rising(let remaining):
            if !allowed {
                fadeOut(ambience, over: 2)
            } else if remaining - dt <= 0 {
                ambienceState = .holding(remaining: Double.random(in: 10...22) * (0.7 + 0.8 * level))
            } else {
                ambienceState = .rising(remaining: remaining - dt)
            }

        case .holding(let remaining):
            if !allowed {
                fadeOut(ambience, over: 2.5)
                break
            }
            // Follow the town's mood while the wave lingers.
            retuneTimer += dt
            if retuneTimer > 3 {
                retuneTimer = 0
                ambiencePeak = peakVolume(for: level)
                ambience.setVolume(ambiencePeak, fadeDuration: 2.5)
            }
            if remaining - dt <= 0 {
                fadeOut(ambience, over: Double.random(in: 5...8))
            } else {
                ambienceState = .holding(remaining: remaining - dt)
            }

        case .falling(let remaining):
            if remaining - dt <= 0 {
                ambience.pause()
                // Quiet towns get long silences; busy ones come back sooner.
                let rest = Double.random(in: 10...24) * (1.1 - 0.7 * level)
                ambienceState = .resting(remaining: rest)
            } else {
                ambienceState = .falling(remaining: remaining - dt)
            }
        }
    }

    // MARK: Private

    private func beginWave(_ player: AVAudioPlayer, level: Double) {
        if !player.isPlaying {
            // Start somewhere new in the recording so waves don't repeat.
            if player.duration > 10 {
                player.currentTime = Double.random(in: 0..<(player.duration - 5))
            }
            player.volume = 0
            player.play()
        }
        ambiencePeak = peakVolume(for: level)
        let rise = Double.random(in: 4...7)
        player.setVolume(ambiencePeak, fadeDuration: rise)
        retuneTimer = 0
        ambienceState = .rising(remaining: rise)
    }

    private func fadeOut(_ player: AVAudioPlayer, over seconds: Double) {
        player.setVolume(0, fadeDuration: seconds)
        ambienceState = .falling(remaining: seconds)
    }

    /// Clearly audible even in a quiet town, and noticeably fuller when it's busy.
    private func peakVolume(for level: Double) -> Float {
        Float((0.38 + 0.42 * level) * cityVolume / 0.8)
    }

    private func applyMute() {
        theme?.setVolume(themeLevel, fadeDuration: 0.6)
        if isMuted, let ambience, ambience.isPlaying {
            fadeOut(ambience, over: 0.6)
        }
    }

    /// Finds the first matching file in the app bundle (mp3, m4a, wav, or aac).
    /// Logs what's in the bundle if nothing matches, so a missing file is easy to spot.
    private func makePlayer(named names: [String]) -> AVAudioPlayer? {
        for name in names {
            for ext in ["m4a", "mp3", "wav", "caf", "aac"] {
                guard let url = Bundle.main.url(forResource: name, withExtension: ext) else { continue }
                do {
                    let player = try AVAudioPlayer(contentsOf: url)
                    player.prepareToPlay()
                    print("Audio loaded: \(name).\(ext)")
                    return player
                } catch {
                    print("Audio file found but couldn't be opened: \(name).\(ext) — \(error.localizedDescription)")
                }
            }
        }
        let bundled = ["mp3", "m4a", "wav", "aac"]
            .flatMap { Bundle.main.paths(forResourcesOfType: $0, inDirectory: nil) }
            .map { ($0 as NSString).lastPathComponent }
        print("Audio file missing from the app target: \(names.first ?? "?"). Audio in the bundle: \(bundled)")
        return nil
    }
}
